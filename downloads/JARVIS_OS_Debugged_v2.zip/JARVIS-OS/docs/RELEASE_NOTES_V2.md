# JARVIS OS 0.2 — Expansion release notes

## What is included

This release extends the original JARVIS OS Python MVP with local-only data
features, safe automation, learning tools, and programmatic developer clients.
It is a **local-first personal assistant prototype**, not an autonomous AGI or
an Android application with phone-system permissions.

- A responsive browser dashboard with sections for chat, PC status, memory,
  notes, tasks, projects, goals, habits, local calendar, workflows, metrics,
  startup ideas, study decks, and searchable offline skills.
- A Python backend and SQLite storage for tasks, projects, focus work, habits,
  study cards, ideas and experiments, and audit logs.
- 283 deterministic offline utility skills in 11 categories, including
  calculations, units, probability, statistics, graph analysis, dates,
  time series, safe static-code inspection, and optional symbolic math.
- Search over notes and allowed files inside the dedicated JARVIS workspace.
- Optional local image and WAV transcription endpoints (extra dependencies and
  models needed); optional cloud AI provider.
- Opt-in private-LAN access for phones through a browser.
- Explicit human approvals for computer actions; bounded, read-only scheduled
  workflows; no unrestricted shell execution tools.
- Generated typed Python and TypeScript SDKs for utility skills and published
  REST API operations, plus a generated utility reference book.

## Counting code accurately

`jarvis lines` reports counts by file type. The output includes TypeScript,
Python, JavaScript, HTML, CSS, tests, generated client interfaces and Markdown
reference documentation. **Source lines are not model-training parameters, AI
capability scores or a quality guarantee.** A large fraction of the SDK source
is generated from real API contracts, and the generated documentation is counted
separately as `.md`.

## Basic verification

```bash
python -m pip install -e '.[dev,ml]'
python -m pytest -q
python -m compileall -q jarvis clients/python
# Optional if Node.js/TypeScript are installed:
tsc --project clients/typescript/tsconfig.json --noEmit
```

The pytest suite exercises API authentication, approvals, database persistence,
project/workflow endpoints, study decks, startup research, utilities, generated
Python SDK calls and safety constraints.

**Validation boundaries**: automated tests and TypeScript checks passed in the
build environment, but an actual Ollama model was not launched for an end-to-end
natural-language conversation. Hardware-specific app launching and browser voice
recognition have not been validated on every PC or phone.

## Safety and privacy

Keep JARVIS running as a non-administrator user, never share its access token,
and do not forward the JARVIS port to the Internet. Plain HTTP on trusted Wi-Fi
is vulnerable to interception, so use HTTPS and account-level authentication
before any Internet-facing deployment. Do not allow unattended computer actions
that require approval. Local data stays in the data directory unless you choose
a cloud LLM or your browser delegates speech recognition to an external service.

## Developer links

- [`../README.md`](../README.md): getting started
- [`ARCHITECTURE.md`](ARCHITECTURE.md): architecture and threat model
- [`../clients/README.md`](../clients/README.md): Python and TypeScript clients
- [`generated/SKILLS.md`](generated/SKILLS.md): complete local skill reference
