# Local JARVIS Skills — Generated Reference

This is automatically generated from the executable registry.
To regenerate: `python tools/generate_clients.py`.

These tools are deterministic, bounded, offline calculations. They do
not execute arbitrary Python, shell commands or HTTP requests.

Total skill methods: **283**.


## Dates

### `add_business_days`

Advance a specified number of weekdays

- API: `POST /api/utilities/run`
- Category: `dates`
- Python client: `jarvis.utilities.add_business_days(...)`
- TypeScript client: `jarvis.utilities.add_business_days(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `start` | string | Yes | YYYY-MM-DD |
| `days` | integer | Yes | Signed weekdays |

**Request envelope:**

```json
{
  "name": "add_business_days",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `add_days`

Add or subtract calendar days

- API: `POST /api/utilities/run`
- Category: `dates`
- Python client: `jarvis.utilities.add_days(...)`
- TypeScript client: `jarvis.utilities.add_days(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `date` | string | Yes | YYYY-MM-DD |
| `days` | integer | Yes | Signed number of days |

**Request envelope:**

```json
{
  "name": "add_days",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `add_months`

Add calendar months, clamping day to month length

- API: `POST /api/utilities/run`
- Category: `dates`
- Python client: `jarvis.utilities.add_months(...)`
- TypeScript client: `jarvis.utilities.add_months(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `date` | string | Yes | YYYY-MM-DD |
| `months` | integer | Yes | Signed number of months |

**Request envelope:**

```json
{
  "name": "add_months",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Strings

### `anagram_check`

Check whether two phrases use the same alphanumeric characters

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.anagram_check(...)`
- TypeScript client: `jarvis.utilities.anagram_check(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `first` | string | Yes | Phrase 1 |
| `second` | string | Yes | Phrase 2 |

**Request envelope:**

```json
{
  "name": "anagram_check",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `arithmetic_sequence`

Produce a finite arithmetic progression

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.arithmetic_sequence(...)`
- TypeScript client: `jarvis.utilities.arithmetic_sequence(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `start` | number | Yes | First term |
| `difference` | number | Yes | Common difference |
| `count` | integer | Yes | Terms |

**Request envelope:**

```json
{
  "name": "arithmetic_sequence",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Measure

### `aspect_ratio`

Simplify pixel aspect ratio

- API: `POST /api/utilities/run`
- Category: `measure`
- Python client: `jarvis.utilities.aspect_ratio(...)`
- TypeScript client: `jarvis.utilities.aspect_ratio(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `width` | integer | Yes | Width |
| `height` | integer | Yes | Height |

**Request envelope:**

```json
{
  "name": "aspect_ratio",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `base_to_number`

Parse a base-2 to base-36 integer

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.base_to_number(...)`
- TypeScript client: `jarvis.utilities.base_to_number(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Digit string |
| `base` | integer | Yes | Base |

**Request envelope:**

```json
{
  "name": "base_to_number",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Probability

### `bayes_rule`

Update a prior probability using sensitivity and false-positive rate

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.bayes_rule(...)`
- TypeScript client: `jarvis.utilities.bayes_rule(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `prior` | number | Yes | Prior P(H) |
| `sensitivity` | number | Yes | P(E given H) |
| `false_positive` | number | Yes | P(E given not H) |

**Request envelope:**

```json
{
  "name": "bayes_rule",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `binomial_at_least`

Binomial probability of at least k successes

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.binomial_at_least(...)`
- TypeScript client: `jarvis.utilities.binomial_at_least(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `trials` | integer | Yes | Trials |
| `successes` | integer | Yes | Minimum successes |
| `p` | number | Yes | Success probability |

**Request envelope:**

```json
{
  "name": "binomial_at_least",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `binomial_exact`

Binomial probability of exactly k successes

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.binomial_exact(...)`
- TypeScript client: `jarvis.utilities.binomial_exact(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `trials` | integer | Yes | Independent trials |
| `successes` | integer | Yes | Success count |
| `p` | number | Yes | Success chance |

**Request envelope:**

```json
{
  "name": "binomial_exact",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `binomial_mean_variance`

Expected value and variance of a binomial distribution

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.binomial_mean_variance(...)`
- TypeScript client: `jarvis.utilities.binomial_mean_variance(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `trials` | integer | Yes | Number of trials |
| `p` | number | Yes | Success probability |

**Request envelope:**

```json
{
  "name": "binomial_mean_variance",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `birthday_collision`

Approximate chance two people share a birthday

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.birthday_collision(...)`
- TypeScript client: `jarvis.utilities.birthday_collision(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `people` | integer | Yes | Group size |

**Request envelope:**

```json
{
  "name": "birthday_collision",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Measure

### `bits_to_bytes`

Convert bit count to full and remaining bytes

- API: `POST /api/utilities/run`
- Category: `measure`
- Python client: `jarvis.utilities.bits_to_bytes(...)`
- TypeScript client: `jarvis.utilities.bits_to_bytes(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `bits` | integer | Yes | Bit count |

**Request envelope:**

```json
{
  "name": "bits_to_bytes",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Probability

### `bootstrap_mean`

Compute deterministic bootstrap means for a small sample

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.bootstrap_mean(...)`
- TypeScript client: `jarvis.utilities.bootstrap_mean(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Input observations |
| `replicates` | integer | No | Replicates |
| `seed` | integer | No | Random seed |

**Request envelope:**

```json
{
  "name": "bootstrap_mean",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Strings

### `build_querystring`

Build URL query string from key-value pairs

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.build_querystring(...)`
- TypeScript client: `jarvis.utilities.build_querystring(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `items` | array | Yes | Pairs as objects with key and value |

**Request envelope:**

```json
{
  "name": "build_querystring",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Dates

### `business_days`

Count weekdays Monday–Friday in inclusive date range, not holidays

- API: `POST /api/utilities/run`
- Category: `dates`
- Python client: `jarvis.utilities.business_days(...)`
- TypeScript client: `jarvis.utilities.business_days(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `start` | string | Yes | YYYY-MM-DD |
| `end` | string | Yes | YYYY-MM-DD |

**Request envelope:**

```json
{
  "name": "business_days",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Measure

### `bytes_to_bits`

Convert bytes to bits

- API: `POST /api/utilities/run`
- Category: `measure`
- Python client: `jarvis.utilities.bytes_to_bits(...)`
- TypeScript client: `jarvis.utilities.bytes_to_bits(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `bytes` | integer | Yes | Byte count |

**Request envelope:**

```json
{
  "name": "bytes_to_bits",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Dates

### `calendar_month`

Create a month grid of dates and empty cells

- API: `POST /api/utilities/run`
- Category: `dates`
- Python client: `jarvis.utilities.calendar_month(...)`
- TypeScript client: `jarvis.utilities.calendar_month(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `year` | integer | Yes | Year |
| `month` | integer | Yes | Month |
| `monday_first` | boolean | No | Start weeks on Monday |

**Request envelope:**

```json
{
  "name": "calendar_month",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Strings

### `case_transform`

Transform labels into snake kebab camel pascal title or constant case

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.case_transform(...)`
- TypeScript client: `jarvis.utilities.case_transform(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Text |
| `style` | string | Yes | Style |

**Request envelope:**

```json
{
  "name": "case_transform",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `character_count`

Count Unicode codepoints by broad category

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.character_count(...)`
- TypeScript client: `jarvis.utilities.character_count(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Passage |

**Request envelope:**

```json
{
  "name": "character_count",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `circle_area`

Circle area and circumference for a positive radius

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.circle_area(...)`
- TypeScript client: `jarvis.utilities.circle_area(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `radius` | number | Yes | Radius |

**Request envelope:**

```json
{
  "name": "circle_area",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `clamp_number`

Constrain a value between two numbers

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.clamp_number(...)`
- TypeScript client: `jarvis.utilities.clamp_number(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `value` | number | Yes | Input |
| `minimum` | number | Yes | Lower limit |
| `maximum` | number | Yes | Upper limit |

**Request envelope:**

```json
{
  "name": "clamp_number",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Statistics

### `coefficient_of_variation`

Compute standard deviation relative to mean

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.coefficient_of_variation(...)`
- TypeScript client: `jarvis.utilities.coefficient_of_variation(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Numeric samples |

**Request envelope:**

```json
{
  "name": "coefficient_of_variation",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Probability

### `coin_toss_distribution`

Distribution of heads across a fixed number of fair flips

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.coin_toss_distribution(...)`
- TypeScript client: `jarvis.utilities.coin_toss_distribution(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `flips` | integer | Yes | Number of flips |

**Request envelope:**

```json
{
  "name": "coin_toss_distribution",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `combinations`

Number of ways to select k items without order

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.combinations(...)`
- TypeScript client: `jarvis.utilities.combinations(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `n` | integer | Yes | Total items |
| `k` | integer | Yes | Selected items |

**Request envelope:**

```json
{
  "name": "combinations",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Strings

### `common_words`

Find words present in both texts

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.common_words(...)`
- TypeScript client: `jarvis.utilities.common_words(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `first` | string | Yes | First text |
| `second` | string | Yes | Second text |

**Request envelope:**

```json
{
  "name": "common_words",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `compound_growth`

Compute compounded hypothetical growth

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.compound_growth(...)`
- TypeScript client: `jarvis.utilities.compound_growth(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `principal` | number | Yes | Initial value |
| `annual_percent` | number | Yes | Annual growth rate |
| `years` | number | Yes | Years |
| `periods` | integer | No | Compounding periods per year |

**Request envelope:**

```json
{
  "name": "compound_growth",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Probability

### `conditional_probability`

Compute P(A given B) from joint and marginal probabilities

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.conditional_probability(...)`
- TypeScript client: `jarvis.utilities.conditional_probability(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `joint` | number | Yes | P(A and B) |
| `given` | number | Yes | P(B) |

**Request envelope:**

```json
{
  "name": "conditional_probability",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Measure

### `cone_volume`

Compute cone volume

- API: `POST /api/utilities/run`
- Category: `measure`
- Python client: `jarvis.utilities.cone_volume(...)`
- TypeScript client: `jarvis.utilities.cone_volume(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `radius` | number | Yes | Base radius |
| `height` | number | Yes | Cone height |

**Request envelope:**

```json
{
  "name": "cone_volume",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `convert_temperature`

Convert Celsius Fahrenheit and Kelvin

- API: `POST /api/utilities/run`
- Category: `measure`
- Python client: `jarvis.utilities.convert_temperature(...)`
- TypeScript client: `jarvis.utilities.convert_temperature(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `value` | number | Yes | Temperature |
| `origin` | string | Yes | c, f or k |
| `destination` | string | Yes | c, f or k |

**Request envelope:**

```json
{
  "name": "convert_temperature",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `convert_units`

Convert between defined units in a physical category

- API: `POST /api/utilities/run`
- Category: `measure`
- Python client: `jarvis.utilities.convert_units(...)`
- TypeScript client: `jarvis.utilities.convert_units(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `value` | number | Yes | Numeric amount |
| `category` | string | Yes | One of the unit categories |
| `origin` | string | Yes | Source symbol |
| `destination` | string | Yes | Target symbol |

**Request envelope:**

```json
{
  "name": "convert_units",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Statistics

### `correlation_matrix`

Compute correlations among several same-length series

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.correlation_matrix(...)`
- TypeScript client: `jarvis.utilities.correlation_matrix(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `series` | array | Yes | List of numeric series |

**Request envelope:**

```json
{
  "name": "correlation_matrix",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `covariance`

Compute sample or population covariance

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.covariance(...)`
- TypeScript client: `jarvis.utilities.covariance(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `first` | array | Yes | Numeric series |
| `second` | array | Yes | Paired numeric series |
| `sample` | boolean | No | Sample covariance |

**Request envelope:**

```json
{
  "name": "covariance",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Measure

### `cuboid_volume`

Compute cuboid volume and surface area

- API: `POST /api/utilities/run`
- Category: `measure`
- Python client: `jarvis.utilities.cuboid_volume(...)`
- TypeScript client: `jarvis.utilities.cuboid_volume(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `length` | number | Yes | Length |
| `width` | number | Yes | Width |
| `height` | number | Yes | Height |

**Request envelope:**

```json
{
  "name": "cuboid_volume",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Statistics

### `cumulative_product`

Calculate bounded running products

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.cumulative_product(...)`
- TypeScript client: `jarvis.utilities.cumulative_product(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Numeric values |

**Request envelope:**

```json
{
  "name": "cumulative_product",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `cumulative_sum`

Calculate running totals for a numeric list

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.cumulative_sum(...)`
- TypeScript client: `jarvis.utilities.cumulative_sum(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Numeric values |

**Request envelope:**

```json
{
  "name": "cumulative_sum",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Measure

### `cylinder_volume`

Compute cylinder volume in input cubic units

- API: `POST /api/utilities/run`
- Category: `measure`
- Python client: `jarvis.utilities.cylinder_volume(...)`
- TypeScript client: `jarvis.utilities.cylinder_volume(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `radius` | number | Yes | Base radius |
| `height` | number | Yes | Height |

**Request envelope:**

```json
{
  "name": "cylinder_volume",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Dates

### `date_range`

Generate an inclusive list of dates in a short interval

- API: `POST /api/utilities/run`
- Category: `dates`
- Python client: `jarvis.utilities.date_range(...)`
- TypeScript client: `jarvis.utilities.date_range(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `start` | string | Yes | YYYY-MM-DD |
| `end` | string | Yes | YYYY-MM-DD |
| `every_days` | integer | No | Interval in days |

**Request envelope:**

```json
{
  "name": "date_range",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `datetime_difference`

Calculate a signed difference between instants

- API: `POST /api/utilities/run`
- Category: `dates`
- Python client: `jarvis.utilities.datetime_difference(...)`
- TypeScript client: `jarvis.utilities.datetime_difference(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `start` | string | Yes | ISO datetime with offset |
| `end` | string | Yes | ISO datetime with offset |

**Request envelope:**

```json
{
  "name": "datetime_difference",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `days_between`

Calculate signed calendar days between two ISO dates

- API: `POST /api/utilities/run`
- Category: `dates`
- Python client: `jarvis.utilities.days_between(...)`
- TypeScript client: `jarvis.utilities.days_between(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `start` | string | Yes | YYYY-MM-DD |
| `end` | string | Yes | YYYY-MM-DD |

**Request envelope:**

```json
{
  "name": "days_between",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `deadline_progress`

Measure date-based progress through a known project timeline

- API: `POST /api/utilities/run`
- Category: `dates`
- Python client: `jarvis.utilities.deadline_progress(...)`
- TypeScript client: `jarvis.utilities.deadline_progress(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `started` | string | Yes | YYYY-MM-DD |
| `deadline` | string | Yes | YYYY-MM-DD |
| `current` | string | Yes | YYYY-MM-DD |

**Request envelope:**

```json
{
  "name": "deadline_progress",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Strings

### `deduplicate_lines`

Remove repeated lines while preserving first occurrence

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.deduplicate_lines(...)`
- TypeScript client: `jarvis.utilities.deduplicate_lines(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Multiline text |
| `ignore_case` | boolean | No | Compare case insensitively |

**Request envelope:**

```json
{
  "name": "deduplicate_lines",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `detect_repetitions`

Show repeated full sentences

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.detect_repetitions(...)`
- TypeScript client: `jarvis.utilities.detect_repetitions(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Document |

**Request envelope:**

```json
{
  "name": "detect_repetitions",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Probability

### `dice_sum_distribution`

Exact discrete distribution for small fair dice sums

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.dice_sum_distribution(...)`
- TypeScript client: `jarvis.utilities.dice_sum_distribution(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `dice` | integer | Yes | Number of dice |
| `sides` | integer | No | Faces per die |

**Request envelope:**

```json
{
  "name": "dice_sum_distribution",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `discount_price`

Apply a discount percentage

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.discount_price(...)`
- TypeScript client: `jarvis.utilities.discount_price(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `original` | number | Yes | Original price |
| `discount_percent` | number | Yes | Discount |

**Request envelope:**

```json
{
  "name": "discount_price",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `distance_2d`

Calculate Euclidean distance between two 2D points

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.distance_2d(...)`
- TypeScript client: `jarvis.utilities.distance_2d(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `x1` | number | Yes | X 1 |
| `y1` | number | Yes | Y 1 |
| `x2` | number | Yes | X 2 |
| `y2` | number | Yes | Y 2 |

**Request envelope:**

```json
{
  "name": "distance_2d",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Measure

### `distance_from_speed`

Calculate distance traveled at constant speed

- API: `POST /api/utilities/run`
- Category: `measure`
- Python client: `jarvis.utilities.distance_from_speed(...)`
- TypeScript client: `jarvis.utilities.distance_from_speed(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `kilometers_per_hour` | number | Yes | Average speed |
| `hours` | number | Yes | Elapsed hours |

**Request envelope:**

```json
{
  "name": "distance_from_speed",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `download_time_estimate`

Estimate download time without network measurement

- API: `POST /api/utilities/run`
- Category: `measure`
- Python client: `jarvis.utilities.download_time_estimate(...)`
- TypeScript client: `jarvis.utilities.download_time_estimate(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `size_megabytes` | number | Yes | File size MB decimal |
| `bandwidth_megabits_per_second` | number | Yes | Mbps |

**Request envelope:**

```json
{
  "name": "download_time_estimate",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `electric_ohms_law`

Solve voltage current or resistance from the other two

- API: `POST /api/utilities/run`
- Category: `measure`
- Python client: `jarvis.utilities.electric_ohms_law(...)`
- TypeScript client: `jarvis.utilities.electric_ohms_law(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `volts` | number | No | Voltage, 0 if unknown |
| `amps` | number | No | Current, 0 if unknown |
| `ohms` | number | No | Resistance, 0 if unknown |
| `solve_for` | string | Yes | One of volts amps ohms |

**Request envelope:**

```json
{
  "name": "electric_ohms_law",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `equal_split`

Divide a bill or quantity equally

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.equal_split(...)`
- TypeScript client: `jarvis.utilities.equal_split(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `total` | number | Yes | Total amount |
| `people` | integer | Yes | Number of people |

**Request envelope:**

```json
{
  "name": "equal_split",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Probability

### `expected_value`

Compute expectation of a discrete probability distribution

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.expected_value(...)`
- TypeScript client: `jarvis.utilities.expected_value(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Possible outcomes |
| `probabilities` | array | Yes | Corresponding probabilities |

**Request envelope:**

```json
{
  "name": "expected_value",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Statistics

### `exponential_moving_average`

Compute exponential weighted moving average

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.exponential_moving_average(...)`
- TypeScript client: `jarvis.utilities.exponential_moving_average(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Numeric time series |
| `alpha` | number | Yes | Smoothing constant |

**Request envelope:**

```json
{
  "name": "exponential_moving_average",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Strings

### `extract_headings`

Extract Markdown headings from an outline

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.extract_headings(...)`
- TypeScript client: `jarvis.utilities.extract_headings(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Markdown text |

**Request envelope:**

```json
{
  "name": "extract_headings",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `extract_patterns`

Extract explicit date email URL hashtag and time patterns

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.extract_patterns(...)`
- TypeScript client: `jarvis.utilities.extract_patterns(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Passage |

**Request envelope:**

```json
{
  "name": "extract_patterns",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `extract_urls`

List HTTP(S) URLs visibly present in plain text

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.extract_urls(...)`
- TypeScript client: `jarvis.utilities.extract_urls(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Passage |

**Request envelope:**

```json
{
  "name": "extract_urls",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `factorial`

Calculate factorial n! for a bounded nonnegative integer

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.factorial(...)`
- TypeScript client: `jarvis.utilities.factorial(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `n` | integer | Yes | Integer |

**Request envelope:**

```json
{
  "name": "factorial",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Probability

### `factorial_probability`

Factorial of a bounded nonnegative integer

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.factorial_probability(...)`
- TypeScript client: `jarvis.utilities.factorial_probability(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `n` | integer | Yes | Value |

**Request envelope:**

```json
{
  "name": "factorial_probability",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `fibonacci`

Generate the first N Fibonacci numbers

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.fibonacci(...)`
- TypeScript client: `jarvis.utilities.fibonacci(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `count` | integer | Yes | Number of terms |

**Request envelope:**

```json
{
  "name": "fibonacci",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Measure

### `file_size_format`

Format a byte count in binary or decimal units

- API: `POST /api/utilities/run`
- Category: `measure`
- Python client: `jarvis.utilities.file_size_format(...)`
- TypeScript client: `jarvis.utilities.file_size_format(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `bytes` | integer | Yes | Byte count |
| `binary` | boolean | No | Use KiB MiB GiB instead of kB MB GB |

**Request envelope:**

```json
{
  "name": "file_size_format",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Statistics

### `five_number_summary`

Find minimum quartiles median and maximum

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.five_number_summary(...)`
- TypeScript client: `jarvis.utilities.five_number_summary(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Numeric samples |

**Request envelope:**

```json
{
  "name": "five_number_summary",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Data

### `format_json`

Pretty-print a bounded JSON value

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.format_json(...)`
- TypeScript client: `jarvis.utilities.format_json(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `value` | object | Yes | Object to format |
| `indent` | integer | No | Indent spaces |

**Request envelope:**

```json
{
  "name": "format_json",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Dates

### `format_time_hhmm`

Convert minutes since midnight to HH:MM, wrapping each day

- API: `POST /api/utilities/run`
- Category: `dates`
- Python client: `jarvis.utilities.format_time_hhmm(...)`
- TypeScript client: `jarvis.utilities.format_time_hhmm(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `minutes` | integer | Yes | Minutes |

**Request envelope:**

```json
{
  "name": "format_time_hhmm",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `fraction_operations`

Add, subtract, multiply or divide two rational numbers

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.fraction_operations(...)`
- TypeScript client: `jarvis.utilities.fraction_operations(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `left` | string | Yes | First fraction, e.g. 3/4 |
| `right` | string | Yes | Second fraction, e.g. 1/2 |
| `operation` | string | Yes | Operation |

**Request envelope:**

```json
{
  "name": "fraction_operations",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Statistics

### `frequency_table`

Count occurrences of categorical labels

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.frequency_table(...)`
- TypeScript client: `jarvis.utilities.frequency_table(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Categories or labels |

**Request envelope:**

```json
{
  "name": "frequency_table",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Strings

### `fuzzy_titles`

Find close candidate titles for a supplied name

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.fuzzy_titles(...)`
- TypeScript client: `jarvis.utilities.fuzzy_titles(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `query` | string | Yes | Title |
| `candidates` | array | Yes | List of titles |
| `limit` | integer | No | Result count |

**Request envelope:**

```json
{
  "name": "fuzzy_titles",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `gcd_lcm`

Compute the greatest common divisor and least common multiple

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.gcd_lcm(...)`
- TypeScript client: `jarvis.utilities.gcd_lcm(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Integer values |

**Request envelope:**

```json
{
  "name": "gcd_lcm",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Probability

### `geometric_exact`

Probability first success occurs on a chosen trial

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.geometric_exact(...)`
- TypeScript client: `jarvis.utilities.geometric_exact(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `p` | number | Yes | Success chance |
| `trial` | integer | Yes | Trial number |

**Request envelope:**

```json
{
  "name": "geometric_exact",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Statistics

### `geometric_mean`

Calculate geometric mean for positive values

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.geometric_mean(...)`
- TypeScript client: `jarvis.utilities.geometric_mean(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Positive numbers |

**Request envelope:**

```json
{
  "name": "geometric_mean",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `geometric_sequence`

Produce a bounded geometric progression

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.geometric_sequence(...)`
- TypeScript client: `jarvis.utilities.geometric_sequence(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `start` | number | Yes | First term |
| `ratio` | number | Yes | Common ratio |
| `count` | integer | Yes | Terms |

**Request envelope:**

```json
{
  "name": "geometric_sequence",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Graphs

### `graph_adjacency_list`

Represent an edge list as a node-neighbor dictionary

- API: `POST /api/utilities/run`
- Category: `graphs`
- Python client: `jarvis.utilities.graph_adjacency_list(...)`
- TypeScript client: `jarvis.utilities.graph_adjacency_list(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `nodes` | array | Yes | Nodes |
| `edges` | array | Yes | Edges |
| `directed` | boolean | No | Directed graph |

**Request envelope:**

```json
{
  "name": "graph_adjacency_list",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `graph_adjacency_matrix`

Create a small binary adjacency matrix

- API: `POST /api/utilities/run`
- Category: `graphs`
- Python client: `jarvis.utilities.graph_adjacency_matrix(...)`
- TypeScript client: `jarvis.utilities.graph_adjacency_matrix(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `nodes` | array | Yes | Nodes |
| `edges` | array | Yes | Edges |
| `directed` | boolean | No | Directed graph |

**Request envelope:**

```json
{
  "name": "graph_adjacency_matrix",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `graph_bipartite`

Check whether an undirected graph can be two-colored

- API: `POST /api/utilities/run`
- Category: `graphs`
- Python client: `jarvis.utilities.graph_bipartite(...)`
- TypeScript client: `jarvis.utilities.graph_bipartite(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `nodes` | array | Yes | Nodes |
| `edges` | array | Yes | Edges |

**Request envelope:**

```json
{
  "name": "graph_bipartite",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `graph_closeness`

Estimate closeness centrality using shortest hop counts

- API: `POST /api/utilities/run`
- Category: `graphs`
- Python client: `jarvis.utilities.graph_closeness(...)`
- TypeScript client: `jarvis.utilities.graph_closeness(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `nodes` | array | Yes | Nodes |
| `edges` | array | Yes | Edges |

**Request envelope:**

```json
{
  "name": "graph_closeness",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `graph_components`

Connected components in an undirected graph

- API: `POST /api/utilities/run`
- Category: `graphs`
- Python client: `jarvis.utilities.graph_components(...)`
- TypeScript client: `jarvis.utilities.graph_components(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `nodes` | array | Yes | Nodes |
| `edges` | array | Yes | Edges |

**Request envelope:**

```json
{
  "name": "graph_components",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `graph_critical_path`

Calculate a dependency path for tasks with durations

- API: `POST /api/utilities/run`
- Category: `graphs`
- Python client: `jarvis.utilities.graph_critical_path(...)`
- TypeScript client: `jarvis.utilities.graph_critical_path(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `tasks` | array | Yes | Objects with id, duration, dependencies |

**Request envelope:**

```json
{
  "name": "graph_critical_path",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `graph_degree`

Compute degree statistics of graph nodes

- API: `POST /api/utilities/run`
- Category: `graphs`
- Python client: `jarvis.utilities.graph_degree(...)`
- TypeScript client: `jarvis.utilities.graph_degree(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `nodes` | array | Yes | Nodes |
| `edges` | array | Yes | Edges |
| `directed` | boolean | No | Directed graph |

**Request envelope:**

```json
{
  "name": "graph_degree",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `graph_density`

Calculate the density of a graph

- API: `POST /api/utilities/run`
- Category: `graphs`
- Python client: `jarvis.utilities.graph_density(...)`
- TypeScript client: `jarvis.utilities.graph_density(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `nodes` | array | Yes | Nodes |
| `edges` | array | Yes | Edges |
| `directed` | boolean | No | Directed |

**Request envelope:**

```json
{
  "name": "graph_density",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `graph_dependency_levels`

Group dependent tasks into parallelizable levels

- API: `POST /api/utilities/run`
- Category: `graphs`
- Python client: `jarvis.utilities.graph_dependency_levels(...)`
- TypeScript client: `jarvis.utilities.graph_dependency_levels(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `nodes` | array | Yes | Task names |
| `edges` | array | Yes | Prerequisite pairs |

**Request envelope:**

```json
{
  "name": "graph_dependency_levels",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `graph_edges_from_matrix`

Convert an adjacency matrix into an edge list

- API: `POST /api/utilities/run`
- Category: `graphs`
- Python client: `jarvis.utilities.graph_edges_from_matrix(...)`
- TypeScript client: `jarvis.utilities.graph_edges_from_matrix(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `nodes` | array | Yes | Nodes |
| `matrix` | array | Yes | Binary matrix |

**Request envelope:**

```json
{
  "name": "graph_edges_from_matrix",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `graph_has_cycle`

Test directed graph for a dependency cycle

- API: `POST /api/utilities/run`
- Category: `graphs`
- Python client: `jarvis.utilities.graph_has_cycle(...)`
- TypeScript client: `jarvis.utilities.graph_has_cycle(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `nodes` | array | Yes | Nodes |
| `edges` | array | Yes | Edges |

**Request envelope:**

```json
{
  "name": "graph_has_cycle",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `graph_reachable`

List nodes reachable from a given node

- API: `POST /api/utilities/run`
- Category: `graphs`
- Python client: `jarvis.utilities.graph_reachable(...)`
- TypeScript client: `jarvis.utilities.graph_reachable(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `nodes` | array | Yes | Node labels |
| `edges` | array | Yes | Edges |
| `source` | string | Yes | Start |
| `directed` | boolean | No | Directed graph |

**Request envelope:**

```json
{
  "name": "graph_reachable",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `graph_shortest_path`

Shortest unweighted path between two nodes

- API: `POST /api/utilities/run`
- Category: `graphs`
- Python client: `jarvis.utilities.graph_shortest_path(...)`
- TypeScript client: `jarvis.utilities.graph_shortest_path(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `nodes` | array | Yes | Node labels |
| `edges` | array | Yes | Node pairs |
| `source` | string | Yes | Start node |
| `target` | string | Yes | End node |
| `directed` | boolean | No | Use directed edges |

**Request envelope:**

```json
{
  "name": "graph_shortest_path",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `graph_topological_order`

Order prerequisites in a directed acyclic graph

- API: `POST /api/utilities/run`
- Category: `graphs`
- Python client: `jarvis.utilities.graph_topological_order(...)`
- TypeScript client: `jarvis.utilities.graph_topological_order(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `nodes` | array | Yes | Nodes |
| `edges` | array | Yes | Pairs [prerequisite,dependent] |

**Request envelope:**

```json
{
  "name": "graph_topological_order",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `graph_weighted_shortest_path`

Dijkstra shortest path with positive weights

- API: `POST /api/utilities/run`
- Category: `graphs`
- Python client: `jarvis.utilities.graph_weighted_shortest_path(...)`
- TypeScript client: `jarvis.utilities.graph_weighted_shortest_path(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `nodes` | array | Yes | Node labels |
| `edges` | array | Yes | Triples [from,to,cost] |
| `source` | string | Yes | Start |
| `target` | string | Yes | End |
| `directed` | boolean | No | Direction matters |

**Request envelope:**

```json
{
  "name": "graph_weighted_shortest_path",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Statistics

### `harmonic_mean`

Calculate harmonic mean for positive values

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.harmonic_mean(...)`
- TypeScript client: `jarvis.utilities.harmonic_mean(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Positive numbers |

**Request envelope:**

```json
{
  "name": "harmonic_mean",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Strings

### `hash_sha256`

Compute SHA-256 digest for plain text, not passwords

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.hash_sha256(...)`
- TypeScript client: `jarvis.utilities.hash_sha256(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Input text |

**Request envelope:**

```json
{
  "name": "hash_sha256",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Statistics

### `histogram`

Build a fixed-width histogram for numeric data

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.histogram(...)`
- TypeScript client: `jarvis.utilities.histogram(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Numeric samples |
| `bins` | integer | No | Bin count |

**Request envelope:**

```json
{
  "name": "histogram",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Strings

### `html_escape`

Escape HTML special characters for safe display

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.html_escape(...)`
- TypeScript client: `jarvis.utilities.html_escape(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Text |

**Request envelope:**

```json
{
  "name": "html_escape",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Probability

### `hypergeometric_exact`

Probability of k successes sampled without replacement

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.hypergeometric_exact(...)`
- TypeScript client: `jarvis.utilities.hypergeometric_exact(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `population` | integer | Yes | Total population |
| `positive` | integer | Yes | Positive items in population |
| `draws` | integer | Yes | Number of draws |
| `successes` | integer | Yes | Observed positive draws |

**Request envelope:**

```json
{
  "name": "hypergeometric_exact",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Measure

### `hyperspace_data_size`

Estimate storage for uncompressed images in bytes

- API: `POST /api/utilities/run`
- Category: `measure`
- Python client: `jarvis.utilities.hyperspace_data_size(...)`
- TypeScript client: `jarvis.utilities.hyperspace_data_size(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `width` | integer | Yes | Width pixels |
| `height` | integer | Yes | Height pixels |
| `channels` | integer | No | Color channels |
| `bits_per_channel` | integer | No | Channel bit depth |

**Request envelope:**

```json
{
  "name": "hyperspace_data_size",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Probability

### `independent_and`

Probability of independent events both occurring

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.independent_and(...)`
- TypeScript client: `jarvis.utilities.independent_and(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `p` | number | Yes | First probability |
| `q` | number | Yes | Second probability |

**Request envelope:**

```json
{
  "name": "independent_and",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `independent_or`

Probability that either independent event occurs

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.independent_or(...)`
- TypeScript client: `jarvis.utilities.independent_or(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `p` | number | Yes | First probability |
| `q` | number | Yes | Second probability |

**Request envelope:**

```json
{
  "name": "independent_or",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Strings

### `initials`

Make initials from a short phrase

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.initials(...)`
- TypeScript client: `jarvis.utilities.initials(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Name or phrase |
| `limit` | integer | No | Maximum initials |

**Request envelope:**

```json
{
  "name": "initials",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `integer_bit_count`

Count 1 bits in a nonnegative integer

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.integer_bit_count(...)`
- TypeScript client: `jarvis.utilities.integer_bit_count(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `value` | integer | Yes | Integer |

**Request envelope:**

```json
{
  "name": "integer_bit_count",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Statistics

### `interquartile_range`

Calculate IQR and Tukey outlier fences

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.interquartile_range(...)`
- TypeScript client: `jarvis.utilities.interquartile_range(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Numeric samples |

**Request envelope:**

```json
{
  "name": "interquartile_range",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Dates

### `iso_week`

Read ISO week, weekday and week-numbering year

- API: `POST /api/utilities/run`
- Category: `dates`
- Python client: `jarvis.utilities.iso_week(...)`
- TypeScript client: `jarvis.utilities.iso_week(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `date` | string | Yes | YYYY-MM-DD |

**Request envelope:**

```json
{
  "name": "iso_week",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Data

### `json_extract_path`

Read a nested JSON object by a simple dotted path

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.json_extract_path(...)`
- TypeScript client: `jarvis.utilities.json_extract_path(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `value` | object | Yes | Source document |
| `path` | string | Yes | Dot-separated keys |

**Request envelope:**

```json
{
  "name": "json_extract_path",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `json_object_diff`

Show changed, added and removed top-level keys

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.json_object_diff(...)`
- TypeScript client: `jarvis.utilities.json_object_diff(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `before` | object | Yes | Earlier object |
| `after` | object | Yes | Later object |

**Request envelope:**

```json
{
  "name": "json_object_diff",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Strings

### `language_script_hint`

Detect which common writing script is most visible

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.language_script_hint(...)`
- TypeScript client: `jarvis.utilities.language_script_hint(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Passage |

**Request envelope:**

```json
{
  "name": "language_script_hint",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Dates

### `leap_year`

Check Gregorian leap-year status

- API: `POST /api/utilities/run`
- Category: `dates`
- Python client: `jarvis.utilities.leap_year(...)`
- TypeScript client: `jarvis.utilities.leap_year(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `year` | integer | Yes | Year |

**Request envelope:**

```json
{
  "name": "leap_year",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Strings

### `line_numbers`

Prefix each line with its line number

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.line_numbers(...)`
- TypeScript client: `jarvis.utilities.line_numbers(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Multiline text |
| `start` | integer | No | Starting number |

**Request envelope:**

```json
{
  "name": "line_numbers",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `linear_interpolation`

Find a point on a line between two measurements

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.linear_interpolation(...)`
- TypeScript client: `jarvis.utilities.linear_interpolation(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `x0` | number | Yes | Start X |
| `y0` | number | Yes | Start Y |
| `x1` | number | Yes | End X |
| `y1` | number | Yes | End Y |
| `x` | number | Yes | Query X |

**Request envelope:**

```json
{
  "name": "linear_interpolation",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Statistics

### `linear_regression`

Fit least-squares slope and intercept for simple regression

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.linear_regression(...)`
- TypeScript client: `jarvis.utilities.linear_regression(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `x` | array | Yes | Numeric x series |
| `y` | array | Yes | Numeric y series |

**Request envelope:**

```json
{
  "name": "linear_regression",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Measure

### `list_units`

List accepted symbols for each conversion category

- API: `POST /api/utilities/run`
- Category: `measure`
- Python client: `jarvis.utilities.list_units(...)`
- TypeScript client: `jarvis.utilities.list_units(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `category` | string | No | Category, or blank for all |

**Request envelope:**

```json
{
  "name": "list_units",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Strings

### `literal_find`

Find exact substring positions without regular expressions

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.literal_find(...)`
- TypeScript client: `jarvis.utilities.literal_find(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Text |
| `needle` | string | Yes | Search term |
| `ignore_case` | boolean | No | Case insensitive |

**Request envelope:**

```json
{
  "name": "literal_find",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Data

### `make_csv`

Convert a JSON table into escaped CSV text

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.make_csv(...)`
- TypeScript client: `jarvis.utilities.make_csv(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `rows` | array | Yes | Rows to encode |
| `delimiter` | string | No | Delimiter |

**Request envelope:**

```json
{
  "name": "make_csv",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Strings

### `markdown_toc`

Create a simple Markdown table of contents

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.markdown_toc(...)`
- TypeScript client: `jarvis.utilities.markdown_toc(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Markdown document |

**Request envelope:**

```json
{
  "name": "markdown_toc",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `mask_identifier`

Mask characters of a user-supplied non-secret identifier

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.mask_identifier(...)`
- TypeScript client: `jarvis.utilities.mask_identifier(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Identifier |
| `keep_last` | integer | No | Trailing visible characters |

**Request envelope:**

```json
{
  "name": "mask_identifier",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Symbolic

### `math_definite_integral`

Compute a definite integral over a bounded numeric interval

- API: `POST /api/utilities/run`
- Category: `symbolic`
- Python client: `jarvis.utilities.math_definite_integral(...)`
- TypeScript client: `jarvis.utilities.math_definite_integral(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `expression` | string | Yes | Integrand |
| `lower` | number | Yes | Lower limit |
| `upper` | number | Yes | Upper limit |

**Request envelope:**

```json
{
  "name": "math_definite_integral",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `math_derivative`

Compute a first or higher-order derivative

- API: `POST /api/utilities/run`
- Category: `symbolic`
- Python client: `jarvis.utilities.math_derivative(...)`
- TypeScript client: `jarvis.utilities.math_derivative(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `expression` | string | Yes | Function, e.g. (x**2+3)**2 |
| `variable` | string | No | Differentiate with respect to |
| `order` | integer | No | Derivative order |

**Request envelope:**

```json
{
  "name": "math_derivative",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `math_evaluate`

Substitute one numeric variable and evaluate expression

- API: `POST /api/utilities/run`
- Category: `symbolic`
- Python client: `jarvis.utilities.math_evaluate(...)`
- TypeScript client: `jarvis.utilities.math_evaluate(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `expression` | string | Yes | Expression |
| `variable` | string | No | Variable |
| `value` | number | Yes | Substitution value |

**Request envelope:**

```json
{
  "name": "math_evaluate",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `math_expand`

Expand products and integer powers

- API: `POST /api/utilities/run`
- Category: `symbolic`
- Python client: `jarvis.utilities.math_expand(...)`
- TypeScript client: `jarvis.utilities.math_expand(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `expression` | string | Yes | Algebraic expression |

**Request envelope:**

```json
{
  "name": "math_expand",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `math_factor`

Factor a bounded polynomial expression

- API: `POST /api/utilities/run`
- Category: `symbolic`
- Python client: `jarvis.utilities.math_factor(...)`
- TypeScript client: `jarvis.utilities.math_factor(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `expression` | string | Yes | Polynomial to factor |

**Request envelope:**

```json
{
  "name": "math_factor",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `math_gradient`

Calculate gradient of a scalar function in up to three variables

- API: `POST /api/utilities/run`
- Category: `symbolic`
- Python client: `jarvis.utilities.math_gradient(...)`
- TypeScript client: `jarvis.utilities.math_gradient(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `expression` | string | Yes | Expression in x, y, z |
| `variables` | array | No | Variable names in order |

**Request envelope:**

```json
{
  "name": "math_gradient",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `math_hessian`

Compute the Hessian matrix of a scalar function

- API: `POST /api/utilities/run`
- Category: `symbolic`
- Python client: `jarvis.utilities.math_hessian(...)`
- TypeScript client: `jarvis.utilities.math_hessian(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `expression` | string | Yes | Expression |
| `variables` | array | No | Variables |

**Request envelope:**

```json
{
  "name": "math_hessian",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `math_indefinite_integral`

Compute a simple symbolic indefinite integral

- API: `POST /api/utilities/run`
- Category: `symbolic`
- Python client: `jarvis.utilities.math_indefinite_integral(...)`
- TypeScript client: `jarvis.utilities.math_indefinite_integral(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `expression` | string | Yes | Integrand |
| `variable` | string | No | Integrating variable |

**Request envelope:**

```json
{
  "name": "math_indefinite_integral",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `math_limit`

Calculate a univariate one-sided or two-sided limit

- API: `POST /api/utilities/run`
- Category: `symbolic`
- Python client: `jarvis.utilities.math_limit(...)`
- TypeScript client: `jarvis.utilities.math_limit(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `expression` | string | Yes | Expression |
| `point` | number | Yes | Value x approaches |
| `direction` | string | No | Approach direction |

**Request envelope:**

```json
{
  "name": "math_limit",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `math_numeric_derivative`

Estimate derivative using centered finite differences

- API: `POST /api/utilities/run`
- Category: `symbolic`
- Python client: `jarvis.utilities.math_numeric_derivative(...)`
- TypeScript client: `jarvis.utilities.math_numeric_derivative(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `expression` | string | Yes | Function of x |
| `at` | number | Yes | Point |
| `step` | number | No | Finite difference step |

**Request envelope:**

```json
{
  "name": "math_numeric_derivative",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `math_partial_derivative`

Compute a multivariable partial derivative

- API: `POST /api/utilities/run`
- Category: `symbolic`
- Python client: `jarvis.utilities.math_partial_derivative(...)`
- TypeScript client: `jarvis.utilities.math_partial_derivative(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `expression` | string | Yes | Expression in x, y or z |
| `variable` | string | Yes | Partial derivative variable |

**Request envelope:**

```json
{
  "name": "math_partial_derivative",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `math_polynomial_coefficients`

Extract polynomial coefficients from highest to lowest degree

- API: `POST /api/utilities/run`
- Category: `symbolic`
- Python client: `jarvis.utilities.math_polynomial_coefficients(...)`
- TypeScript client: `jarvis.utilities.math_polynomial_coefficients(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `expression` | string | Yes | Polynomial |
| `variable` | string | No | Variable |

**Request envelope:**

```json
{
  "name": "math_polynomial_coefficients",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `math_simplify`

Simplify an algebraic expression using optional SymPy

- API: `POST /api/utilities/run`
- Category: `symbolic`
- Python client: `jarvis.utilities.math_simplify(...)`
- TypeScript client: `jarvis.utilities.math_simplify(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `expression` | string | Yes | Expression using x, sin(x), x**2, etc. |

**Request envelope:**

```json
{
  "name": "math_simplify",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `math_solve_polynomial`

Solve a univariate polynomial equation expression = 0

- API: `POST /api/utilities/run`
- Category: `symbolic`
- Python client: `jarvis.utilities.math_solve_polynomial(...)`
- TypeScript client: `jarvis.utilities.math_solve_polynomial(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `expression` | string | Yes | Polynomial expression |
| `variable` | string | No | Unknown variable |

**Request envelope:**

```json
{
  "name": "math_solve_polynomial",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `math_substitute`

Replace one symbol with a number

- API: `POST /api/utilities/run`
- Category: `symbolic`
- Python client: `jarvis.utilities.math_substitute(...)`
- TypeScript client: `jarvis.utilities.math_substitute(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `expression` | string | Yes | Expression |
| `variable` | string | Yes | Symbol |
| `value` | number | Yes | Numeric replacement |

**Request envelope:**

```json
{
  "name": "math_substitute",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `math_taylor_series`

Compute a truncated Taylor series at zero or another point

- API: `POST /api/utilities/run`
- Category: `symbolic`
- Python client: `jarvis.utilities.math_taylor_series(...)`
- TypeScript client: `jarvis.utilities.math_taylor_series(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `expression` | string | Yes | Expression |
| `point` | number | No | Expansion point |
| `order` | integer | No | Terms through order n-1 |

**Request envelope:**

```json
{
  "name": "math_taylor_series",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Statistics

### `mean_absolute_deviation`

Compute average absolute deviation around the mean

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.mean_absolute_deviation(...)`
- TypeScript client: `jarvis.utilities.mean_absolute_deviation(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Numeric samples |

**Request envelope:**

```json
{
  "name": "mean_absolute_deviation",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `mean_median_mode`

Calculate mean median and modes

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.mean_median_mode(...)`
- TypeScript client: `jarvis.utilities.mean_median_mode(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Numeric samples |

**Request envelope:**

```json
{
  "name": "mean_median_mode",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `median_absolute_deviation`

Compute median absolute deviation from sample median

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.median_absolute_deviation(...)`
- TypeScript client: `jarvis.utilities.median_absolute_deviation(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Numeric samples |

**Request envelope:**

```json
{
  "name": "median_absolute_deviation",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Dates

### `minutes_to_duration`

Display total minutes as days, hours and minutes

- API: `POST /api/utilities/run`
- Category: `dates`
- Python client: `jarvis.utilities.minutes_to_duration(...)`
- TypeScript client: `jarvis.utilities.minutes_to_duration(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `minutes` | integer | Yes | Total signed minutes |

**Request envelope:**

```json
{
  "name": "minutes_to_duration",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Statistics

### `moving_average`

Compute sliding simple moving averages

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.moving_average(...)`
- TypeScript client: `jarvis.utilities.moving_average(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Numeric time series |
| `window` | integer | Yes | Number of samples per window |

**Request envelope:**

```json
{
  "name": "moving_average",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Probability

### `normal_cdf`

Cumulative normal probability for a z-score

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.normal_cdf(...)`
- TypeScript client: `jarvis.utilities.normal_cdf(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `z` | number | Yes | Z score |

**Request envelope:**

```json
{
  "name": "normal_cdf",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `normal_interval`

Probability between two z-scores

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.normal_interval(...)`
- TypeScript client: `jarvis.utilities.normal_interval(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `low` | number | Yes | Lower z score |
| `high` | number | Yes | Upper z score |

**Request envelope:**

```json
{
  "name": "normal_interval",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `normal_zscore`

Convert a measurement to standard deviation units

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.normal_zscore(...)`
- TypeScript client: `jarvis.utilities.normal_zscore(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `value` | number | Yes | Observation |
| `mean` | number | Yes | Population mean |
| `stddev` | number | Yes | Population standard deviation |

**Request envelope:**

```json
{
  "name": "normal_zscore",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Statistics

### `normalize_minmax`

Map a numeric series to a selected range

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.normalize_minmax(...)`
- TypeScript client: `jarvis.utilities.normalize_minmax(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Numeric samples |
| `lower` | number | No | Target lower bound |
| `upper` | number | No | Target upper bound |

**Request envelope:**

```json
{
  "name": "normalize_minmax",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Strings

### `normalize_text`

Standardize Unicode whitespace and optionally case

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.normalize_text(...)`
- TypeScript client: `jarvis.utilities.normalize_text(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Text |
| `casefold` | boolean | No | Convert to casefolded lowercase |

**Request envelope:**

```json
{
  "name": "normalize_text",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Dates

### `nth_weekday`

Find the Nth specified weekday in a calendar month

- API: `POST /api/utilities/run`
- Category: `dates`
- Python client: `jarvis.utilities.nth_weekday(...)`
- TypeScript client: `jarvis.utilities.nth_weekday(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `year` | integer | Yes | Year |
| `month` | integer | Yes | Month |
| `weekday` | integer | Yes | Monday=0 through Sunday=6 |
| `occurrence` | integer | Yes | Nth occurrence, 1–5 |

**Request envelope:**

```json
{
  "name": "nth_weekday",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `number_to_base`

Convert an integer to binary, octal or hexadecimal

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.number_to_base(...)`
- TypeScript client: `jarvis.utilities.number_to_base(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `value` | integer | Yes | Integer |
| `base` | integer | Yes | Base |

**Request envelope:**

```json
{
  "name": "number_to_base",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Probability

### `odds_to_probability`

Convert positive odds ratio to probability

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.odds_to_probability(...)`
- TypeScript client: `jarvis.utilities.odds_to_probability(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `odds` | number | Yes | Odds for vs against |

**Request envelope:**

```json
{
  "name": "odds_to_probability",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Dates

### `overlap_time_ranges`

Find intersection of two timezone-aware intervals

- API: `POST /api/utilities/run`
- Category: `dates`
- Python client: `jarvis.utilities.overlap_time_ranges(...)`
- TypeScript client: `jarvis.utilities.overlap_time_ranges(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `first_start` | string | Yes | Timestamp |
| `first_end` | string | Yes | Timestamp |
| `second_start` | string | Yes | Timestamp |
| `second_end` | string | Yes | Timestamp |

**Request envelope:**

```json
{
  "name": "overlap_time_ranges",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Measure

### `pace_from_time`

Calculate minutes per km from minutes and distance

- API: `POST /api/utilities/run`
- Category: `measure`
- Python client: `jarvis.utilities.pace_from_time(...)`
- TypeScript client: `jarvis.utilities.pace_from_time(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `minutes` | number | Yes | Elapsed minutes |
| `kilometers` | number | Yes | Distance in km |

**Request envelope:**

```json
{
  "name": "pace_from_time",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Strings

### `palindrome_check`

Check if alphanumeric characters read identically backwards

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.palindrome_check(...)`
- TypeScript client: `jarvis.utilities.palindrome_check(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Phrase |

**Request envelope:**

```json
{
  "name": "palindrome_check",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `paragraph_split`

Split text on empty lines

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.paragraph_split(...)`
- TypeScript client: `jarvis.utilities.paragraph_split(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Multiline text |

**Request envelope:**

```json
{
  "name": "paragraph_split",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Data

### `parse_csv`

Parse simple comma-separated data into row objects

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.parse_csv(...)`
- TypeScript client: `jarvis.utilities.parse_csv(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | CSV content |
| `delimiter` | string | No | Field delimiter |

**Request envelope:**

```json
{
  "name": "parse_csv",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `parse_json`

Validate and decode a JSON text value

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.parse_json(...)`
- TypeScript client: `jarvis.utilities.parse_json(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | JSON document |

**Request envelope:**

```json
{
  "name": "parse_json",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Strings

### `parse_querystring`

Extract query-string parameters without issuing HTTP requests

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.parse_querystring(...)`
- TypeScript client: `jarvis.utilities.parse_querystring(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | URL query string |

**Request envelope:**

```json
{
  "name": "parse_querystring",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Dates

### `parse_time_hhmm`

Parse 24-hour clock time to elapsed minutes

- API: `POST /api/utilities/run`
- Category: `dates`
- Python client: `jarvis.utilities.parse_time_hhmm(...)`
- TypeScript client: `jarvis.utilities.parse_time_hhmm(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `time` | string | Yes | HH:MM |

**Request envelope:**

```json
{
  "name": "parse_time_hhmm",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Statistics

### `pearson_correlation`

Compute Pearson linear correlation for paired data

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.pearson_correlation(...)`
- TypeScript client: `jarvis.utilities.pearson_correlation(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `first` | array | Yes | First numeric series |
| `second` | array | Yes | Second numeric series |

**Request envelope:**

```json
{
  "name": "pearson_correlation",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `percent_change`

Calculate the relative percentage change

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.percent_change(...)`
- TypeScript client: `jarvis.utilities.percent_change(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `before` | number | Yes | Original value |
| `after` | number | Yes | Updated value |

**Request envelope:**

```json
{
  "name": "percent_change",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `percent_of`

Calculate a percentage of any positive or negative number

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.percent_of(...)`
- TypeScript client: `jarvis.utilities.percent_of(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `part` | number | Yes | The percentage |
| `whole` | number | Yes | The amount |

**Request envelope:**

```json
{
  "name": "percent_of",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

**Example questions:** 20 percent of 450


## Statistics

### `percent_of_total`

Calculate percent share for each nonnegative contribution

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.percent_of_total(...)`
- TypeScript client: `jarvis.utilities.percent_of_total(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Nonnegative numeric values |

**Request envelope:**

```json
{
  "name": "percent_of_total",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `percentage_difference`

Compare two measurements symmetrically

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.percentage_difference(...)`
- TypeScript client: `jarvis.utilities.percentage_difference(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `first` | number | Yes | First amount |
| `second` | number | Yes | Second amount |

**Request envelope:**

```json
{
  "name": "percentage_difference",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Statistics

### `percentile_rank`

Percent of observations less than or equal to a given value

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.percentile_rank(...)`
- TypeScript client: `jarvis.utilities.percentile_rank(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Numeric samples |
| `value` | number | Yes | Value to compare |

**Request envelope:**

```json
{
  "name": "percentile_rank",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Probability

### `permutations`

Ordered arrangements of k selected items

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.permutations(...)`
- TypeScript client: `jarvis.utilities.permutations(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `n` | integer | Yes | Total items |
| `k` | integer | Yes | Selected items |

**Request envelope:**

```json
{
  "name": "permutations",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Measure

### `pixel_density`

Compute approximate pixels per inch for a display

- API: `POST /api/utilities/run`
- Category: `measure`
- Python client: `jarvis.utilities.pixel_density(...)`
- TypeScript client: `jarvis.utilities.pixel_density(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `width_px` | integer | Yes | Horizontal pixels |
| `height_px` | integer | Yes | Vertical pixels |
| `diagonal_inches` | number | Yes | Diagonal screen size |

**Request envelope:**

```json
{
  "name": "pixel_density",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Probability

### `poisson_exact`

Poisson probability of exactly k events

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.poisson_exact(...)`
- TypeScript client: `jarvis.utilities.poisson_exact(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `rate` | number | Yes | Expected number of events |
| `count` | integer | Yes | Number of observed events |

**Request envelope:**

```json
{
  "name": "poisson_exact",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Statistics

### `population_range`

Get count min max span and mean from numeric data

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.population_range(...)`
- TypeScript client: `jarvis.utilities.population_range(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Numeric samples |

**Request envelope:**

```json
{
  "name": "population_range",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Measure

### `power_energy`

Calculate energy from constant power and elapsed time

- API: `POST /api/utilities/run`
- Category: `measure`
- Python client: `jarvis.utilities.power_energy(...)`
- TypeScript client: `jarvis.utilities.power_energy(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `watts` | number | Yes | Power in W |
| `hours` | number | Yes | Duration in hours |

**Request envelope:**

```json
{
  "name": "power_energy",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `prime_check`

Check whether an integer is prime using trial division

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.prime_check(...)`
- TypeScript client: `jarvis.utilities.prime_check(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `value` | integer | Yes | Integer to check |

**Request envelope:**

```json
{
  "name": "prime_check",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `prime_factors`

Find prime factors of a moderate integer

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.prime_factors(...)`
- TypeScript client: `jarvis.utilities.prime_factors(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `value` | integer | Yes | Positive integer |

**Request envelope:**

```json
{
  "name": "prime_factors",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Probability

### `probability_not`

Compute the complement of an event probability

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.probability_not(...)`
- TypeScript client: `jarvis.utilities.probability_not(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `p` | number | Yes | Event probability |

**Request envelope:**

```json
{
  "name": "probability_not",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `probability_to_odds`

Convert event probability into odds for vs against

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.probability_to_odds(...)`
- TypeScript client: `jarvis.utilities.probability_to_odds(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `probability` | number | Yes | Probability |

**Request envelope:**

```json
{
  "name": "probability_to_odds",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `proportion`

Solve a proportion a/b=c/d for missing d

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.proportion(...)`
- TypeScript client: `jarvis.utilities.proportion(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `a` | number | Yes | Known numerator |
| `b` | number | Yes | Known denominator |
| `c` | number | Yes | Known second numerator |

**Request envelope:**

```json
{
  "name": "proportion",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `pythagorean`

Solve a right triangle hypotenuse from two sides

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.pythagorean(...)`
- TypeScript client: `jarvis.utilities.pythagorean(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `a` | number | Yes | First leg |
| `b` | number | Yes | Second leg |

**Request envelope:**

```json
{
  "name": "pythagorean",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Software

### `python_assignment_names`

List variables assigned in Python source

- API: `POST /api/utilities/run`
- Category: `software`
- Python client: `jarvis.utilities.python_assignment_names(...)`
- TypeScript client: `jarvis.utilities.python_assignment_names(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `source` | string | Yes | Source |

**Request envelope:**

```json
{
  "name": "python_assignment_names",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `python_ast_counts`

Count syntax node types in a Python file

- API: `POST /api/utilities/run`
- Category: `software`
- Python client: `jarvis.utilities.python_ast_counts(...)`
- TypeScript client: `jarvis.utilities.python_ast_counts(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `source` | string | Yes | Source |

**Request envelope:**

```json
{
  "name": "python_ast_counts",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `python_broad_exception_candidates`

Find bare excepts and broad exception handlers

- API: `POST /api/utilities/run`
- Category: `software`
- Python client: `jarvis.utilities.python_broad_exception_candidates(...)`
- TypeScript client: `jarvis.utilities.python_broad_exception_candidates(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `source` | string | Yes | Source |

**Request envelope:**

```json
{
  "name": "python_broad_exception_candidates",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `python_call_names`

List function call names statically from Python source

- API: `POST /api/utilities/run`
- Category: `software`
- Python client: `jarvis.utilities.python_call_names(...)`
- TypeScript client: `jarvis.utilities.python_call_names(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `source` | string | Yes | Source |

**Request envelope:**

```json
{
  "name": "python_call_names",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `python_classes`

Extract classes, bases, methods, and source line numbers

- API: `POST /api/utilities/run`
- Category: `software`
- Python client: `jarvis.utilities.python_classes(...)`
- TypeScript client: `jarvis.utilities.python_classes(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `source` | string | Yes | Source text |

**Request envelope:**

```json
{
  "name": "python_classes",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `python_complexity`

Estimate branch-based cyclomatic complexity of Python functions

- API: `POST /api/utilities/run`
- Category: `software`
- Python client: `jarvis.utilities.python_complexity(...)`
- TypeScript client: `jarvis.utilities.python_complexity(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `source` | string | Yes | Source |

**Request envelope:**

```json
{
  "name": "python_complexity",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `python_constant_values`

List simple module-level constant assignments

- API: `POST /api/utilities/run`
- Category: `software`
- Python client: `jarvis.utilities.python_constant_values(...)`
- TypeScript client: `jarvis.utilities.python_constant_values(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `source` | string | Yes | Source |

**Request envelope:**

```json
{
  "name": "python_constant_values",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `python_definition_outline`

Produce a class/function declaration outline

- API: `POST /api/utilities/run`
- Category: `software`
- Python client: `jarvis.utilities.python_definition_outline(...)`
- TypeScript client: `jarvis.utilities.python_definition_outline(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `source` | string | Yes | Source |

**Request envelope:**

```json
{
  "name": "python_definition_outline",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `python_docstrings`

Collect module, class and function docstrings

- API: `POST /api/utilities/run`
- Category: `software`
- Python client: `jarvis.utilities.python_docstrings(...)`
- TypeScript client: `jarvis.utilities.python_docstrings(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `source` | string | Yes | Source |

**Request envelope:**

```json
{
  "name": "python_docstrings",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `python_format_import_suggestions`

Suggest grouping import modules by name

- API: `POST /api/utilities/run`
- Category: `software`
- Python client: `jarvis.utilities.python_format_import_suggestions(...)`
- TypeScript client: `jarvis.utilities.python_format_import_suggestions(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `source` | string | Yes | Source |

**Request envelope:**

```json
{
  "name": "python_format_import_suggestions",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `python_functions`

List functions, arguments, line ranges and async markers

- API: `POST /api/utilities/run`
- Category: `software`
- Python client: `jarvis.utilities.python_functions(...)`
- TypeScript client: `jarvis.utilities.python_functions(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `source` | string | Yes | Source text |

**Request envelope:**

```json
{
  "name": "python_functions",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `python_imports`

Extract literal import statements without importing packages

- API: `POST /api/utilities/run`
- Category: `software`
- Python client: `jarvis.utilities.python_imports(...)`
- TypeScript client: `jarvis.utilities.python_imports(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `source` | string | Yes | Source |

**Request envelope:**

```json
{
  "name": "python_imports",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `python_keyword_check`

Check Python keyword and identifier rules

- API: `POST /api/utilities/run`
- Category: `software`
- Python client: `jarvis.utilities.python_keyword_check(...)`
- TypeScript client: `jarvis.utilities.python_keyword_check(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `name` | string | Yes | Candidate variable or function name |

**Request envelope:**

```json
{
  "name": "python_keyword_check",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `python_mutable_default_candidates`

Find literal list/dict/set defaults in function definitions

- API: `POST /api/utilities/run`
- Category: `software`
- Python client: `jarvis.utilities.python_mutable_default_candidates(...)`
- TypeScript client: `jarvis.utilities.python_mutable_default_candidates(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `source` | string | Yes | Source |

**Request envelope:**

```json
{
  "name": "python_mutable_default_candidates",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `python_syntax_check`

Parse Python source and report syntax errors without running code

- API: `POST /api/utilities/run`
- Category: `software`
- Python client: `jarvis.utilities.python_syntax_check(...)`
- TypeScript client: `jarvis.utilities.python_syntax_check(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `source` | string | Yes | Source text |

**Request envelope:**

```json
{
  "name": "python_syntax_check",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `python_todo_comments`

Locate TODO and FIXME comments

- API: `POST /api/utilities/run`
- Category: `software`
- Python client: `jarvis.utilities.python_todo_comments(...)`
- TypeScript client: `jarvis.utilities.python_todo_comments(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `source` | string | Yes | Source text |

**Request envelope:**

```json
{
  "name": "python_todo_comments",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `python_unused_import_candidates`

Find imports whose names are not referenced elsewhere in the AST

- API: `POST /api/utilities/run`
- Category: `software`
- Python client: `jarvis.utilities.python_unused_import_candidates(...)`
- TypeScript client: `jarvis.utilities.python_unused_import_candidates(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `source` | string | Yes | Source |

**Request envelope:**

```json
{
  "name": "python_unused_import_candidates",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `quadratic_roots`

Solve a real quadratic equation ax²+bx+c=0

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.quadratic_roots(...)`
- TypeScript client: `jarvis.utilities.quadratic_roots(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `a` | number | Yes | Coefficient a |
| `b` | number | Yes | Coefficient b |
| `c` | number | Yes | Coefficient c |

**Request envelope:**

```json
{
  "name": "quadratic_roots",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Statistics

### `quantile`

Find a linearly interpolated quantile

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.quantile(...)`
- TypeScript client: `jarvis.utilities.quantile(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Numeric samples |
| `quantile` | number | Yes | Fraction between 0 and 1 |

**Request envelope:**

```json
{
  "name": "quantile",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `ratio_simplify`

Reduce an integer ratio using the greatest common divisor

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.ratio_simplify(...)`
- TypeScript client: `jarvis.utilities.ratio_simplify(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `a` | integer | Yes | First integer |
| `b` | integer | Yes | Second integer |

**Request envelope:**

```json
{
  "name": "ratio_simplify",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Statistics

### `regression_predict`

Predict y using fitted line from paired training data

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.regression_predict(...)`
- TypeScript client: `jarvis.utilities.regression_predict(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `x` | array | Yes | Training x series |
| `y` | array | Yes | Training y series |
| `predict_x` | number | Yes | New x |

**Request envelope:**

```json
{
  "name": "regression_predict",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Strings

### `remove_empty_lines`

Filter blank lines from a passage

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.remove_empty_lines(...)`
- TypeScript client: `jarvis.utilities.remove_empty_lines(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Multiline text |

**Request envelope:**

```json
{
  "name": "remove_empty_lines",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `replace_literal`

Replace literal text with another substring

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.replace_literal(...)`
- TypeScript client: `jarvis.utilities.replace_literal(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Input |
| `old` | string | Yes | Exact old text |
| `new` | string | Yes | Replacement |
| `limit` | integer | No | Maximum replacements |

**Request envelope:**

```json
{
  "name": "replace_literal",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Measure

### `rescale_image`

Rescale an image to fit within given bounds, preserving aspect ratio

- API: `POST /api/utilities/run`
- Category: `measure`
- Python client: `jarvis.utilities.rescale_image(...)`
- TypeScript client: `jarvis.utilities.rescale_image(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `width` | integer | Yes | Original width |
| `height` | integer | Yes | Original height |
| `max_width` | integer | Yes | Target width |
| `max_height` | integer | Yes | Target height |
| `upscale` | boolean | No | Allow enlarging the original |

**Request envelope:**

```json
{
  "name": "rescale_image",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Statistics

### `root_mean_square`

Calculate root-mean-square of numeric values

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.root_mean_square(...)`
- TypeScript client: `jarvis.utilities.root_mean_square(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Numbers |

**Request envelope:**

```json
{
  "name": "root_mean_square",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `round_significant`

Round a finite number to N significant digits

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.round_significant(...)`
- TypeScript client: `jarvis.utilities.round_significant(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `value` | number | Yes | Number |
| `digits` | integer | Yes | Significant digits |

**Request envelope:**

```json
{
  "name": "round_significant",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Probability

### `sample_mean_standard_error`

Estimate standard error for a sample average

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.sample_mean_standard_error(...)`
- TypeScript client: `jarvis.utilities.sample_mean_standard_error(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `stddev` | number | Yes | Sample standard deviation |
| `sample_size` | integer | Yes | Number of observations |

**Request envelope:**

```json
{
  "name": "sample_mean_standard_error",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `sample_proportion_interval`

Wilson interval for a sample percentage

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.sample_proportion_interval(...)`
- TypeScript client: `jarvis.utilities.sample_proportion_interval(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `successes` | integer | Yes | Number of successes |
| `trials` | integer | Yes | Total trials |
| `z` | number | No | Critical z value |

**Request envelope:**

```json
{
  "name": "sample_proportion_interval",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Strings

### `sentence_split`

Split a passage into sentences with their order preserved

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.sentence_split(...)`
- TypeScript client: `jarvis.utilities.sentence_split(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Passage |

**Request envelope:**

```json
{
  "name": "sentence_split",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Time_Series

### `series_anomaly_iqr`

Flag values outside the interquartile fence

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_anomaly_iqr(...)`
- TypeScript client: `jarvis.utilities.series_anomaly_iqr(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Observed values |
| `multiplier` | number | No | IQR multiplier |

**Request envelope:**

```json
{
  "name": "series_anomaly_iqr",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_anomaly_zscore`

Flag values exceeding a standard z-score threshold

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_anomaly_zscore(...)`
- TypeScript client: `jarvis.utilities.series_anomaly_zscore(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Observed values |
| `threshold` | number | No | Absolute z threshold |

**Request envelope:**

```json
{
  "name": "series_anomaly_zscore",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_autocorrelation`

Lagged autocorrelation of a time series

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_autocorrelation(...)`
- TypeScript client: `jarvis.utilities.series_autocorrelation(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Observations |
| `lag` | integer | Yes | Positive lag |

**Request envelope:**

```json
{
  "name": "series_autocorrelation",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_centered_smoothing`

Centered mean smoothing for an odd-width window

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_centered_smoothing(...)`
- TypeScript client: `jarvis.utilities.series_centered_smoothing(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Values |
| `window` | integer | No | Odd window |

**Request envelope:**

```json
{
  "name": "series_centered_smoothing",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_cross_correlation`

Pearson correlation of two aligned series

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_cross_correlation(...)`
- TypeScript client: `jarvis.utilities.series_cross_correlation(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `first` | array | Yes | First series |
| `second` | array | Yes | Second series |

**Request envelope:**

```json
{
  "name": "series_cross_correlation",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_cumulative_product`

Running product across observations

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_cumulative_product(...)`
- TypeScript client: `jarvis.utilities.series_cumulative_product(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Numbers |

**Request envelope:**

```json
{
  "name": "series_cumulative_product",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_cumulative_sum`

Running total across observations

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_cumulative_sum(...)`
- TypeScript client: `jarvis.utilities.series_cumulative_sum(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Numbers |

**Request envelope:**

```json
{
  "name": "series_cumulative_sum",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_detrend`

Subtract the least-squares linear trend from a series

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_detrend(...)`
- TypeScript client: `jarvis.utilities.series_detrend(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Observed series |

**Request envelope:**

```json
{
  "name": "series_detrend",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_differences`

Compute successive first differences

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_differences(...)`
- TypeScript client: `jarvis.utilities.series_differences(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Time-ordered numbers |

**Request envelope:**

```json
{
  "name": "series_differences",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_drawdown`

Compute drop relative to running maximum, in percent

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_drawdown(...)`
- TypeScript client: `jarvis.utilities.series_drawdown(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Positive observed values |

**Request envelope:**

```json
{
  "name": "series_drawdown",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_exponential_average`

Exponentially weighted moving average (EMA)

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_exponential_average(...)`
- TypeScript client: `jarvis.utilities.series_exponential_average(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Observations |
| `span` | integer | Yes | Smoothing span |

**Request envelope:**

```json
{
  "name": "series_exponential_average",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_forecast_average`

Constant-mean baseline forecast

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_forecast_average(...)`
- TypeScript client: `jarvis.utilities.series_forecast_average(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Historical data |
| `steps` | integer | No | Steps ahead |

**Request envelope:**

```json
{
  "name": "series_forecast_average",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_forecast_last`

Last-observation-carried-forward baseline forecast

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_forecast_last(...)`
- TypeScript client: `jarvis.utilities.series_forecast_last(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Historical data |
| `steps` | integer | No | Future steps |

**Request envelope:**

```json
{
  "name": "series_forecast_last",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_forecast_linear`

Extrapolate a fitted linear trend with explicit caveat

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_forecast_linear(...)`
- TypeScript client: `jarvis.utilities.series_forecast_linear(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Historical values |
| `steps` | integer | No | Number of forecast steps |

**Request envelope:**

```json
{
  "name": "series_forecast_linear",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_lag_table`

Autocorrelation values for a range of lags

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_lag_table(...)`
- TypeScript client: `jarvis.utilities.series_lag_table(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Observations |
| `max_lag` | integer | No | Maximum lag |

**Request envelope:**

```json
{
  "name": "series_lag_table",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_largest_changes`

List the largest absolute changes between neighboring values

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_largest_changes(...)`
- TypeScript client: `jarvis.utilities.series_largest_changes(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Values |
| `limit` | integer | No | Maximum changes |

**Request envelope:**

```json
{
  "name": "series_largest_changes",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_linear_trend`

Fit a least-squares time trend across equal intervals

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_linear_trend(...)`
- TypeScript client: `jarvis.utilities.series_linear_trend(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Observed series |

**Request envelope:**

```json
{
  "name": "series_linear_trend",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_momentum`

Subtract observation from k steps earlier

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_momentum(...)`
- TypeScript client: `jarvis.utilities.series_momentum(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Series |
| `period` | integer | Yes | Number of periods back |

**Request envelope:**

```json
{
  "name": "series_momentum",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_moving_average`

Trailing simple moving average over a fixed window

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_moving_average(...)`
- TypeScript client: `jarvis.utilities.series_moving_average(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Observations |
| `window` | integer | Yes | Window length |

**Request envelope:**

```json
{
  "name": "series_moving_average",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_normalize_minmax`

Scale finite observations to a 0..1 range

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_normalize_minmax(...)`
- TypeScript client: `jarvis.utilities.series_normalize_minmax(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Observations |

**Request envelope:**

```json
{
  "name": "series_normalize_minmax",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_peak_trough`

Return indices and values of min and max observations

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_peak_trough(...)`
- TypeScript client: `jarvis.utilities.series_peak_trough(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Observations |

**Request envelope:**

```json
{
  "name": "series_peak_trough",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_percent_change`

Percentage growth from each observation to the next

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_percent_change(...)`
- TypeScript client: `jarvis.utilities.series_percent_change(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Time-ordered numbers |

**Request envelope:**

```json
{
  "name": "series_percent_change",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_rebase`

Rebase a series to an index value of 100

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_rebase(...)`
- TypeScript client: `jarvis.utilities.series_rebase(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Observations |

**Request envelope:**

```json
{
  "name": "series_rebase",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_resample_chunks`

Aggregate adjacent values into non-overlapping chunks

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_resample_chunks(...)`
- TypeScript client: `jarvis.utilities.series_resample_chunks(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Series |
| `size` | integer | Yes | Observations per chunk |
| `method` | boolean | No | Use sum instead of mean |

**Request envelope:**

```json
{
  "name": "series_resample_chunks",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_rolling_maximum`

Maximum over each trailing observation window

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_rolling_maximum(...)`
- TypeScript client: `jarvis.utilities.series_rolling_maximum(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Observations |
| `window` | integer | Yes | Window size |

**Request envelope:**

```json
{
  "name": "series_rolling_maximum",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_rolling_minimum`

Minimum over each trailing observation window

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_rolling_minimum(...)`
- TypeScript client: `jarvis.utilities.series_rolling_minimum(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Observations |
| `window` | integer | Yes | Window size |

**Request envelope:**

```json
{
  "name": "series_rolling_minimum",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_rolling_stddev`

Sample standard deviation in each rolling window

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_rolling_stddev(...)`
- TypeScript client: `jarvis.utilities.series_rolling_stddev(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Observations |
| `window` | integer | Yes | Window size |

**Request envelope:**

```json
{
  "name": "series_rolling_stddev",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_run_lengths`

Compute consecutive runs of equal categorical values

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_run_lengths(...)`
- TypeScript client: `jarvis.utilities.series_run_lengths(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Categorical sequence |

**Request envelope:**

```json
{
  "name": "series_run_lengths",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_standardize`

Transform observations into z-score units

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_standardize(...)`
- TypeScript client: `jarvis.utilities.series_standardize(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Observations |

**Request envelope:**

```json
{
  "name": "series_standardize",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `series_zero_crossings`

Count crossings between negative and positive values

- API: `POST /api/utilities/run`
- Category: `time_series`
- Python client: `jarvis.utilities.series_zero_crossings(...)`
- TypeScript client: `jarvis.utilities.series_zero_crossings(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Values |

**Request envelope:**

```json
{
  "name": "series_zero_crossings",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Probability

### `shannon_entropy`

Compute Shannon information entropy in bits

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.shannon_entropy(...)`
- TypeScript client: `jarvis.utilities.shannon_entropy(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `probabilities` | array | Yes | Probabilities |

**Request envelope:**

```json
{
  "name": "shannon_entropy",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `simple_interest`

Calculate non-compound interest, not investment advice

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.simple_interest(...)`
- TypeScript client: `jarvis.utilities.simple_interest(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `principal` | number | Yes | Initial principal |
| `annual_percent` | number | Yes | Annual interest percentage |
| `years` | number | Yes | Number of years |

**Request envelope:**

```json
{
  "name": "simple_interest",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Probability

### `simulate_discrete`

Reproducible weighted random sampling for education

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.simulate_discrete(...)`
- TypeScript client: `jarvis.utilities.simulate_discrete(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Possible outcomes |
| `weights` | array | Yes | Nonnegative weights |
| `count` | integer | No | Number of draws |
| `seed` | integer | No | Random seed |

**Request envelope:**

```json
{
  "name": "simulate_discrete",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Strings

### `slugify`

Create a URL-friendly ASCII slug from a title

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.slugify(...)`
- TypeScript client: `jarvis.utilities.slugify(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Title or phrase |

**Request envelope:**

```json
{
  "name": "slugify",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `sort_lines`

Sort a list of lines alphabetically

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.sort_lines(...)`
- TypeScript client: `jarvis.utilities.sort_lines(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Multiline text |
| `reverse` | boolean | No | Descending order |
| `casefold` | boolean | No | Case insensitive |

**Request envelope:**

```json
{
  "name": "sort_lines",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Software

### `source_bracket_balance`

Check raw bracket balances for plain text, not a parser

- API: `POST /api/utilities/run`
- Category: `software`
- Python client: `jarvis.utilities.source_bracket_balance(...)`
- TypeScript client: `jarvis.utilities.source_bracket_balance(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `source` | string | Yes | Text |

**Request envelope:**

```json
{
  "name": "source_bracket_balance",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `source_diff`

Generate a bounded unified diff for two text versions

- API: `POST /api/utilities/run`
- Category: `software`
- Python client: `jarvis.utilities.source_diff(...)`
- TypeScript client: `jarvis.utilities.source_diff(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `before` | string | Yes | Earlier text |
| `after` | string | Yes | New text |
| `context` | integer | No | Context lines |

**Request envelope:**

```json
{
  "name": "source_diff",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `source_extract_urls`

Find links appearing in an arbitrary text input

- API: `POST /api/utilities/run`
- Category: `software`
- Python client: `jarvis.utilities.source_extract_urls(...)`
- TypeScript client: `jarvis.utilities.source_extract_urls(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `source` | string | Yes | Text to inspect |

**Request envelope:**

```json
{
  "name": "source_extract_urls",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `source_find_repeated_lines`

Count repeated nonempty lines of pasted source

- API: `POST /api/utilities/run`
- Category: `software`
- Python client: `jarvis.utilities.source_find_repeated_lines(...)`
- TypeScript client: `jarvis.utilities.source_find_repeated_lines(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `source` | string | Yes | Source |
| `minimum` | integer | No | Minimum repetitions |

**Request envelope:**

```json
{
  "name": "source_find_repeated_lines",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `source_indent_profile`

Summarize indentation widths in source text

- API: `POST /api/utilities/run`
- Category: `software`
- Python client: `jarvis.utilities.source_indent_profile(...)`
- TypeScript client: `jarvis.utilities.source_indent_profile(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `source` | string | Yes | Source text |

**Request envelope:**

```json
{
  "name": "source_indent_profile",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `source_lines`

Count blank and nonblank source lines

- API: `POST /api/utilities/run`
- Category: `software`
- Python client: `jarvis.utilities.source_lines(...)`
- TypeScript client: `jarvis.utilities.source_lines(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `source` | string | Yes | Source |

**Request envelope:**

```json
{
  "name": "source_lines",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `source_trailing_space_lines`

Report source lines with trailing whitespace

- API: `POST /api/utilities/run`
- Category: `software`
- Python client: `jarvis.utilities.source_trailing_space_lines(...)`
- TypeScript client: `jarvis.utilities.source_trailing_space_lines(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `source` | string | Yes | Source text |

**Request envelope:**

```json
{
  "name": "source_trailing_space_lines",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Statistics

### `spearman_correlation`

Compute Spearman rank correlation with tie averaging

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.spearman_correlation(...)`
- TypeScript client: `jarvis.utilities.spearman_correlation(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `first` | array | Yes | First numeric series |
| `second` | array | Yes | Second numeric series |

**Request envelope:**

```json
{
  "name": "spearman_correlation",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Measure

### `speed_from_distance`

Calculate average speed from time and distance

- API: `POST /api/utilities/run`
- Category: `measure`
- Python client: `jarvis.utilities.speed_from_distance(...)`
- TypeScript client: `jarvis.utilities.speed_from_distance(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `kilometers` | number | Yes | Distance in km |
| `hours` | number | Yes | Elapsed hours |

**Request envelope:**

```json
{
  "name": "speed_from_distance",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `sphere_volume`

Compute sphere volume and surface area

- API: `POST /api/utilities/run`
- Category: `measure`
- Python client: `jarvis.utilities.sphere_volume(...)`
- TypeScript client: `jarvis.utilities.sphere_volume(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `radius` | number | Yes | Sphere radius |

**Request envelope:**

```json
{
  "name": "sphere_volume",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Statistics

### `standard_error`

Compute standard error of sample mean

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.standard_error(...)`
- TypeScript client: `jarvis.utilities.standard_error(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Numeric samples |

**Request envelope:**

```json
{
  "name": "standard_error",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Dates

### `start_end_of_month`

Get first and last day of a month

- API: `POST /api/utilities/run`
- Category: `dates`
- Python client: `jarvis.utilities.start_end_of_month(...)`
- TypeScript client: `jarvis.utilities.start_end_of_month(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `date` | string | Yes | A date within the month |

**Request envelope:**

```json
{
  "name": "start_end_of_month",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Data

### `table_add_constant`

Add a fixed text field to every record

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.table_add_constant(...)`
- TypeScript client: `jarvis.utilities.table_add_constant(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `rows` | array | Yes | Rows |
| `column` | string | Yes | New field name |
| `value` | string | Yes | Assigned value |

**Request envelope:**

```json
{
  "name": "table_add_constant",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `table_column_average`

Average a numeric column, ignoring empty values

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.table_column_average(...)`
- TypeScript client: `jarvis.utilities.table_column_average(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `rows` | array | Yes | Rows |
| `column` | string | Yes | Field |

**Request envelope:**

```json
{
  "name": "table_column_average",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `table_column_statistics`

Numeric count, sum, mean, median and range

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.table_column_statistics(...)`
- TypeScript client: `jarvis.utilities.table_column_statistics(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `rows` | array | Yes | Rows |
| `column` | string | Yes | Field |

**Request envelope:**

```json
{
  "name": "table_column_statistics",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `table_column_sum`

Add a numeric column, ignoring empty values

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.table_column_sum(...)`
- TypeScript client: `jarvis.utilities.table_column_sum(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `rows` | array | Yes | Rows |
| `column` | string | Yes | Field |

**Request envelope:**

```json
{
  "name": "table_column_sum",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `table_columns`

List all columns present in a JSON table

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.table_columns(...)`
- TypeScript client: `jarvis.utilities.table_columns(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `rows` | array | Yes | Table of row objects |

**Request envelope:**

```json
{
  "name": "table_columns",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `table_cross_tab`

Produce frequency counts for combinations of columns

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.table_cross_tab(...)`
- TypeScript client: `jarvis.utilities.table_cross_tab(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `rows` | array | Yes | Rows |
| `columns` | array | Yes | Fields to group |

**Request envelope:**

```json
{
  "name": "table_cross_tab",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `table_date_bucket`

Group ISO date strings by month

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.table_date_bucket(...)`
- TypeScript client: `jarvis.utilities.table_date_bucket(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `rows` | array | Yes | Rows |
| `date_column` | string | Yes | ISO date field |

**Request envelope:**

```json
{
  "name": "table_date_bucket",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `table_distinct`

Remove duplicate complete JSON rows

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.table_distinct(...)`
- TypeScript client: `jarvis.utilities.table_distinct(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `rows` | array | Yes | Rows |

**Request envelope:**

```json
{
  "name": "table_distinct",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `table_drop_empty`

Remove rows whose specified fields are all empty

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.table_drop_empty(...)`
- TypeScript client: `jarvis.utilities.table_drop_empty(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `rows` | array | Yes | Rows |
| `columns` | array | Yes | Field names |

**Request envelope:**

```json
{
  "name": "table_drop_empty",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `table_fill_missing`

Replace absent or null fields with a chosen value

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.table_fill_missing(...)`
- TypeScript client: `jarvis.utilities.table_fill_missing(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `rows` | array | Yes | Rows |
| `column` | string | Yes | Field |
| `value` | string | Yes | Replacement text |

**Request envelope:**

```json
{
  "name": "table_fill_missing",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `table_filter_equal`

Filter rows by exact value for a named column

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.table_filter_equal(...)`
- TypeScript client: `jarvis.utilities.table_filter_equal(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `rows` | array | Yes | Rows |
| `column` | string | Yes | Field name |
| `value` | string | Yes | Desired text value |
| `case_sensitive` | boolean | No | Exact case match |

**Request envelope:**

```json
{
  "name": "table_filter_equal",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `table_filter_numeric`

Filter rows based on a number comparison

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.table_filter_numeric(...)`
- TypeScript client: `jarvis.utilities.table_filter_numeric(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `rows` | array | Yes | Rows |
| `column` | string | Yes | Field name |
| `comparison` | string | Yes | Comparison |
| `value` | number | Yes | Numeric threshold |

**Request envelope:**

```json
{
  "name": "table_filter_numeric",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `table_group_count`

Count records grouped by a categorical field

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.table_group_count(...)`
- TypeScript client: `jarvis.utilities.table_group_count(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `rows` | array | Yes | Rows |
| `column` | string | Yes | Category field |

**Request envelope:**

```json
{
  "name": "table_group_count",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `table_group_sum`

Sum a numeric column grouped by a category

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.table_group_sum(...)`
- TypeScript client: `jarvis.utilities.table_group_sum(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `rows` | array | Yes | Rows |
| `group_by` | string | Yes | Category field |
| `value_column` | string | Yes | Numeric field |

**Request envelope:**

```json
{
  "name": "table_group_sum",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `table_join`

Join two small tables on an exact string key

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.table_join(...)`
- TypeScript client: `jarvis.utilities.table_join(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `left` | array | Yes | Left table |
| `right` | array | Yes | Right table |
| `key` | string | Yes | Common join field |

**Request envelope:**

```json
{
  "name": "table_join",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `table_pivot_counts`

Count combinations of two categorical fields

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.table_pivot_counts(...)`
- TypeScript client: `jarvis.utilities.table_pivot_counts(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `rows` | array | Yes | Rows |
| `row_field` | string | Yes | Rows |
| `column_field` | string | Yes | Columns |

**Request envelope:**

```json
{
  "name": "table_pivot_counts",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `table_rename_column`

Rename one field in every row without changing values

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.table_rename_column(...)`
- TypeScript client: `jarvis.utilities.table_rename_column(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `rows` | array | Yes | Rows |
| `before` | string | Yes | Old name |
| `after` | string | Yes | New name |

**Request envelope:**

```json
{
  "name": "table_rename_column",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `table_select`

Select and reorder table columns

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.table_select(...)`
- TypeScript client: `jarvis.utilities.table_select(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `rows` | array | Yes | Rows |
| `columns` | array | Yes | Desired field names |

**Request envelope:**

```json
{
  "name": "table_select",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `table_sort`

Sort a table on a column, sorting missing values last

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.table_sort(...)`
- TypeScript client: `jarvis.utilities.table_sort(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `rows` | array | Yes | Rows |
| `column` | string | Yes | Sort column |
| `descending` | boolean | No | Reverse sort order |

**Request envelope:**

```json
{
  "name": "table_sort",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `table_take`

Take a bounded slice of rows

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.table_take(...)`
- TypeScript client: `jarvis.utilities.table_take(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `rows` | array | Yes | Rows |
| `start` | integer | No | Start index |
| `count` | integer | No | Maximum returned rows |

**Request envelope:**

```json
{
  "name": "table_take",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `table_transpose`

Transpose a small matrix of lists

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.table_transpose(...)`
- TypeScript client: `jarvis.utilities.table_transpose(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `matrix` | array | Yes | Rectangular matrix |

**Request envelope:**

```json
{
  "name": "table_transpose",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `table_unique`

Find unique values in one table column

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.table_unique(...)`
- TypeScript client: `jarvis.utilities.table_unique(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `rows` | array | Yes | Rows |
| `column` | string | Yes | Field |

**Request envelope:**

```json
{
  "name": "table_unique",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `table_value_counts`

Count occurrences of each value in a column

- API: `POST /api/utilities/run`
- Category: `data`
- Python client: `jarvis.utilities.table_value_counts(...)`
- TypeScript client: `jarvis.utilities.table_value_counts(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `rows` | array | Yes | Rows |
| `column` | string | Yes | Field |
| `limit` | integer | No | Results limit |

**Request envelope:**

```json
{
  "name": "table_value_counts",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `tax_addition`

Add a percentage-based tax as a mathematical operation

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.tax_addition(...)`
- TypeScript client: `jarvis.utilities.tax_addition(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `subtotal` | number | Yes | Subtotal |
| `tax_percent` | number | Yes | Tax rate |

**Request envelope:**

```json
{
  "name": "tax_addition",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Strings

### `text_diff`

Create a unified line-by-line difference between text versions

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.text_diff(...)`
- TypeScript client: `jarvis.utilities.text_diff(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `before` | string | Yes | Original |
| `after` | string | Yes | Updated |

**Request envelope:**

```json
{
  "name": "text_diff",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `text_similarity`

Compare two passages using lexical similarity and shared keywords

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.text_similarity(...)`
- TypeScript client: `jarvis.utilities.text_similarity(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `first` | string | Yes | First passage |
| `second` | string | Yes | Second passage |

**Request envelope:**

```json
{
  "name": "text_similarity",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `text_stats`

Profile word count sentences and document traits

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.text_stats(...)`
- TypeScript client: `jarvis.utilities.text_stats(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Text to analyze |

**Request envelope:**

```json
{
  "name": "text_stats",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `text_summary`

Select source sentences as a short extractive summary

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.text_summary(...)`
- TypeScript client: `jarvis.utilities.text_summary(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Passage |
| `sentences_count` | integer | No | Number of sentences |

**Request envelope:**

```json
{
  "name": "text_summary",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `text_wrap`

Wrap plain text to a specified column width

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.text_wrap(...)`
- TypeScript client: `jarvis.utilities.text_wrap(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Plain text |
| `width` | integer | No | Columns |
| `preserve_whitespace` | boolean | No | Preserve whitespace |

**Request envelope:**

```json
{
  "name": "text_wrap",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Dates

### `time_block_count`

Count complete focus blocks fitting into available minutes

- API: `POST /api/utilities/run`
- Category: `dates`
- Python client: `jarvis.utilities.time_block_count(...)`
- TypeScript client: `jarvis.utilities.time_block_count(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `available_minutes` | integer | Yes | Available time |
| `work_minutes` | integer | Yes | Work block length |
| `break_minutes` | integer | No | Rest block length |

**Request envelope:**

```json
{
  "name": "time_block_count",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `time_slot_schedule`

Make fixed-duration study or work slots

- API: `POST /api/utilities/run`
- Category: `dates`
- Python client: `jarvis.utilities.time_slot_schedule(...)`
- TypeScript client: `jarvis.utilities.time_slot_schedule(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `start` | string | Yes | ISO timestamp with timezone |
| `number` | integer | Yes | Slots |
| `slot_minutes` | integer | Yes | Time per slot |
| `break_minutes` | integer | No | Break after each slot |

**Request envelope:**

```json
{
  "name": "time_slot_schedule",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `timezone_convert`

Convert an explicit timestamp between IANA timezones

- API: `POST /api/utilities/run`
- Category: `dates`
- Python client: `jarvis.utilities.timezone_convert(...)`
- TypeScript client: `jarvis.utilities.timezone_convert(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `timestamp` | string | Yes | ISO datetime with UTC offset |
| `destination` | string | Yes | IANA zone name, e.g. Asia/Kolkata |

**Request envelope:**

```json
{
  "name": "timezone_convert",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `tip_calculator`

Calculate a total with a user-chosen gratuity

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.tip_calculator(...)`
- TypeScript client: `jarvis.utilities.tip_calculator(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `bill` | number | Yes | Bill amount |
| `tip_percent` | number | Yes | Tip percentage |
| `people` | integer | No | People sharing the bill |

**Request envelope:**

```json
{
  "name": "tip_calculator",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Strings

### `top_bigrams`

List common adjacent two-word phrases

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.top_bigrams(...)`
- TypeScript client: `jarvis.utilities.top_bigrams(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Passage |
| `limit` | integer | No | Phrase count |

**Request envelope:**

```json
{
  "name": "top_bigrams",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `top_keywords`

Extract common non-stopword terms from a passage

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.top_keywords(...)`
- TypeScript client: `jarvis.utilities.top_keywords(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Passage |
| `limit` | integer | No | Keyword count |

**Request envelope:**

```json
{
  "name": "top_keywords",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `triangle_area`

Triangle area using base and height

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.triangle_area(...)`
- TypeScript client: `jarvis.utilities.triangle_area(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `base` | number | Yes | Base |
| `height` | number | Yes | Height |

**Request envelope:**

```json
{
  "name": "triangle_area",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Probability

### `uniform_probability`

Probability of a subinterval in a uniform range

- API: `POST /api/utilities/run`
- Category: `probability`
- Python client: `jarvis.utilities.uniform_probability(...)`
- TypeScript client: `jarvis.utilities.uniform_probability(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `minimum` | number | Yes | Minimum |
| `maximum` | number | Yes | Maximum |
| `event_low` | number | Yes | Event lower limit |
| `event_high` | number | Yes | Event upper limit |

**Request envelope:**

```json
{
  "name": "uniform_probability",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Strings

### `url_decode_component`

Decode percent-encoded URL text

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.url_decode_component(...)`
- TypeScript client: `jarvis.utilities.url_decode_component(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Encoded text |

**Request envelope:**

```json
{
  "name": "url_decode_component",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `url_encode_component`

Percent-encode one URL path component

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.url_encode_component(...)`
- TypeScript client: `jarvis.utilities.url_encode_component(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Text |

**Request envelope:**

```json
{
  "name": "url_encode_component",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Statistics

### `value_growth_rate`

Compute growth rates between consecutive measurements

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.value_growth_rate(...)`
- TypeScript client: `jarvis.utilities.value_growth_rate(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Numeric series |

**Request envelope:**

```json
{
  "name": "value_growth_rate",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

### `variance`

Sample or population variance and standard deviation

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.variance(...)`
- TypeScript client: `jarvis.utilities.variance(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Numeric samples |
| `sample` | boolean | No | Use sample n-1 denominator |

**Request envelope:**

```json
{
  "name": "variance",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Dates

### `weekday`

Read weekday name and ISO weekday number for a date

- API: `POST /api/utilities/run`
- Category: `dates`
- Python client: `jarvis.utilities.weekday(...)`
- TypeScript client: `jarvis.utilities.weekday(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `date` | string | Yes | YYYY-MM-DD |

**Request envelope:**

```json
{
  "name": "weekday",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Numbers

### `weighted_average`

Calculate weighted arithmetic mean

- API: `POST /api/utilities/run`
- Category: `numbers`
- Python client: `jarvis.utilities.weighted_average(...)`
- TypeScript client: `jarvis.utilities.weighted_average(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Numeric values |
| `weights` | array | Yes | Nonnegative weights |

**Request envelope:**

```json
{
  "name": "weighted_average",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Strings

### `word_frequency`

Count words within a passage

- API: `POST /api/utilities/run`
- Category: `strings`
- Python client: `jarvis.utilities.word_frequency(...)`
- TypeScript client: `jarvis.utilities.word_frequency(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `text` | string | Yes | Passage |
| `limit` | integer | No | Maximum frequency rows |

**Request envelope:**

```json
{
  "name": "word_frequency",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.


## Statistics

### `z_scores`

Standardize samples using population deviation

- API: `POST /api/utilities/run`
- Category: `statistics`
- Python client: `jarvis.utilities.z_scores(...)`
- TypeScript client: `jarvis.utilities.z_scores(args)`

| Parameter | JSON type | Required | Description |
| --- | --- | --- | --- |
| `values` | array | Yes | Numeric samples |

**Request envelope:**

```json
{
  "name": "z_scores",
  "arguments": {}
}
```

**Result:** JSON object with `utility`, `category` and `result`.

