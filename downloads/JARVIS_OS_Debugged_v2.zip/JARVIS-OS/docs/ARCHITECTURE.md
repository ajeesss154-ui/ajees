# JARVIS OS: implementation architecture

## Actual boundaries

- **PC (host)**: Python/FastAPI server, persistent SQLite database, psutil telemetry,
  approved allowlisted PC app/website launch, a sandboxed workspace, and LLM API calls.
- **Phone**: responsive browser client on the same local network. A phone is a *remote
  terminal*, not an Android process controller. The server must be running to serve it.
- **AI brain**: Ollama's local `/api/chat` function-calling API (default `qwen3:4b`)
  or an optional OpenAI model through the Python SDK. This is not a separately trained AGI.
- **ML fallback**: optional TF-IDF + logistic regression intent classifier trained on
  example phrases to recognize five basic informational commands. It does not do
  general conversation. Ollama is the real conversational model.
- **Local retrieval**: the `search_knowledge` tool ranks relevant notes and workspace
  text files with optional TF-IDF/cosine similarity. This is keyword-based ML search,
  not neural semantic embeddings or autonomous learning.
- **Persistent state**: `jarvis.sqlite3` under the user's data directory; separate
  messages, user-approved facts, notes, tasks, reminders, approval records, notifications
  and an audit trail.
- **Voice**: browser Web Speech API for microphone transcription and browser speech
  synthesis for speaking replies. Exact recognition availability depends on browser,
  network and HTTPS; no claim of full offline STT.

## Chat tool lifecycle

```mermaid
flowchart LR
    A[Browser UI] --> B[FastAPI bearer auth]
    B --> C[Agent]
    C --> D[LLM provider]
    D -->|function call| E{Needs approval?}
    E -->|No| F[Allowlisted tool]
    E -->|Yes| G[Pending approval in SQLite]
    G --> H[Human approves or denies]
    H -->|Approved| F
    F --> I[Audit log]
    I --> C
    C --> B
    B --> A
```

## Threat model / security choices

1. **Never directly trust model-generated arguments.** Tool implementations validate all
   inputs and restrict functionality; no arbitrary shell command tool is exposed.
2. **High-impact actions require a fresh, one-use approval.** Approval requests expire
   after 10 minutes and can be declined. The backend ensures a decision is only taken
   once, reducing accidental duplicate execution.
3. **Local files are sandboxed.** Paths are resolved against a dedicated workspace.
   Hidden system folders and home-directory secrets cannot be read through a path
   like `../`. New file creation refuses overwrites. Symlinks leaving the workspace
   are rejected. This is a practical boundary, not an OS-level security sandbox.
4. **Token is generated locally** with high entropy and permission `0600` where
   supported. All private API endpoints require it. The browser stores it only in
   `sessionStorage`, not in a cookie. Static pages do not expose it.
5. **LAN access is opt-in** and plain HTTP is not secure against local-network
   interception. For production or Internet deployments add HTTPS, proper per-user
   accounts, device identity, rate limits and stronger audit controls.
6. **Privacy**: when using local Ollama, prompts go to your local Ollama server, not
   to OpenAI. Browser speech recognition *may* use a platform speech service depending
   on the browser; do not describe that feature as private/offline unconditionally.
7. **Prompt injection**: tools/notes/facts are untrusted source data, not policy.
   This is a mitigation, not proof the model cannot be tricked. Review all actions.
8. **Reminders**: persistent notifications are created when due, and shown in the
   interface when it next connects. The host process must be started again after a
   shutdown; this is not a background phone notification service.

## Version 0.2 extended architecture

- `jarvis/advanced/store.py` and `advanced/api.py`: SQLite-backed projects,
  goals, habits, calendar, focus sessions, metrics, bookmarks and preferences.
- `jarvis/advanced/workflows.py`: validation, bounded execution and scheduled
  read-only workflows through the existing tool permissions.
- `jarvis/advanced/learning.py` and `learning_api.py`: private flashcard decks
  with review scheduling.
- `jarvis/advanced/ideas.py` and `ideas_api.py`: idea scoring, experiments and
  user-supplied customer-feedback records.
- `jarvis/intelligence/`: local document indexing, ranked search, text analysis
  and context assembly for the agent.
- `jarvis/perception/`: optional local image description and WAV transcription
  with separately configured model dependencies.
- `jarvis/utilities/`: deterministic offline skills, including type validation,
  input budgets, domain rules and JSON API; not a general code interpreter.
- `jarvis/static/`: project dashboard, study deck UI, skill browser, idea lab,
  chat, browser voice controls and pending approval cards.
- `tools/generate_clients.py`: source generator reading FastAPI OpenAPI and the
  real utility registry and writing Python/TypeScript client methods and docs.
- `clients/python/` and `clients/typescript/`: reusable bearer-token developer
  APIs for PC/web/mobile front ends (no independent phone hardware control).

## Source map

| Path | Responsibility |
|---|---|
| `jarvis/config.py` | environment configuration and token bootstrap |
| `jarvis/storage.py` | SQLite schema and transaction-safe operations |
| `jarvis/tools.py` | tool definitions, parameter checks and computer actions |
| `jarvis/llm.py` | Ollama/OpenAI function-calling adapters |
| `jarvis/agent.py` | conversation loop, tool dispatch, memory injection |
| `jarvis/ml.py` | optional ML fallback intent classification |
| `jarvis/retrieval.py` | local TF-IDF retrieval over notes and workspace documents |
| `jarvis/api.py` | protected REST API and reminder worker |
| `jarvis/cli.py` | server CLI and config doctor |
| `jarvis/static/` | responsive UI, browser voice, dashboard |
| `tests/` | security, API, storage, tools and model-loop tests |

## Longer-term improvements beyond this prototype

For a production-grade multi-device assistant, next steps include independent,
explicitly permissioned Android/Windows agents, optional wake-word recognition,
fully local speech recognition and synthesis, production embedding/vector retrieval,
OAuth-scoped email/calendar integrations, permissioned accessibility APIs,
stronger encryption/key management, device identity/revocation, CI/CD and
real-device security and usability tests. The existing web UI has no Android OS
permissions, and its scheduled workflows are intentionally restricted.
