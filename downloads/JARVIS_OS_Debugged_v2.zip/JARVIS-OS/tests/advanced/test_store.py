"""Data isolation, validation and CRUD tests for assistant subsystems."""
from datetime import datetime, timedelta, timezone
from uuid import uuid4

import pytest

from jarvis.storage import Database
from jarvis.advanced.security import SecurityError
from jarvis.advanced.store import OperationsStore


@pytest.fixture
def ops(tmp_path):
    return OperationsStore(Database(tmp_path/'advanced.sqlite3'))


def test_projects_roundtrip_and_items(ops):
    project=ops.add_project('New research lab','Develop software assistants','purple')
    assert project['color']=='purple'
    assert len(ops.projects())==1
    item=ops.add_project_item(project['id'],'Build brain',priority=3)
    assert ops.projects()[0]['item_count']==1
    assert ops.set_project_item(item['id'],'doing')
    assert ops.project_items(project['id'])[0]['status']=='doing'
    assert ops.set_project_item(item['id'],'done')
    assert ops.projects()[0]['done_count']==1
    assert ops.update_project(project['id'],status='archived')
    assert ops.projects()==[]
    assert len(ops.projects(include_archived=True))==1


def test_project_validation_blocks_other_tables(ops):
    with pytest.raises(SecurityError):ops.add_project('X',color='invalid')
    with pytest.raises(SecurityError):ops.add_project_item(str(uuid4()),'Bad')
    project=ops.add_project('Valid')
    with pytest.raises(SecurityError):ops.add_project_item(project['id'],'x',priority=4)
    with pytest.raises(SecurityError):ops.set_project_item(str(uuid4()),'deleted')
    with pytest.raises(SecurityError):ops._update('sqlite_master','x',{'name':'bad'})


def test_goals_progress_and_validation(ops):
    goal=ops.add_goal('Release alpha',target_on='2027-01-01')
    assert goal['target_on']=='2027-01-01'
    assert ops.goals()[0]['progress']==0
    assert ops.update_goal(goal['id'],75)
    assert ops.goals()[0]['progress']==75
    assert ops.update_goal(goal['id'],100)
    assert ops.goals()[0]['status']=='completed'
    with pytest.raises(SecurityError):ops.update_goal(goal['id'],101)
    with pytest.raises(SecurityError):ops.update_goal(goal['id'],-1)
    with pytest.raises(SecurityError):ops.add_goal('bad',target_on='01/01/2027')


def test_habits_are_idempotent_and_no_future_marks(ops):
    habit=ops.add_habit('Read a chapter',3)
    today=datetime.now(timezone.utc).date().isoformat()
    assert ops.habit_check(habit['id'],today)
    assert not ops.habit_check(habit['id'],today)
    assert ops.habits()[0]['total_checks']==1
    assert ops.habit_check(habit['id'],today,False)
    assert ops.habits()[0]['total_checks']==0
    tomorrow=(datetime.now(timezone.utc)+timedelta(days=2)).date().isoformat()
    with pytest.raises(SecurityError):ops.habit_check(habit['id'],tomorrow)
    with pytest.raises(SecurityError):ops.add_habit('test',target_per_week=0)


def test_calendar_timezone_and_order(ops):
    start=(datetime.now(timezone.utc)+timedelta(hours=2)).isoformat()
    finish=(datetime.now(timezone.utc)+timedelta(hours=3)).isoformat()
    e=ops.create_event('Design meeting',start,finish,'Discuss UI','meeting')
    assert len(ops.events(start,finish))==1
    assert ops.remove_event(e['id'])
    assert ops.events(start,finish)==[]
    with pytest.raises(SecurityError):ops.create_event('Invalid',finish,start)
    with pytest.raises(SecurityError):ops.create_event('No timezone','2027-02-02T12:00:00',finish)
    with pytest.raises(SecurityError):ops.create_event('too long',start,(datetime.now(timezone.utc)+timedelta(days=90)).isoformat())


def test_bookmark_validations(ops):
    item=ops.add_bookmark('Docs','https://python.org')
    assert ops.bookmarks('docs')[0]['url']=='https://python.org'
    assert ops.delete_bookmark(item['id'])
    assert ops.bookmarks()==[]
    for url in ['http://example.org','https://localhost','https://127.0.0.1','file:///etc/passwd',
                'https://name:pass@example.com','https://[::1]/']:
        with pytest.raises(SecurityError):ops.add_bookmark('Bad',url)


def test_snippets_and_focus_timer(ops):
    item=ops.add_snippet('Example','print(1+1)','python')
    assert ops.snippets('print')[0]['content']=='print(1+1)'
    assert ops.delete_snippet(item['id'])
    assert ops.snippets()==[]
    start=ops.start_focus('Programming')
    with pytest.raises(SecurityError):ops.start_focus('Another active')
    end=ops.finish_focus(start['id'],'Completed a task')
    assert end['duration_seconds']>=0
    assert ops.focus_sessions()[0]['notes']=='Completed a task'
    with pytest.raises(SecurityError):ops.finish_focus(start['id'])


def test_schedules_claim_once(ops):
    wf=ops.save_workflow('Test','',[{'tool':'get_time','args':{}}])
    first=(datetime.now(timezone.utc)+timedelta(minutes=15)).isoformat()
    schedule=ops.add_schedule('Repeat',wf['id'],15,first)
    assert ops.schedules()[0]['id']==schedule['id']
    earlier=(datetime.now(timezone.utc)+timedelta(minutes=10)).isoformat()
    assert ops.claim_due_schedules(earlier)==[]
    later=(datetime.now(timezone.utc)+timedelta(minutes=20)).isoformat()
    assert len(ops.claim_due_schedules(later))==1
    assert ops.claim_due_schedules(later)==[]
    assert ops.toggle_schedule(schedule['id'],False)
    assert ops.schedules(enabled_only=True)==[]
    with pytest.raises(SecurityError):ops.add_schedule('bad',wf['id'],0,first)


def test_preferences_reject_arbitrary_keys(ops):
    assert ops.set_preference('theme','dark')['value']=='dark'
    assert ops.set_preference('speech_speed',1.1)['value']==1.1
    assert ops.preferences()['theme']=='dark'
    with pytest.raises(SecurityError):ops.set_preference('access_token','steal-me')
    with pytest.raises(SecurityError):ops.set_preference('speech_speed',999)
    with pytest.raises(SecurityError):ops.set_preference('notifications_enabled','false')


def test_activity_dashboard(ops):
    ops.add_project('Startup')
    ops.add_habit('Review progress')
    result=ops.dashboard()
    assert result['projects']==1 and result['habits']==1
    assert len(result['recent_activity'])>=2
