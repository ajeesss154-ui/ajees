"""Regression checks for concrete validation and persisted-index bugs."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from jarvis.intelligence.index import LocalIndex
from jarvis.intelligence.semantic import SemanticIndex, SemanticUnavailable
from jarvis.perception.audio import AudioRejected, WavValidator, wav_from_samples
from jarvis.storage import Database


def test_title_only_note_change_updates_index_and_title_search(tmp_path):
    db = Database(tmp_path / 'notes.sqlite3')
    folder = tmp_path / 'workspace'
    folder.mkdir()
    note = db.save_note('Original title', 'This content is unchanged.')
    index = LocalIndex(db, folder)
    index.refresh()
    with db.connect() as connection:
        connection.execute('UPDATE notes SET title=? WHERE id=?', ('Orbital launch study', note['id']))
    assert index.refresh()['changed_sources'] == 1
    hits = index.search('Orbital launch study')
    assert hits and hits[0]['title'] == 'Orbital launch study'
    assert index.refresh()['changed_sources'] == 0


def test_failed_source_reindex_preserves_previously_usable_index(tmp_path):
    db = Database(tmp_path / 'notes.sqlite3')
    folder = tmp_path / 'workspace'
    folder.mkdir()
    note = db.save_note('Original title', 'Original searchable orbital material.')
    index = LocalIndex(db, folder)
    index.refresh()
    with db.connect() as connection:
        connection.execute('UPDATE notes SET title=?,body=? WHERE id=?', ('New title', 'New source material.', note['id']))
        connection.execute("""CREATE TRIGGER reject_source_update BEFORE INSERT ON knowledge_chunks
                              WHEN NEW.title='New title'
                              BEGIN SELECT RAISE(ABORT,'test index write failure'); END""")
    assert index.refresh()['errors'] == 1
    assert index.search('orbital')[0]['title'] == 'Original title'
    assert index.sources()[0]['title'] == 'Original title'


def test_wav_rejects_truncated_or_incomplete_pcm_frames():
    valid = wav_from_samples([0, 100, -100, 20] * 200)
    assert WavValidator.inspect(valid).frames == 800
    with pytest.raises(AudioRejected):
        WavValidator.inspect(valid[:-20])
    with pytest.raises(AudioRejected):
        wav_from_samples([1, 2, 3], channels=2)


class FakeEmbedder:
    model_name = 'test-local-embedding'
    fail = False

    def embed(self, texts):
        if self.fail:
            raise SemanticUnavailable('Model unavailable')
        return [[1.0, 0.0] for _ in texts]


def test_failed_semantic_rebuild_preserves_existing_records():
    embedder = FakeEmbedder()
    index = SemanticIndex(embedder)
    index.build(['Original document'])
    embedder.fail = True
    with pytest.raises(SemanticUnavailable):
        index.build(['Replacement document'])
    assert index.texts == ['Original document']
    assert index.vectors == [[1.0, 0.0]]


@pytest.mark.parametrize('vectors', [None, {}, [[]], [['bad', 1]], [[True, 1]], [[float('nan'), 1]], [[float('inf'), 1]], [[10**500, 1]]])
def test_semantic_load_rejects_malformed_values_without_replacing_index(tmp_path, vectors):
    index = SemanticIndex(FakeEmbedder())
    index.build(['Original document'])
    source = tmp_path / 'index.json'
    source.write_text(json.dumps({'version': 1, 'model': 'test-local-embedding', 'texts': ['Untrusted document'], 'vectors': vectors}))
    with pytest.raises(ValueError):
        index.load(source)
    assert index.texts == ['Original document']
    assert index.vectors == [[1.0, 0.0]]


def test_index_and_workspace_backup_exclude_private_file_variants(tmp_path):
    from jarvis.advanced.backup import BackupManager
    import zipfile
    (tmp_path/'data').mkdir()
    db=Database(tmp_path/'data'/'db.sqlite3')
    folder=tmp_path/'workspace';folder.mkdir()
    (folder/'public.txt').write_text('Safe example document')
    for name in ['credentials.json', '.env.local', '.env.production.json', 'id_rsa.pem', 'server.key']:
        (folder/name).write_text('dummy secret fixture')
    index=LocalIndex(db,folder);index.refresh()
    assert [item['title'] for item in index.sources()]==['public.txt']
    backup=BackupManager(db,tmp_path/'data')
    saved=backup.create(include_workspace=True,workspace=folder)
    with zipfile.ZipFile(backup.directory/saved['filename']) as archive:
        workspace=[name for name in archive.namelist() if name.startswith('workspace/')]
    assert workspace==['workspace/public.txt']


def test_index_and_backup_reject_directory_alias_to_protected_content(tmp_path, monkeypatch):
    from jarvis.advanced.backup import BackupManager
    import zipfile
    data=tmp_path/'data';data.mkdir()
    db=Database(data/'db.sqlite3')
    folder=tmp_path/'workspace';folder.mkdir()
    private=folder/'.ssh';private.mkdir()
    (private/'settings.txt').write_text('dummy credential fixture')
    alias=folder/'public-alias';alias.symlink_to(private,target_is_directory=True)
    (folder/'public.txt').write_text('Safe public notes')
    original=Path.rglob
    def directory_walk(path, pattern):
        # Model a platform traversing an internal directory junction. The final
        # file reports is_symlink=False, so resolved-component checks matter.
        if path==folder:
            return iter([folder/'public.txt',alias/'settings.txt'])
        return original(path,pattern)
    monkeypatch.setattr(Path,'rglob',directory_walk)
    index=LocalIndex(db,folder);index.refresh()
    assert [item['title'] for item in index.sources()]==['public.txt']
    backup=BackupManager(db,data)
    saved=backup.create(include_workspace=True,workspace=folder)
    with zipfile.ZipFile(backup.directory/saved['filename']) as archive:
        workspace=[name for name in archive.namelist() if name.startswith('workspace/')]
    assert workspace==['workspace/public.txt']
