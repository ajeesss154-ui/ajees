from datetime import datetime, timedelta, timezone

import pytest

from jarvis.advanced.store import OperationsStore
from jarvis.advanced.workflows import WorkflowEngine,WORKFLOW_TEMPLATES
from jarvis.advanced.security import SecurityError
from jarvis.storage import Database
from jarvis.tools import ToolRegistry
from jarvis.config import Settings


@pytest.fixture
def engine(tmp_path):
    settings=Settings(data_dir=tmp_path/'data',workspace=tmp_path/'data'/'workspace',
                      access_token='workflow-test-token-long-enough',enable_ml_fallback=False)
    db=Database(settings.database_path)
    store=OperationsStore(db)
    return WorkflowEngine(store,ToolRegistry(db,settings))


def test_templates_validate(engine):
    for template in WORKFLOW_TEMPLATES:
        assert engine.dry_run(template['steps'])['valid']


def test_workflow_run_records_results(engine):
    wf=engine.create('Diagnostic','Computer health',WORKFLOW_TEMPLATES[0]['steps'])
    result=engine.run(wf['id'])
    assert result['status']=='completed'
    assert len(result['results'])==2
    assert all(step['ok'] for step in result['results'])
    assert len(engine.store.workflow_runs(wf['id']))==1
    assert engine.run(wf['id'])['status']=='completed'


def test_reject_tools_with_approvals(engine):
    with pytest.raises(SecurityError):engine.create('Risk','',
        [{'tool':'open_website','args':{'url':'https://example.org'}}])
    with pytest.raises(SecurityError):engine.create('Write','',
        [{'tool':'create_task','args':{'title':'bad'}}])
    with pytest.raises(SecurityError):engine.create('Invalid','',
        [{'tool':'get_time','args':{'unknown':'bad'}}])


def test_disabled_workflow_not_run(engine):
    wf=engine.create('One','',WORKFLOW_TEMPLATES[0]['steps'])
    engine.store.toggle_workflow(wf['id'],False)
    with pytest.raises(SecurityError):engine.run(wf['id'])


def test_schedule_tick_read_only(engine):
    wf=engine.create('One','',WORKFLOW_TEMPLATES[0]['steps'])
    first=(datetime.now(timezone.utc)+timedelta(minutes=16)).isoformat()
    sched=engine.create_schedule('Periodic',wf['id'],15,first)
    assert engine.tick()==[]
    with engine.store.db.connect() as db:
        db.execute('UPDATE schedules SET next_run_at=? WHERE id=?',
                   ((datetime.now(timezone.utc)-timedelta(minutes=1)).isoformat(),sched['id']))
    outputs=engine.tick()
    assert len(outputs)==1
    assert outputs[0]['status']=='completed'
    assert engine.tick()==[]
