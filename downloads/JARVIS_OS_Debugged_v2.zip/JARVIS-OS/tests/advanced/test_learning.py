"""Persistent study data and private API tests."""
from datetime import date,timedelta

import pytest

from jarvis.advanced.learning import StudyLibrary
from jarvis.advanced.security import SecurityError
from jarvis.storage import Database


@pytest.fixture
def library(tmp_path):
    return StudyLibrary(Database(tmp_path/'jarvis.db'))


def test_decks_and_card_lifecycle(library):
    deck=library.create_deck('Math derivatives','Chain rule and derivatives')
    assert library.decks()[0]['title']=='Math derivatives'
    card=library.add_card(deck['id'],'Derivative of x**2?','2x','calculus')
    assert library.get_card(card['id'])['back']=='2x'
    assert library.cards(deck['id'],'derivative')[0]['id']==card['id']
    assert library.decks()[0]['due']==1
    assert library.update_card(card['id'],back='2*x')
    assert library.get_card(card['id'])['back']=='2*x'
    exported=library.export_deck(deck['id'])
    assert exported['cards'][0]['front'].startswith('Derivative')
    assert library.update_deck(deck['id'],archived=True)
    assert library.decks()==[]
    assert library.decks(True)[0]['archived']==1
    assert library.delete_card(card['id'])
    assert not library.get_card(card['id'])


def test_spaced_repetition_schedule(library):
    deck=library.create_deck('AI concepts')
    card=library.add_card(deck['id'],'What is a neural network?','A model of connected layers.')
    assert library.due()[0]['id']==card['id']
    review=library.review(card['id'],5)
    assert review['interval_days']==1
    assert len(library.due())==0
    second=library.review(card['id'],5)
    assert second['interval_days']==6
    third=library.review(card['id'],2)
    assert third['repetitions']==0
    assert third['interval_days']==1
    assert library.statistics()['reviews']==3
    assert len(library.reviews(card['id']))==3


def test_early_review_and_unknown_deck(library):
    with pytest.raises(SecurityError):
        library.add_card('nonexistent','Q?','A')
    deck=library.create_deck('Notes')
    card=library.add_card(deck['id'],'Q','A')
    with pytest.raises(SecurityError):
        library.review(card['id'],6)
    with pytest.raises(SecurityError):
        library.review(card['id'],-1)
    with pytest.raises(SecurityError):
        library.review(card['id'],4,day='not a date')
    assert library.statistics()['decks']==1
    assert library.statistics()['cards']==1


def test_library_api(client,headers):
    assert client.get('/api/study/decks').status_code==401
    deck=client.post('/api/study/decks',headers=headers,json={
        'title':'Python 101'}).json()
    assert deck['title']=='Python 101'
    card=client.post('/api/study/decks/'+deck['id']+'/cards',headers=headers,
        json={'front':'What is Python?','back':'A programming language'}).json()
    assert card['front']=='What is Python?'
    assert len(client.get('/api/study/due',headers=headers).json())==1
    reviewed=client.post('/api/study/cards/'+card['id']+'/review',headers=headers,
        json={'grade':4})
    assert reviewed.status_code==200,reviewed.text
    assert len(client.get('/api/study/due',headers=headers).json())==0
    assert client.get('/api/study/statistics',headers=headers).json()['reviews']==1
    assert client.get('/api/study/decks/'+deck['id']+'/export',headers=headers).json()['cards']
    assert client.patch('/api/study/cards/'+card['id'],headers=headers,
        json={'back':'A high-level language'}).json()['updated']
    assert client.delete('/api/study/cards/'+card['id'],headers=headers).json()['deleted']


def test_import_deck_cards(client,headers):
    deck=client.post('/api/study/decks',headers=headers,json={'title':'Science'}).json()
    payload={'cards':[{'front':'A','back':'1'},{'front':'B','back':'2'}]}
    r=client.post('/api/study/decks/'+deck['id']+'/import',headers=headers,json=payload)
    assert r.status_code==201,r.text
    assert len(client.get('/api/study/decks/'+deck['id']+'/cards',headers=headers).json())==2
