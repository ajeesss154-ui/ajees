from io import BytesIO
import base64
import wave

import pytest

from jarvis.perception.images import ImageRejected,ImageValidator
from jarvis.perception.audio import AudioRejected,WavValidator,wav_from_samples


def test_images_roundtrip_with_pillow():
    from PIL import Image
    image=Image.new('RGB',(128,64),(10,20,30))
    buffer=BytesIO();image.save(buffer,format='PNG')
    content=buffer.getvalue()
    value=base64.b64encode(content).decode('ascii')
    facts=ImageValidator.inspect(ImageValidator.from_base64(value))
    assert facts.width==128 and facts.height==64
    assert facts.mime=='image/png'
    assert len(facts.sha256)==64


def test_image_invalid_inputs():
    with pytest.raises(ImageRejected):ImageValidator.from_base64('@@!??')
    with pytest.raises(ImageRejected):ImageValidator.inspect(b'not an image')
    with pytest.raises(ImageRejected):ImageValidator.from_base64('data:text/html;base64,PGgxPkhlbGxvPC9oMT4=')


def test_wav_validation():
    samples=[0,200,-200,500,-500]*500
    data=wav_from_samples(samples)
    info=WavValidator.inspect(data)
    assert info.channels==1 and info.sample_rate==16000
    assert info.seconds>0
    with pytest.raises(AudioRejected):WavValidator.inspect(b'bad')
    with pytest.raises(AudioRejected):wav_from_samples([1,2,3],sample_rate=5)
