from pathlib import Path

import pytest

from jarvis.advanced.security import (
    CapabilityPolicy,SecurityError,TokenBucket,RateLimiter,
    redact_secrets,validate_relative_path,validate_url,validate_label,
    validate_slug,validate_id,bounded_json,safe_nested_lookup,
    normalize_origin,create_pairing_code
)


def test_secret_redaction():
    assert '[REDACTED]' in redact_secrets('Authorization: Bearer abcdefghijklmnop')
    assert 'supersecretpassword' not in redact_secrets('password=supersecretpassword')
    assert '[REDACTED]' in redact_secrets('sk-ABCDEFGHIJKLMNOPQ')


@pytest.mark.parametrize('value',[None,'','  ','\x00secret'])
def test_reject_labels(value):
    with pytest.raises(SecurityError):validate_label(value)


@pytest.mark.parametrize('value',['https://localhost:8000','http://example.org',
    'https://192.168.1.5/','https://10.0.0.1','https://127.0.0.1',
    'https://user:pass@example.org','ftp://example.org','https://[::1]'])
def test_reject_private_urls(value):
    with pytest.raises(SecurityError):validate_url(value)


def test_validate_good_url():
    assert validate_url('https://example.org/docs?x=1')=='https://example.org/docs?x=1'


def test_paths_cannot_escape(tmp_path):
    root=tmp_path/'space';root.mkdir()
    outside=tmp_path/'secret.txt';outside.write_text('hidden')
    (root/'link.txt').symlink_to(outside)
    for name in ['../secret.txt','/etc/passwd','credentials.json','.env','link.txt','../../x']:
        with pytest.raises(SecurityError):validate_relative_path(root,name)
    assert validate_relative_path(root,'safe.txt')==root/'safe.txt'


def test_capability_policy_write_actions_are_excluded():
    policy=CapabilityPolicy()
    policy.check_workflow(['get_time','list_tasks'])
    for dangerous in ['launch_app','open_website','create_workspace_file','save_snippet',
                      'create_task','remember_fact']:
        with pytest.raises(SecurityError):policy.check_workflow([dangerous])
    with pytest.raises(SecurityError):policy.check_workflow(['get_time']*50)


def test_rate_limit_by_client():
    limiter=RateLimiter(rate=.2,burst=2)
    assert limiter.permit('a',100)
    assert limiter.permit('a',100)
    assert not limiter.permit('a',100)
    assert limiter.permit('b',100)
    assert limiter.permit('a',110)


def test_json_bounds():
    assert bounded_json({'a':True})=='{"a":true}'
    with pytest.raises(SecurityError):bounded_json({'a':'x'*100},max_bytes=10)
    assert safe_nested_lookup({'a':{'b':3}},'a.b')==3
    with pytest.raises(SecurityError):safe_nested_lookup({'a':3},'a.__class__')
    with pytest.raises(SecurityError):normalize_origin('null')
    assert normalize_origin('https://example.org')=='https://example.org'
    assert len(create_pairing_code())==9


def test_unicode_token_comparison_returns_a_boolean():
    from jarvis.advanced.security import secure_compare
    assert secure_compare('valid-token', 'valid-token')
    assert not secure_compare('valid-token', 'invalid-token')
    assert not secure_compare('valid-token', 'tökén')
    assert secure_compare('tökén', 'tökén')
    assert not secure_compare('valid-token', '\ud800')
    assert not secure_compare(None, 'valid-token')


@pytest.mark.parametrize('name', ['.env.local', '.env.production', 'ID_RSA.pem', 'id_ed25519.pub', 'server.pfx', 'secret.PEM'])
def test_sensitive_workspace_names_are_consistently_blocked(tmp_path, name):
    from jarvis.advanced.security import is_protected_name
    assert is_protected_name(name)
    with pytest.raises(SecurityError):
        validate_relative_path(tmp_path, name)


def test_workspace_alias_cannot_bypass_secret_target_filter(tmp_path):
    hidden = tmp_path / '.env.local'
    hidden.write_text('dummy secret fixture')
    (tmp_path / 'innocent.txt').symlink_to(hidden)
    with pytest.raises(SecurityError):
        validate_relative_path(tmp_path, 'innocent.txt')


@pytest.mark.parametrize('host', ['127.1', '127.0.1', '0x7f000001', '017700000001', '0x7f.0.0.1'])
def test_alternative_numeric_loopback_not_accepted_as_hostname(host):
    with pytest.raises(SecurityError):
        validate_url('https://' + host)
