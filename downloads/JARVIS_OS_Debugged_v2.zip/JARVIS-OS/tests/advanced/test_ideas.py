"""Startup idea lab persistence and API integration checks."""
from __future__ import annotations

import pytest

from jarvis.storage import Database
from jarvis.advanced.ideas import IdeaLab
from jarvis.advanced.security import SecurityError


@pytest.fixture
def lab(tmp_path):
    return IdeaLab(Database(tmp_path/'lab.db'))


def test_idea_scoring_and_search(lab):
    first=lab.create_idea('Private AI assistant','People have scattered tools',
                         'Unify tasks, notes and reminders',impact=8,confidence=6,effort=4)
    second=lab.create_idea('Voice recipes','Hard to search for dinner','Voice cookbook',
                          impact=5,confidence=5,effort=10)
    assert first['priority_score']==12
    assert lab.ideas()[0]['id']==first['id']
    assert lab.ideas(query='Voice')[0]['id']==second['id']
    assert lab.update_idea(second['id'],status='research',impact=10)
    assert lab.ideas(status='research')[0]['impact']==10
    assert lab.delete_idea(second['id'])
    assert not lab.get_idea(second['id'])


def test_experiments_and_decisions(lab):
    idea=lab.create_idea('JARVIS Mobile','Poor task workflow','New UI')
    exp=lab.add_experiment(idea['id'],'Mobile form is faster',
                           'seconds per completed task','At least 20% decrease')
    assert exp['status']=='planned'
    assert lab.conclude_experiment(exp['id'],'completed','Median time dropped','Keep feature')
    assert lab.experiments(idea['id'])[0]['conclusion']=='Keep feature'
    decision=lab.record_decision('UI framework','Small local project',
                  ['Vanilla JS','React'],'Vanilla JS','Low dependencies')
    assert decision['options']==['Vanilla JS','React']
    assert lab.decisions()[0]['title']=='UI framework'
    assert lab.overview()['decisions']==1
    with pytest.raises(SecurityError):
        lab.delete_idea(idea['id'])


def test_feedback_inbox(lab):
    record=lab.add_feedback('Demo user','Offline mode matters')
    assert record['status']=='new'
    assert lab.feedback(status='new')[0]['message']=='Offline mode matters'
    assert lab.update_feedback(record['id'],'reviewed')
    assert lab.overview()['new_feedback']==0
    with pytest.raises(SecurityError):
        lab.update_feedback(record['id'],'unknown')


def test_idea_lab_api(client,headers):
    assert client.get('/api/lab/overview').status_code==401
    created=client.post('/api/lab/ideas',headers=headers,json={
        'title':'Personal AI','problem':'Too many apps','solution':'One smart dashboard',
        'impact':8,'confidence':7,'effort':4})
    assert created.status_code==201,created.text
    idea=created.json()
    assert idea['priority_score']==14
    assert client.get('/api/lab/ideas',headers=headers).json()[0]['id']==idea['id']
    exp=client.post('/api/lab/experiments',headers=headers,json={
        'idea_id':idea['id'],'hypothesis':'Fast tasks improve productivity',
        'metric':'completion time','success_criterion':'Less than 5 minutes'})
    assert exp.status_code==201,exp.text
    assert client.patch('/api/lab/experiments/'+exp.json()['id'],headers=headers,
        json={'status':'completed','conclusion':'Positive result'}).json()['updated']
    feedback=client.post('/api/lab/feedback',headers=headers,
        json={'source':'Friend','message':'Works on phone'}).json()
    assert client.patch('/api/lab/feedback/'+feedback['id'],headers=headers,
        json={'status':'reviewed'}).status_code==200
    assert client.get('/api/lab/overview',headers=headers).json()['decisions']==0
    assert client.patch('/api/lab/ideas/'+idea['id'],headers=headers,
        json={'impact':11}).status_code==422
    assert client.delete('/api/lab/ideas/'+idea['id'],headers=headers).status_code==400
