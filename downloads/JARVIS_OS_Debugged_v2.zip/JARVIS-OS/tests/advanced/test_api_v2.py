"""Real FastAPI integration coverage for all private v2 routes."""
from datetime import datetime,timezone,timedelta

import pytest


def test_v2_requires_token(client,headers):
    routes=['/api/v2/dashboard','/api/v2/projects','/api/v2/goals',
            '/api/v2/habits','/api/v2/events','/api/v2/bookmarks',
            '/api/v2/workflows','/api/v2/schedules','/api/v2/metrics',
            '/api/v2/backups','/api/knowledge/stats','/api/perception/features']
    for path in routes:
        assert client.get(path).status_code==401,path
        assert client.get(path,headers=headers).status_code==200,path


def test_projects_and_items_api(client,headers):
    r=client.post('/api/v2/projects',headers=headers,json={
        'name':'JARVIS V2','description':'Code','color':'cyan'})
    assert r.status_code==201,r.text
    project=r.json()
    r=client.post(f'/api/v2/projects/{project["id"]}/items',headers=headers,
        json={'title':'Implement server','priority':3})
    assert r.status_code==201,r.text
    item=r.json()
    assert len(client.get('/api/v2/projects',headers=headers).json())==1
    assert client.patch(f'/api/v2/project-items/{item["id"]}',headers=headers,
        json={'status':'done'}).json()['updated']
    assert client.get(f'/api/v2/projects/{project["id"]}/items',headers=headers).json()[0]['status']=='done'
    assert client.patch(f'/api/v2/projects/{project["id"]}',headers=headers,
        json={'status':'archived'}).json()['updated']
    assert client.get('/api/v2/projects',headers=headers).json()==[]


def test_goals_habits_and_focus_api(client,headers):
    response=client.post('/api/v2/goals',headers=headers,json={'title':'Finish school project'})
    assert response.status_code==201,response.text
    goal=response.json()
    assert client.patch(f'/api/v2/goals/{goal["id"]}',headers=headers,
        json={'progress':45}).json()['updated']
    habit=client.post('/api/v2/habits',headers=headers,
        json={'name':'Study programming','target_per_week':3}).json()
    assert habit['name']=='Study programming'
    day=datetime.now(timezone.utc).date().isoformat()
    assert client.post(f'/api/v2/habits/{habit["id"]}/check',headers=headers,
        json={'day':day,'checked':True}).json()['changed']
    assert client.get('/api/v2/habits',headers=headers).json()[0]['total_checks']==1
    active=client.post('/api/v2/focus',headers=headers,json={'topic':'Testing'}).json()
    assert 'id' in active
    assert client.post(f'/api/v2/focus/{active["id"]}/finish',headers=headers,
        json={'notes':'Finished integration tests'}).status_code==200


def test_calendar_and_bookmarks_api(client,headers):
    start=(datetime.now(timezone.utc)+timedelta(days=1)).isoformat()
    end=(datetime.now(timezone.utc)+timedelta(days=1,hours=1)).isoformat()
    data={'title':'Review work','start':start,'end':end}
    res=client.post('/api/v2/events',headers=headers,json=data)
    assert res.status_code==201,res.text
    assert client.get('/api/v2/events',headers=headers).json()[0]['title']=='Review work'
    assert client.delete('/api/v2/events/'+res.json()['id'],headers=headers).json()['deleted']
    invalid=client.post('/api/v2/events',headers=headers,json={**data,'end':start})
    assert invalid.status_code==400
    link=client.post('/api/v2/bookmarks',headers=headers,
                     json={'title':'Python','url':'https://python.org'})
    assert link.status_code==201,link.text
    assert len(client.get('/api/v2/bookmarks',headers=headers).json())==1
    assert client.delete('/api/v2/bookmarks/'+link.json()['id'],headers=headers).json()['deleted']
    assert client.post('/api/v2/bookmarks',headers=headers,
                       json={'title':'Bad','url':'https://localhost/private'}).status_code==400


def test_workflow_and_schedule_api(client,headers):
    data={'name':'Status check','steps':[{'tool':'get_time','args':{}},
                                         {'tool':'list_tasks','args':{'include_completed':False}}]}
    valid=client.post('/api/v2/workflows/validate',headers=headers,json=data)
    assert valid.status_code==200,valid.text
    created=client.post('/api/v2/workflows',headers=headers,json=data)
    assert created.status_code==201,created.text
    wf=created.json()
    result=client.post('/api/v2/workflows/'+wf['id']+'/run',headers=headers).json()
    assert result['status']=='completed'
    assert len(client.get('/api/v2/workflows/'+wf['id']+'/runs',headers=headers).json())==1
    future=(datetime.now(timezone.utc)+timedelta(hours=1)).isoformat()
    schedule=client.post('/api/v2/schedules',headers=headers,json={
        'name':'Hourly check','workflow_id':wf['id'],'interval_minutes':60,'first_at':future})
    assert schedule.status_code==201,schedule.text
    assert len(client.get('/api/v2/schedules',headers=headers).json())==1
    assert client.patch('/api/v2/schedules/'+schedule.json()['id'],headers=headers,
                        json={'enabled':False}).json()['updated']
    bad=client.post('/api/v2/workflows',headers=headers,json={
        'name':'Dangerous','steps':[{'tool':'launch_app','args':{'name':'calculator'}}]})
    assert bad.status_code==400


def test_backups_and_preferences_api(client,headers):
    change=client.patch('/api/v2/settings',headers=headers,json={'key':'theme','value':'dark'})
    assert change.status_code==200
    assert client.get('/api/v2/settings',headers=headers).json()['theme']=='dark'
    assert client.patch('/api/v2/settings',headers=headers,
        json={'key':'access_token','value':'fake'}).status_code==400
    backup=client.post('/api/v2/backups',headers=headers,json={'include_workspace':False})
    assert backup.status_code==201,backup.text
    filename=backup.json()['filename']
    assert client.get('/api/v2/backups/'+filename+'/validate',headers=headers).json()['valid']
    assert len(client.get('/api/v2/backups',headers=headers).json())==1


def test_knowledge_api(client,headers,app):
    client.post('/api/notes',headers=headers,json={'title':'Demo','body':'A local JARVIS assistant stores notes and actions.'})
    refresh=client.post('/api/knowledge/refresh',headers=headers)
    assert refresh.status_code==200,refresh.text
    res=client.post('/api/knowledge/search',headers=headers,
                    json={'query':'notes assistant','limit':4})
    assert res.status_code==200,res.text
    assert len(res.json())>0
    summary=client.post('/api/knowledge/text/summary',headers=headers,json={
        'text':'JARVIS is a software assistant. It helps track projects and tasks.','sentences_count':1})
    assert summary.status_code==200
    profile=client.post('/api/knowledge/text/profile',headers=headers,json={'text':'Hello JARVIS world.'})
    assert profile.json()['words']==3
    assert client.post('/api/knowledge/search',headers=headers,json={'query':'x','kind':'bad'}).status_code==400


def test_media_rejects_invalid_input(client,headers):
    assert client.post('/api/perception/image',headers=headers,
        json={'prompt':'Describe','image_base64':'a'*50}).status_code==400
    assert client.post('/api/perception/audio',headers=headers,
        json={'wav_base64':'a'*50}).status_code==400
