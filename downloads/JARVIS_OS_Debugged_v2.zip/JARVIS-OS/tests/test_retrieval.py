from jarvis.storage import Database
from jarvis.retrieval import KnowledgeSearch


def test_local_knowledge_retrieval(settings):
    db=Database(settings.database_path)
    db.save_note('Astronomy research', 'Black holes, neutron stars, and a telescope observation program.')
    db.save_note('Startup plan', 'Build a personal AI assistant for PCs and phones.')
    (settings.workspace/'project.md').write_text('The dashboard uses Python FastAPI and SQLite memory.')
    search=KnowledgeSearch(db,settings.workspace)
    hits=search.search('Python FastAPI dashboard')
    assert hits and hits[0]['source'] == 'workspace:project.md'
    hits=search.search('neutron star telescope')
    assert hits and hits[0]['title'] == 'Astronomy research'


def test_retrieval_never_leaves_workspace(settings):
    db=Database(settings.database_path)
    out=settings.data_dir/'outside.md'
    out.write_text('secret text outside of workspace')
    (settings.workspace/'external.md').symlink_to(out)
    results=KnowledgeSearch(db,settings.workspace).search('secret text')
    assert results == []


def test_search_excludes_credentials_and_hidden_private_directories(settings):
    db = Database(settings.database_path)
    for relative in ["credentials.json", "SECRETS.JSON", ".env.local", ".ssh/profile.txt", ".git/config.json"]:
        path = settings.workspace / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("sentinel-private-credential", encoding="utf-8")
    (settings.workspace / "safe.md").write_text("ordinary public workspace note", encoding="utf-8")
    search = KnowledgeSearch(db, settings.workspace)
    assert [doc["title"] for doc in search.documents()] == ["safe.md"]
    assert search.search("sentinel-private-credential") == []
    assert search.search("ordinary public workspace")
