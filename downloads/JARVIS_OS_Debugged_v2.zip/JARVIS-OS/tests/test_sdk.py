"""End-to-end contract checks for the generated Python developer SDK."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "clients" / "python"))
from jarvis_sdk import JarvisAPIError, JarvisClient


def test_sdk_calls_live_local_api(app, settings):
    sdk = JarvisClient(token=settings.access_token)
    try:
        sdk._http.close()
        with TestClient(app, headers={"Authorization": f"Bearer {settings.access_token}"}) as transport:
            sdk._http = transport
            assert sdk.routes.health_api_health_get() == {"status": "ok"}
            result = sdk.utilities.percent_of(part=20, whole=250)
            assert result["utility"] == "percent_of"
            assert result["result"] == 50
            result = sdk.utilities.add_days(date="2026-10-30", days=2)
            assert result["result"] == "2026-11-01"
            count = sdk.routes.stats_api_utilities_stats_get()
            assert count["skills"] >= 280
            with pytest.raises(JarvisAPIError) as error:
                sdk.utilities.percent_of(part=1, whole='not-a-number')
            # Server-side schema validation rejects wrong argument types.
            assert error.value.status in (400, 422)
    finally:
        sdk.close()


def test_sdk_refuses_unsafe_transport():
    with pytest.raises(ValueError, match='HTTPS'):
        JarvisClient(token='sample-secret', base_url='http://192.168.2.10:8765')
    with pytest.raises(ValueError, match='required'):
        JarvisClient(token='')
    with pytest.raises(ValueError, match='credentials'):
        JarvisClient(token='secret', base_url='https://alice:password@example.com')


def test_sdk_rejects_external_paths():
    sdk = JarvisClient(token='sample-secret')
    try:
        with pytest.raises(ValueError, match='Only JARVIS'):
            sdk._request('GET', 'https://malicious.example/path')
        with pytest.raises(ValueError, match='Unsupported'):
            sdk._request('TRACE', '/api/health')
    finally:
        sdk.close()


def test_generated_utility_sdk_matches_every_registered_skill():
    from jarvis.utilities.catalog import build_utility_registry
    sdk = JarvisClient(token='local-development-token')
    try:
        skills = build_utility_registry().catalog()
        assert len(skills) >= 280
        for item in skills:
            assert callable(getattr(sdk.utilities, item['name'], None)), item['name']
    finally:
        sdk.close()


@pytest.mark.parametrize('base_url', [
    'https://jarvis.example/?wrong=1',
    'https://jarvis.example/#ignored',
])
def test_sdk_rejects_ambiguous_server_urls(base_url):
    with pytest.raises(ValueError, match='query or fragment'):
        JarvisClient(token='local-test-token', base_url=base_url)


@pytest.mark.parametrize('path', [
    '/api/../private', '/api/%2e%2e/private', '/api/health#ignored',
    '/api/..\\private',
])
def test_sdk_rejects_traversal_before_sending_request(path):
    with JarvisClient(token='local-test-token') as sdk:
        with pytest.raises(ValueError, match='Only JARVIS'):
            sdk._request('GET', path)
