from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from threading import Barrier

from jarvis.storage import Database


def test_reminder_claims_are_once_only_across_concurrent_pollers(settings):
    db = Database(settings.database_path)
    due = (datetime.now(timezone.utc) - timedelta(seconds=1)).isoformat(timespec="seconds")
    reminder = db.add_reminder("Notify once", due)
    gate = Barrier(8)

    def poll(_):
        gate.wait(timeout=5)
        return db.due_reminders()

    with ThreadPoolExecutor(max_workers=8) as workers:
        batches = list(workers.map(poll, range(8)))

    claimed = [item for batch in batches for item in batch]
    assert [item["id"] for item in claimed] == [reminder["id"]]
    assert len(db.notifications()) == 1
    assert db.due_reminders() == []
    assert db.reminders() == []
