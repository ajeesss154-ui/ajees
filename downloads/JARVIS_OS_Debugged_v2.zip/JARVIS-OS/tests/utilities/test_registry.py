"""Contracts for deterministic offline skills and the JARVIS adapter."""
from __future__ import annotations

import json
import math

import pytest

from jarvis.utilities.catalog import build_utility_registry
from jarvis.utilities.core import UtilityError, Utility, UtilityRegistry, N, S, A
from jarvis.utilities.assistant_tools import install_utility_tools
from jarvis.tools import ToolRegistry
from jarvis.storage import Database


@pytest.fixture(scope='module')
def skills():
    return build_utility_registry()


def run(skills, name, **arguments):
    return skills.execute(name, arguments)['result']


def test_all_skills_have_valid_schema(skills):
    catalog=skills.catalog()
    assert len(catalog)>=260
    assert len({item['name'] for item in catalog})==len(catalog)
    assert all(item['description'] for item in catalog)
    for skill in catalog:
        assert skill['parameters']['type']=='object'
        assert skill['parameters']['additionalProperties'] is False
        assert set(skill['parameters']['required']).issubset(skill['parameters']['properties'])
    assert len(skills.categories())>=10


def test_type_validation_primitive(skills):
    with pytest.raises(UtilityError,match='numeric'):
        run(skills,'percent_of',part='twenty',whole=100)
    with pytest.raises(UtilityError,match='Unsupported'):
        run(skills,'percent_of',part=20,whole=100,password='ignore')
    with pytest.raises(UtilityError,match='Missing'):
        run(skills,'percent_of',part=20)
    with pytest.raises(UtilityError,match='Unknown'):
        run(skills,'secret_shell',command='whoami')


def test_invalid_payloads(skills):
    for payload in (None, [], 'hello', 11):
        with pytest.raises(UtilityError):
            skills.execute('percent_of',payload)
    with pytest.raises(UtilityError):
        run(skills,'parse_csv',text='x'*15001)
    with pytest.raises(UtilityError):
        run(skills,'table_columns',rows=[['a'],['b']])
    with pytest.raises(UtilityError):
        run(skills,'graph_components',nodes=['x'],edges=[['x','unknown']])
    with pytest.raises(UtilityError):
        run(skills,'python_functions',source='def missing(:\n pass')


def test_registry_prevents_duplicates():
    reg=UtilityRegistry()
    spec=Utility('my_skill','math','Test skill',{'x':N('Input')},lambda x:x)
    reg.add(spec)
    with pytest.raises(UtilityError,match='Duplicate'):
        reg.add(spec)
    with pytest.raises(UtilityError,match='Invalid'):
        reg.add(Utility('bad-name','math','Bad',{},lambda :None))
    with pytest.raises(UtilityError,match='documented'):
        reg.add(Utility('wrong_arg','math','Mismatch',{'y':N('Y')},lambda x:x))


def test_local_data_skills(skills):
    table=[{'city':'A','amount':3},{'city':'B','amount':5},
           {'city':'A','amount':7}]
    assert run(skills,'table_column_sum',rows=table,column='amount')['sum']==15
    assert run(skills,'table_group_count',rows=table,column='city')==[
        {'group':'A','count':2},{'group':'B','count':1}]
    assert run(skills,'table_filter_numeric',rows=table,column='amount',
               comparison='gt',value=5)==[{'city':'A','amount':7}]
    assert run(skills,'table_select',rows=table,columns=['amount'])==[
        {'amount':3},{'amount':5},{'amount':7}]
    assert run(skills,'table_distinct',rows=[table[0],table[0],table[1]])==table[:2]
    csv_data=run(skills,'make_csv',rows=table)
    result=run(skills,'parse_csv',text=csv_data)
    assert result['count']==3
    assert result['rows'][0]['amount']=='3'
    diff=run(skills,'json_object_diff',before={'a':1,'b':2},after={'a':4,'c':3})
    assert set(diff['added'])=={'c'}
    assert set(diff['removed'])=={'b'}
    assert set(diff['changed'])=={'a'}


def test_graph_tools(skills):
    edges=[['a','b'],['a','c'],['c','d']]
    result=run(skills,'graph_shortest_path',nodes=['a','b','c','d'],edges=edges,
               source='a',target='d')
    assert result['path']==['a','c','d']
    assert result['distance']==2
    sorted_nodes=run(skills,'graph_topological_order',nodes=['a','b','c','d'],edges=edges)
    assert sorted_nodes.index('a')<sorted_nodes.index('b')
    with pytest.raises(UtilityError,match='cycle'):
        run(skills,'graph_topological_order',nodes=['a','b'],edges=[['a','b'],['b','a']])
    components=run(skills,'graph_components',nodes=['a','b','c'],edges=[['a','b']])
    assert components['count']==2
    weighted=run(skills,'graph_weighted_shortest_path',nodes=['a','b','c'],
                 edges=[['a','b',1],['b','c',2],['a','c',8]],source='a',target='c')
    assert weighted['distance']==3
    assert weighted['path']==['a','b','c']
    critical=run(skills,'graph_critical_path',tasks=[
        {'id':'design','duration':2,'dependencies':[]},
        {'id':'code','duration':5,'dependencies':['design']},
        {'id':'test','duration':3,'dependencies':['code']}])
    assert critical['critical_path']==['design','code','test']
    assert critical['total_duration']==10


def test_software_analysis_does_not_execute_code(skills,tmp_path):
    marker=tmp_path/'never.txt'
    source=f"open({str(marker)!r}, 'w').write('secret')\n"
    assert run(skills,'python_syntax_check',source=source)['valid']
    assert not marker.exists()
    assert run(skills,'python_call_names',source=source)[0]['name']=='write'
    assert run(skills,'python_functions',source='def f(x):\n return x+1')==[
        {'name':'f','async':False,'arguments':['x'],
         'decorators':0,'line':1,'end_line':2}]
    imports=run(skills,'python_unused_import_candidates',source='import os\nprint("hello")')
    assert imports==[{'name':'os','line':1}]
    assert run(skills,'python_syntax_check',source='def (')['valid'] is False
    assert run(skills,'source_diff',before='a\nb',after='a\nc')['changed']


def test_probability_and_series(skills):
    assert run(skills,'binomial_exact',trials=4,successes=2,p=.5)==pytest.approx(.375)
    assert run(skills,'combinations',n=10,k=3)==120
    assert run(skills,'normal_cdf',z=0)==pytest.approx(.5)
    assert run(skills,'independent_or',p=.5,q=.5)==pytest.approx(.75)
    assert run(skills,'shannon_entropy',probabilities=[.5,.5])==pytest.approx(1)
    assert run(skills,'series_moving_average',values=[1,2,3,4],window=2)==[1.5,2.5,3.5]
    assert run(skills,'series_differences',values=[2,5,11])==[3.,6.]
    assert run(skills,'series_cumulative_sum',values=[1,3,6])==[1.,4.,10.]
    assert run(skills,'series_forecast_last',values=[1,3,6],steps=2)['forecast']==[6.,6.]
    assert run(skills,'series_run_lengths',values=['x','x','y'])==[
        {'value':'x','length':2},{'value':'y','length':1}]
    assert run(skills,'series_anomaly_iqr',values=[1,2,3,4,50])['outliers'][0]['value']==50


def test_assistant_tool_adapter(settings):
    db=Database(settings.database_path)
    jarvis_tools=ToolRegistry(db,settings)
    install_utility_tools(jarvis_tools)
    assert 'run_local_utility' in [schema['function']['name'] for schema in jarvis_tools.schemas()]
    result=jarvis_tools.handle('run_local_utility',{'name':'percent_of',
        'arguments_json':json.dumps({'part':5,'whole':200})},audit=False)
    assert result['ok'] is True
    assert result['result']['result']==10
    rejected=jarvis_tools.handle('run_local_utility',{'name':'python_syntax_check',
        'arguments_json':'{"source":"bad"}'},audit=False)
    assert rejected['ok'] is True
    bad=jarvis_tools.handle('run_local_utility',{'name':'shell',
        'arguments_json':'{"command":"echo test"}'},audit=False)
    assert 'error' in bad


def test_utilities_api_authentication(client,headers):
    assert client.get('/api/utilities/catalog').status_code==401
    assert client.get('/api/utilities/categories',headers=headers).status_code==200
    catalog=client.get('/api/utilities/catalog',headers=headers).json()
    assert len(catalog)>=260
    response=client.post('/api/utilities/run',headers=headers,
        json={'name':'percent_of','arguments':{'part':12,'whole':50}})
    assert response.status_code==200,response.text
    assert response.json()['result']==6
    assert client.post('/api/utilities/run',headers=headers,
        json={'name':'unknown','arguments':{}}).status_code==400
    assert client.post('/api/utilities/run',headers=headers,
        json={'name':'percent_of','arguments':{'part':'bad','whole':50}}).status_code==400
    assert client.get('/api/utilities/catalog/percent_of',headers=headers).status_code==200
    assert client.get('/api/utilities/catalog/no-such-thing',headers=headers).status_code==404
