"""Restricted AST algebra tests, including code-injection attempts."""
from __future__ import annotations

import os

import pytest

from jarvis.utilities.catalog import build_utility_registry
from jarvis.utilities.core import UtilityError


@pytest.fixture(scope='module')
def r():
    return build_utility_registry()


def test_derivative_chain_rule(r):
    result=r.execute('math_derivative',{'expression':'(x**2+4)**3'})['result']
    assert result['derivative']=='6*x*(x**2 + 4)**2'


def test_second_derivative(r):
    result=r.execute('math_derivative',{'expression':'x**4','order':2})['result']
    assert result['derivative']=='12*x**2'


def test_symbolic_polynomial_roots(r):
    result=r.execute('math_solve_polynomial',{'expression':'x**2 - 5*x + 6'})['result']
    assert result['roots']==['2','3']


def test_limits_and_integration(r):
    result=r.execute('math_limit',{'expression':'sin(x)/x','point':0})['result']
    assert result['limit']=='1'
    assert r.execute('math_indefinite_integral',{'expression':'3*x**2'})['result']['integral']=='x**3 + C'


def test_gradient(r):
    result=r.execute('math_gradient',{'expression':'x**2 + y**2'})['result']
    assert result=={'x':'2*x','y':'2*y'}


def test_rejects_attribute_execution(r,tmp_path):
    marker=tmp_path/'injected.txt'
    expr=f'__import__("os").system("touch {marker}")'
    with pytest.raises(UtilityError):
        r.execute('math_simplify',{'expression':expr})
    assert not marker.exists()


def test_rejects_huge_powers(r):
    with pytest.raises(UtilityError,match='Power'):
        r.execute('math_expand',{'expression':'x**999999'})


def test_rejects_unsupported_python_constructs(r):
    for expr in ('[x for x in range(100)]','x.__class__','(lambda x:x)(2)',
                 'open("hello.txt")','x if x > 0 else 0'):
        with pytest.raises(UtilityError):
            r.execute('math_simplify',{'expression':expr})


def test_zero_polynomial(r):
    result=r.execute('math_polynomial_coefficients',{'expression':'0'})['result']
    assert result['coefficients']==['0']
