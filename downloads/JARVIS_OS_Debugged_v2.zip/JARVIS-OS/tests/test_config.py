from pathlib import Path

import pytest

from jarvis.config import Settings


@pytest.mark.parametrize("token", ["too-short", " " * 32, "a" * 20 + " ", "a" * 20 + "é", "x" * 513])
def test_custom_access_token_validation(tmp_path, token):
    with pytest.raises(ValueError, match="printable ASCII"):
        Settings(data_dir=tmp_path / "data", access_token=token)


def test_generated_token_is_stable_and_custom_valid_token_is_accepted(tmp_path, monkeypatch):
    monkeypatch.delenv("JARVIS_ACCESS_TOKEN", raising=False)
    first = Settings(data_dir=tmp_path / "data")
    again = Settings(data_dir=tmp_path / "data")
    assert len(first.access_token) >= 32
    assert first.access_token == again.access_token
    custom = Settings(data_dir=tmp_path / "other", access_token="custom-long-token-for-local-testing")
    assert custom.access_token == "custom-long-token-for-local-testing"
