"""Optional browser regression: run with Python Playwright and installed Chromium.

Uses the real static UI and explicit test-only HTTP fixtures. No AI service is called.
Set CHROME_EXECUTABLE_PATH to use an existing Chrome; otherwise Playwright's Chromium.
"""
from __future__ import annotations
import json
import os
from pathlib import Path
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread
from urllib.parse import urlsplit
from playwright.sync_api import sync_playwright, Error

ASSETS = Path(__file__).resolve().parents[1] / 'jarvis' / 'static'

class Handler(SimpleHTTPRequestHandler):
    def translate_path(self, raw):
        route = urlsplit(raw).path
        relative = route.removeprefix('/static/') if route.startswith('/static/') else 'index.html'
        target = (ASSETS / relative).resolve()
        return str(target if target.is_relative_to(ASSETS) else ASSETS / 'missing')
    def log_message(self, *_args):
        pass


def main():
    server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    Thread(target=server.serve_forever, daemon=True).start()
    try:
        with sync_playwright() as p:
            options = {'headless': True}
            if os.getenv('CHROME_EXECUTABLE_PATH'):
                options['executable_path'] = os.environ['CHROME_EXECUTABLE_PATH']
            browser = p.chromium.launch(**options)
            page = browser.new_page()
            page.add_init_script("""
                window.__stoppedRecognition = 0; window.__spoken = [];
                class Speech {
                    start() {} stop() { this.abort(); }
                    abort() { window.__stoppedRecognition++; this.onend?.(); }
                }
                window.SpeechRecognition = Speech;
                Object.defineProperty(window, 'speechSynthesis', {value:{
                    cancel(){}, speak(u){window.__spoken.push(u.text);}
                }});
            """)
            pending_chat = []
            def route_api(route):
                path = urlsplit(route.request.url).path
                if path == '/api/chat' and not pending_chat:
                    pending_chat.append(route)
                    return
                if path == '/api/chat':
                    data = {'reply': 'A fresh reply', 'tools_used': [], 'approvals': []}
                elif path == '/api/me':
                    data = {'provider':'fixture', 'model':'browser-test'}
                elif path == '/api/status':
                    data = {'ok':False, 'error':'Test fixture has no telemetry'}
                else:
                    data = []
                route.fulfill(status=200, content_type='application/json', body=json.dumps(data))
            page.route('**/api/**', route_api)
            page.goto(f'http://127.0.0.1:{server.server_port}')
            page.locator('#accessToken').fill('test-only-token')
            page.locator('#loginForm button').click()
            page.locator('#loginOverlay').wait_for(state='hidden')
            page.locator('#voiceToggle').click()
            page.locator('#micBtn').click()
            page.locator('#chatInput').fill('This pending answer must be discarded')
            page.locator('#sendBtn').click()
            page.get_by_text('Thinking...', exact=True).wait_for()
            page.locator('#logout').click()
            page.locator('#loginOverlay').wait_for(state='visible')
            assert page.evaluate('window.__stoppedRecognition') >= 1
            assert page.evaluate('state.requests.size') == 0
            assert page.locator('#chatMessages').inner_text() == ''
            try:
                pending_chat[0].fulfill(status=200, content_type='application/json', body=json.dumps({'reply':'Late private response'}))
            except Error:
                pass  # The browser correctly aborted this request at disconnect.
            page.wait_for_timeout(100)
            assert 'Late private response' not in page.locator('body').inner_text()
            assert page.evaluate('window.__spoken') == []
            page.locator('#accessToken').fill('fresh-test-token')
            page.locator('#loginForm button').click()
            page.locator('#loginOverlay').wait_for(state='hidden')
            page.locator('#chatInput').fill('A new session request')
            page.locator('#sendBtn').click()
            page.get_by_text('A fresh reply', exact=True).wait_for()
            assert page.evaluate('state.busy') is False
            browser.close()
            print('PASS: disconnect cancels requests and microphone, discards late replies, and allows reconnect.')
    finally:
        server.shutdown()
        server.server_close()

if __name__ == '__main__':
    main()
