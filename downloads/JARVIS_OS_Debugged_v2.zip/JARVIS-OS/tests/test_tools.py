from __future__ import annotations

from datetime import datetime, timezone, timedelta
import pytest

from jarvis.storage import Database
from jarvis.tools import ToolRegistry, safe_calculate, ToolError, parse_due_at


@pytest.fixture
def tools(settings):
    return ToolRegistry(Database(settings.database_path),settings)


def test_safe_arithmetic():
    assert safe_calculate('(4+5)*7') == 63
    assert safe_calculate('2**6') == 64
    assert safe_calculate('-3.5*2') == -7
    for dangerous in ["__import__('os').system('whoami')",'10**1000000','2/0','x+3','[1,2]','abs(-3)']:
        with pytest.raises(ToolError):
            safe_calculate(dangerous)


def test_memory_notes_tasks(tools):
    assert tools.handle('remember_fact',{'key':'Favorite language','value':'Python'})['ok']
    assert tools.handle('recall_facts',{})['result'][0]['value'] == 'Python'
    assert tools.handle('forget_fact',{'key':'Favorite language'})['result']['forgotten']
    assert tools.handle('add_note',{'title':'test','body':'100% safe'})['ok']
    assert len(tools.handle('search_notes',{'query':'% safe'})['result']) == 1
    assert tools.handle('create_task',{'title':'test task'})['ok']
    assert len(tools.handle('list_tasks',{})['result']) == 1


def test_workspace_security(tools, settings):
    workspace=settings.workspace
    (workspace/'hello.md').write_text('Hello from the workspace')
    assert tools.handle('read_workspace_file',{'path':'hello.md'})['result']['content'].startswith('Hello')
    assert 'error' in tools.handle('read_workspace_file',{'path':'../access_token'})
    assert 'error' in tools.handle('read_workspace_file',{'path':'/etc/passwd'})
    assert 'error' in tools.handle('read_workspace_file',{'path':'missing.md'})
    assert tools.handle('create_workspace_file',{'path':'new.md','content':'hello'})['approval_required']
    assert not (workspace/'new.md').exists()
    assert tools.handle('create_workspace_file',{'path':'new.md','content':'hello'},approved=True)['ok']
    assert (workspace/'new.md').read_text() == 'hello'
    assert 'error' in tools.handle('create_workspace_file',{'path':'new.md','content':'overwrite'},approved=True)
    (workspace/'evil.md').symlink_to(settings.data_dir/'access_token')
    assert 'error' in tools.handle('read_workspace_file',{'path':'evil.md'})


def test_open_site_requires_permission(tools, monkeypatch):
    called=[]
    monkeypatch.setattr('jarvis.tools.webbrowser.open', lambda url: (called.append(url), True)[1])
    pending=tools.handle('open_website',{'url':'https://example.com'})
    assert pending['approval_required'] and called == []
    assert 'error' in tools.handle('open_website',{'url':'javascript:alert(1)'},approved=True)
    assert 'error' in tools.handle('open_website',{'url':'file:///etc/passwd'},approved=True)
    assert tools.handle('open_website',{'url':'https://example.com'},approved=True)['ok']
    assert called == ['https://example.com']


def test_reminder_must_have_timezone():
    with pytest.raises(ToolError):parse_due_at('2027-11-01T09:00:00')
    in_1h=(datetime.now(timezone.utc)+timedelta(hours=1)).isoformat()
    assert parse_due_at(in_1h).endswith('+00:00')


def test_open_site_reports_browser_failure_instead_of_success(tools, monkeypatch):
    monkeypatch.setattr("jarvis.tools.webbrowser.open", lambda url: False)
    result = tools.handle("open_website", {"url": "https://example.com"}, approved=True)
    assert "error" in result
    assert "ok" not in result
    assert "No browser accepted" in result["error"]


@pytest.mark.parametrize("invalid", [True, False, 1.5, "7", None])
def test_integer_tool_arguments_are_validated_before_handler(tools, invalid):
    from jarvis.tools import ToolDefinition, obj
    seen = []
    tools.register(ToolDefinition("integer_contract", "Test integer contract",
                                 obj({"value": {"type": "integer"}}, ["value"]),
                                 lambda args: seen.append(args["value"])))
    assert "error" in tools.handle("integer_contract", {"value": invalid})
    assert seen == []
    assert tools.handle("integer_contract", {"value": 7})["ok"]
    assert seen == [7]


def test_workspace_tools_reject_protected_files_and_directories(tools, settings):
    root = settings.workspace
    (root / "credentials.json").write_text('{"token":"private-fixture"}')
    (root / ".git").mkdir()
    (root / ".git" / "notes.md").write_text("private repository fixture")
    assert "error" in tools.handle("read_workspace_file", {"path": "credentials.json"})
    assert "error" in tools.handle("read_workspace_file", {"path": ".git/notes.md"})
    assert "error" in tools.handle("create_workspace_file", {"path": ".git/new.md", "content": "bad"}, approved=True)
    visible = tools.handle("list_workspace", {})["result"]
    assert not any(item["name"] in {"credentials.json", ".git"} for item in visible)
    assert not (root / ".git" / "new.md").exists()


def test_workspace_tools_reject_sensitive_variants_and_symlink_aliases(tools, settings):
    root = settings.workspace
    (root / ".env.json").write_text('{"token":"private-fixture"}')
    assert "error" in tools.handle("read_workspace_file", {"path": ".env.json"})
    assert "error" in tools.handle("create_workspace_file", {"path": "id_rsa.json", "content": "secret"}, approved=True)
    try:
        (root / "ordinary.json").symlink_to(root / ".env.json")
    except (OSError, NotImplementedError):
        pytest.skip("This environment cannot create symbolic links")
    assert "error" in tools.handle("read_workspace_file", {"path": "ordinary.json"})
