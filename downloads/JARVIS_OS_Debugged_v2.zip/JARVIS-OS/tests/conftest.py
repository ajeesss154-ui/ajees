from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from jarvis.api import create_app
from jarvis.config import Settings


@pytest.fixture
def settings(tmp_path):
    return Settings(data_dir=tmp_path / "data", workspace=tmp_path / "workspace",
                    provider="ollama", access_token="test-super-secret-token", enable_ml_fallback=False)


@pytest.fixture
def app(settings):
    return create_app(settings)


@pytest.fixture
def client(app):
    with TestClient(app) as c:
        yield c


@pytest.fixture
def headers(settings):
    return {"Authorization": f"Bearer {settings.access_token}"}
