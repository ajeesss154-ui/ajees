from __future__ import annotations

import pytest
from jarvis.agent import JarvisAgent, AgentDeps
from jarvis.llm import ModelReply, FunctionCall, ModelUnavailable
from jarvis.storage import Database
from jarvis.tools import ToolRegistry


class ToolThenFinal:
    def __init__(self): self.calls = 0
    async def complete(self,messages,tools):
        self.calls += 1
        if self.calls == 1:
            return ModelReply('',[FunctionCall('get_time',{})],{
                'role':'assistant','content':'','tool_calls':[
                    {'function':{'name':'get_time','arguments':{}}}]
            })
        assert messages[-1]['role'] == 'tool'
        return ModelReply('It is now daytime.',[],{'role':'assistant','content':'It is now daytime.'})


class ApprovalModel:
    async def complete(self,messages,tools):
        return ModelReply('Opening your website.',[FunctionCall('open_website',{'url':'https://example.com'})],
                          {'role':'assistant','content':'Opening your website.','tool_calls':[
                              {'function':{'name':'open_website','arguments':{'url':'https://example.com'}}}]})


class FailingModel:
    async def complete(self,messages,tools):
        raise ModelUnavailable('not connected')


def deps(settings):
    db=Database(settings.database_path)
    return AgentDeps(db,ToolRegistry(db,settings),settings)


@pytest.mark.asyncio
async def test_agent_executes_read_only_tool(settings):
    assistant=JarvisAgent(deps(settings),ToolThenFinal())
    answer=await assistant.chat('what time is it?','testsession')
    assert answer.reply == 'It is now daytime.'
    assert answer.tools_used == ['get_time']
    assert answer.approvals == []
    assert len(assistant.deps.db.history('testsession')) == 2


@pytest.mark.asyncio
async def test_agent_requires_approval(settings):
    assistant=JarvisAgent(deps(settings),ApprovalModel())
    answer=await assistant.chat('open example.com','session')
    assert len(answer.approvals) == 1
    assert 'NOT been executed' in answer.reply
    assert assistant.deps.db.approvals()[0]['tool'] == 'open_website'


@pytest.mark.asyncio
async def test_offline_fallback(settings):
    assistant=JarvisAgent(deps(settings),FailingModel())
    answer=await assistant.chat('status','session')
    assert answer.offline
    assert 'Offline basic-command mode' in answer.reply
    unknown=await assistant.chat('explain the history of computing','session')
    assert 'AI brain' in unknown.reply


class OversizedToolBatch:
    def __init__(self):
        self.calls = 0

    async def complete(self, messages, tools):
        self.calls += 1
        calls = [FunctionCall("create_task", {"title": f"Unexpected task {i}"}, f"call-{i}")
                 for i in range(6)]
        assistant = {"role": "assistant", "content": "", "tool_calls": [
            {"id": call.call_id, "type": "function", "function": {
                "name": call.name, "arguments": '{"title":"unexpected"}'}}
            for call in calls]}
        return ModelReply("", calls, assistant)


@pytest.mark.asyncio
@pytest.mark.parametrize("provider_name", ["ollama", "openai"])
async def test_oversized_tool_batch_is_rejected_before_any_action(settings, provider_name):
    settings.provider = provider_name
    provider = OversizedToolBatch()
    assistant = JarvisAgent(deps(settings), provider)
    answer = await assistant.chat("create six tasks", "oversized-batch")
    assert "too many actions" in answer.reply
    assert answer.tools_used == []
    assert answer.approvals == []
    assert assistant.deps.db.tasks(include_completed=True) == []
    assert provider.calls == 1
    assert len(assistant.deps.db.history("oversized-batch")) == 2
