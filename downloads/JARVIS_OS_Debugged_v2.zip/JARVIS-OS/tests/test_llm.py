from __future__ import annotations

import httpx
import pytest
from jarvis.llm import OllamaProvider, ModelUnavailable


@pytest.mark.asyncio
async def test_ollama_function_call_is_parsed(settings, monkeypatch):
    calls=[]
    def handler(request):
        payload = __import__('json').loads(request.content)
        calls.append(payload)
        return httpx.Response(200,json={'message': {'role':'assistant','content':'',
            'tool_calls':[{'function':{'name':'get_time','arguments':{}}}]}})
    actual=httpx.AsyncClient
    monkeypatch.setattr('jarvis.llm.httpx.AsyncClient',lambda **kw:actual(transport=httpx.MockTransport(handler),**kw))
    result=await OllamaProvider(settings).complete([{'role':'user','content':'time'}],[])
    assert result.calls[0].name == 'get_time'
    assert calls[0]['stream'] is False
    assert calls[0]['model'] == settings.ollama_model


@pytest.mark.asyncio
async def test_ollama_connection_error_is_explained(settings,monkeypatch):
    def handler(request):
        raise httpx.ConnectError('test not running')
    actual=httpx.AsyncClient
    monkeypatch.setattr('jarvis.llm.httpx.AsyncClient',lambda **kw:actual(transport=httpx.MockTransport(handler),**kw))
    with pytest.raises(ModelUnavailable,match='Ollama is unavailable'):
        await OllamaProvider(settings).complete([{'role':'user','content':'hi'}],[])
