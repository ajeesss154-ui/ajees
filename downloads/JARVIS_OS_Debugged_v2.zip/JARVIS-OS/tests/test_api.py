from __future__ import annotations

from datetime import datetime, timezone, timedelta


def test_private_endpoints_need_token(client, headers):
    assert client.get('/api/health').json() == {'status': 'ok'}
    assert client.get('/').status_code == 200
    assert client.get('/api/notes').status_code == 401
    assert client.get('/api/notes', headers={'Authorization':'Bearer wrong'}).status_code == 401
    assert client.get('/api/notes', headers=headers).status_code == 200
    assert client.get('/api/me', headers=headers).json()['provider'] == 'ollama'


def test_tasks_notes_and_history(client, headers):
    task = client.post('/api/tasks', headers=headers, json={'title':'Finish JARVIS MVP'})
    assert task.status_code == 201
    task_id = task.json()['id']
    assert len(client.get('/api/tasks',headers=headers).json()) == 1
    assert client.post(f'/api/tasks/{task_id}/complete',headers=headers).json()['completed']
    note = client.post('/api/notes',headers=headers,json={'title':'Idea','body':'voice on mobile'})
    assert note.status_code == 201
    assert client.get('/api/notes',headers=headers).json()[0]['body'] == 'voice on mobile'
    assert client.get('/api/history/demo',headers=headers).json() == []


def test_reminder_utc_and_notifications(client, headers, app):
    due = (datetime.now(timezone.utc)+timedelta(seconds=5)).isoformat()
    res = client.post('/api/reminders',headers=headers,json={'text':'Wake up','due_at':due})
    assert res.status_code == 201
    assert len(client.get('/api/reminders',headers=headers).json()) == 1
    past = (datetime.now(timezone.utc)-timedelta(seconds=5)).isoformat()
    assert client.post('/api/reminders',headers=headers,json={'text':'Old','due_at':past}).status_code == 400
    assert client.post('/api/reminders',headers=headers,json={'text':'Unzoned','due_at':'2027-01-01T12:00:00'}).status_code == 400
    # Make due without sleeping to avoid flaky timer tests.
    with app.state.db.connect() as db:
        db.execute('UPDATE reminders SET due_at=?', (past,))
    notices = client.get('/api/notifications',headers=headers).json()
    assert len(notices) == 1 and notices[0]['text'] == 'Wake up'
    assert len(client.get('/api/notifications',headers=headers).json()) == 1
    assert client.post('/api/notifications/'+notices[0]['id']+'/ack',headers=headers).json()['acknowledged']
    assert client.get('/api/notifications',headers=headers).json() == []


def test_approval_only_once(client, headers, app):
    tools = app.state.registry
    pending = tools.handle('open_website', {'url':'https://example.org'})
    assert pending['approval_required']
    assert client.get('/api/approvals',headers=headers).json()[0]['id'] == pending['id']
    # Deny before touching webbrowser to keep this a deterministic unit test.
    url = '/api/approvals/'+pending['id']
    assert client.post(url+'/deny',headers=headers).json()['status'] == 'denied'
    assert client.post(url+'/approve',headers=headers).status_code == 404


def test_malformed_api_requests(client, headers):
    assert client.post('/api/chat',headers=headers,json={'message':'   ','session_id':'x'}).status_code == 422
    assert client.post('/api/notes',headers=headers,json={'title':'','body':'body'}).status_code == 422
    assert client.post('/api/tasks',headers=headers,json={'title':'x'*301}).status_code == 422


def test_live_chat_endpoint_with_fake_llm(settings):
    from jarvis.api import create_app
    from fastapi.testclient import TestClient
    from jarvis.llm import ModelReply
    class Brain:
        async def complete(self, messages, tools):
            return ModelReply('JARVIS here. Systems green.')
    with TestClient(create_app(settings, provider=Brain())) as app_client:
        headers = {'Authorization': 'Bearer '+settings.access_token}
        response = app_client.post('/api/chat', headers=headers,
                                   json={'message':'Hello','session_id':'demo123'})
        assert response.status_code == 200
        assert response.json()['reply'] == 'JARVIS here. Systems green.'
        history = app_client.get('/api/history/demo123',headers=headers).json()
        assert [m['role'] for m in history] == ['user','assistant']


def test_non_ascii_bearer_token_is_unauthorized_not_server_error(client):
    response = client.get("/api/me", headers=[(b"authorization", b"Bearer caf\xe9-super-secret-token")])
    assert response.status_code == 401
