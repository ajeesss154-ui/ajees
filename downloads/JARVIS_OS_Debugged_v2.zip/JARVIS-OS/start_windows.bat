@echo off
setlocal EnableExtensions
pushd "%~dp0" || exit /b 1
if exist ".venv\Scripts\python.exe" goto check_python

echo Creating the JARVIS Python environment...
where py >nul 2>nul
if not errorlevel 1 (
  py -3 -m venv .venv
) else (
  python -m venv .venv
)
if errorlevel 1 goto missing_python
if not exist ".venv\Scripts\python.exe" goto missing_python

:check_python
".venv\Scripts\python.exe" -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 11) else 1)"
if errorlevel 1 goto missing_python

echo Installing JARVIS and the optional basic command classifier...
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -e ".[ml]"
if errorlevel 1 goto failed

echo.
echo Open http://127.0.0.1:8765 after the server starts.
echo The terminal displays your private access token. Keep it private.
echo Full local AI needs Ollama and a model: ollama pull qwen3:4b
".venv\Scripts\python.exe" -m jarvis serve
if errorlevel 1 goto failed
popd
exit /b 0

:missing_python
echo Python 3.11 or newer is required. Python 3.12 is recommended.
echo Install Python from https://www.python.org/downloads/ and reopen this file.
echo If an existing .venv uses an older Python, create a fresh virtual environment.
goto failed

:failed
echo JARVIS could not start. Read the error above.
popd
pause
exit /b 1
