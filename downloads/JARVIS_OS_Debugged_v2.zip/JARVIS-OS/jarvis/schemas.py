"""Strict request/response contracts."""
from __future__ import annotations

from pydantic import BaseModel, Field, field_validator
import uuid


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=6000)
    session_id: str = Field(default_factory=lambda: str(uuid.uuid4()), max_length=80)

    @field_validator("message")
    @classmethod
    def not_blank(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("message cannot be blank")
        return v.strip()


class ChatResponse(BaseModel):
    session_id: str
    reply: str
    approvals: list[dict] = Field(default_factory=list)
    tools_used: list[str] = Field(default_factory=list)
    offline: bool = False


class ApprovalResponse(BaseModel):
    id: str
    status: str
    message: str


class SessionResponse(BaseModel):
    valid: bool
    provider: str
    model: str
    workspace: str


class NoteInput(BaseModel):
    title: str = Field(min_length=1, max_length=120)
    body: str = Field(min_length=1, max_length=20000)

    @field_validator('title', 'body')
    @classmethod
    def nonempty(cls, value: str) -> str:
        if not value.strip():
            raise ValueError('Field cannot contain only whitespace')
        return value


class TaskInput(BaseModel):
    title: str = Field(min_length=1, max_length=300)

    @field_validator('title')
    @classmethod
    def nonempty(cls, value: str) -> str:
        if not value.strip():
            raise ValueError('Title cannot contain only whitespace')
        return value


class ReminderInput(BaseModel):
    text: str = Field(min_length=1, max_length=500)
    due_at: str = Field(min_length=10, max_length=40)

    @field_validator('text')
    @classmethod
    def nonempty(cls, value: str) -> str:
        if not value.strip():
            raise ValueError('Reminder text cannot contain only whitespace')
        return value
