"""Pluggable LLM clients, supporting local Ollama and optional OpenAI.

Both providers use tool calling. OpenAI's Chat Completions remains supported;
this interface is intentionally small enough to add the Responses API later.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import json
from typing import Any
import httpx

from .config import Settings


class ModelUnavailable(Exception):
    pass


@dataclass
class FunctionCall:
    name: str
    arguments: dict
    call_id: str = ""


@dataclass
class ModelReply:
    content: str = ""
    calls: list[FunctionCall] = field(default_factory=list)
    assistant_message: dict = field(default_factory=dict)


class OllamaProvider:
    def __init__(self, settings: Settings):
        self.settings = settings

    async def complete(self, messages: list[dict], tools: list[dict]) -> ModelReply:
        payload = {"model": self.settings.ollama_model, "messages": messages,
                   "tools": tools, "stream": False, "think": False,
                   "options": {"temperature": 0.35}}
        try:
            async with httpx.AsyncClient(timeout=120) as client:
                response = await client.post(self.settings.ollama_url.rstrip("/") + "/api/chat", json=payload)
                response.raise_for_status()
                data = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise ModelUnavailable(f"Ollama is unavailable: {exc}") from exc
        message = data.get("message", {})
        calls = []
        for item in message.get("tool_calls", []) or []:
            fn = item.get("function", {})
            args = fn.get("arguments", {})
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except ValueError:
                    args = {}
            calls.append(FunctionCall(str(fn.get("name", "")), args if isinstance(args, dict) else {}))
        return ModelReply(str(message.get("content") or ""), calls,
                          {k: v for k, v in message.items() if k in {"role", "content", "tool_calls"}})


class OpenAIProvider:
    def __init__(self, settings: Settings):
        self.settings = settings
        if not settings.openai_api_key:
            raise ModelUnavailable("OPENAI_API_KEY must be set for cloud mode")
        try:
            from openai import AsyncOpenAI
        except ImportError as exc:
            raise ModelUnavailable("Install cloud support: pip install -e '.[openai]'") from exc
        self.client = AsyncOpenAI(api_key=settings.openai_api_key, timeout=90)

    async def complete(self, messages: list[dict], tools: list[dict]) -> ModelReply:
        try:
            response = await self.client.chat.completions.create(
                model=self.settings.openai_model, messages=messages, tools=tools,
                temperature=0.35,
            )
            message = response.choices[0].message
        except Exception as exc:
            raise ModelUnavailable(f"OpenAI request failed: {type(exc).__name__}: {exc}") from exc
        calls = []
        for call in message.tool_calls or []:
            try:
                args = json.loads(call.function.arguments)
            except ValueError:
                args = {}
            calls.append(FunctionCall(call.function.name, args if isinstance(args, dict) else {}, call.id))
        assistant = {"role": "assistant", "content": message.content or ""}
        if message.tool_calls:
            assistant["tool_calls"] = [
                {"id": c.id, "type": "function", "function": {"name": c.function.name, "arguments": c.function.arguments}}
                for c in message.tool_calls
            ]
        return ModelReply(message.content or "", calls, assistant)
