"""Optional local sentence-embedding search with no cloud dependency.

To enable: pip install -e '.[embeddings]' and let sentence-transformers
fetch a supported model. The first model download requires network access.
No embedding is fetched from a third-party hosted inference API.
"""
from __future__ import annotations

from dataclasses import dataclass
import json
import math
from pathlib import Path
from typing import Sequence,Any

from .ranking import HybridRanker


class SemanticUnavailable(RuntimeError):
    pass


@dataclass(frozen=True)
class SemanticMatch:
    index: int
    score: float
    text: str


class LocalEmbedder:
    def __init__(self, model_name: str = 'sentence-transformers/all-MiniLM-L6-v2',
                 *, local_files_only: bool = True):
        self.model_name=model_name
        self.local_files_only=local_files_only
        self._model=None

    def load(self):
        if self._model is not None:return self._model
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as exc:
            raise SemanticUnavailable("Install optional embeddings: pip install -e '.[embeddings]'") from exc
        try:
            self._model=SentenceTransformer(self.model_name,
                                            local_files_only=self.local_files_only)
        except Exception as exc:
            raise SemanticUnavailable('Embedding model not found in local cache') from exc
        return self._model

    def embed(self, texts: Sequence[str]) -> list[list[float]]:
        if len(texts)>500:raise ValueError('Too many texts')
        if any(len(text)>20000 for text in texts):raise ValueError('Text too long')
        model=self.load()
        vectors=model.encode(list(texts),normalize_embeddings=True,show_progress_bar=False)
        return [vector.tolist() for vector in vectors]


def dot(a:Sequence[float],b:Sequence[float]) -> float:
    if len(a)!=len(b):raise ValueError('Embedding lengths differ')
    return sum(x*y for x,y in zip(a,b))


def l2norm(values:Sequence[float]) -> float:
    return math.sqrt(sum(value*value for value in values))


def cosine(a:Sequence[float],b:Sequence[float]) -> float:
    divisor=l2norm(a)*l2norm(b)
    return dot(a,b)/divisor if divisor else 0.0


class SemanticIndex:
    def __init__(self, embedder: LocalEmbedder | None = None):
        self.embedder=embedder or LocalEmbedder()
        self.texts:list[str]=[]
        self.vectors:list[list[float]]=[]

    def build(self,texts:Sequence[str]) -> dict:
        if not texts: self.texts=[];self.vectors=[];return {'indexed':0}
        candidate_texts=list(texts)
        candidate_vectors=self.embedder.embed(candidate_texts)
        self._validate(candidate_texts,candidate_vectors)
        # A missing model or failed embedding must not corrupt an existing index.
        self.texts=candidate_texts
        self.vectors=candidate_vectors
        return {'indexed':len(self.texts),'dimensions':len(self.vectors[0])}

    def search(self,query:str,limit:int=10) -> list[SemanticMatch]:
        if not self.texts:return []
        vector=self.embedder.embed([query])[0]
        scores=[cosine(vector,doc) for doc in self.vectors]
        top=sorted(range(len(scores)),key=lambda i:scores[i],reverse=True)[:limit]
        return [SemanticMatch(i,round(scores[i],4),self.texts[i]) for i in top]

    def save(self,destination:Path) -> None:
        """Only JSON embeddings and text; no pickle/object deserialization."""
        payload={'version':1,'model':self.embedder.model_name,
                 'texts':self.texts,'vectors':self.vectors}
        self._validate(self.texts,self.vectors)
        encoded=json.dumps(payload,ensure_ascii=False,allow_nan=False)
        if len(encoded.encode('utf-8'))>20*1024*1024:raise ValueError('Index is too big')
        destination.write_text(encoded,encoding='utf-8')

    def load(self,path:Path) -> None:
        if path.stat().st_size>20*1024*1024:raise ValueError('Index file too big')
        obj=json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(obj,dict) or obj.get('version')!=1 or obj.get('model')!=self.embedder.model_name:
            raise ValueError('Index format or embedding model differs')
        texts=obj.get('texts');vectors=obj.get('vectors')
        self._validate(texts,vectors)
        self.texts=texts;self.vectors=vectors

    @staticmethod
    def _validate(texts:Any,vectors:Any) -> None:
        if not isinstance(texts,list) or not isinstance(vectors,list) or len(texts)!=len(vectors):
            raise ValueError('Invalid index')
        if len(texts)>5000 or any(not isinstance(t,str) or len(t)>20000 for t in texts):
            raise ValueError('Invalid indexed texts')
        dimensions=None
        for vector in vectors:
            if not isinstance(vector,list) or not 1<=len(vector)<=2048:
                raise ValueError('Invalid vector dimensions')
            if dimensions is None:dimensions=len(vector)
            if len(vector)!=dimensions:raise ValueError('Invalid vector dimensions')
            try:
                valid=all(type(value) in (int,float) and math.isfinite(value) for value in vector)
            except (TypeError,OverflowError):valid=False
            if not valid:raise ValueError('Embedding values must be finite numbers')
