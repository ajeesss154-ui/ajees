"""Source-aware text chunking for retrieval-augmented generation (RAG)."""
from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import re
from typing import Iterator, Sequence

from .text import sentences, tokens


@dataclass(frozen=True)
class Chunk:
    id: str
    source: str
    title: str
    section: str
    text: str
    start: int
    end: int
    ordinal: int
    approx_tokens: int

    def as_dict(self) -> dict:
        return self.__dict__.copy()


def stable_id(source: str, start: int, content: str) -> str:
    return sha256(f'{source}\0{start}\0{content}'.encode('utf-8')).hexdigest()[:24]


def heading_ranges(content: str) -> list[tuple[int,int,str]]:
    """Return spans headed by Markdown-style titles, including preamble."""
    lines=content.splitlines(keepends=True)
    headings=[]
    offset=0
    for line in lines:
        match=re.match(r'^\s{0,3}#{1,6}\s+(.+?)\s*#*\s*$',line)
        if match:
            headings.append((offset,match.group(1).strip()))
        offset+=len(line)
    if not headings:return [(0,len(content),'')]
    spans=[]
    if headings[0][0]>0:spans.append((0,headings[0][0],''))
    for i,(start,title) in enumerate(headings):
        end=headings[i+1][0] if i+1<len(headings) else len(content)
        spans.append((start,end,title))
    return spans


def split_big_word(word: str, limit: int) -> list[str]:
    if limit<1:raise ValueError('Limit must be positive')
    return [word[i:i+limit] for i in range(0,len(word),limit)]


def split_sentences(text: str, size: int, overlap: int) -> Iterator[tuple[int,int,str]]:
    """Recursive boundary-preserving chunks with overlapping character windows."""
    if size<100:raise ValueError('Chunk size must be >=100 characters')
    if overlap<0 or overlap>=size:raise ValueError('Overlap must be smaller than size')
    if not text.strip():return
    cursor=0
    while cursor<len(text):
        end=min(cursor+size,len(text))
        if end<len(text):
            # Prefer the last paragraph/sentence break, then a space.
            window=text[cursor:end]
            candidates=[window.rfind('\n\n'),window.rfind('. '),window.rfind('\n'),
                        window.rfind(' ')]
            break_at=next((c for c in candidates if c>int(size*.52)),None)
            if break_at is not None:end=cursor+break_at+1
        piece=text[cursor:end]
        if piece.strip():yield cursor,end,piece.strip()
        if end>=len(text):break
        cursor=max(cursor+1,end-overlap)


def chunk_document(source: str,title: str,text: str, *, chunk_size: int = 900,
                   overlap: int = 140, max_chunks: int = 150) -> list[Chunk]:
    if len(text)>1_000_000:raise ValueError('Text too large')
    result=[]
    for section_start,section_end,section_title in heading_ranges(text):
        part=text[section_start:section_end]
        for relative_start,relative_end,content in split_sentences(part,chunk_size,overlap):
            offset=section_start+relative_start
            result.append(Chunk(stable_id(source,offset,content),source,title,
                        section_title,content,offset,section_start+relative_end,
                        len(result),max(1,len(tokens(content,minimum=1)))))
            if len(result)>=max_chunks:return result
    return result


def merge_context(chunks: Sequence[Chunk], max_chars: int = 7000) -> str:
    """Context with source delimiters that never masquerade as system messages."""
    fragments=[];used=0
    for chunk in chunks:
        label=f'[SOURCE {chunk.source} / SECTION {chunk.section or "main"}]\n'
        part=(label+chunk.text).replace('\x00','')
        if used+len(part)>max_chars:
            remaining=max_chars-used
            if remaining<100:break
            fragments.append(part[:remaining]);break
        fragments.append(part)
        used+=len(part)
    return '\n\n--- source boundary ---\n\n'.join(fragments)
