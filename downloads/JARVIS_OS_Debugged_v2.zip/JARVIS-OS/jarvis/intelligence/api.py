"""User-controlled indexing and text analysis endpoints.

Documents never leave the local backend unless the user explicitly submits
text to a separate cloud-model chat endpoint. This API itself is offline.
"""
from __future__ import annotations

from typing import Callable

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from jarvis.advanced.security import SecurityError
from .index import LocalIndex
from .text import text_profile, extract_entities
from .summarize import summarize, compare_documents, question_candidates
from .context import ContextAssembler


class TextRequest(BaseModel):
    text: str = Field(min_length=1,max_length=100000)


class CompareRequest(BaseModel):
    first: str = Field(min_length=1,max_length=100000)
    second: str = Field(min_length=1,max_length=100000)


class SearchInput(BaseModel):
    query: str = Field(min_length=1,max_length=350)
    limit: int = Field(default=8,ge=1,le=25)
    kind: str = 'all'


class SummarizeInput(BaseModel):
    text: str = Field(min_length=1,max_length=100000)
    sentences_count: int = Field(default=4,ge=1,le=20)


def build_router(index: LocalIndex, assembler: ContextAssembler,
                 auth: Callable) -> APIRouter:
    router=APIRouter(prefix='/api/knowledge',tags=['Local Knowledge'],
                     dependencies=[Depends(auth)])

    @router.get('/stats')
    def stats():
        return index.stats()

    @router.post('/refresh')
    def refresh():
        return index.refresh()

    @router.get('/sources')
    def sources():
        return index.sources()

    @router.post('/search')
    def search(request:SearchInput):
        try:
            return index.search(request.query,limit=request.limit,kind=request.kind)
        except SecurityError as exc:
            raise HTTPException(400,str(exc)) from exc

    @router.get('/chunks/{chunk_id}')
    def get_chunk(chunk_id: str):
        chunk=index.preview(chunk_id)
        if chunk is None:raise HTTPException(404,'Index entry not found')
        return chunk

    @router.post('/context')
    def context(request:SearchInput):
        return assembler.assemble(request.query)

    @router.post('/text/profile')
    def profile(request:TextRequest):
        return text_profile(request.text)

    @router.post('/text/entities')
    def entities(request:TextRequest):
        return extract_entities(request.text)

    @router.post('/text/summary')
    def summary(request:SummarizeInput):
        return summarize(request.text,sentences_count=request.sentences_count)

    @router.post('/text/compare')
    def compare(request:CompareRequest):
        return compare_documents(request.first,request.second)

    @router.post('/text/study-prompts')
    def study_prompts(request:TextRequest):
        return question_candidates(request.text)

    return router
