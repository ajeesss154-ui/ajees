"""An incremental, local SQLite FTS5 search index over user-approved content.

Default sources are notes and files in the confined JARVIS workspace. This
module does not read the user's home directory, browser profiles or messages
from other apps; files with sensitive names are explicitly excluded.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json
import re
import sqlite3
from typing import Iterable

from jarvis.storage import Database, utcnow
from jarvis.retrieval import SAFE_EXTENSIONS
from jarvis.advanced.security import SecurityError, is_protected_name
from .chunking import Chunk, chunk_document
from .ranking import HybridRanker
from .text import tokens


@dataclass(frozen=True)
class IndexStats:
    source_count: int
    chunk_count: int
    updated_count: int
    removed_count: int
    error_count: int

    def as_dict(self) -> dict:
        return self.__dict__.copy()


class LocalIndex:
    def __init__(self, db: Database, workspace: Path, *, max_documents: int = 450):
        self.db=db
        self.workspace=Path(workspace).resolve()
        self.max_documents=max_documents
        self.supports_fts=True
        self._initialize()

    def _initialize(self) -> None:
        with self.db.connect() as con:
            con.executescript('''
                CREATE TABLE IF NOT EXISTS knowledge_sources (
                    source TEXT PRIMARY KEY, title TEXT NOT NULL,
                    checksum TEXT NOT NULL, kind TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS knowledge_chunks (
                    id TEXT PRIMARY KEY, source TEXT NOT NULL,
                    title TEXT NOT NULL, section TEXT NOT NULL,
                    content TEXT NOT NULL, position INTEGER NOT NULL,
                    start_offset INTEGER NOT NULL, end_offset INTEGER NOT NULL,
                    FOREIGN KEY(source) REFERENCES knowledge_sources(source)
                );
                CREATE INDEX IF NOT EXISTS idx_knowledge_source
                    ON knowledge_chunks(source, position);
            ''')
            try:
                con.execute('''CREATE VIRTUAL TABLE IF NOT EXISTS knowledge_fts USING fts5(
                    chunk_id UNINDEXED, content, title,
                    tokenize='unicode61 remove_diacritics 2'
                )''')
            except sqlite3.OperationalError:
                self.supports_fts=False

    def _sources(self) -> list[dict]:
        sources=[]
        for note in self.db.notes(limit=150):
            sources.append({'source':'note:'+note['id'],'title':note['title'],
                            'kind':'note','text':note['body']})
        for path in sorted(self.workspace.rglob('*')):
            if len(sources)>=self.max_documents:break
            if path.is_symlink() or not path.is_file():continue
            if path.suffix.lower() not in SAFE_EXTENSIONS:continue
            if any(is_protected_name(part) for part in path.relative_to(self.workspace).parts):
                continue
            resolved=path.resolve()
            if not resolved.is_relative_to(self.workspace):continue
            # Directory junctions may be traversed on Windows even when the
            # final file itself is not a symlink. Validate the resolved names.
            if any(is_protected_name(part) for part in resolved.relative_to(self.workspace).parts):
                continue
            try:
                if path.stat().st_size>120_000:continue
                body=path.read_text(encoding='utf-8')
            except (OSError,UnicodeError):continue
            sources.append({'source':'workspace:'+path.relative_to(self.workspace).as_posix(),
                            'title':path.name,'kind':'file','text':body})
        return sources

    def refresh(self, *, max_chunks_per_source: int = 60) -> dict:
        documents=self._sources()
        current={item['source'] for item in documents}
        errors=0;updated=0
        with self.db.connect() as con:
            previous={row['source']:row['checksum'] for row in con.execute(
                        'SELECT source,checksum FROM knowledge_sources')}
            removed=set(previous)-current
            for source in removed:
                self._delete_source(con,source)
            for entry in documents:
                # Metadata is part of the indexed content: title-only edits must refresh FTS.
                fingerprint=json.dumps([entry['kind'],entry['title'],entry['text']],
                                       ensure_ascii=False,separators=(',', ':'))
                checksum=sha256(fingerprint.encode('utf-8')).hexdigest()
                if previous.get(entry['source'])==checksum:continue
                chunks=chunk_document(entry['source'],entry['title'],entry['text'],
                                      max_chunks=max_chunks_per_source)
                # Keep a usable previous index if a single source update fails.
                con.execute('SAVEPOINT knowledge_source_update')
                try:
                    self._delete_source(con,entry['source'])
                    con.execute('INSERT INTO knowledge_sources VALUES (?,?,?,?,?)',
                                (entry['source'],entry['title'],checksum,entry['kind'],utcnow()))
                    for chunk in chunks:
                        con.execute('INSERT INTO knowledge_chunks VALUES (?,?,?,?,?,?,?,?)',
                            (chunk.id,chunk.source,chunk.title,chunk.section,
                             chunk.text,chunk.ordinal,chunk.start,chunk.end))
                        if self.supports_fts:
                            con.execute('INSERT INTO knowledge_fts(chunk_id,content,title) VALUES (?,?,?)',
                                        (chunk.id,chunk.text,chunk.title))
                    updated+=1
                except sqlite3.Error:
                    con.execute('ROLLBACK TO knowledge_source_update')
                    errors+=1
                finally:
                    con.execute('RELEASE knowledge_source_update')
        stats=self.stats()
        return {**stats,'changed_sources':updated,'removed_sources':len(removed),
                'errors':errors}

    def _delete_source(self, con: sqlite3.Connection, source: str) -> None:
        if self.supports_fts:
            con.execute('''DELETE FROM knowledge_fts WHERE chunk_id IN (
                SELECT id FROM knowledge_chunks WHERE source=?)''',(source,))
        con.execute('DELETE FROM knowledge_chunks WHERE source=?',(source,))
        con.execute('DELETE FROM knowledge_sources WHERE source=?',(source,))

    def stats(self) -> dict:
        with self.db.connect() as con:
            return {'sources':con.execute('SELECT COUNT(*) FROM knowledge_sources').fetchone()[0],
                    'chunks':con.execute('SELECT COUNT(*) FROM knowledge_chunks').fetchone()[0],
                    'fts5':self.supports_fts}

    def search(self, query: str, *, limit: int = 8, kind: str = 'all',
               hybrid: bool = True) -> list[dict]:
        if not isinstance(query,str) or not query.strip() or len(query)>350:
            raise SecurityError('Use a short search query (up to 350 characters)')
        if kind not in {'all','file','note'}:
            raise SecurityError('Unknown source kind')
        limit=max(1,min(limit,25))
        with self.db.connect() as con:
            if self.supports_fts:
                terms=tokens(query,stopwords=True)[:12]
                if not terms:return []
                # Quote each term: no user-supplied FTS syntax or operator injection.
                expression=' OR '.join('"'+term.replace('"','')+'"' for term in terms)
                try:
                    rows=con.execute('''SELECT c.*, s.kind AS kind,
                        bm25(knowledge_fts, 1.0, 0.35) AS match_score
                        FROM knowledge_fts
                        JOIN knowledge_chunks c ON c.id=knowledge_fts.chunk_id
                        JOIN knowledge_sources s ON s.source=c.source
                        WHERE knowledge_fts MATCH ? AND (?='all' OR s.kind=?)
                        ORDER BY match_score LIMIT ?''',
                        (expression,kind,kind,min(200,limit*12))).fetchall()
                except sqlite3.OperationalError:
                    rows=[]
            else:
                pattern='%'+query.replace('%','\\%').replace('_','\\_')+'%'
                rows=con.execute('''SELECT c.*,s.kind AS kind,0.0 AS match_score
                    FROM knowledge_chunks c JOIN knowledge_sources s ON s.source=c.source
                    WHERE (c.content LIKE ? ESCAPE '\\' OR c.title LIKE ? ESCAPE '\\')
                    AND (?='all' OR s.kind=?) LIMIT 200''',
                    (pattern,pattern,kind,kind)).fetchall()
        items=[dict(row) for row in rows]
        if hybrid and len(items)>1:
            ranker=HybridRanker([row['title']+' '+row['content'] for row in items])
            ranking=ranker.search(query,limit=limit,weighted=True)
            selected=[(items[h.index],h.score) for h in ranking]
        else:
            selected=[(row,round(1/(1+abs(row['match_score'])),3)) for row in items[:limit]]
        return [{'id':item['id'],'source':item['source'],'title':item['title'],
                 'section':item['section'],'kind':item['kind'],
                 'snippet':item['content'][:950],'score':score,
                 'position':item['position']} for item,score in selected]

    def preview(self, chunk_id: str) -> dict | None:
        with self.db.connect() as con:
            row=con.execute('''SELECT c.*,s.kind AS kind FROM knowledge_chunks c
                    JOIN knowledge_sources s ON s.source=c.source WHERE c.id=?''',
                    (chunk_id,)).fetchone()
        return dict(row) if row else None

    def sources(self) -> list[dict]:
        with self.db.connect() as con:
            return [dict(row) for row in con.execute('''SELECT s.*,
                (SELECT COUNT(*) FROM knowledge_chunks c WHERE c.source=s.source) AS chunks
                FROM knowledge_sources s ORDER BY updated_at DESC LIMIT 450''')]

    def remove_source(self, source: str) -> bool:
        """Remove from index only; does not delete the user's original file/note."""
        if not source.startswith(('note:','workspace:')):raise SecurityError('Unknown source')
        with self.db.connect() as con:
            found=con.execute('SELECT 1 FROM knowledge_sources WHERE source=?',
                              (source,)).fetchone() is not None
            if found:self._delete_source(con,source)
        return found
