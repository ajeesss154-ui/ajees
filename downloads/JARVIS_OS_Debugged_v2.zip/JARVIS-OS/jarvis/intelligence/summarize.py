"""Offline extractive summarization and document comparison utilities.

The output consists only of source sentences, so it cannot invent facts the
way an unconstrained generative summarizer can. It is not a substitute for
medical, legal or factual verification of the original document.
"""
from __future__ import annotations

from collections import Counter, defaultdict
import math
from typing import Sequence

from .text import sentences, tokens, ngrams, cosine_bow


def _sentence_scores(parts: Sequence[str]) -> list[float]:
    corpus=[tokens(item,stopwords=True) for item in parts]
    weights=Counter(term for sentence in corpus for term in set(sentence))
    n=max(1,len(parts))
    scores=[]
    for index,words in enumerate(corpus):
        if not words:scores.append(0.0);continue
        importance=sum(math.log(1+n/max(1,weights[w])) for w in words)/math.sqrt(len(words))
        location=1.2 if index==0 else (1.1 if index<3 else 1)
        scores.append(importance*location)
    return scores


def summarize(text: str, *, sentences_count: int = 4, max_chars: int = 3500) -> dict:
    """Extract salient full sentences. Do not generate paraphrased claims."""
    if not 1<=sentences_count<=20:raise ValueError('Choose 1–20 sentences')
    if len(text)>100_000:raise ValueError('Text exceeds local summary limit')
    parts=sentences(text)
    if not parts:return {'summary':'','selected':[],'source_sentences':0}
    if len(parts)<=sentences_count:selected=list(range(len(parts)))
    else:
        scores=_sentence_scores(parts)
        candidates=sorted(range(len(parts)),key=lambda i:scores[i],reverse=True)
        selected=[]
        for index in candidates:
            if any(cosine_bow(parts[index],parts[other])>.9 for other in selected):continue
            selected.append(index)
            if len(selected)>=sentences_count:break
        selected.sort()
    excerpts=[];used=0
    for index in selected:
        content=parts[index]
        if used+len(content)>max_chars:break
        excerpts.append(content)
        used+=len(content)
    return {'summary':' '.join(excerpts),'selected':selected,
            'source_sentences':len(parts),'extraction_only':True}


def compare_documents(a: str, b: str, *, keywords_limit: int = 16) -> dict:
    """Compare vocabulary of two pieces of text, without asserting provenance."""
    ta=Counter(tokens(a,stopwords=True));tb=Counter(tokens(b,stopwords=True))
    diff_a=ta-tb;diff_b=tb-ta
    return {
        'cosine_similarity':round(cosine_bow(a,b),4),
        'shared_keywords':[word for word,_ in (ta&tb).most_common(keywords_limit)],
        'only_in_first':diff_a.most_common(keywords_limit),
        'only_in_second':diff_b.most_common(keywords_limit),
        'first_words':sum(ta.values()),
        'second_words':sum(tb.values()),
    }


def question_candidates(text: str, limit: int = 8) -> list[str]:
    """Heuristic study prompts from provided text, no hallucinated answers."""
    result=[]
    for line in sentences(text):
        words=tokens(line,stopwords=True)
        if len(words)<3 or len(line)>350:continue
        subject=' '.join(words[:3])
        question=f'Explain the main idea in this statement: {line}'
        if question not in result:result.append(question)
        if len(result)>=limit:break
    return result
