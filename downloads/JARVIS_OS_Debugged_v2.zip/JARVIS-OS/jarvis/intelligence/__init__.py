"""Local natural-language understanding and retrieval; optional ML backends."""
