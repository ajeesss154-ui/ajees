"""Lexical, probabilistic and hybrid ranking for locally indexed knowledge.

BM25 is implemented without external dependencies. Optional cosine scoring
uses document-term weights; the semantic backend is added separately.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
import heapq
import math
from typing import Iterable, Sequence

from .text import tokens, term_frequency, cosine_bow


@dataclass(frozen=True)
class RankedHit:
    index: int
    score: float
    lexical: float
    semantic: float


class BM25:
    def __init__(self, corpus: Sequence[str], *, k1: float = 1.5, b: float = 0.75):
        if k1<=0 or not 0<=b<=1:raise ValueError('Invalid BM25 constants')
        self.k1=k1;self.b=b
        self.documents=[tokens(doc,stopwords=True) for doc in corpus]
        self.frequencies=[Counter(doc) for doc in self.documents]
        self.lengths=[len(doc) for doc in self.documents]
        self.count=len(corpus)
        self.average_len=sum(self.lengths)/max(1,self.count)
        self.doc_frequency=Counter()
        for freq in self.frequencies:self.doc_frequency.update(freq.keys())

    def score(self, query: str) -> list[float]:
        result=[0.0]*self.count
        qterms=Counter(tokens(query,stopwords=True))
        for term,query_count in qterms.items():
            df=self.doc_frequency.get(term,0)
            if df==0:continue
            idf=math.log(1+(self.count-df+0.5)/(df+0.5))
            for i,tf in enumerate(self.frequencies):
                f=tf.get(term,0)
                if not f:continue
                adjustment=1-self.b+self.b*self.lengths[i]/max(1,self.average_len)
                result[i]+=idf*f*(self.k1+1)/(f+self.k1*adjustment)*min(query_count,3)
        return result

    def rank(self, query: str, limit: int = 10) -> list[tuple[int,float]]:
        scores=self.score(query)
        return [(i,round(score,5)) for i,score in heapq.nlargest(
            limit,enumerate(scores),key=lambda pair:pair[1]) if score>0]


class TfIdf:
    """Sparse TF-IDF implementation for small private datasets."""
    def __init__(self, documents: Sequence[str]):
        self.documents=list(documents)
        self.df=Counter()
        for doc in self.documents:self.df.update(set(tokens(doc,stopwords=True)))
        self.n=len(self.documents)
        self.vectors=[self.vectorize(doc) for doc in self.documents]

    def vectorize(self, text: str) -> dict[str,float]:
        tf=term_frequency(text)
        weights={}
        for term,count in tf.items():
            idf=math.log((1+self.n)/(1+self.df.get(term,0)))+1
            weights[term]=(1+math.log(count))*idf
        norm=math.sqrt(sum(x*x for x in weights.values()))
        return {term:weight/norm for term,weight in weights.items()} if norm else {}

    def score(self, query: str) -> list[float]:
        query_vector=self.vectorize(query)
        return [sum(value*vector.get(term,0.0) for term,value in query_vector.items())
                for vector in self.vectors]


def reciprocal_rank_fusion(rankings: Sequence[Sequence[tuple[int,float]]], k: int = 60,
                          limit: int = 12) -> list[tuple[int,float]]:
    """Combine result ordering without requiring calibrated score ranges."""
    if k<1:raise ValueError('k must be positive')
    scores=defaultdict(float)
    for result in rankings:
        for rank,(index,_) in enumerate(result,1):
            scores[index]+=1/(k+rank)
    return sorted(scores.items(),key=lambda pair:(-pair[1],pair[0]))[:limit]


class HybridRanker:
    def __init__(self, documents: Sequence[str]):
        self.documents=list(documents)
        self.bm25=BM25(documents)
        self.tfidf=TfIdf(documents)

    def search(self, query: str, limit: int = 10, *, weighted: bool = False) -> list[RankedHit]:
        bm=self.bm25.score(query)
        cos=self.tfidf.score(query)
        if weighted:
            max_bm=max(bm,default=0) or 1
            scores=[0.6*a/max_bm+0.4*b for a,b in zip(bm,cos)]
            ranking=sorted(range(len(scores)),key=lambda i:scores[i],reverse=True)[:limit]
            return [RankedHit(i,round(scores[i],4),round(bm[i],4),round(cos[i],4))
                    for i in ranking if scores[i]>0]
        lex=sorted(enumerate(bm),key=lambda pair:pair[1],reverse=True)
        sem=sorted(enumerate(cos),key=lambda pair:pair[1],reverse=True)
        fused=reciprocal_rank_fusion([[(i,s) for i,s in lex if s>0],
                                     [(i,s) for i,s in sem if s>0]],limit=limit)
        return [RankedHit(i,round(score,5),round(bm[i],4),round(cos[i],4))
                for i,score in fused]


def diversify(hits: Sequence[RankedHit], documents: Sequence[str],
              limit: int = 6, penalty: float = 0.4) -> list[RankedHit]:
    """Maximum marginal relevance-like post-filter for varied snippets."""
    selected=[]
    remaining=list(hits)
    while remaining and len(selected)<limit:
        def value(item):
            similarity=max((cosine_bow(documents[item.index],
                                       documents[chosen.index]) for chosen in selected),default=0)
            return item.score-penalty*similarity
        pick=max(remaining,key=value)
        selected.append(pick);remaining.remove(pick)
    return selected
