"""Deterministic NLP utilities to support an AI personal assistant offline.

These helpers make no network calls and never train on other users' data.
They deliberately distinguish measured facts from heuristic estimates.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
import math
import re
import string
import unicodedata
from typing import Iterable, Sequence


ENGLISH_STOPWORDS=frozenset('''a about above after again against all am an and any are as at be because
been before being below between both but by can could did do does doing down during each few for from
further had has have having he her here hers herself him himself his how i if in into is it its itself
just me more most my myself no nor not now of off on once only or other our ours ourselves out over own
same she should so some such than that the their theirs them themselves then there these they this those
through to too under until up very was we were what when where which while who whom why will with you
your yours yourself yourselves may might must shall would should must let lets it's that's isn't don't
can't were we're we've it'll i've i'm we'd they've we're i'd you'll etc'''.split())

TOKEN_PATTERN=re.compile(r"[\w]+(?:[-'][\w]+)*",re.UNICODE)
SENTENCE_PATTERN=re.compile(r'(?<=[.!?。！？])\s+(?=[^\s])')
EMAIL_PATTERN=re.compile(r'(?<![\w.])[A-Z0-9_.+-]+@[A-Z0-9.-]+\.[A-Z]{2,}(?!\w)',re.I)
URL_PATTERN=re.compile(r'https?://[^\s<>"\']+',re.I)
HASHTAG_PATTERN=re.compile(r'(?<!\w)#[A-Za-z][A-Za-z0-9_]{1,40}')
CODE_PATTERN=re.compile(r'(?m)^\s*(?:def |class |function |import |from |const |let |var |<[^>]+>)')


def normalize(text: str, *, casefold: bool = True) -> str:
    """Normalize Unicode and whitespace, preserving meaningful punctuation."""
    text=unicodedata.normalize('NFKC',text.replace('\x00',''))
    text=re.sub(r'[\u200b-\u200d\ufeff]','',text)
    text=re.sub(r'\s+',' ',text).strip()
    return text.casefold() if casefold else text


def tokens(text: str, *, stopwords: bool = False, minimum: int = 2) -> list[str]:
    words=[x.casefold() for x in TOKEN_PATTERN.findall(normalize(text))]
    return [w for w in words if len(w)>=minimum and (not stopwords or w not in ENGLISH_STOPWORDS)]


def sentences(text: str, limit: int = 1000) -> list[str]:
    text=text.strip()
    if not text:return []
    output=[]
    for line in text.splitlines():
        line=line.strip()
        if not line: continue
        for segment in SENTENCE_PATTERN.split(line):
            segment=segment.strip()
            if segment:output.append(segment)
            if len(output)>=limit:return output
    return output


def word_count(text: str) -> int:
    return len(tokens(text, minimum=1))


def term_frequency(text: str, *, stopwords: bool = True) -> Counter[str]:
    return Counter(tokens(text,stopwords=stopwords))


def ngrams(words: Sequence[str], n: int) -> list[tuple[str,...]]:
    if n<1 or n>5: raise ValueError('n must be between 1 and 5')
    return [tuple(words[i:i+n]) for i in range(max(0,len(words)-n+1))]


def keywords(text: str, limit: int = 12) -> list[dict]:
    counts=term_frequency(text)
    length=max(1,sum(counts.values()))
    return [{'term':word,'count':cnt,'percent':round(100*cnt/length,2)}
            for word,cnt in counts.most_common(max(1,min(limit,80)))]


def lexical_diversity(text: str) -> float:
    words=tokens(text,minimum=1)
    return round(len(set(words))/len(words),3) if words else 0.0


def estimated_reading_minutes(text: str, wpm: int = 200) -> float:
    if wpm<=0:raise ValueError('Reading speed must be positive')
    return round(word_count(text)/wpm,1)


def paragraph_count(text: str) -> int:
    return len([line for line in re.split(r'\n\s*\n',text) if line.strip()])


def top_phrases(text: str, n: int = 2, limit: int = 10) -> list[tuple[str,int]]:
    terms=tokens(text,stopwords=False)
    pairs=(gram for gram in ngrams(terms,n) if not any(w in ENGLISH_STOPWORDS for w in gram))
    counts=Counter(' '.join(gram) for gram in pairs)
    return counts.most_common(max(0,min(limit,100)))


def repeated_sentences(text: str, minimum: int = 2) -> list[dict]:
    arr=sentences(text)
    counts=Counter(normalize(sentence) for sentence in arr if len(sentence)>15)
    return [{'sentence':sent,'count':count} for sent,count in counts.items() if count>=minimum]


def punctuation_density(text: str) -> float:
    if not text:return 0.0
    return round(sum(ch in string.punctuation for ch in text)/len(text),3)


def text_profile(text: str) -> dict:
    """Lightweight document profile: not a psychometric or identity classifier."""
    if len(text)>1_000_000:raise ValueError('Document too large for profile')
    w=word_count(text)
    s=sentences(text)
    return {
        'characters':len(text),'words':w,'sentences':len(s),
        'paragraphs':paragraph_count(text),
        'average_words_per_sentence':round(w/max(1,len(s)),1),
        'lexical_diversity':lexical_diversity(text),
        'estimated_reading_minutes':estimated_reading_minutes(text),
        'punctuation_density':punctuation_density(text),
        'emails':len(EMAIL_PATTERN.findall(text)),
        'urls':len(URL_PATTERN.findall(text)),
        'code_like':bool(CODE_PATTERN.search(text)),
        'top_keywords':keywords(text),
    }


def jaccard(a: str, b: str) -> float:
    ta=set(tokens(a,stopwords=True));tb=set(tokens(b,stopwords=True))
    union=ta|tb
    return len(ta&tb)/len(union) if union else 1.0


def cosine_bow(a: str, b: str) -> float:
    ca=term_frequency(a);cb=term_frequency(b)
    if not ca or not cb:return 0.0
    dot=sum(value*cb.get(term,0) for term,value in ca.items())
    norm_a=math.sqrt(sum(v*v for v in ca.values()))
    norm_b=math.sqrt(sum(v*v for v in cb.values()))
    return dot/(norm_a*norm_b)


def deduplicate(texts: Iterable[str], threshold: float = 0.93) -> list[str]:
    """Preserve order, eliminating near-identical text blocks."""
    if not 0<=threshold<=1:raise ValueError('Invalid threshold')
    seen=[]
    for text in texts:
        if any(jaccard(text,existing)>=threshold for existing in seen):continue
        seen.append(text)
    return seen


def extract_entities(text: str) -> dict[str,list[str]]:
    """Extract explicitly present patterns, not inferred identities."""
    dates=re.findall(r'\b\d{4}-\d{2}-\d{2}\b',text)
    times=re.findall(r'\b(?:[01]?\d|2[0-3]):[0-5]\d\b',text)
    money=re.findall(r'(?<!\w)(?:₹|\$|€|£)\s?\d[\d,]*(?:\.\d{1,2})?',text)
    return {
        'dates':list(dict.fromkeys(dates))[:30],
        'times':list(dict.fromkeys(times))[:30],
        'currency_mentions':list(dict.fromkeys(money))[:30],
        'emails':list(dict.fromkeys(EMAIL_PATTERN.findall(text)))[:30],
        'urls':list(dict.fromkeys(URL_PATTERN.findall(text)))[:30],
        'hashtags':list(dict.fromkeys(HASHTAG_PATTERN.findall(text)))[:30],
    }


def highlight_offsets(text: str, query: str, max_hits: int = 15) -> list[dict]:
    """Return offsets for client highlighting; never inject HTML into the DOM."""
    if not query or len(query)>100:return []
    matches=[]
    for match in re.finditer(re.escape(query),text,re.I):
        matches.append({'start':match.start(),'end':match.end()})
        if len(matches)>=max_hits:break
    return matches


def overlap_ratio(source: str, answer: str) -> float:
    """Cheap heuristic to flag text that may not be grounded in a source."""
    terms=set(tokens(answer,stopwords=True))
    if not terms:return 1.0
    return round(len(terms&set(tokens(source,stopwords=True)))/len(terms),3)


def detect_language_hint(text: str) -> str:
    """Script hint, not full language identification."""
    counts={'tamil':0,'devanagari':0,'arabic':0,'cjk':0,'latin':0}
    for ch in text:
        cp=ord(ch)
        if 0x0B80<=cp<=0x0BFF:counts['tamil']+=1
        elif 0x0900<=cp<=0x097F:counts['devanagari']+=1
        elif 0x0600<=cp<=0x06FF:counts['arabic']+=1
        elif 0x4E00<=cp<=0x9FFF:counts['cjk']+=1
        elif 'a'<=ch.lower()<='z':counts['latin']+=1
    return max(counts,key=counts.get) if any(counts.values()) else 'unknown'


@dataclass(frozen=True)
class TextDelta:
    added_words: tuple[str,...]
    removed_words: tuple[str,...]
    similarity: float


def difference(old: str, new: str) -> TextDelta:
    before=Counter(tokens(old));after=Counter(tokens(new))
    return TextDelta(tuple((after-before).elements())[:100],
                     tuple((before-after).elements())[:100],round(cosine_bow(old,new),3))
