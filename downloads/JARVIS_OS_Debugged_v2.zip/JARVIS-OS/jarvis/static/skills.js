/* Skill explorer: safe, explicit user-driven execution of deterministic tools. */
'use strict';
let skillCatalog = [];
let chosenSkill = null;
let lastSkillResult = '';

const skillNode = id => document.getElementById(id);

async function loadSkills() {
  if (!state.token) return;
  try {
    if (!skillCatalog.length) {
      skillCatalog = await api('/utilities/catalog');
      const categories = [...new Set(skillCatalog.map(skill => skill.category))].sort();
      const select = skillNode('skillCategory');
      select.replaceChildren();
      const option = el('option','','All categories');
      option.value = '';
      select.append(option);
      for (const category of categories) {
        const item = el('option','',category);
        item.value = category;
        select.append(item);
      }
    }
    renderSkills();
  } catch (error) {
    toast('Skills unavailable: '+ error.message);
  }
}

function renderSkills() {
  const area = skillNode('skillsList');
  if (!area) return;
  const term = skillNode('skillSearch').value.toLowerCase().trim();
  const category = skillNode('skillCategory').value;
  const matching = skillCatalog.filter(skill =>
    (!category || skill.category === category) &&
    (!term || `${skill.name} ${skill.description} ${skill.category}`.toLowerCase().includes(term)));
  skillNode('skillsCount').textContent = `${matching.length} / ${skillCatalog.length} TOOLS`;
  area.replaceChildren();
  if (!matching.length) {
    area.append(el('p','empty-row','No matching skills.'));
    return;
  }
  for (const skill of matching) {
    const card = el('button','skill-entry');
    card.type='button';
    if (skill.name === chosenSkill?.name) card.classList.add('selected');
    card.append(el('span','skill-name',skill.name),
                el('span','skill-cat',skill.category),
                el('small','skill-description',skill.description));
    card.onclick = () => chooseSkill(skill);
    area.append(card);
  }
}

function chooseSkill(skill) {
  chosenSkill = skill;
  skillNode('skillTitle').textContent = skill.name.replaceAll('_',' ');
  skillNode('skillDescription').textContent = skill.description;
  const schemaZone = skillNode('skillSchema');
  schemaZone.replaceChildren();
  const schema = skill.parameters?.properties || {};
  const required = new Set(skill.parameters?.required || []);
  for (const [name, spec] of Object.entries(schema)) {
    const description = spec.description || '';
    const row = el('div','skill-param');
    row.append(el('b','', name),
               el('span','', ` · ${spec.type} ${required.has(name) ? '(required)' : '(optional)'}`),
               el('small','',description));
    schemaZone.append(row);
  }
  if (!Object.keys(schema).length) schemaZone.append(el('p','hint-text','No arguments required.'));
  const parameters = {};
  for (const name of required) {
    const spec = schema[name];
    if (!spec) continue;
    parameters[name] = spec.enum?.[0] ?? (spec.type === 'string' ? '' :
      spec.type === 'array' ? [] : spec.type === 'object' ? {} :
      spec.type === 'boolean' ? false : 0);
  }
  skillNode('skillArguments').value = JSON.stringify(parameters,null,2);
  skillNode('skillRun').disabled = false;
  skillNode('skillResult').textContent = 'Enter arguments, then execute.';
  lastSkillResult='';
  renderSkills();
}

async function runSkill(event) {
  event.preventDefault();
  if (!chosenSkill) return;
  const button=skillNode('skillRun');
  let argumentsValue;
  try {
    argumentsValue=JSON.parse(skillNode('skillArguments').value);
    if (Array.isArray(argumentsValue) || !argumentsValue || typeof argumentsValue!=='object') {
      throw new Error('Provide a JSON object containing named arguments.');
    }
  } catch (error) {
    toast('JSON input error: '+error.message);
    return;
  }
  button.disabled=true;
  skillNode('skillResult').textContent = 'Processing locally...';
  try {
    const response=await api('/utilities/run','POST',
      {name:chosenSkill.name,arguments:argumentsValue});
    lastSkillResult=JSON.stringify(response.result,null,2);
    skillNode('skillResult').textContent=lastSkillResult;
  } catch (error) {
    lastSkillResult='';
    skillNode('skillResult').textContent='Error: '+error.message;
  } finally {
    button.disabled=false;
  }
}

skillNode('skillCategory')?.addEventListener('change',renderSkills);
skillNode('skillSearch')?.addEventListener('input',renderSkills);
skillNode('skillForm')?.addEventListener('submit',runSkill);
skillNode('copySkillResult')?.addEventListener('click',async () => {
  if (!lastSkillResult) {
    toast('Run a skill first.');
    return;
  }
  try {
    await navigator.clipboard.writeText(lastSkillResult);
    toast('Result copied.');
  } catch (error) {
    toast('Copy unavailable. Select the result to copy it manually.');
  }
});
