/* JARVIS OS v0.2 · advanced control center. No third-party JS dependencies. */
'use strict';

let selectedProject = null;
const v2 = (route, method='GET', data=undefined) => api('/v2' + route, method, data);
const get = id => document.getElementById(id);
const dateFormat = value => {
  if (!value) return 'No date';
  const date = new Date(value);
  return Number.isNaN(date.valueOf()) ? value : date.toLocaleString();
};

function emptyContent(node, message) {
  node.replaceChildren();
  node.append(el('p','empty-row', message));
}
function makeRow(title, subtitle='', body='') {
  const row=el('div','collection-row');
  const content=el('div','adv-row-content');
  content.append(el('strong','', title));
  if (subtitle) content.append(el('small','',subtitle));
  if (body) content.append(el('div','note-body',body));
  row.append(content);
  return row;
}
function plainButton(label, handler, className='') {
  const button=el('button',className,label);
  button.type='button';
  button.onclick=async () => {
    button.disabled=true;
    try {await handler();}
    catch(error){toast(error.message);}
    finally{button.disabled=false;}
  };
  return button;
}
function safeError(error) {toast(error.message || String(error));}

async function loadAdvancedPage(page) {
  if (!state.token) return;
  try {
    if (page==='projects') await loadProjects();
    if (page==='habits') await loadGoalsHabits();
    if (page==='calendar') await loadCalendar();
    if (page==='automation') await loadAutomation();
    if (page==='insights') await loadInsights();
    if (page==='skills') await loadSkills();
    if (page==='study') await loadStudy();
    if (page==='lab') await loadLab();
  } catch(error) {safeError(error);}
}

async function loadProjects() {
  const items=await v2('/projects');
  const list=get('projectsList');list.replaceChildren();
  if (!items.length) {emptyContent(list,'No projects yet. Create your first mission.');return;}
  for (const project of items) {
    const card=makeRow(project.name,`${project.done_count}/${project.item_count} tasks completed`,project.description);
    card.classList.add('adv-clickable');
    card.onclick=()=>selectProject(project);
    if (selectedProject?.id===project.id) card.classList.add('adv-selected');
    card.append(plainButton('View tasks',()=>selectProject(project),'compact-button'));
    list.append(card);
  }
  if (selectedProject) {
    const active=items.find(item=>item.id===selectedProject.id);
    if(active) await selectProject(active,false);
  }
}
async function selectProject(project, refreshList=true) {
  selectedProject=project;
  get('projectStatus').textContent=project.status.toUpperCase();
  get('projectSummary').textContent=project.name+' · '+project.description;
  const list=get('projectTasks');
  const items=await v2(`/projects/${encodeURIComponent(project.id)}/items`);
  list.replaceChildren();
  if (!items.length) emptyContent(list,'Add tasks to your project using the form above.');
  for (const task of items) {
    const row=makeRow(task.title,`${task.status.toUpperCase()} · PRIORITY ${task.priority}`,
                      task.details);
    if(task.status!=='done') {
      row.append(plainButton('Mark done',async()=>{
        await v2(`/project-items/${encodeURIComponent(task.id)}`,'PATCH',{status:'done'});
        await selectProject(project,false);
      },'compact-button'));
    }
    list.append(row);
  }
  if (refreshList) await loadProjects();
}

async function loadGoalsHabits() {
  const [goals,habits]=await Promise.all([v2('/goals'),v2('/habits')]);
  const goalsZone=get('goalsList');goalsZone.replaceChildren();
  if (!goals.length) emptyContent(goalsZone,'No goals saved yet.');
  for(const goal of goals) {
    const row=makeRow(goal.title,`${goal.progress}% · ${goal.status.toUpperCase()}`,
                      goal.description);
    const bar=el('div','adv-progress');const inner=el('div','adv-progress-fill');
    inner.style.width=Math.max(0,Math.min(100,goal.progress))+'%';
    bar.append(inner);row.querySelector('.adv-row-content').append(bar);
    if(goal.status==='active') {
      const controls=el('div','adv-inline');
      const range=el('input','adv-range');
      range.type='range';range.min='0';range.max='100';range.step='5';range.value=goal.progress;
      range.setAttribute('aria-label','Progress for '+goal.title);
      controls.append(range,plainButton('Update',async()=>{
        await v2(`/goals/${encodeURIComponent(goal.id)}`,'PATCH',{progress:Number(range.value)});
        await loadGoalsHabits();
      },'compact-button'));
      row.querySelector('.adv-row-content').append(controls);
    }
    goalsZone.append(row);
  }
  const habitZone=get('habitsList');habitZone.replaceChildren();
  if(!habits.length)emptyContent(habitZone,'No routines created yet.');
  const today=new Date().toLocaleDateString('en-CA');
  for(const habit of habits) {
    const doneToday=habit.checks.includes(today);
    const row=makeRow(habit.emoji+' '+habit.name,
      `${habit.total_checks} recent checks · Target ${habit.target_per_week}/week`,
      'Checking a routine is optional. No penalty for missed days.');
    row.append(plainButton(doneToday?'Uncheck today':'Done today',async()=>{
      await v2(`/habits/${encodeURIComponent(habit.id)}/check`,'POST',
        {day:today,checked:!doneToday});
      await loadGoalsHabits();
    },'compact-button'));
    habitZone.append(row);
  }
}

async function loadCalendar() {
  const events=await v2('/events?days=120');
  const list=get('calendarList');list.replaceChildren();
  if(!events.length) emptyContent(list,'No events in your local calendar.');
  for(const item of events) {
    const row=makeRow(item.title,`${dateFormat(item.starts_at)} – ${dateFormat(item.ends_at)}`,
                      item.description);
    row.append(plainButton('Remove',async()=>{
      if(!confirm(`Delete the local event "${item.title}"?`))return;
      await v2(`/events/${encodeURIComponent(item.id)}`,'DELETE');
      await loadCalendar();
    },'compact-button'));
    list.append(row);
  }
}

async function loadAutomation() {
  const [templates,workflows,schedules]=await Promise.all([
    v2('/workflow-templates'),v2('/workflows'),v2('/schedules')]);
  const templateZone=get('workflowTemplates');templateZone.replaceChildren();
  for (const item of templates) {
    const row=makeRow(item.name,`${item.steps.length} read-only tool steps`,item.description);
    row.append(plainButton('Install',async()=>{
      await v2('/workflows','POST',item);
      toast('Workflow saved.');await loadAutomation();
    },'compact-button'));
    templateZone.append(row);
  }
  const list=get('workflowList');list.replaceChildren();
  if(!workflows.length)emptyContent(list,'Install a starter workflow to begin.');
  for(const wf of workflows) {
    const row=makeRow(wf.name,`${wf.steps.length} STEPS · ${wf.enabled?'ENABLED':'PAUSED'}`,wf.description);
    row.append(plainButton('Run now',async()=>{
      const res=await v2(`/workflows/${encodeURIComponent(wf.id)}/run`,'POST');
      toast(`Workflow ${res.status} — ${res.results.length} steps`);
      await loadAutomation();
    },'compact-button'));
    list.append(row);
  }
  const select=get('scheduleWorkflow');
  select.replaceChildren();
  const none=el('option','','Choose workflow');none.value='';select.append(none);
  for(const wf of workflows.filter(w=>w.enabled)) {
    const opt=el('option','',wf.name);opt.value=wf.id;select.append(opt);
  }
  const scheduleZone=get('schedulesList');scheduleZone.replaceChildren();
  if(!schedules.length)emptyContent(scheduleZone,'No automatic checks scheduled.');
  for(const item of schedules) {
    const row=makeRow(item.name,
      `Every ${item.interval_minutes} minutes · ${item.enabled?'ACTIVE':'PAUSED'}`,
      `Next run: ${dateFormat(item.next_run_at)}`);
    row.append(plainButton(item.enabled?'Pause':'Resume',async()=>{
      await v2(`/schedules/${encodeURIComponent(item.id)}`,'PATCH',{enabled:!item.enabled});
      await loadAutomation();
    },'compact-button'));
    scheduleZone.append(row);
  }
}

async function loadInsights() {
  const [dashboard,metrics,backups]=await Promise.all([
    v2('/dashboard'),v2('/metrics'),v2('/backups')]);
  const numbers=get('insightNumbers');numbers.replaceChildren();
  for(const [key,value] of Object.entries(dashboard)) {
    if(typeof value!=='number')continue;
    const widget=el('div','module');
    widget.append(el('span','',key.replaceAll('_',' ').toUpperCase()),el('strong','',String(value)));
    numbers.append(widget);
  }
  const history=get('insightHistory');history.replaceChildren();
  for(const item of dashboard.recent_activity||[]) {
    history.append(makeRow(item.message,dateFormat(item.at),item.kind));
  }
  if(!history.children.length)emptyContent(history,'Your activity will appear here.');
  if(metrics.computer?.samples) {
    const latest=metrics.computer.latest;
    const stats=makeRow('SYSTEM SUMMARY',
      `${metrics.computer.samples} LOCAL SAMPLES`,
      `Average CPU: ${metrics.computer.cpu_avg}% · RAM: ${metrics.computer.memory_avg}%`);
    history.prepend(stats);
  }
  const backupsZone=get('backupList');backupsZone.replaceChildren();
  if(!backups.length) emptyContent(backupsZone,'No backups saved on this PC yet.');
  for(const item of backups) {
    const row=makeRow(item.filename,dateFormat(item.created_at),
                      `${Math.ceil(item.size_bytes/1024)} KB · saved locally`);
    row.append(plainButton('Verify',async()=>{
      const result=await v2(`/backups/${encodeURIComponent(item.filename)}/validate`);
      toast(result.valid?'Backup hash verified.':'Backup verification failed.');
    },'compact-button'));
    backupsZone.append(row);
  }
}

function attachAdvancedForms() {
  get('projectForm')?.addEventListener('submit',async e=>{
    e.preventDefault();
    try {
      await v2('/projects','POST',{name:get('projectName').value.trim(),
                                    description:get('projectDescription').value.trim()});
      get('projectName').value='';get('projectDescription').value='';
      await loadProjects();toast('Project created locally.');
    } catch(error){safeError(error);}
  });
  get('projectTaskForm')?.addEventListener('submit',async e=>{
    e.preventDefault();
    if(!selectedProject){toast('Select a project first.');return;}
    try {
      await v2(`/projects/${encodeURIComponent(selectedProject.id)}/items`,'POST',
               {title:get('projectTaskTitle').value.trim()});
      get('projectTaskTitle').value='';await selectProject(selectedProject);
    } catch(error){safeError(error);}
  });
  get('goalForm')?.addEventListener('submit',async e=>{
    e.preventDefault();
    try {
      await v2('/goals','POST',{title:get('goalTitle').value.trim(),
                                  description:get('goalDescription').value.trim()});
      get('goalTitle').value='';get('goalDescription').value='';
      await loadGoalsHabits();toast('Goal saved.');
    } catch(error){safeError(error);}
  });
  get('habitForm')?.addEventListener('submit',async e=>{
    e.preventDefault();
    try {
      await v2('/habits','POST',{name:get('habitName').value.trim(),
                                   target_per_week:Number(get('habitTarget').value)});
      get('habitName').value='';await loadGoalsHabits();
    } catch(error){safeError(error);}
  });
  get('calendarForm')?.addEventListener('submit',async e=>{
    e.preventDefault();
    const start=new Date(get('eventStart').value);
    const end=new Date(get('eventEnd').value);
    if(Number.isNaN(start.valueOf())||Number.isNaN(end.valueOf())||end<=start){
      toast('Select a start and end time in the right order.');return;
    }
    try {
      await v2('/events','POST',{title:get('eventTitle').value.trim(),
        start:start.toISOString(),end:end.toISOString(),
        description:get('eventDescription').value.trim()});
      get('eventTitle').value='';get('eventDescription').value='';
      await loadCalendar();toast('Event saved to local calendar.');
    } catch(error){safeError(error);}
  });
  get('scheduleForm')?.addEventListener('submit',async e=>{
    e.preventDefault();
    const workflowId=get('scheduleWorkflow').value;
    if(!workflowId){toast('Choose a saved workflow first.');return;}
    const minutes=Number(get('scheduleInterval').value);
    const next=new Date(Date.now()+minutes*60000).toISOString();
    try {
      await v2('/schedules','POST',{name:'Scheduled workflow check',
        workflow_id:workflowId,interval_minutes:minutes,first_at:next});
      await loadAutomation();toast('Scheduled on the running PC server.');
    } catch(error){safeError(error);}
  });
  get('backupNow')?.addEventListener('click',async()=>{
    if(!confirm('Create a private local backup on your PC?'))return;
    try {const backup=await v2('/backups','POST',{include_workspace:false});
      toast('Created '+backup.filename);await loadInsights();}
    catch(error){safeError(error);}
  });
  get('refreshProjects')?.addEventListener('click',loadProjects);
  get('refreshCalendar')?.addEventListener('click',loadCalendar);
  get('refreshInsights')?.addEventListener('click',loadInsights);
}
attachAdvancedForms();

/* Explicitly selected local file perception — never opens camera or desktop. */
async function fileAsBase64(file, maxSize) {
  if (file.size > maxSize) throw new Error('File is too large for local analysis.');
  const buffer=await file.arrayBuffer();
  const data=new Uint8Array(buffer);
  // Batch byte conversion to prevent argument-spread stack exhaustion.
  let binary='';
  for(let i=0;i<data.length;i+=0x8000) {
    binary+=String.fromCharCode(...data.subarray(i,i+0x8000));
  }
  return btoa(binary);
}

async function analyzeSelectedImage(event) {
  const input=event.currentTarget;
  const file=input.files?.[0];
  if(!file)return;
  try {
    if(!['image/png','image/jpeg','image/webp'].includes(file.type)) {
      throw new Error('Choose a PNG, JPEG or WEBP image.');
    }
    const prompt=window.prompt('What should JARVIS examine in this image?',
      'Describe the visible objects and any legible text.');
    if(!prompt)return;
    toast('Analyzing selected image using optional local vision model...');
    const image_base64=await fileAsBase64(file,4*1024*1024);
    const result=await api('/perception/image','POST',{prompt,image_base64});
    appendMessage('user','[Image selected] '+prompt);
    appendMessage('assistant',result.answer);
    switchPage('chat');
  } catch(error){safeError(error);}
  finally {input.value='';}
}

async function transcribeSelectedWav(event) {
  const input=event.currentTarget;
  const file=input.files?.[0];
  if(!file)return;
  try {
    if(!file.name.toLowerCase().endsWith('.wav'))throw new Error('Choose a PCM .wav file.');
    toast('Transcribing selected audio locally (if Whisper is installed)...');
    const wav_base64=await fileAsBase64(file,8*1024*1024);
    const result=await api('/perception/audio','POST',{wav_base64});
    appendMessage('assistant','[Audio transcription] '+(result.text||'(No speech detected)'));
    switchPage('chat');
  } catch(error){safeError(error);}
  finally {input.value='';}
}

async function updateKnowledgeStats() {
  const stats=await api('/knowledge/stats');
  get('knowledgeStats').textContent=
    `${stats.sources} indexed sources · ${stats.chunks} searchable chunks · ${stats.fts5?'SQLite full-text index':'basic search'}`;
}
async function performKnowledgeSearch() {
  const query=get('knowledgeQuery').value.trim();
  if(!query)return;
  const rows=await api('/knowledge/search','POST',{query,limit:12});
  const zone=get('knowledgeResults');zone.replaceChildren();
  if(!rows.length)emptyContent(zone,'No matching sources. Try reindexing first.');
  for(const row of rows) {
    zone.append(makeRow(row.title,`${row.source} · relevance ${Number(row.score).toFixed(2)}`,
                        row.snippet));
  }
}

get('knowledgeForm')?.addEventListener('submit',async event=>{
  event.preventDefault();
  try{await performKnowledgeSearch();}
  catch(error){safeError(error);}
});
get('indexRefresh')?.addEventListener('click',async()=>{
  try {
    const result=await api('/knowledge/refresh','POST');
    toast(`Indexed ${result.sources} sources (${result.changed_sources} updated).`);
    await updateKnowledgeStats();
  }catch(error){safeError(error);}
});
get('jarvisImageFile')?.addEventListener('change',analyzeSelectedImage);
get('jarvisWavFile')?.addEventListener('change',transcribeSelectedWav);
