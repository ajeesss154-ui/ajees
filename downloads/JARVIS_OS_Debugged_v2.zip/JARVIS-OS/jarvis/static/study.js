/* Private flashcards; all HTML elements use textContent for user content. */
'use strict';
let studyCurrentDeck = null;
let studyCurrentCard = null;
let studyQueue = [];
let studyAnswerVisible = false;
let studyReady = false;

const study = (path,method='GET',body=undefined) => api('/study'+path,method,body);
const studyElement = id => document.getElementById(id);

async function loadStudy() {
  if (!state.token) return;
  const [decks,stats] = await Promise.all([study('/decks'),study('/statistics')]);
  const counters=studyElement('studyCounters');
  counters.replaceChildren();
  const labels=[['DECKS',stats.decks],['CARDS',stats.cards],['DUE',stats.due],
                ['REVIEWS',stats.reviews]];
  for (const [label,value] of labels) {
    const widget=el('div','module');
    widget.append(el('span','',label),el('strong','',String(value)));
    counters.append(widget);
  }
  const zone=studyElement('studyDeckList');
  zone.replaceChildren();
  if (!decks.length) zone.append(el('p','empty-row','Create a deck to add flashcards.'));
  for (const deck of decks) {
    const row=el('button','study-deck');
    row.type='button';
    row.classList.toggle('active',studyCurrentDeck?.id===deck.id);
    row.append(el('strong','',deck.title),
               el('small','',`${deck.cards} cards · ${deck.due} due`));
    row.onclick=()=>selectStudyDeck(deck);
    zone.append(row);
  }
  if (studyCurrentDeck) {
    const found=decks.find(deck=>deck.id===studyCurrentDeck.id);
    if (found) await selectStudyDeck(found,false);
    else studyCurrentDeck=null;
  }
  if (!studyCurrentDeck && decks.length) await selectStudyDeck(decks[0],false);
  await refreshStudyQueue();
}

async function selectStudyDeck(deck,refreshQueue=true) {
  studyCurrentDeck=deck;
  studyElement('studyDeckSelected').textContent=deck.title.toUpperCase().slice(0,45);
  const cards=await study(`/decks/${encodeURIComponent(deck.id)}/cards`);
  const area=studyElement('studyCards');
  area.replaceChildren();
  if (!cards.length) area.append(el('p','empty-row','No flashcards yet. Add your first question.'));
  for (const card of cards) {
    const row=el('div','collection-row');
    const copy=el('div','adv-row-content');
    copy.append(el('strong','',card.front),el('small','',`Due: ${card.due_on}`),
                el('div','note-body',card.back));
    row.append(copy);
    const remove=el('button','compact-button','Remove');
    remove.type='button';
    remove.onclick=async()=>{
      if (!confirm('Remove this flashcard?')) return;
      try {
        await study(`/cards/${encodeURIComponent(card.id)}`,'DELETE');
        await loadStudy();
      } catch (err) {toast(err.message);}
    };
    row.append(remove);
    area.append(row);
  }
  if (refreshQueue) await refreshStudyQueue();
  studyElement('studyDeckList').querySelectorAll('button.study-deck').forEach(node => {
    node.classList.toggle('active',node.textContent.includes(deck.title));
  });
}

async function refreshStudyQueue() {
  if (!studyElement('studyReviewPanel')) return;
  const cards=await study('/due?limit=100');
  const active=studyCurrentDeck ? cards.filter(card=>card.deck_id===studyCurrentDeck.id) : cards;
  studyQueue=active;
  studyElement('studyReviewCount').textContent=`${active.length} DUE`;
  studyCurrentCard=active[0] || null;
  studyAnswerVisible=false;
  updateStudyReview();
}

function updateStudyReview() {
  const card=studyCurrentCard;
  studyElement('studyReviewQuestion').textContent=card?.front || 'Nothing due right now.';
  studyElement('studyReviewAnswer').textContent=card?.back || '';
  studyElement('studyReviewAnswer').classList.toggle('hidden',!studyAnswerVisible);
  studyElement('studyReveal').disabled=!card || studyAnswerVisible;
  for (const id of ['studyAgain','studyHard','studyGood','studyEasy']) {
    studyElement(id).disabled=!card || !studyAnswerVisible;
  }
}

async function reviewStudyCard(grade) {
  if (!studyCurrentCard || !studyAnswerVisible) return;
  const card=studyCurrentCard;
  try {
    const answer=await study(`/cards/${encodeURIComponent(card.id)}/review`,
                             'POST',{grade});
    toast(`Saved review. Next due ${answer.next_due_on}.`);
    await loadStudy();
  } catch (error) {toast(error.message);}
}

studyElement('studyDeckForm')?.addEventListener('submit',async event=>{
  event.preventDefault();
  const title=studyElement('studyDeckName').value.trim();
  if (!title) return;
  try {
    const deck=await study('/decks','POST',{title});
    studyCurrentDeck=deck;
    studyElement('studyDeckName').value='';
    await loadStudy();
    toast('Study deck created.');
  } catch(error) {toast(error.message);}
});

studyElement('studyCardForm')?.addEventListener('submit',async event=>{
  event.preventDefault();
  if (!studyCurrentDeck) {toast('Select or create a study deck first.');return;}
  try {
    await study(`/decks/${encodeURIComponent(studyCurrentDeck.id)}/cards`,'POST',{
      front:studyElement('studyQuestion').value.trim(),
      back:studyElement('studyAnswer').value.trim()});
    studyElement('studyQuestion').value='';
    studyElement('studyAnswer').value='';
    await loadStudy();
    toast('Card saved.');
  } catch(error) {toast(error.message);}
});

studyElement('studyRefresh')?.addEventListener('click',()=>loadStudy().catch(err=>toast(err.message)));
studyElement('studyReveal')?.addEventListener('click',()=>{
  studyAnswerVisible=true;
  updateStudyReview();
});
for (const [button,grade] of [['studyAgain',0],['studyHard',2],
                              ['studyGood',4],['studyEasy',5]]) {
  studyElement(button)?.addEventListener('click',()=>reviewStudyCard(grade));
}
