/* JARVIS OS — zero-framework browser UI. All server-supplied text uses textContent. */
'use strict';

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => [...document.querySelectorAll(sel)];
const uniqueId = () => (globalThis.crypto?.randomUUID?.() || 'session-' + Date.now() + '-' + Math.random().toString(36).slice(2));
const state = {
  token: sessionStorage.getItem('jarvis_token') || '',
  session: localStorage.getItem('jarvis_session') || uniqueId(),
  page: 'chat',
  speaking: false,
  recording: false,
  busy: false,
  recognition: null,
  statusTimer: null,
  noticeTimer: null,
  connectionGeneration: 0,
  requests: new Set(),
};
const CONNECTION_ENDED = 'Connection changed. Please retry.';
function cancelConnectionWork() {
  state.connectionGeneration++;
  for (const controller of state.requests) controller.abort();
  state.requests.clear();
}
localStorage.setItem('jarvis_session', state.session);

async function api(path, method='GET', body=undefined) {
  const generation = state.connectionGeneration;
  const controller = new AbortController();
  state.requests.add(controller);
  const headers = {Authorization: 'Bearer ' + state.token};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  try {
    let response;
    try {
      response = await fetch('/api' + path, {method, headers, body:body === undefined ? undefined : JSON.stringify(body), cache:'no-store', signal:controller.signal});
    } catch (_) {
      if (generation !== state.connectionGeneration || controller.signal.aborted) throw new Error(CONNECTION_ENDED);
      throw new Error('Could not reach JARVIS server. Is it still running?');
    }
    if (generation !== state.connectionGeneration) throw new Error(CONNECTION_ENDED);
    if (response.status === 401) {
      disconnect();
      throw new Error('Invalid session token. Please reconnect.');
    }
    const content = await response.json().catch(() => ({}));
    if (generation !== state.connectionGeneration) throw new Error(CONNECTION_ENDED);
    if (!response.ok) throw new Error(typeof content.detail === 'string' ? content.detail : `Request failed (${response.status})`);
    return content;
  } finally { state.requests.delete(controller); }
}

function el(tag, className='', text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function toast(message) {
  if (message === CONNECTION_ENDED) return;
  const node = el('div','toast',message);
  $('#toastArea').prepend(node);
  setTimeout(() => node.remove(), 6500);
}

function setStatus(message, online) {
  $('#engineStatus').textContent = message;
  $('#engineIndicator').classList.toggle('offline', !online);
  $('#coreState').textContent = online ? 'AWAITING INSTRUCTIONS' : 'MODEL NOT CONNECTED';
}

async function connect(token) {
  cancelConnectionWork();
  state.token = token.trim();
  if (!state.token) throw new Error('Please enter the token from your terminal.');
  const me = await api('/me');
  sessionStorage.setItem('jarvis_token', state.token);
  $('#loginOverlay').classList.add('hidden');
  $('#loginError').textContent = '';
  $('#sidebarModel').textContent = `${me.provider} / ${me.model}`;
  setStatus('Server connected', true);
  await Promise.allSettled([loadHistory(), refreshApprovals(), refreshStatus(), loadTasks(), loadNotes(), checkNotifications()]);
  if (typeof loadAdvancedPage === 'function' && state.page !== 'chat') loadAdvancedPage(state.page);
  if (!state.statusTimer) state.statusTimer = setInterval(refreshStatus, 20000);
  if (!state.noticeTimer) state.noticeTimer = setInterval(checkNotifications, 15000);
}

function disconnect() {
  cancelConnectionWork();
  try { state.recognition?.abort(); } catch (_) { /* Already stopped. */ }
  window.speechSynthesis?.cancel();
  state.recording = false;
  state.speaking = false;
  state.busy = false;
  $('#sendBtn').disabled = false;
  $('#micBtn').classList.remove('listening');
  $('#voiceToggle').setAttribute('aria-pressed', 'false');
  $('#voiceToggle').textContent = '🔇 Voice off';
  for (const id of ['chatMessages','approvalZone','taskList','reminderList','noteList','factList','auditList','toolList','projectsList','projectTasks','goalsList','habitsList','calendarList','workflowList','schedulesList','insightNumbers','insightHistory','backupList','studyCounters','studyDeckList','studyCards','studyReviewQuestion','studyReviewAnswer','labCounters','labIdeasList','labExperimentsList','labFeedbackList','knowledgeStats','knowledgeResults','skillResult','skillSchema']) {
    document.getElementById(id)?.replaceChildren();
  }
  document.querySelectorAll('form:not(#loginForm)').forEach(form => form.reset());
  state.token = '';
  sessionStorage.removeItem('jarvis_token');
  clearInterval(state.statusTimer);
  clearInterval(state.noticeTimer);
  state.statusTimer = null;
  state.noticeTimer = null;
  $('#loginOverlay').classList.remove('hidden');
  setStatus('Not connected', false);
}

const pageLabels = {chat:'AI ASSISTANT',device:'DEVICE STATUS',tasks:'TASKS & REMINDERS',notes:'MEMORY & NOTES',activity:'ACTIVITY LOG',projects:'PROJECTS',habits:'GOALS & HABITS',calendar:'LOCAL CALENDAR',automation:'WORKFLOWS',insights:'INSIGHTS',skills:'OFFLINE SKILLS',study:'STUDY DECKS',lab:'STARTUP LAB'};
function switchPage(page) {
  if (!pageLabels[page]) return;
  state.page = page;
  $$('.page').forEach(n => n.classList.toggle('active', n.id === page+'Page'));
  $$('.nav-item').forEach(n => n.classList.toggle('active', n.dataset.page === page));
  $('#breadcrumb').textContent = pageLabels[page];
  if (!state.token) return;
  if (page === 'tasks') loadTasks();
  if (page === 'notes') loadNotes();
  if (page === 'device') refreshStatus();
  if (page === 'activity') loadAudit();
  if (typeof loadAdvancedPage === 'function') loadAdvancedPage(page);
}

function appendMessage(role, text) {
  const log = $('#chatMessages');
  log.querySelector('.empty-conversation')?.remove();
  const outer = el('div', 'message ' + (role === 'user' ? 'user' : 'assistant'));
  outer.append(el('div','message-avatar', role === 'user' ? '◉' : '◈'));
  const body = el('div','message-body');
  body.append(el('div','message-name', role === 'user' ? 'YOU' : 'JARVIS'));
  body.append(el('div','message-text', text));
  outer.append(body);
  log.append(outer);
  log.scrollTop = log.scrollHeight;
  return outer;
}

async function loadHistory() {
  try {
    const history = await api('/history/' + encodeURIComponent(state.session));
    $('#chatMessages').replaceChildren();
    if (!history.length) {
      const empty = el('div', 'empty-conversation');
      empty.append(el('span','empty-logo','◈'), el('strong','', 'Systems standing by.'),
                   el('span','','Type a message or tap the microphone to begin.'));
      $('#chatMessages').append(empty);
    }
    history.forEach(msg => appendMessage(msg.role, msg.content));
  } catch (err) {toast(err.message);}
}

async function sendMessage(raw) {
  const message = raw.trim();
  if (!message || state.busy || !state.token) return;
  const generation = state.connectionGeneration;
  state.busy = true;
  $('#sendBtn').disabled = true;
  $('#chatInput').value = '';
  $('#chatInput').style.height = '';
  appendMessage('user', message);
  const placeholder = appendMessage('assistant', 'Thinking...');
  $('#coreState').textContent = 'PROCESSING REQUEST';
  try {
    const result = await api('/chat', 'POST', {message, session_id:state.session});
    placeholder.querySelector('.message-text').textContent = result.reply;
    if (result.offline) setStatus('AI model not connected', false);
    if (result.approvals?.length) await refreshApprovals();
    if (state.speaking) speak(result.reply);
    if (result.tools_used?.length) {
      await Promise.allSettled([refreshStatus(), loadTasks(), loadNotes()]);
    }
  } catch (err) {
    if (generation !== state.connectionGeneration) return;
    placeholder.querySelector('.message-text').textContent = 'Error: ' + err.message;
    toast(err.message);
  } finally {
    if (generation !== state.connectionGeneration) return;
    state.busy = false;
    $('#sendBtn').disabled = false;
    $('#coreState').textContent = 'AWAITING INSTRUCTIONS';
    $('#chatInput').focus();
    $('#chatMessages').scrollTop = $('#chatMessages').scrollHeight;
  }
}

async function refreshApprovals() {
  if (!state.token) return;
  try {
    const pending = await api('/approvals');
    const zone = $('#approvalZone');
    zone.replaceChildren();
    for (const request of pending) {
      const card = el('div','approval-card');
      card.append(el('span','',`⚠ Permission needed · ${request.description}`));
      const buttons = el('div','approval-buttons');
      const yes = el('button','approve-btn','Approve');
      const no = el('button','deny-btn','Deny');
      yes.onclick = () => decide(request.id, true);
      no.onclick = () => decide(request.id, false);
      buttons.append(yes,no);
      card.append(buttons);
      zone.append(card);
    }
  } catch (err) {toast(err.message);}
}

async function decide(id, approve) {
  try {
    const result = await api(`/approvals/${encodeURIComponent(id)}/${approve ? 'approve' : 'deny'}`, 'POST');
    toast(result.status === 'completed' ? 'Action approved and completed.' : result.message);
    appendMessage('assistant', result.status === 'completed' ? 'Permission granted. ' + result.message : result.message);
    await Promise.allSettled([refreshApprovals(), refreshStatus(), loadAudit()]);
  } catch (err) {toast(err.message);}
}

function percent(node, value) {
  node.textContent = typeof value === 'number' ? Math.round(value) + '%' : '--';
}
function meter(name, value) {
  $(name).style.width = typeof value === 'number' ? Math.max(0, Math.min(value,100))+'%' : '0%';
}
async function refreshStatus() {
  if (!state.token) return;
  try {
    const result = await api('/status');
    if (!result.ok) throw new Error(result.error || 'Telemetry unavailable');
    const v = result.result;
    percent($('#cpuShort'), v.cpu_percent);
    percent($('#ramShort'), v.ram_used_percent);
    $('#batteryShort').textContent = v.battery_percent === null ? 'N/A' : Math.round(v.battery_percent) + '%';
    percent($('#deviceCPU'),v.cpu_percent);
    percent($('#deviceRAM'),v.ram_used_percent);
    percent($('#deviceDisk'),v.disk_usage_percent);
    $('#deviceBattery').textContent = v.battery_percent === null ? 'N/A' : Math.round(v.battery_percent) + '%';
    meter('#cpuMeter',v.cpu_percent);meter('#ramMeter',v.ram_used_percent);
    meter('#diskMeter',v.disk_usage_percent);meter('#batteryMeter',v.battery_percent);
    $('#deviceDetails').textContent = `OS:             ${v.platform}\nCPU CORES:      ${v.cpu_logical_cores}\nTOTAL RAM:      ${v.ram_total_gb} GB\nBATTERY POWER:  ${v.battery_plugged_in === null ? 'unknown' : v.battery_plugged_in ? 'plugged in' : 'on battery'}\nDATA:           Live from host PC`;
  } catch (_) { /* dashboard remains usable even if telemetry fails */ }
}

function collectionEmpty(parent, msg) {parent.append(el('div','empty-row',msg));}

async function loadTasks() {
  if (!state.token) return;
  try {
    const [tasks,reminders] = await Promise.all([api('/tasks'),api('/reminders')]);
    const taskList = $('#taskList');taskList.replaceChildren();
    const open = tasks.filter(t => !t.completed).length;
    $('#taskCount').textContent = `${open} OPEN`;
    if (!tasks.length) collectionEmpty(taskList,'No tasks yet. Create one above.');
    for (const task of tasks) {
      const row = el('div','collection-row'+(task.completed ? ' completed':''));
      const text = el('div');text.append(el('strong','',task.title),el('small','', task.completed ? 'COMPLETED' : 'OPEN'));
      row.append(text);
      if (!task.completed) {const btn = el('button','','✓ Done');btn.onclick = async()=>{
        try {await api('/tasks/'+encodeURIComponent(task.id)+'/complete','POST'); await loadTasks();}catch(e){toast(e.message);}
      };row.append(btn);}
      taskList.append(row);
    }
    const list = $('#reminderList');list.replaceChildren();
    if (!reminders.length) collectionEmpty(list,'No upcoming reminders.');
    for (const reminder of reminders) {
      const row = el('div','collection-row');const body = el('div');
      body.append(el('strong','',reminder.text),el('small','',new Date(reminder.due_at).toLocaleString()));
      row.append(body);list.append(row);
    }
  } catch(err){toast(err.message);}
}

async function loadNotes() {
  if (!state.token) return;
  try {
    const [notes, facts] = await Promise.all([api('/notes'),api('/facts')]);
    const list = $('#noteList');list.replaceChildren();
    if (!notes.length) collectionEmpty(list,'Your notes will appear here.');
    for (const note of notes.slice(0,35)) {
      const row=el('div','collection-row');const text=el('div');
      text.append(el('strong','',note.title),el('small','',new Date(note.created_at).toLocaleString()));
      text.append(el('div','note-body',note.body));row.append(text);list.append(row);
    }
    const factsList=$('#factList');factsList.replaceChildren();
    if (!facts.length) collectionEmpty(factsList,'Say “Remember that my favorite coding language is Python”.');
    for (const fact of facts) {
      const row=el('div','collection-row');const text=el('div');
      text.append(el('strong','',fact.key),el('small','',fact.value));row.append(text);factsList.append(row);
    }
  } catch(err){toast(err.message);}
}

async function loadAudit() {
  if (!state.token) return;
  try {
    const [logs,tools] = await Promise.all([api('/audit'),api('/tools')]);
    const list=$('#auditList');list.replaceChildren();
    if (!logs.length) collectionEmpty(list,'No tool actions recorded yet.');
    for (const log of logs) {
      const row=el('div','collection-row');const text=el('div');
      text.append(el('strong','',`${log.tool} · ${log.status}`));
      text.append(el('small','',new Date(log.created_at).toLocaleString()));
      const detail=el('div','note-body',log.result);text.append(detail);row.append(text);list.append(row);
    }
    const grid=$('#toolList');grid.replaceChildren();
    for (const tool of tools) {
      const item=el('div','tool-item');
      item.append(el('strong','',tool.name),el('small','',tool.description));
      if(tool.approval)item.append(el('span','approval-tag','⚠ REQUIRES APPROVAL'));
      grid.append(item);
    }
  } catch(err){toast(err.message);}
}

async function checkNotifications() {
  if (!state.token) return;
  try {
    const notices=await api('/notifications');
    for (const note of notices) {
      toast('⏰ JARVIS Reminder: ' + note.text);
      if (state.speaking) speak('Reminder: '+note.text);
      await api('/notifications/'+encodeURIComponent(note.id)+'/ack','POST');
    }
    if (notices.length) await loadTasks();
  } catch(_) { /* offline polling should be quiet */ }
}

function speak(text) {
  if (!('speechSynthesis' in window)) return;
  window.speechSynthesis.cancel();
  const utterance=new SpeechSynthesisUtterance(text.slice(0,1800));
  utterance.rate=1.02;utterance.pitch=.90;utterance.lang='en-US';
  speechSynthesis.speak(utterance);
}
function setupSpeech() {
  const Speech=window.SpeechRecognition || window.webkitSpeechRecognition;
  const mic=$('#micBtn');
  if (!Speech) {mic.title='Speech recognition is unsupported in this browser';mic.disabled=true;return;}
  if (!window.isSecureContext) {mic.title='Phone microphone requires HTTPS; text chat still works';mic.disabled=true;return;}
  const recognition=new Speech();recognition.lang='en-US';recognition.continuous=false;recognition.interimResults=false;
  recognition.onresult=(event)=>{
    const transcript=event.results?.[0]?.[0]?.transcript || '';
    if(transcript)sendMessage(transcript);
  };
  recognition.onerror=(event)=>toast('Microphone: '+event.error);
  recognition.onend=()=>{state.recording=false;mic.classList.remove('listening');mic.title='Tap to speak';};
  state.recognition=recognition;
  mic.onclick=()=>{
    try {
      if(state.recording)recognition.stop();
      else {recognition.start();state.recording=true;mic.classList.add('listening');mic.title='Listening... tap to stop';}
    } catch(err){toast('Microphone: '+err.message);}
  };
}

$('#loginForm').addEventListener('submit', async (event)=>{
  event.preventDefault();
  const btn=$('#loginForm button');btn.disabled=true;
  try{await connect($('#accessToken').value);$('#accessToken').value='';}
  catch(err){$('#loginError').textContent=err.message;}
  finally{btn.disabled=false;}
});
$('#logout').onclick=disconnect;
$$('.nav-item').forEach(btn=>btn.onclick=()=>switchPage(btn.dataset.page));
$$('.prompt-chip').forEach(btn=>btn.onclick=()=>sendMessage(btn.dataset.message));
$('#chatForm').addEventListener('submit',event=>{event.preventDefault();sendMessage($('#chatInput').value);});
$('#chatInput').addEventListener('keydown',event=>{
  if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();sendMessage($('#chatInput').value);}
});
$('#chatInput').addEventListener('input',()=>{
  $('#chatInput').style.height='auto';
  $('#chatInput').style.height=Math.min($('#chatInput').scrollHeight,130)+'px';
});
$('#clearChat').onclick=async()=>{
  if(!confirm('Delete the message history for this conversation? Saved notes and tasks will remain.'))return;
  try{await api('/history/'+encodeURIComponent(state.session),'DELETE'); await loadHistory();}
  catch(err){toast(err.message);}
};
$('#voiceToggle').onclick=()=>{
  state.speaking=!state.speaking;
  $('#voiceToggle').setAttribute('aria-pressed',String(state.speaking));
  $('#voiceToggle').textContent=state.speaking?'🔊 Voice on':'🔇 Voice off';
  if(!state.speaking)window.speechSynthesis?.cancel();
};
$('#refreshStatus').onclick=refreshStatus;
$('#refreshAudit').onclick=loadAudit;
$('#taskForm').addEventListener('submit',async(event)=>{
  event.preventDefault();const title=$('#taskTitle').value.trim();if(!title)return;
  try{await api('/tasks','POST',{title});$('#taskTitle').value='';await loadTasks();toast('Task created.');}
  catch(err){toast(err.message);}
});
$('#noteForm').addEventListener('submit',async(event)=>{
  event.preventDefault();const title=$('#noteTitle').value.trim();const body=$('#noteBody').value.trim();if(!title||!body)return;
  try{await api('/notes','POST',{title,body});$('#noteTitle').value='';$('#noteBody').value='';await loadNotes();toast('Note saved locally.');}
  catch(err){toast(err.message);}
});
$('#reminderForm').addEventListener('submit',async(event)=>{
  event.preventDefault();const text=$('#reminderText').value.trim();const local=$('#reminderWhen').value;
  if(!text||!local)return;
  const date=new Date(local);
  if(Number.isNaN(date.getTime())){toast('Please choose a valid date and time.');return;}
  try{await api('/reminders','POST',{text,due_at:date.toISOString()});$('#reminderText').value='';$('#reminderWhen').value='';await loadTasks();toast('Reminder scheduled. Keep the server running.');}
  catch(err){toast(err.message);}
});
setupSpeech();
setInterval(()=>$('#clock').textContent=new Date().toLocaleTimeString(),1000);
$('#clock').textContent=new Date().toLocaleTimeString();
if(state.token) connect(state.token).catch(err=>{$('#loginError').textContent=err.message;disconnect();});
