/* Private idea lab, experiments and feedback. Untrusted data uses textContent. */
'use strict';
const lab = (path,method='GET',data=undefined) => api('/lab'+path,method,data);
const labField = id => document.getElementById(id);

async function loadLab() {
  if (!state.token) return;
  const [overview,ideas,experiments,feedback] = await Promise.all([
    lab('/overview'),lab('/ideas'),lab('/experiments'),lab('/feedback')]);
  const stats=labField('labCounters');
  stats.replaceChildren();
  const numbers=[['IDEAS',ideas.length],['EXPERIMENTS',experiments.length],
                 ['NEW FEEDBACK',overview.new_feedback],['DECISIONS',overview.decisions]];
  for (const [label,value] of numbers) {
    const widget=el('div','module');
    widget.append(el('span','',label),el('strong','',String(value)));
    stats.append(widget);
  }

  const ideaZone=labField('labIdeasList');
  ideaZone.replaceChildren();
  if (!ideas.length) ideaZone.append(el('p','empty-row','No ideas saved yet.'));
  for (const idea of ideas) {
    const row=el('div','collection-row');
    const content=el('div','adv-row-content');
    content.append(el('strong','',idea.title),
                   el('small','',`${idea.status.toUpperCase()} · PRIORITY ${idea.priority_score}`),
                   el('div','note-body',`PROBLEM: ${idea.problem}\nSOLUTION: ${idea.solution}`));
    row.append(content);
    const select=el('select','lab-status');
    for (const choice of ['backlog','research','testing','ready','paused','discarded']) {
      const opt=el('option','',choice);
      opt.value=choice;
      select.append(opt);
    }
    select.value=idea.status;
    select.setAttribute('aria-label','Status for '+idea.title);
    select.onchange=async()=>{
      select.disabled=true;
      try {
        await lab(`/ideas/${encodeURIComponent(idea.id)}`,'PATCH',{status:select.value});
        await loadLab();
      } catch(error) {toast(error.message);select.value=idea.status;}
      finally {select.disabled=false;}
    };
    row.append(select);
    ideaZone.append(row);
  }

  const experimentSelect=labField('labExperimentIdea');
  const current=experimentSelect.value;
  experimentSelect.replaceChildren();
  const fallback=el('option','','Choose an idea');fallback.value='';
  experimentSelect.append(fallback);
  for (const idea of ideas) {
    const option=el('option','',idea.title);
    option.value=idea.id;
    experimentSelect.append(option);
  }
  experimentSelect.value=ideas.some(idea=>idea.id===current) ? current : '';

  const expZone=labField('labExperimentsList');
  expZone.replaceChildren();
  if (!experiments.length) expZone.append(el('p','empty-row','Add a hypothesis and a measurement before testing.'));
  for (const experiment of experiments) {
    const row=el('div','collection-row');
    const content=el('div','adv-row-content');
    content.append(el('strong','',experiment.hypothesis),
                   el('small','',`${experiment.status.toUpperCase()} · ${experiment.metric}`),
                   el('div','note-body',experiment.success_criterion));
    row.append(content);
    if (experiment.status==='planned') {
      const run=el('button','compact-button','Mark running');
      run.type='button';
      run.onclick=async()=>{
        try {
          await lab(`/experiments/${encodeURIComponent(experiment.id)}`,'PATCH',{status:'running'});
          await loadLab();
        } catch(error) {toast(error.message);}
      };
      row.append(run);
    }
    expZone.append(row);
  }

  const feedbackZone=labField('labFeedbackList');
  feedbackZone.replaceChildren();
  if (!feedback.length) feedbackZone.append(el('p','empty-row','Feedback you save will appear here.'));
  for (const item of feedback) {
    const row=el('div','collection-row');
    const content=el('div','adv-row-content');
    content.append(el('strong','',item.source),
                   el('small','',item.status.toUpperCase()+' · '+item.created_at),
                   el('div','note-body',item.message));
    row.append(content);
    if (item.status==='new') {
      const mark=el('button','compact-button','Reviewed');
      mark.type='button';
      mark.onclick=async()=>{
        try {
          await lab(`/feedback/${encodeURIComponent(item.id)}`,'PATCH',{status:'reviewed'});
          await loadLab();
        } catch(error){toast(error.message);}
      };
      row.append(mark);
    }
    feedbackZone.append(row);
  }
}

labField('labIdeaForm')?.addEventListener('submit',async event=>{
  event.preventDefault();
  const input={
    title:labField('labIdeaTitle').value.trim(),
    problem:labField('labIdeaProblem').value.trim(),
    solution:labField('labIdeaSolution').value.trim(),
    audience:labField('labIdeaAudience').value.trim(),
    impact:Number(labField('labIdeaImpact').value),
    confidence:Number(labField('labIdeaConfidence').value),
    effort:Number(labField('labIdeaEffort').value)
  };
  try {
    await lab('/ideas','POST',input);
    labField('labIdeaForm').reset();
    await loadLab();
    toast('Idea saved privately on this PC.');
  } catch(error) {toast(error.message);}
});

labField('labExperimentForm')?.addEventListener('submit',async event=>{
  event.preventDefault();
  const input={idea_id:labField('labExperimentIdea').value,
               hypothesis:labField('labExperimentHypothesis').value.trim(),
               metric:labField('labExperimentMetric').value.trim(),
               success_criterion:labField('labExperimentCriterion').value.trim()};
  if (!input.idea_id) {toast('Choose a saved idea first.');return;}
  try {
    await lab('/experiments','POST',input);
    labField('labExperimentForm').reset();
    await loadLab();
    toast('Experiment saved.');
  } catch(error) {toast(error.message);}
});

labField('labFeedbackForm')?.addEventListener('submit',async event=>{
  event.preventDefault();
  const input={source:labField('labFeedbackSource').value.trim(),
               message:labField('labFeedbackMessage').value.trim()};
  try {
    await lab('/feedback','POST',input);
    labField('labFeedbackForm').reset();
    await loadLab();
    toast('Feedback saved.');
  } catch(error) {toast(error.message);}
});

labField('labRefresh')?.addEventListener('click',()=>loadLab().catch(err=>toast(err.message)));
