"""Perception API: submit your own image or WAV file explicitly.

Authenticated by the main app's bearer token. Responses describe *only* the
submitted media. No automatic capture, OS access or persistent storage.
"""
from __future__ import annotations

import asyncio
import base64
import binascii
from typing import Callable

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from .images import OllamaVision, ImageRejected, ImageValidator
from .audio import OfflineTranscriber, AudioRejected, WavValidator


class VisionRequest(BaseModel):
    prompt: str = Field(min_length=1,max_length=1200)
    image_base64: str = Field(min_length=50,max_length=6_000_000)


class AudioRequest(BaseModel):
    wav_base64: str = Field(min_length=50,max_length=11_000_000)
    language: str | None = Field(default=None,max_length=8)


def build_router(auth:Callable, url:str) -> APIRouter:
    router=APIRouter(prefix='/api/perception',tags=['Opt-in Perception'],
                     dependencies=[Depends(auth)])
    vision=OllamaVision(url)
    transcriber=OfflineTranscriber()

    @router.get('/features')
    def features():
        return {
            'image_description':{'enabled':True,'model':vision.model,'requires':'Pillow and local Ollama vision model'},
            'wav_transcription':{'enabled':True,'requires':'faster-whisper and a downloaded STT model'},
            'automatic_capture':False,'records_media':False,
        }

    @router.post('/image')
    async def describe_image(data:VisionRequest):
        try:
            raw=ImageValidator.from_base64(data.image_base64)
            return await vision.describe(data.prompt,raw)
        except ImageRejected as exc:
            raise HTTPException(400,str(exc)) from exc

    @router.post('/audio')
    async def transcribe_audio(data:AudioRequest):
        try:
            raw=base64.b64decode(data.wav_base64,validate=True)
            WavValidator.inspect(raw)
            return await asyncio.to_thread(transcriber.transcribe,raw,language=data.language)
        except (ValueError,binascii.Error,AudioRejected) as exc:
            raise HTTPException(400,str(exc)) from exc

    return router
