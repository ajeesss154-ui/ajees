"""Opt-in audio validation and optional on-device speech recognition.

A web browser may already provide speech recognition. This module adds an
optional faster-whisper backend for a PC that has the necessary ML runtime.
The audio is never recorded automatically or uploaded by this module.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import io
import os
import struct
import tempfile
import threading
import wave
from typing import Any


class AudioRejected(ValueError):
    pass


MAX_AUDIO_BYTES=8*1024*1024
MAX_DURATION_SECONDS=120
SUPPORTED_SAMPLING={8000,16000,22050,24000,32000,44100,48000}


@dataclass(frozen=True)
class AudioFacts:
    channels: int
    sample_rate: int
    frames: int
    seconds: float
    sample_width: int

    def as_dict(self) -> dict:
        return self.__dict__.copy()


class WavValidator:
    """Validate finite-length PCM WAV without allocating sample buffers."""
    @staticmethod
    def inspect(raw: bytes) -> AudioFacts:
        if not isinstance(raw,bytes) or not 44<=len(raw)<=MAX_AUDIO_BYTES:
            raise AudioRejected('WAV audio must be 44 bytes to 8 MB')
        try:
            with wave.open(io.BytesIO(raw),'rb') as wav:
                channels=wav.getnchannels()
                sample_rate=wav.getframerate()
                sample_width=wav.getsampwidth()
                frames=wav.getnframes()
                compression=wav.getcomptype()
                expected_bytes=frames*channels*sample_width
                if expected_bytes>MAX_AUDIO_BYTES:
                    raise AudioRejected('Decoded audio is too large')
                # Header declarations alone do not prove that PCM samples exist.
                # Read one extra frame to reject partial trailing stereo frames too.
                if len(wav.readframes(frames+1))!=expected_bytes:
                    raise AudioRejected('WAV sample data is truncated or misaligned')
        except AudioRejected:
            raise
        except (EOFError,wave.Error,ValueError) as exc:
            raise AudioRejected('Unsupported WAV container') from exc
        if compression!='NONE' or channels not in {1,2}:
            raise AudioRejected('Only mono/stereo PCM WAV is supported')
        if sample_width not in {1,2,3,4} or sample_rate not in SUPPORTED_SAMPLING:
            raise AudioRejected('Unsupported WAV format or sample rate')
        seconds=frames/sample_rate
        if seconds<=0 or seconds>MAX_DURATION_SECONDS:
            raise AudioRejected('Audio must be 0–120 seconds')
        return AudioFacts(channels,sample_rate,frames,round(seconds,2),sample_width)


def clip_16bit(samples:list[int],minimum:int=-32768,maximum:int=32767) -> bytes:
    """Convert signed integer PCM sample values, clipping safely."""
    if len(samples)>MAX_DURATION_SECONDS*48000*2:
        raise AudioRejected('Too many samples')
    return struct.pack('<'+'h'*len(samples),
                       *(max(minimum,min(maximum,int(value))) for value in samples))


def wav_from_samples(samples: list[int], *, sample_rate: int=16000,
                     channels: int=1) -> bytes:
    if sample_rate not in SUPPORTED_SAMPLING:raise AudioRejected('Unsupported sample rate')
    if channels not in {1,2}:raise AudioRejected('Unsupported channel count')
    if len(samples)%channels:raise AudioRejected('Samples must contain complete channel frames')
    content=clip_16bit(samples)
    buffer=io.BytesIO()
    with wave.open(buffer,'wb') as wav:
        wav.setnchannels(channels)
        wav.setsampwidth(2)
        wav.setframerate(sample_rate)
        wav.writeframes(content)
    return buffer.getvalue()


class OfflineTranscriber:
    """Load the Whisper model only when a user explicitly asks to transcribe."""
    def __init__(self,model_size: str='tiny', device: str='cpu',compute_type:str='int8'):
        self.model_size=model_size
        self.device=device
        self.compute_type=compute_type
        self._model=None
        self._lock=threading.Lock()

    def _load(self):
        if self._model is not None:return self._model
        try:
            from faster_whisper import WhisperModel
        except ImportError as exc:
            raise AudioRejected('Install offline STT: pip install -e ".[speech]"') from exc
        try:
            # Downloading a model, if not cached, is performed by library on first use.
            self._model=WhisperModel(self.model_size,device=self.device,
                                     compute_type=self.compute_type)
        except Exception as exc:
            raise AudioRejected('Whisper model could not be loaded') from exc
        return self._model

    def transcribe(self,audio:bytes, *, language: str|None=None) -> dict:
        info=WavValidator.inspect(audio)
        if language is not None and (len(language)>8 or not language.isalpha()):
            raise AudioRejected('Invalid language hint')
        with self._lock:
            model=self._load()
            tmp_path=None
            try:
                with tempfile.NamedTemporaryFile(suffix='.wav',delete=False) as temporary:
                    temporary.write(audio)
                    tmp_path=Path(temporary.name)
                segments,metadata=model.transcribe(str(tmp_path),beam_size=3,
                                                   language=language,vad_filter=True)
                passages=[]
                for i,segment in enumerate(segments):
                    if i>=120:break
                    passages.append({'start':round(segment.start,2),
                                     'end':round(segment.end,2),
                                     'text':segment.text.strip()})
                return {'text':' '.join(x['text'] for x in passages),
                        'segments':passages,'language':getattr(metadata,'language',None),
                        'duration_seconds':info.seconds,'offline':True}
            finally:
                if tmp_path is not None:
                    try:tmp_path.unlink(missing_ok=True)
                    except OSError:pass
