"""Opt-in local image and audio perception tools."""
