"""Local knowledge search with optional TF-IDF similarity.

No text leaves the machine during indexing. Searches only notes and the
explicitly designated JARVIS workspace, not the user's entire hard drive.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re

from .storage import Database
from .advanced.security import is_protected_name

SAFE_EXTENSIONS = {".md", ".txt", ".csv", ".json", ".py", ".yaml", ".yml"}


@dataclass
class KnowledgeHit:
    source: str
    title: str
    snippet: str
    relevance: float

    def as_dict(self) -> dict:
        return {"source": self.source, "title": self.title,
                "snippet": self.snippet, "relevance": round(self.relevance, 3)}


class KnowledgeSearch:
    def __init__(self, db: Database, workspace: Path):
        self.db = db
        self.workspace = workspace.resolve()

    def documents(self, max_documents: int = 250) -> list[dict]:
        data = []
        for note in self.db.notes(limit=100):
            data.append({"source": "note:" + note["id"],
                         "title": note["title"], "text": note["body"][:12000]})
        for path in self.workspace.rglob('*'):
            if len(data) >= max_documents:
                break
            if path.is_symlink() or not path.is_file() or path.suffix.lower() not in SAFE_EXTENSIONS:
                continue
            relative = path.relative_to(self.workspace)
            if any(is_protected_name(part) for part in relative.parts):
                continue
            real = path.resolve()
            if not real.is_relative_to(self.workspace):
                continue
            if any(is_protected_name(part) for part in real.relative_to(self.workspace).parts):
                continue
            try:
                if path.stat().st_size > 60000:
                    continue
                content = path.read_text(encoding='utf-8')[:12000]
            except (OSError, UnicodeError):
                continue
            data.append({"source": "workspace:" + str(path.relative_to(self.workspace)),
                         "title": path.name, "text": content})
        return data

    def search(self, query: str, limit: int = 5) -> list[dict]:
        if not isinstance(query, str) or not query.strip() or len(query) > 350:
            raise ValueError('Use a short, non-empty search query (max 350 characters)')
        documents = self.documents()
        if not documents:
            return []
        texts = [f"{item['title']} {item['title']} {item['text']}" for item in documents]
        scores = None
        try:
            from sklearn.feature_extraction.text import TfidfVectorizer
            from sklearn.metrics.pairwise import cosine_similarity
            model = TfidfVectorizer(ngram_range=(1,2), stop_words='english',
                                    max_features=16000, max_df=1.0)
            matrix = model.fit_transform(texts + [query])
            scores = cosine_similarity(matrix[-1], matrix[:-1])[0].tolist()
        except (ImportError, ValueError):
            # Pure Python token-overlap fallback, useful in minimal installs.
            terms = set(re.findall(r'[a-z0-9]{3,}',query.lower()))
            scores = [len(terms & set(re.findall(r'[a-z0-9]{3,}',t.lower()))) /
                      max(1,len(terms)) for t in texts]
        ranking = sorted(range(len(documents)), key=lambda i: scores[i], reverse=True)
        hits: list[dict] = []
        for index in ranking:
            score = float(scores[index])
            if score <= 0:
                break
            d = documents[index]
            # Show a locally grounded excerpt that overlaps with query words.
            words = re.findall(r'[\w-]{3,}', query.lower())
            snippet_text = d['text']
            matches = [snippet_text.lower().find(w) for w in words if w in snippet_text.lower()]
            offset = max(0, min(matches) - 75) if matches else 0
            snippet = snippet_text[offset:offset+500].strip()
            hits.append(KnowledgeHit(d['source'], d['title'], snippet,score).as_dict())
            if len(hits) >= max(1,min(limit,10)):
                break
        return hits
