"""Predictable, bounded assistant workflows and recurring *read-only* jobs.

Workflows use tool names from a fixed allowlist, literal JSON arguments, no
expression evaluation, no arbitrary scripting and no write/device actions.
Each scheduled execution is limited to one run per claim, with a short budget.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import asyncio
import json
import time
from typing import Any, Callable

from jarvis.tools import ToolRegistry
from jarvis.storage import utcnow
from .security import SecurityError, CapabilityPolicy, bounded_json, safe_nested_lookup
from .store import OperationsStore
from .events import EventHub
from .observability import OperationMetrics


@dataclass(frozen=True)
class Step:
    tool: str
    args: dict
    label: str = ''
    stop_on_error: bool = True

    @classmethod
    def parse(cls, item: dict) -> 'Step':
        if not isinstance(item, dict):
            raise SecurityError('Each step must be a JSON object')
        if set(item) - {'tool','args','label','stop_on_error'}:
            raise SecurityError('Unknown workflow step fields')
        tool = item.get('tool')
        args = item.get('args',{})
        label = item.get('label','')
        stop = item.get('stop_on_error',True)
        if not isinstance(tool,str) or not tool or len(tool)>70:
            raise SecurityError('Missing tool name')
        if not isinstance(args,dict) or not isinstance(label,str) or type(stop) is not bool:
            raise SecurityError('Invalid step arguments')
        bounded_json(args,max_bytes=3000)
        return cls(tool,args,label[:120],stop)


class WorkflowEngine:
    def __init__(self, store: OperationsStore, tools: ToolRegistry,
                 events: EventHub | None = None, metrics: OperationMetrics | None = None):
        self.store = store
        self.tools = tools
        self.events = events or EventHub()
        self.metrics = metrics or OperationMetrics()
        self.policy = CapabilityPolicy()
        self._locks: set[str] = set()

    def validate(self, raw_steps: list[dict], *, scheduled: bool = False) -> list[Step]:
        if not isinstance(raw_steps,list):
            raise SecurityError('Steps must be a list')
        steps = [Step.parse(item) for item in raw_steps]
        self.policy.check_workflow([step.tool for step in steps], unattended=not scheduled)
        schemas = {spec['function']['name']: spec['function']['parameters']
                   for spec in self.tools.schemas()}
        for step in steps:
            if step.tool not in schemas:
                raise SecurityError('Tool is not present in this installation')
            props = schemas[step.tool]['properties']
            required = schemas[step.tool]['required']
            if set(step.args)-set(props) or set(required)-set(step.args):
                raise SecurityError(f'Invalid arguments to {step.tool}')
            for name,val in step.args.items():
                expected = props[name]['type']
                if expected=='string' and not isinstance(val,str):
                    raise SecurityError(f'{name} needs text')
                if expected=='boolean' and type(val) is not bool:
                    raise SecurityError(f'{name} needs true/false')
        return steps

    def create(self, name: str, description: str, raw_steps: list[dict]) -> dict:
        steps = self.validate(raw_steps)
        return self.store.save_workflow(name,description,[asdict(step) for step in steps])

    def dry_run(self, raw_steps: list[dict]) -> dict:
        steps = self.validate(raw_steps)
        return {'valid':True,'will_run':len(steps),
                'operations':[{'tool':step.tool,'args':step.args,
                               'requires_approval':False} for step in steps],
                'explanation':'Read-only steps. A dry run never executes tools.'}

    def run(self, workflow_id: str, *, scheduled: bool = False) -> dict:
        workflow = self.store.workflow(workflow_id)
        if not workflow:
            raise SecurityError('Workflow does not exist')
        if not workflow['enabled']:
            raise SecurityError('Workflow disabled')
        if workflow_id in self._locks:
            raise SecurityError('Workflow already running')
        steps = self.validate(workflow['steps'], scheduled=scheduled)
        # Hard cap is a *duration* budget, not real-time preemption of blocking tools.
        start = time.monotonic()
        results=[]
        self._locks.add(workflow_id)
        status = 'completed'
        error = ''
        try:
            for idx,step in enumerate(steps):
                if time.monotonic()-start > 18:
                    status='timed_out'
                    error='Workflow exceeded time budget'
                    break
                outcome=self.tools.handle(step.tool,step.args,audit=True)
                # Do not allow queued approvals: invalid workflow by construction.
                if outcome.get('approval_required'):
                    status='blocked'
                    error='Step unexpectedly required approval'
                    break
                success=bool(outcome.get('ok'))
                results.append({'index':idx,'tool':step.tool,'label':step.label,
                                'ok':success,'output':outcome.get('result') if success else
                                outcome.get('error','Failed')})
                if not success and step.stop_on_error:
                    status='failed';error='Workflow stopped after a tool error';break
        except Exception as exc:
            status='error';error='Workflow error: '+type(exc).__name__
        finally:
            self._locks.discard(workflow_id)
        result={'workflow_id':workflow_id,'name':workflow['name'],
                'status':status,'results':results,'duration_ms':round(1000*(time.monotonic()-start),1)}
        record=self.store.save_workflow_run(workflow_id,status,results,error)
        result['run_id']=record['id']
        if error: result['error']=error
        self.metrics.record('workflow',time.monotonic()-start,status=='completed')
        self.events.publish('workflow',{'kind':'workflow','id':workflow_id,'status':status,
                                        'name':workflow['name']})
        return result

    def create_schedule(self, name: str, workflow_id: str, minutes: int,
                        first_at: str) -> dict:
        workflow=self.store.workflow(workflow_id)
        if not workflow:
            raise SecurityError('Workflow not found')
        self.validate(workflow['steps'],scheduled=True)
        if len(self.store.schedules())>=self.policy.max_jobs:
            raise SecurityError('Too many scheduled workflows')
        return self.store.add_schedule(name,workflow_id,minutes,first_at)

    def tick(self) -> list[dict]:
        """Claim and run due read-only jobs; call from the server loop.

        The claim is committed *before* execution. If the machine reboots mid-
        tick it might skip an execution, but never makes unsafe duplicate writes.
        """
        outcomes=[]
        for item in self.store.claim_due_schedules(utcnow(),max_claims=3):
            try:
                result=self.run(item['workflow_id'],scheduled=True)
                outcomes.append(result)
            except (SecurityError,ValueError) as exc:
                outcomes.append({'status':'failed','schedule_id':item['id'],'error':str(exc)})
        return outcomes


WORKFLOW_TEMPLATES: list[dict] = [
    {
        'name':'Morning systems check',
        'description':'Check computer health and time without modifying any device settings.',
        'steps':[{'tool':'get_time','args':{}},{'tool':'computer_status','args':{}}],
    },
    {
        'name':'Daily planning snapshot',
        'description':'Summarise current open tasks and future reminders.',
        'steps':[{'tool':'list_tasks','args':{'include_completed':False}},
                 {'tool':'list_reminders','args':{}}],
    },
    {
        'name':'Memory review',
        'description':'Fetch remembered facts and note titles.',
        'steps':[{'tool':'recall_facts','args':{}},{'tool':'list_notes','args':{}}],
    },
    {
        'name':'Workspace snapshot',
        'description':'Show the current contents of the restricted JARVIS workspace.',
        'steps':[{'tool':'list_workspace','args':{}}],
    },
]
