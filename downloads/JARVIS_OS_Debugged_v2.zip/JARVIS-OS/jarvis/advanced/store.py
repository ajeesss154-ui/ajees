"""Durable user-owned information for projects, goals, calendar and automation.

Every query is parameterized. Objects are updated through dedicated methods,
never through unchecked SQL fragments or user-controlled table names.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
import json
import sqlite3
from typing import Any, Literal
from uuid import uuid4

from jarvis.storage import Database, utcnow
from .security import SecurityError, bounded_json, validate_label


def ident() -> str:
    return str(uuid4())


def _dicts(rows) -> list[dict]:
    return [dict(row) for row in rows]


def _iso_datetime(raw: str, *, future_only: bool = False) -> str:
    try:
        dt = datetime.fromisoformat(raw.replace('Z', '+00:00'))
    except (AttributeError, ValueError) as exc:
        raise SecurityError('Supply an ISO 8601 date and timezone offset') from exc
    if dt.tzinfo is None:
        raise SecurityError('Timezone offset is required')
    if future_only and dt <= datetime.now(timezone.utc):
        raise SecurityError('Time must be in the future')
    return dt.astimezone(timezone.utc).isoformat(timespec='seconds')


def _date(raw: str) -> str:
    try:
        value = datetime.strptime(raw, '%Y-%m-%d')
    except (ValueError, TypeError) as exc:
        raise SecurityError('Expected YYYY-MM-DD') from exc
    return value.strftime('%Y-%m-%d')


class OperationsStore:
    """Companion schema alongside the existing Database class.

    A separate domain class means older JARVIS databases continue to work.
    """
    def __init__(self, db: Database):
        self.db = db
        self._migrate()

    def _migrate(self) -> None:
        with self.db.connect() as con:
            con.executescript('''
                CREATE TABLE IF NOT EXISTS projects (
                    id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL,
                    color TEXT NOT NULL DEFAULT 'cyan', status TEXT NOT NULL DEFAULT 'active',
                    created_at TEXT NOT NULL, updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS project_items (
                    id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id),
                    title TEXT NOT NULL, details TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT 'todo', priority INTEGER NOT NULL DEFAULT 2,
                    due_on TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_project_items ON project_items(project_id, status);
                CREATE TABLE IF NOT EXISTS goals (
                    id TEXT PRIMARY KEY, title TEXT NOT NULL, description TEXT NOT NULL,
                    target_on TEXT, status TEXT NOT NULL DEFAULT 'active',
                    progress INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS habits (
                    id TEXT PRIMARY KEY, name TEXT NOT NULL, emoji TEXT NOT NULL DEFAULT '✓',
                    target_per_week INTEGER NOT NULL DEFAULT 5,
                    status TEXT NOT NULL DEFAULT 'active', created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS habit_checks (
                    habit_id TEXT NOT NULL REFERENCES habits(id), day TEXT NOT NULL,
                    created_at TEXT NOT NULL, PRIMARY KEY(habit_id, day)
                );
                CREATE TABLE IF NOT EXISTS calendar_events (
                    id TEXT PRIMARY KEY, title TEXT NOT NULL, starts_at TEXT NOT NULL,
                    ends_at TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
                    category TEXT NOT NULL DEFAULT 'personal', created_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_calendar_starts ON calendar_events(starts_at);
                CREATE TABLE IF NOT EXISTS bookmarks (
                    id TEXT PRIMARY KEY, title TEXT NOT NULL, url TEXT NOT NULL,
                    description TEXT NOT NULL DEFAULT '', tags TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS quick_snippets (
                    id TEXT PRIMARY KEY, title TEXT NOT NULL, content TEXT NOT NULL,
                    language TEXT NOT NULL DEFAULT 'text', created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS focus_sessions (
                    id TEXT PRIMARY KEY, topic TEXT NOT NULL, started_at TEXT NOT NULL,
                    ended_at TEXT, duration_seconds INTEGER, notes TEXT NOT NULL DEFAULT ''
                );
                CREATE TABLE IF NOT EXISTS workflows (
                    id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL,
                    steps_json TEXT NOT NULL, enabled INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL, updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS workflow_runs (
                    id TEXT PRIMARY KEY, workflow_id TEXT NOT NULL, status TEXT NOT NULL,
                    started_at TEXT NOT NULL, finished_at TEXT NOT NULL,
                    results_json TEXT NOT NULL, error TEXT NOT NULL DEFAULT ''
                );
                CREATE INDEX IF NOT EXISTS idx_workflow_runs ON workflow_runs(workflow_id,started_at);
                CREATE TABLE IF NOT EXISTS schedules (
                    id TEXT PRIMARY KEY, name TEXT NOT NULL, workflow_id TEXT NOT NULL,
                    interval_minutes INTEGER NOT NULL, next_run_at TEXT NOT NULL,
                    enabled INTEGER NOT NULL DEFAULT 1, last_run_at TEXT,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS assistant_settings (
                    key TEXT PRIMARY KEY, value_json TEXT NOT NULL, updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS activity_events (
                    id TEXT PRIMARY KEY, kind TEXT NOT NULL, target_id TEXT,
                    message TEXT NOT NULL, at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_activity ON activity_events(at);
            ''')

    def _exists(self, table: str, object_id: str) -> bool:
        # Only internal literal table names may be passed to this helper.
        if table not in {'projects','project_items','goals','habits','calendar_events',
                         'bookmarks','quick_snippets','focus_sessions','workflows'}:
            raise SecurityError('Unknown collection')
        with self.db.connect() as con:
            return con.execute(f'SELECT 1 FROM {table} WHERE id=?', (object_id,)).fetchone() is not None

    def record_activity(self, kind: str, message: str, target_id: str | None = None) -> None:
        with self.db.connect() as con:
            con.execute('INSERT INTO activity_events VALUES (?,?,?,?,?)',
                        (ident(), kind[:30], target_id, message[:400], utcnow()))

    def activity(self, limit: int = 80) -> list[dict]:
        with self.db.connect() as con:
            return _dicts(con.execute('SELECT * FROM activity_events ORDER BY rowid DESC LIMIT ?',
                                       (min(limit, 200),)).fetchall())

    # Projects --------------------------------------------------------------
    def add_project(self, name: str, description: str = '', color: str = 'cyan') -> dict:
        name = validate_label(name, limit=150)
        if color not in {'cyan','purple','green','orange','blue','pink'}:
            raise SecurityError('Unknown project accent')
        item = {'id': ident(), 'name': name, 'description': description[:3000],
                'color': color, 'status': 'active', 'created_at': utcnow(), 'updated_at': utcnow()}
        with self.db.connect() as con:
            con.execute('''INSERT INTO projects
                (id,name,description,color,status,created_at,updated_at)
                VALUES (:id,:name,:description,:color,:status,:created_at,:updated_at)''', item)
        self.record_activity('project', f'Created project: {name}', item['id'])
        return item

    def projects(self, include_archived: bool = False) -> list[dict]:
        with self.db.connect() as con:
            data = _dicts(con.execute('''SELECT p.*, COUNT(i.id) AS item_count,
                    SUM(CASE WHEN i.status='done' THEN 1 ELSE 0 END) AS done_count
                    FROM projects p LEFT JOIN project_items i ON i.project_id=p.id
                    WHERE (?=1 OR p.status='active') GROUP BY p.id
                    ORDER BY p.updated_at DESC LIMIT 120''', (int(include_archived),)).fetchall())
        for item in data:
            item['done_count'] = item['done_count'] or 0
        return data

    def update_project(self, object_id: str, *, name: str | None = None,
                       description: str | None = None, status: str | None = None) -> bool:
        updates: dict[str,str] = {'updated_at': utcnow()}
        if name is not None: updates['name'] = validate_label(name, limit=150)
        if description is not None: updates['description'] = description[:3000]
        if status is not None:
            if status not in {'active','archived'}: raise SecurityError('Bad project status')
            updates['status'] = status
        return self._update('projects', object_id, updates)

    def add_project_item(self, project_id: str, title: str, *, details: str = '',
                         priority: int = 2, due_on: str | None = None) -> dict:
        if not self._exists('projects', project_id):
            raise SecurityError('Project not found')
        if priority not in {1,2,3}:
            raise SecurityError('Priority must be 1, 2 or 3')
        item = {'id': ident(), 'project_id': project_id, 'title': validate_label(title, limit=300),
                'details': details[:5000], 'status': 'todo', 'priority': priority,
                'due_on': _date(due_on) if due_on else None,
                'created_at': utcnow(), 'updated_at': utcnow()}
        with self.db.connect() as con:
            con.execute('''INSERT INTO project_items
                (id,project_id,title,details,status,priority,due_on,created_at,updated_at)
                VALUES (:id,:project_id,:title,:details,:status,:priority,:due_on,:created_at,:updated_at)''',item)
            con.execute('UPDATE projects SET updated_at=? WHERE id=?', (utcnow(), project_id))
        self.record_activity('project_item', f'Added task: {item["title"]}', item['id'])
        return item

    def project_items(self, project_id: str, include_done: bool = True) -> list[dict]:
        with self.db.connect() as con:
            return _dicts(con.execute('''SELECT * FROM project_items WHERE project_id=?
                 AND (?=1 OR status!='done') ORDER BY priority DESC, created_at DESC LIMIT 500''',
                        (project_id, int(include_done))).fetchall())

    def set_project_item(self, item_id: str, status: str) -> bool:
        if status not in {'todo','doing','blocked','done'}:
            raise SecurityError('Unknown task status')
        result = self._update('project_items', item_id, {'status': status, 'updated_at':utcnow()})
        if result: self.record_activity('project_item', 'Task status → ' + status, item_id)
        return result

    # Goals -----------------------------------------------------------------
    def add_goal(self, title: str, description: str = '', target_on: str | None = None) -> dict:
        obj = {'id': ident(), 'title': validate_label(title, limit=240),
               'description': description[:3500], 'target_on': _date(target_on) if target_on else None,
               'status':'active', 'progress':0, 'created_at':utcnow(), 'updated_at':utcnow()}
        with self.db.connect() as con:
            con.execute('''INSERT INTO goals
             (id,title,description,target_on,status,progress,created_at,updated_at)
             VALUES (:id,:title,:description,:target_on,:status,:progress,:created_at,:updated_at)''',obj)
        self.record_activity('goal', f'Created goal: {title}', obj['id'])
        return obj

    def goals(self, include_completed: bool = True) -> list[dict]:
        with self.db.connect() as con:
            return _dicts(con.execute("SELECT * FROM goals WHERE (?=1 OR status='active') ORDER BY updated_at DESC LIMIT 120",
                    (int(include_completed),)).fetchall())

    def update_goal(self, object_id: str, progress: int, status: str | None = None) -> bool:
        if type(progress) is not int or not 0 <= progress <= 100:
            raise SecurityError('Progress must be between 0 and 100')
        if status is not None and status not in {'active','completed','paused','archived'}:
            raise SecurityError('Unknown goal state')
        changes = {'progress':progress, 'updated_at':utcnow()}
        if status is not None: changes['status'] = status
        elif progress == 100: changes['status'] = 'completed'
        result = self._update('goals', object_id, changes)
        if result: self.record_activity('goal', f'Progress updated to {progress}%', object_id)
        return result

    # Habits ----------------------------------------------------------------
    def add_habit(self, name: str, target_per_week: int = 5, emoji: str = '✓') -> dict:
        if type(target_per_week) is not int or not 1 <= target_per_week <= 7:
            raise SecurityError('Weekly target must be from 1 to 7')
        obj = {'id': ident(), 'name': validate_label(name, limit=120),
               'emoji': emoji[:4], 'target_per_week':target_per_week, 'status':'active',
               'created_at':utcnow()}
        with self.db.connect() as con:
            con.execute('''INSERT INTO habits
                (id,name,emoji,target_per_week,status,created_at)
                VALUES (:id,:name,:emoji,:target_per_week,:status,:created_at)''',obj)
        self.record_activity('habit', f'Created habit: {name}', obj['id'])
        return obj

    def habit_check(self, habit_id: str, day: str, checked: bool = True) -> bool:
        if not self._exists('habits', habit_id): raise SecurityError('Habit not found')
        day = _date(day)
        if day > datetime.now(timezone.utc).date().isoformat():
            raise SecurityError('Cannot check future dates')
        if day < (datetime.now(timezone.utc) - timedelta(days=366)).date().isoformat():
            raise SecurityError('Habits are editable for the last year only')
        with self.db.connect() as con:
            if checked:
                cur = con.execute('INSERT OR IGNORE INTO habit_checks VALUES (?,?,?)',
                                  (habit_id, day, utcnow()))
            else:
                cur = con.execute('DELETE FROM habit_checks WHERE habit_id=? AND day=?',
                                  (habit_id, day))
        return bool(cur.rowcount)

    def habits(self, weeks: int = 4) -> list[dict]:
        if not 1 <= weeks <= 12: raise SecurityError('Weeks must be from 1 to 12')
        since = (datetime.now(timezone.utc)-timedelta(weeks=weeks)).date().isoformat()
        with self.db.connect() as con:
            objs = _dicts(con.execute('SELECT * FROM habits ORDER BY created_at DESC LIMIT 100').fetchall())
            checks = _dicts(con.execute('SELECT habit_id,day FROM habit_checks WHERE day>=? ORDER BY day',
                                        (since,)).fetchall())
        by_habit: dict[str,list[str]] = {}
        for check in checks:
            by_habit.setdefault(check['habit_id'], []).append(check['day'])
        for obj in objs:
            obj['checks'] = by_habit.get(obj['id'], [])
            obj['total_checks'] = len(obj['checks'])
        return objs

    # Calendar --------------------------------------------------------------
    def create_event(self, title: str, start: str, end: str, description: str = '',
                     category: str = 'personal') -> dict:
        begin, finish = _iso_datetime(start), _iso_datetime(end)
        if finish <= begin: raise SecurityError('Event must finish after it starts')
        if datetime.fromisoformat(finish) - datetime.fromisoformat(begin) > timedelta(days=30):
            raise SecurityError('Event duration is limited to 30 days')
        if category not in {'personal','work','study','meeting','other'}:
            raise SecurityError('Invalid event category')
        obj = {'id': ident(), 'title':validate_label(title, limit=200),
               'starts_at':begin, 'ends_at':finish,
               'description':description[:2000], 'category':category, 'created_at':utcnow()}
        with self.db.connect() as con:
            con.execute('''INSERT INTO calendar_events
                (id,title,starts_at,ends_at,description,category,created_at)
                VALUES (:id,:title,:starts_at,:ends_at,:description,:category,:created_at)''',obj)
        self.record_activity('calendar', f'Scheduled: {title}', obj['id'])
        return obj

    def events(self, start: str, end: str, *, limit: int = 200) -> list[dict]:
        first, last = _iso_datetime(start), _iso_datetime(end)
        if first > last: raise SecurityError('Invalid date range')
        with self.db.connect() as con:
            return _dicts(con.execute('''SELECT * FROM calendar_events
                WHERE ends_at>=? AND starts_at<=? ORDER BY starts_at LIMIT ?''',
                (first, last, min(limit, 500))).fetchall())

    def remove_event(self, event_id: str) -> bool:
        return self._delete('calendar_events', event_id)

    # Bookmarks -------------------------------------------------------------
    def add_bookmark(self, title: str, url: str, description: str = '', tags: str = '') -> dict:
        from .security import validate_url
        obj = {'id': ident(), 'title':validate_label(title, limit=160),
               'url': validate_url(url, allow_http=False),
               'description':description[:1500], 'tags':tags[:250], 'created_at':utcnow()}
        with self.db.connect() as con:
            con.execute('''INSERT INTO bookmarks
                (id,title,url,description,tags,created_at)
                VALUES (:id,:title,:url,:description,:tags,:created_at)''',obj)
        return obj

    def bookmarks(self, search: str = '') -> list[dict]:
        with self.db.connect() as con:
            term = '%' + search.replace('%','\\%').replace('_','\\_') + '%'
            return _dicts(con.execute('''SELECT * FROM bookmarks
                 WHERE title LIKE ? ESCAPE '\\' OR tags LIKE ? ESCAPE '\\'
                 ORDER BY created_at DESC LIMIT 200''', (term,term)).fetchall())

    def delete_bookmark(self, item_id: str) -> bool:
        return self._delete('bookmarks', item_id)

    # Snippets --------------------------------------------------------------
    def add_snippet(self, title: str, content: str, language: str = 'text') -> dict:
        if len(content) > 20000: raise SecurityError('Snippet too large')
        if not language.isalnum() or len(language)>30: raise SecurityError('Invalid language')
        obj = {'id': ident(), 'title':validate_label(title, limit=160),
               'content':content, 'language':language, 'created_at':utcnow(), 'updated_at':utcnow()}
        with self.db.connect() as con:
            con.execute('''INSERT INTO quick_snippets
                (id,title,content,language,created_at,updated_at)
                VALUES (:id,:title,:content,:language,:created_at,:updated_at)''',obj)
        return obj

    def snippets(self, query: str = '') -> list[dict]:
        with self.db.connect() as con:
            term = '%' + query.replace('%','\\%').replace('_','\\_') + '%'
            return _dicts(con.execute('''SELECT * FROM quick_snippets
             WHERE title LIKE ? ESCAPE '\\' OR content LIKE ? ESCAPE '\\'
             ORDER BY created_at DESC LIMIT 100''', (term, term)).fetchall())

    def delete_snippet(self, item_id: str) -> bool:
        return self._delete('quick_snippets', item_id)

    # Focus timer -----------------------------------------------------------
    def start_focus(self, topic: str) -> dict:
        obj = {'id':ident(), 'topic':validate_label(topic, limit=160),
               'started_at': utcnow(), 'ended_at':None, 'duration_seconds':None, 'notes':''}
        with self.db.connect() as con:
            active = con.execute('SELECT id FROM focus_sessions WHERE ended_at IS NULL').fetchone()
            if active: raise SecurityError('Finish the active focus session first')
            con.execute('''INSERT INTO focus_sessions
                (id,topic,started_at,ended_at,duration_seconds,notes)
                VALUES (:id,:topic,:started_at,:ended_at,:duration_seconds,:notes)''',obj)
        return obj

    def finish_focus(self, session_id: str, notes: str = '') -> dict:
        now = utcnow()
        with self.db.connect() as con:
            original = con.execute('SELECT * FROM focus_sessions WHERE id=? AND ended_at IS NULL',
                                   (session_id,)).fetchone()
            if not original: raise SecurityError('Active focus session not found')
            elapsed = max(0, int((datetime.fromisoformat(now) -
                                  datetime.fromisoformat(original['started_at'])).total_seconds()))
            con.execute('''UPDATE focus_sessions SET ended_at=?,duration_seconds=?,notes=?
                           WHERE id=?''', (now, elapsed, notes[:2000], session_id))
        return {'id':session_id,'duration_seconds':elapsed,'ended_at':now}

    def focus_sessions(self, limit: int = 50) -> list[dict]:
        with self.db.connect() as con:
            return _dicts(con.execute('SELECT * FROM focus_sessions ORDER BY rowid DESC LIMIT ?',
                                      (min(limit,200),)).fetchall())

    # Workflows -------------------------------------------------------------
    def save_workflow(self, name: str, description: str, steps: list[dict]) -> dict:
        steps_json = bounded_json(steps, max_bytes=20000)
        obj = {'id':ident(), 'name':validate_label(name,limit=160),
               'description':description[:2000], 'steps_json':steps_json,
               'enabled':1,'created_at':utcnow(),'updated_at':utcnow()}
        with self.db.connect() as con:
            con.execute('''INSERT INTO workflows
                (id,name,description,steps_json,enabled,created_at,updated_at)
                VALUES (:id,:name,:description,:steps_json,:enabled,:created_at,:updated_at)''',obj)
        self.record_activity('workflow', f'Created workflow: {name}', obj['id'])
        return self._decode_workflow(obj)

    @staticmethod
    def _decode_workflow(row: dict) -> dict:
        result = dict(row)
        result['steps'] = json.loads(result.pop('steps_json'))
        result['enabled'] = bool(result['enabled'])
        return result

    def workflows(self) -> list[dict]:
        with self.db.connect() as con:
            rows = _dicts(con.execute('SELECT * FROM workflows ORDER BY created_at DESC LIMIT 100').fetchall())
        return [self._decode_workflow(obj) for obj in rows]

    def workflow(self, workflow_id: str) -> dict | None:
        with self.db.connect() as con:
            row = con.execute('SELECT * FROM workflows WHERE id=?',(workflow_id,)).fetchone()
        return self._decode_workflow(dict(row)) if row else None

    def toggle_workflow(self, workflow_id: str, enabled: bool) -> bool:
        return self._update('workflows',workflow_id,{'enabled':int(enabled),'updated_at':utcnow()})

    def save_workflow_run(self, workflow_id: str, status: str, results: list,
                          error: str = '') -> dict:
        obj = {'id':ident(), 'workflow_id':workflow_id,'status':status,
               'started_at':utcnow(),'finished_at':utcnow(),
               'results_json':bounded_json(results,max_bytes=45000), 'error':error[:1000]}
        with self.db.connect() as con:
            con.execute('''INSERT INTO workflow_runs
              (id,workflow_id,status,started_at,finished_at,results_json,error)
              VALUES (:id,:workflow_id,:status,:started_at,:finished_at,:results_json,:error)''',obj)
        return obj

    def workflow_runs(self, workflow_id: str, limit: int = 30) -> list[dict]:
        with self.db.connect() as con:
            rows = _dicts(con.execute('SELECT * FROM workflow_runs WHERE workflow_id=? ORDER BY rowid DESC LIMIT ?',
                                    (workflow_id,min(limit,100))).fetchall())
        for row in rows:
            row['results'] = json.loads(row.pop('results_json'))
        return rows

    # Schedules -------------------------------------------------------------
    def add_schedule(self, name: str, workflow_id: str, interval_minutes: int,
                     first_at: str) -> dict:
        if type(interval_minutes) is not int or not 15 <= interval_minutes <= 10080:
            raise SecurityError('Interval must be 15 minutes to 7 days')
        if not self.workflow(workflow_id): raise SecurityError('Workflow does not exist')
        obj = {'id':ident(), 'name':validate_label(name,limit=120),
               'workflow_id':workflow_id,'interval_minutes':interval_minutes,
               'next_run_at':_iso_datetime(first_at,future_only=True),
               'enabled':1, 'last_run_at':None,'created_at':utcnow()}
        with self.db.connect() as con:
            con.execute('''INSERT INTO schedules
                (id,name,workflow_id,interval_minutes,next_run_at,enabled,last_run_at,created_at)
                VALUES (:id,:name,:workflow_id,:interval_minutes,:next_run_at,:enabled,:last_run_at,:created_at)''',obj)
        return obj

    def schedules(self, enabled_only: bool = False) -> list[dict]:
        with self.db.connect() as con:
            return _dicts(con.execute('''SELECT * FROM schedules WHERE (?=0 OR enabled=1)
                 ORDER BY next_run_at LIMIT 120''',(int(enabled_only),)).fetchall())

    def toggle_schedule(self, schedule_id: str, enabled: bool) -> bool:
        with self.db.connect() as con:
            result = con.execute('UPDATE schedules SET enabled=? WHERE id=?',
                                 (int(enabled),schedule_id))
        return bool(result.rowcount)

    def claim_due_schedules(self, now: str, max_claims: int = 4) -> list[dict]:
        """Single-statement optimistic claims; advance before execution.

        A crash may skip work, never create unbounded duplicate executions.
        """
        claimed = []
        with self.db.connect() as con:
            rows = con.execute('''SELECT * FROM schedules WHERE enabled=1 AND next_run_at<=?
                ORDER BY next_run_at ASC LIMIT ?''',(now,min(max_claims,10))).fetchall()
            for row in rows:
                duration = timedelta(minutes=row['interval_minutes'])
                current = datetime.fromisoformat(row['next_run_at'])
                now_dt = datetime.fromisoformat(now)
                while current <= now_dt:
                    current += duration
                cursor = con.execute('''UPDATE schedules SET last_run_at=?,next_run_at=?
                    WHERE id=? AND next_run_at=? AND enabled=1''',
                    (now,current.isoformat(timespec='seconds'),row['id'],row['next_run_at']))
                if cursor.rowcount:
                    claimed.append(dict(row))
        return claimed

    # Preferences -----------------------------------------------------------
    def set_preference(self, key: str, value: Any) -> dict:
        if key not in {'assistant_name','speech_speed','temperature','language','theme',
                       'notifications_enabled','preferred_reply_style'}:
            raise SecurityError('Unknown preference')
        if key == 'speech_speed' and (type(value) not in (float,int) or not 0.5<=value<=2):
            raise SecurityError('Speech speed must be between 0.5 and 2')
        if key == 'temperature' and (type(value) not in (float,int) or not 0<=value<=1):
            raise SecurityError('Temperature must be between 0 and 1')
        if key == 'notifications_enabled' and type(value) is not bool:
            raise SecurityError('notifications_enabled must be true or false')
        if isinstance(value,str) and len(value)>80:
            raise SecurityError('Preference value too long')
        encoded=bounded_json(value,max_bytes=300)
        with self.db.connect() as con:
            con.execute('''INSERT INTO assistant_settings VALUES (?,?,?)
                ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json,
                  updated_at=excluded.updated_at''',(key,encoded,utcnow()))
        return {'key':key,'value':value}

    def preferences(self) -> dict[str,Any]:
        with self.db.connect() as con:
            rows=con.execute('SELECT key,value_json FROM assistant_settings').fetchall()
        return {row['key']:json.loads(row['value_json']) for row in rows}

    # Helpers ---------------------------------------------------------------
    def _update(self, table: str, object_id: str, fields: dict) -> bool:
        ALLOWED = {'projects': {'name','description','status','updated_at'},
                   'project_items': {'status','updated_at'},
                   'goals': {'progress','status','updated_at'},
                   'workflows': {'enabled','updated_at'}}
        if not fields or table not in ALLOWED or not fields.keys() <= ALLOWED[table]:
            raise SecurityError('Invalid update')
        sql = ','.join(f'{field}=?' for field in fields)
        with self.db.connect() as con:
            cur=con.execute(f'UPDATE {table} SET {sql} WHERE id=?',
                            (*fields.values(), object_id))
        return bool(cur.rowcount)

    def _delete(self, table: str, item_id: str) -> bool:
        if table not in {'calendar_events','bookmarks','quick_snippets'}:
            raise SecurityError('Deletion not permitted for this collection')
        with self.db.connect() as con:
            cur = con.execute(f'DELETE FROM {table} WHERE id=?',(item_id,))
        return bool(cur.rowcount)

    def dashboard(self) -> dict:
        with self.db.connect() as con:
            tables = {
                'projects': "SELECT COUNT(*) FROM projects WHERE status='active'",
                'open_project_tasks': "SELECT COUNT(*) FROM project_items WHERE status!='done'",
                'goals': "SELECT COUNT(*) FROM goals WHERE status='active'",
                'habits': "SELECT COUNT(*) FROM habits WHERE status='active'",
                'calendar_events': 'SELECT COUNT(*) FROM calendar_events',
                'bookmarks': 'SELECT COUNT(*) FROM bookmarks',
                'workflows': 'SELECT COUNT(*) FROM workflows WHERE enabled=1',
                'schedules': 'SELECT COUNT(*) FROM schedules WHERE enabled=1',
            }
            result={key:con.execute(sql).fetchone()[0] for key,sql in tables.items()}
        result['recent_activity'] = self.activity(limit=12)
        return result
