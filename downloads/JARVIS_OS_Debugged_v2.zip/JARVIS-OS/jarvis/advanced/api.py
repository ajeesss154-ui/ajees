"""Authenticated v2 routes for the personal assistant's extended features.

Uses a dependency provided by the existing API, so new routes inherit the
same bearer-token authentication. Nothing is opened to anonymous users.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
import json
from typing import Any, Callable

from fastapi import APIRouter, Depends, HTTPException, Query, Response
from pydantic import BaseModel, Field, field_validator

from .security import SecurityError, redact_secrets
from .store import OperationsStore
from .workflows import WorkflowEngine, WORKFLOW_TEMPLATES
from .backup import BackupManager
from .events import EventHub
from .observability import OperationMetrics, SystemSampler


class ProjectCreate(BaseModel):
    name: str = Field(min_length=1,max_length=150)
    description: str = Field(default='',max_length=3000)
    color: str = 'cyan'


class ProjectPatch(BaseModel):
    name: str | None = Field(default=None,min_length=1,max_length=150)
    description: str | None = Field(default=None,max_length=3000)
    status: str | None = None


class ProjectItemCreate(BaseModel):
    title: str = Field(min_length=1,max_length=300)
    details: str = Field(default='',max_length=5000)
    priority: int = Field(default=2,ge=1,le=3)
    due_on: str | None = None


class StatePatch(BaseModel):
    status: str


class GoalCreate(BaseModel):
    title: str = Field(min_length=1,max_length=240)
    description: str = Field(default='',max_length=3500)
    target_on: str | None = None


class GoalProgress(BaseModel):
    progress: int = Field(ge=0,le=100)
    status: str | None = None


class HabitCreate(BaseModel):
    name: str = Field(min_length=1,max_length=120)
    target_per_week: int = Field(default=5,ge=1,le=7)
    emoji: str = Field(default='✓',max_length=4)


class HabitCheck(BaseModel):
    day: str
    checked: bool = True


class EventCreate(BaseModel):
    title: str = Field(min_length=1,max_length=200)
    start: str
    end: str
    description: str = Field(default='',max_length=2000)
    category: str = 'personal'


class BookmarkCreate(BaseModel):
    title: str = Field(min_length=1,max_length=160)
    url: str = Field(max_length=2048)
    description: str = Field(default='',max_length=1500)
    tags: str = Field(default='',max_length=250)


class SnippetCreate(BaseModel):
    title: str = Field(min_length=1,max_length=160)
    content: str = Field(min_length=1,max_length=20000)
    language: str = Field(default='text',max_length=30)


class FocusBegin(BaseModel):
    topic: str = Field(min_length=1,max_length=160)


class FocusFinish(BaseModel):
    notes: str = Field(default='',max_length=2000)


class WorkflowStepInput(BaseModel):
    tool: str = Field(min_length=1,max_length=80)
    args: dict[str,Any] = Field(default_factory=dict)
    label: str = Field(default='',max_length=120)
    stop_on_error: bool = True


class WorkflowCreate(BaseModel):
    name: str = Field(min_length=1,max_length=160)
    description: str = Field(default='',max_length=2000)
    steps: list[WorkflowStepInput] = Field(min_length=1,max_length=12)


class WorkflowToggle(BaseModel):
    enabled: bool


class ScheduleCreate(BaseModel):
    name: str = Field(min_length=1,max_length=120)
    workflow_id: str
    interval_minutes: int = Field(ge=15,le=10080)
    first_at: str


class PreferencePatch(BaseModel):
    key: str
    value: Any


class BackupCreate(BaseModel):
    include_workspace: bool = False


class APIContext:
    def __init__(self, store: OperationsStore, workflow: WorkflowEngine,
                 backup: BackupManager, events: EventHub,
                 metrics: OperationMetrics, sampler: SystemSampler,
                 workspace):
        self.store=store
        self.workflow=workflow
        self.backup=backup
        self.events=events
        self.metrics=metrics
        self.sampler=sampler
        self.workspace=workspace


def build_router(ctx: APIContext, authenticate: Callable) -> APIRouter:
    router=APIRouter(prefix='/api/v2',tags=['Extended Assistant'],
                     dependencies=[Depends(authenticate)])
    store=ctx.store

    # Convert predictable user-validation errors to 400, not 500.
    def call(fn, *args, **kwargs):
        try:
            return fn(*args,**kwargs)
        except SecurityError as exc:
            raise HTTPException(400,str(exc)) from exc

    def record(topic:str, body: dict):
        ctx.events.publish(topic,body)

    @router.get('/dashboard')
    def dashboard():
        return store.dashboard()

    @router.get('/activity')
    def activity(limit: int = Query(40,ge=1,le=200)):
        return store.activity(limit)

    @router.get('/projects')
    def projects(include_archived: bool = False):
        return store.projects(include_archived)

    @router.post('/projects',status_code=201)
    def add_project(data:ProjectCreate):
        result=call(store.add_project,data.name,data.description,data.color)
        record('task',{'kind':'project','id':result['id'],'name':result['name'],'status':'created'})
        return result

    @router.patch('/projects/{project_id}')
    def change_project(project_id: str,data:ProjectPatch):
        return {'updated':call(store.update_project,project_id,**data.model_dump(exclude_unset=True))}

    @router.get('/projects/{project_id}/items')
    def project_items(project_id:str):
        return store.project_items(project_id)

    @router.post('/projects/{project_id}/items',status_code=201)
    def add_project_item(project_id:str,data:ProjectItemCreate):
        item=call(store.add_project_item,project_id,**data.model_dump())
        record('task',{'kind':'project_task','id':item['id'],'status':'created'})
        return item

    @router.patch('/project-items/{item_id}')
    def update_project_item(item_id:str, data:StatePatch):
        return {'updated':call(store.set_project_item,item_id,data.status)}

    @router.get('/goals')
    def goals():
        return store.goals()

    @router.post('/goals',status_code=201)
    def add_goal(item:GoalCreate):
        return call(store.add_goal,**item.model_dump())

    @router.patch('/goals/{goal_id}')
    def goal_progress(goal_id:str, item:GoalProgress):
        return {'updated':call(store.update_goal,goal_id,item.progress,item.status)}

    @router.get('/habits')
    def habits(weeks:int=Query(4,ge=1,le=12)):
        return store.habits(weeks)

    @router.post('/habits',status_code=201)
    def add_habit(item:HabitCreate):
        return call(store.add_habit,**item.model_dump())

    @router.post('/habits/{habit_id}/check')
    def check_habit(habit_id:str,item:HabitCheck):
        return {'changed':call(store.habit_check,habit_id,item.day,item.checked)}

    @router.get('/events')
    def events(days:int=Query(30,ge=1,le=365)):
        now=datetime.now(timezone.utc)
        return store.events((now-timedelta(days=1)).isoformat(),
                            (now+timedelta(days=days)).isoformat())

    @router.post('/events',status_code=201)
    def add_event(item:EventCreate):
        result=call(store.create_event,item.title,item.start,item.end,
                    item.description,item.category)
        record('task',{'kind':'event','id':result['id'],'status':'created'})
        return result

    @router.delete('/events/{event_id}')
    def delete_event(event_id:str):
        return {'deleted':store.remove_event(event_id)}

    @router.get('/bookmarks')
    def bookmarks(query:str=Query('',max_length=200)):
        return store.bookmarks(query)

    @router.post('/bookmarks',status_code=201)
    def bookmark(item:BookmarkCreate):
        return call(store.add_bookmark,**item.model_dump())

    @router.delete('/bookmarks/{bookmark_id}')
    def delete_bookmark(bookmark_id:str):
        return {'deleted':store.delete_bookmark(bookmark_id)}

    @router.get('/snippets')
    def snippets(query:str=Query('',max_length=200)):
        return store.snippets(query)

    @router.post('/snippets',status_code=201)
    def snippet(item:SnippetCreate):
        return call(store.add_snippet,**item.model_dump())

    @router.delete('/snippets/{snippet_id}')
    def delete_snippet(snippet_id:str):
        return {'deleted':store.delete_snippet(snippet_id)}

    @router.get('/focus')
    def focus():
        return store.focus_sessions()

    @router.post('/focus',status_code=201)
    def focus_start(item:FocusBegin):
        return call(store.start_focus,item.topic)

    @router.post('/focus/{focus_id}/finish')
    def focus_finish(focus_id:str,item:FocusFinish):
        return call(store.finish_focus,focus_id,item.notes)

    @router.get('/workflows')
    def workflows():
        return store.workflows()

    @router.get('/workflow-templates')
    def workflow_templates():
        return WORKFLOW_TEMPLATES

    @router.post('/workflows/validate')
    def validate_workflow(item:WorkflowCreate):
        return call(ctx.workflow.dry_run,[step.model_dump() for step in item.steps])

    @router.post('/workflows',status_code=201)
    def create_workflow(item:WorkflowCreate):
        result=call(ctx.workflow.create,item.name,item.description,
                    [step.model_dump() for step in item.steps])
        return result

    @router.get('/workflows/{workflow_id}/runs')
    def workflow_runs(workflow_id:str):
        return store.workflow_runs(workflow_id)

    @router.post('/workflows/{workflow_id}/run')
    def run_workflow(workflow_id:str):
        return call(ctx.workflow.run,workflow_id)

    @router.patch('/workflows/{workflow_id}')
    def toggle_workflow(workflow_id:str,item:WorkflowToggle):
        return {'updated':store.toggle_workflow(workflow_id,item.enabled)}

    @router.get('/schedules')
    def schedules():
        return store.schedules()

    @router.post('/schedules',status_code=201)
    def create_schedule(item:ScheduleCreate):
        return call(ctx.workflow.create_schedule,item.name,item.workflow_id,
                    item.interval_minutes,item.first_at)

    @router.patch('/schedules/{schedule_id}')
    def schedule_toggle(schedule_id:str,item:WorkflowToggle):
        return {'updated':store.toggle_schedule(schedule_id,item.enabled)}

    @router.get('/settings')
    def preferences():
        return store.preferences()

    @router.patch('/settings')
    def update_preference(item:PreferencePatch):
        return call(store.set_preference,item.key,item.value)

    @router.get('/metrics')
    def metrics():
        return {'operations':ctx.metrics.summary(),'computer':ctx.sampler.overview()}

    @router.get('/metrics/timeseries')
    def metrics_series(limit:int=Query(60,ge=1,le=180)):
        return ctx.sampler.timeseries(limit)

    @router.get('/events')
    def events_recent():
        return ctx.events.recent()

    @router.get('/backups')
    def backups():
        return ctx.backup.list()

    @router.post('/backups',status_code=201)
    def create_backup(item: BackupCreate):
        # Backups are saved locally; download endpoints intentionally omitted.
        return ctx.backup.create(include_workspace=item.include_workspace,
                                 workspace=ctx.workspace)

    @router.get('/backups/{filename}/validate')
    def check_backup(filename:str):
        return call(ctx.backup.validate,filename)

    return router
