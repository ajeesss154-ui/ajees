"""Private local flashcards and spaced-repetition study scheduling.

The algorithm is a small SM-2-inspired heuristic, not a personalized model of
learning. The user controls content and reviews; no automated grade pressure.
Information is stored only in the existing local SQLite database.
"""
from __future__ import annotations

from datetime import date, timedelta, datetime, timezone
import json
import sqlite3
import uuid
from typing import Any

from jarvis.storage import Database, utcnow
from .security import SecurityError


def _id():
    return str(uuid.uuid4())


def _text(value: str, label: str, maximum: int):
    if not isinstance(value, str):
        raise SecurityError(f'{label} must be text')
    val=value.strip()
    if not val or len(val)>maximum:
        raise SecurityError(f'{label} must be 1 to {maximum} characters')
    return val


def _date(raw):
    try:
        return date.fromisoformat(raw)
    except (TypeError, ValueError) as exc:
        raise SecurityError('Use YYYY-MM-DD for calendar dates') from exc


class StudyLibrary:
    def __init__(self, db: Database):
        self.db=db
        self._initialize()

    def _initialize(self):
        with self.db.connect() as con:
            con.executescript('''
                CREATE TABLE IF NOT EXISTS study_decks (
                    id TEXT PRIMARY KEY, title TEXT NOT NULL,
                    description TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL, archived INTEGER NOT NULL DEFAULT 0
                );
                CREATE TABLE IF NOT EXISTS study_cards (
                    id TEXT PRIMARY KEY, deck_id TEXT NOT NULL REFERENCES study_decks(id),
                    front TEXT NOT NULL, back TEXT NOT NULL, tags TEXT NOT NULL DEFAULT '',
                    ease REAL NOT NULL DEFAULT 2.5,
                    interval_days INTEGER NOT NULL DEFAULT 0,
                    repetitions INTEGER NOT NULL DEFAULT 0,
                    due_on TEXT NOT NULL, review_count INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_study_cards_deck
                  ON study_cards(deck_id,due_on);
                CREATE TABLE IF NOT EXISTS study_reviews (
                    id TEXT PRIMARY KEY, card_id TEXT NOT NULL,
                    grade INTEGER NOT NULL, interval_days INTEGER NOT NULL,
                    ease REAL NOT NULL, reviewed_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_study_reviews_card
                  ON study_reviews(card_id,reviewed_at);
            ''')

    def create_deck(self, title: str, description: str = '') -> dict:
        title=_text(title,'Title',160)
        if not isinstance(description,str) or len(description)>1500:
            raise SecurityError('Description too long')
        row={'id':_id(),'title':title,'description':description,
             'created_at':utcnow(),'archived':0}
        with self.db.connect() as con:
            con.execute('''INSERT INTO study_decks(id,title,description,created_at,archived)
                           VALUES(:id,:title,:description,:created_at,:archived)''',row)
        return row

    def decks(self, include_archived: bool = False):
        with self.db.connect() as con:
            rows=con.execute('''SELECT d.*,COUNT(c.id) AS cards,
                              COUNT(CASE WHEN c.due_on<=? THEN 1 END) AS due
                              FROM study_decks d LEFT JOIN study_cards c ON c.deck_id=d.id
                              WHERE (? OR d.archived=0)
                              GROUP BY d.id ORDER BY d.created_at DESC LIMIT 150''',
                              (date.today().isoformat(),int(include_archived))).fetchall()
        return [dict(row) for row in rows]

    def get_deck(self, deck_id: str):
        with self.db.connect() as con:
            row=con.execute('SELECT * FROM study_decks WHERE id=?',(deck_id,)).fetchone()
        return dict(row) if row else None

    def update_deck(self, deck_id: str, title: str | None = None,
                    description: str | None = None, archived: bool | None = None):
        updates={}
        if title is not None:updates['title']=_text(title,'Title',160)
        if description is not None:
            if not isinstance(description,str) or len(description)>1500:
                raise SecurityError('Description too long')
            updates['description']=description
        if archived is not None:
            if type(archived) is not bool:raise SecurityError('Archived must be boolean')
            updates['archived']=int(archived)
        if not updates:raise SecurityError('Nothing to update')
        columns=','.join(f'{key}=?' for key in updates)
        with self.db.connect() as con:
            change=con.execute(f'UPDATE study_decks SET {columns} WHERE id=?',
                               (*updates.values(),deck_id))
        return bool(change.rowcount)

    def add_card(self, deck_id: str, front: str, back: str, tags: str = ''):
        front=_text(front,'Question',2000)
        back=_text(back,'Answer',4000)
        if not isinstance(tags,str) or len(tags)>300:
            raise SecurityError('Tags too long')
        deck=self.get_deck(deck_id)
        if not deck or deck['archived']:
            raise SecurityError('Study deck not found or archived')
        row={'id':_id(),'deck_id':deck_id,'front':front,'back':back,'tags':tags,
             'ease':2.5,'interval_days':0,'repetitions':0,
             'due_on':date.today().isoformat(),'review_count':0,
             'created_at':utcnow(),'updated_at':utcnow()}
        with self.db.connect() as con:
            con.execute('''INSERT INTO study_cards VALUES
                        (:id,:deck_id,:front,:back,:tags,:ease,:interval_days,
                         :repetitions,:due_on,:review_count,:created_at,:updated_at)''',row)
        return row

    def cards(self, deck_id: str, query: str = '', limit: int = 100):
        if not self.get_deck(deck_id):raise SecurityError('Deck not found')
        if not isinstance(query,str) or len(query)>200:
            raise SecurityError('Invalid search term')
        if not 1<=limit<=200:raise SecurityError('Invalid limit')
        term='%'+query.replace('\\','\\\\').replace('%','\\%').replace('_','\\_')+'%'
        with self.db.connect() as con:
            rows=con.execute('''SELECT * FROM study_cards WHERE deck_id=?
                           AND (front LIKE ? ESCAPE '\\' OR back LIKE ? ESCAPE '\\'
                                OR tags LIKE ? ESCAPE '\\')
                           ORDER BY due_on ASC,created_at ASC LIMIT ?''',
                           (deck_id,term,term,term,limit)).fetchall()
        return [dict(row) for row in rows]

    def get_card(self, card_id: str):
        with self.db.connect() as con:
            row=con.execute('SELECT * FROM study_cards WHERE id=?',(card_id,)).fetchone()
        return dict(row) if row else None

    def update_card(self, card_id: str, front: str | None = None,
                    back: str | None = None, tags: str | None = None):
        updates={}
        if front is not None:updates['front']=_text(front,'Question',2000)
        if back is not None:updates['back']=_text(back,'Answer',4000)
        if tags is not None:
            if len(tags)>300:raise SecurityError('Tags too long')
            updates['tags']=tags
        if not updates:raise SecurityError('Nothing to update')
        updates['updated_at']=utcnow()
        columns=','.join(f'{key}=?' for key in updates)
        with self.db.connect() as con:
            change=con.execute(f'UPDATE study_cards SET {columns} WHERE id=?',
                               (*updates.values(),card_id))
        return bool(change.rowcount)

    def delete_card(self, card_id: str):
        with self.db.connect() as con:
            con.execute('DELETE FROM study_reviews WHERE card_id=?',(card_id,))
            change=con.execute('DELETE FROM study_cards WHERE id=?',(card_id,))
        return bool(change.rowcount)

    def due(self, deck_id: str | None = None, as_of: str | None = None, limit: int = 50):
        day=_date(as_of) if as_of else date.today()
        if day>date.today()+timedelta(days=2*365):
            raise SecurityError('Due date too far in the future')
        if not 1<=limit<=200:raise SecurityError('Invalid limit')
        query='''SELECT c.*,d.title AS deck_title FROM study_cards c
                 JOIN study_decks d ON d.id=c.deck_id
                 WHERE d.archived=0 AND c.due_on<=?'''
        params=[day.isoformat()]
        if deck_id:
            query+=' AND c.deck_id=?'
            params.append(deck_id)
        query+=' ORDER BY c.due_on,c.created_at LIMIT ?'
        params.append(limit)
        with self.db.connect() as con:
            rows=con.execute(query,params).fetchall()
        return [dict(row) for row in rows]

    @staticmethod
    def next_interval(grade: int, current: dict) -> dict:
        if type(grade) is not int or not 0<=grade<=5:
            raise SecurityError('Grade must be an integer between 0 and 5')
        ease=float(current['ease'])
        repetitions=int(current['repetitions'])
        old_interval=int(current['interval_days'])
        new_ease=max(1.3,ease+(0.1-(5-grade)*(0.08+(5-grade)*0.02)))
        if grade<3:
            return {'ease':new_ease,'interval_days':1,'repetitions':0}
        if repetitions==0:
            interval=1
        elif repetitions==1:
            interval=6
        else:
            interval=max(1,round(old_interval*new_ease))
        return {'ease':new_ease,'interval_days':min(interval,365*5),
                'repetitions':repetitions+1}

    def review(self,card_id: str,grade: int,day: str | None = None):
        when=_date(day) if day else date.today()
        if when>date.today()+timedelta(days=1) or when<date.today()-timedelta(days=365):
            raise SecurityError('Review date must be recent')
        with self.db.connect() as con:
            card=con.execute('''SELECT c.* FROM study_cards c JOIN study_decks d
                                 ON d.id=c.deck_id WHERE c.id=? AND d.archived=0''',
                                 (card_id,)).fetchone()
            if not card:raise SecurityError('Card not found')
            next_state=self.next_interval(grade,dict(card))
            due=(when+timedelta(days=next_state['interval_days'])).isoformat()
            now=utcnow()
            con.execute('''UPDATE study_cards SET ease=?,interval_days=?,repetitions=?,
                          due_on=?,review_count=review_count+1,updated_at=? WHERE id=?''',
                        (next_state['ease'],next_state['interval_days'],
                         next_state['repetitions'],due,now,card_id))
            con.execute('''INSERT INTO study_reviews VALUES (?,?,?,?,?,?)''',
                        (_id(),card_id,grade,next_state['interval_days'],next_state['ease'],now))
        return {'card_id':card_id,'grade':grade,'next_due_on':due,**next_state}

    def reviews(self,card_id: str | None = None,limit: int = 100):
        if not 1<=limit<=200:raise SecurityError('Invalid limit')
        with self.db.connect() as con:
            if card_id:
                rows=con.execute('''SELECT * FROM study_reviews WHERE card_id=?
                                    ORDER BY reviewed_at DESC LIMIT ?''',(card_id,limit)).fetchall()
            else:
                rows=con.execute('''SELECT * FROM study_reviews
                                    ORDER BY reviewed_at DESC LIMIT ?''',(limit,)).fetchall()
        return [dict(row) for row in rows]

    def statistics(self):
        today=date.today().isoformat()
        with self.db.connect() as con:
            row=con.execute('''SELECT COUNT(*) AS cards,
                        SUM(CASE WHEN due_on<=? THEN 1 ELSE 0 END) AS due,
                        SUM(review_count) AS reviews,
                        AVG(ease) AS average_ease
                        FROM study_cards''',(today,)).fetchone()
            decks=con.execute('SELECT COUNT(*) FROM study_decks WHERE archived=0').fetchone()[0]
            recent=con.execute('''SELECT date(reviewed_at) AS day,COUNT(*) AS reviews
                                  FROM study_reviews GROUP BY date(reviewed_at)
                                  ORDER BY day DESC LIMIT 30''').fetchall()
        return {'decks':decks,'cards':row['cards'],'due':row['due'] or 0,
                'reviews':row['reviews'] or 0,
                'average_ease':round(row['average_ease'] or 0,3),
                'recent':[dict(r) for r in recent]}

    def import_cards(self,deck_id: str,cards: list[dict]):
        if len(cards)>100:raise SecurityError('At most 100 cards per import')
        if any(not isinstance(card,dict) for card in cards):
            raise SecurityError('Expected objects with front and back fields')
        return [self.add_card(deck_id,card.get('front',''),card.get('back',''),
                              card.get('tags','')) for card in cards]

    def export_deck(self,deck_id: str):
        deck=self.get_deck(deck_id)
        if not deck:raise SecurityError('Deck not found')
        return {'version':1,'deck':{'title':deck['title'],'description':deck['description']},
                'cards':[{'front':card['front'],'back':card['back'],'tags':card['tags']}
                         for card in self.cards(deck_id,limit=200)]}
