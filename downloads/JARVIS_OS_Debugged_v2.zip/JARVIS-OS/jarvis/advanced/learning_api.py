"""Token-protected study-deck REST endpoints, including review schedule."""
from __future__ import annotations

from typing import Callable

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from .learning import StudyLibrary
from .security import SecurityError


class DeckCreate(BaseModel):
    title:str=Field(min_length=1,max_length=160)
    description:str=Field(default='',max_length=1500)


class DeckUpdate(BaseModel):
    title:str|None=Field(default=None,min_length=1,max_length=160)
    description:str|None=Field(default=None,max_length=1500)
    archived:bool|None=None


class CardCreate(BaseModel):
    front:str=Field(min_length=1,max_length=2000)
    back:str=Field(min_length=1,max_length=4000)
    tags:str=Field(default='',max_length=300)


class CardUpdate(BaseModel):
    front:str|None=Field(default=None,min_length=1,max_length=2000)
    back:str|None=Field(default=None,min_length=1,max_length=4000)
    tags:str|None=Field(default=None,max_length=300)


class CardReview(BaseModel):
    grade:int=Field(ge=0,le=5)
    day:str|None=None


class ImportCards(BaseModel):
    cards:list[CardCreate]=Field(min_length=1,max_length=100)


def build_router(library:StudyLibrary,authenticate:Callable):
    router=APIRouter(prefix='/api/study',tags=['Study and Learning'],
                     dependencies=[Depends(authenticate)])

    def safe(fn,*args,**kwargs):
        try:
            return fn(*args,**kwargs)
        except SecurityError as exc:
            raise HTTPException(400,str(exc)) from exc

    @router.get('/decks')
    def decks(archived:bool=False):
        return library.decks(archived)

    @router.post('/decks',status_code=201)
    def create_deck(data:DeckCreate):
        return safe(library.create_deck,data.title,data.description)

    @router.get('/decks/{deck_id}')
    def deck(deck_id:str):
        row=library.get_deck(deck_id)
        if not row:raise HTTPException(404,'Deck not found')
        return row

    @router.patch('/decks/{deck_id}')
    def update_deck(deck_id:str,data:DeckUpdate):
        updated=safe(library.update_deck,deck_id,**data.model_dump(exclude_none=True))
        if not updated:raise HTTPException(404,'Deck not found')
        return {'updated':updated}

    @router.get('/decks/{deck_id}/cards')
    def cards(deck_id:str,query:str='',limit:int=Query(default=100,ge=1,le=200)):
        return safe(library.cards,deck_id,query,limit)

    @router.post('/decks/{deck_id}/cards',status_code=201)
    def create_card(deck_id:str,data:CardCreate):
        return safe(library.add_card,deck_id,**data.model_dump())

    @router.post('/decks/{deck_id}/import',status_code=201)
    def import_cards(deck_id:str,data:ImportCards):
        return safe(library.import_cards,deck_id,[card.model_dump() for card in data.cards])

    @router.get('/decks/{deck_id}/export')
    def export_deck(deck_id:str):
        return safe(library.export_deck,deck_id)

    @router.get('/cards/{card_id}')
    def card(card_id:str):
        row=library.get_card(card_id)
        if not row:raise HTTPException(404,'Card not found')
        return row

    @router.patch('/cards/{card_id}')
    def update_card(card_id:str,data:CardUpdate):
        updated=safe(library.update_card,card_id,**data.model_dump(exclude_none=True))
        if not updated:raise HTTPException(404,'Card not found')
        return {'updated':updated}

    @router.delete('/cards/{card_id}')
    def delete_card(card_id:str):
        return {'deleted':library.delete_card(card_id)}

    @router.post('/cards/{card_id}/review')
    def review(card_id:str,data:CardReview):
        return safe(library.review,card_id,data.grade,data.day)

    @router.get('/due')
    def due(deck_id:str|None=None,day:str|None=None,
            limit:int=Query(default=50,ge=1,le=200)):
        return safe(library.due,deck_id,day,limit)

    @router.get('/reviews')
    def reviews(card_id:str|None=None,limit:int=Query(default=100,ge=1,le=200)):
        return safe(library.reviews,card_id,limit)

    @router.get('/statistics')
    def statistics():
        return library.statistics()

    return router
