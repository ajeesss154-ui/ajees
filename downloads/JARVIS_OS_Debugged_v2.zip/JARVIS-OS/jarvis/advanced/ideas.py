"""Private startup idea lab: hypotheses, experiments, decisions and feedback.

Everything is local. This is a planning notebook, not a market validation or
automated business decision engine. User-entered scores are heuristic inputs.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime,timezone
import json
import sqlite3
import uuid
from typing import Any

from jarvis.storage import Database,utcnow
from .security import SecurityError


def _new_id():
    return str(uuid.uuid4())


def _txt(value,name,size,allow_empty=False):
    if not isinstance(value,str):
        raise SecurityError(f'{name} must be text')
    content=value.strip()
    if (not content and not allow_empty) or len(content)>size:
        raise SecurityError(f'{name} length is invalid (maximum {size})')
    return content


def _score(value,label):
    if type(value) is not int or not 1<=value<=10:
        raise SecurityError(f'{label} must be an integer from 1 to 10')
    return value


class IdeaLab:
    def __init__(self,db:Database):
        self.db=db
        self._initialize()

    def _initialize(self):
        with self.db.connect() as con:
            con.executescript('''
                CREATE TABLE IF NOT EXISTS lab_ideas (
                    id TEXT PRIMARY KEY,title TEXT NOT NULL,
                    problem TEXT NOT NULL,solution TEXT NOT NULL,
                    audience TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT 'backlog',
                    impact INTEGER NOT NULL DEFAULT 5,
                    confidence INTEGER NOT NULL DEFAULT 5,
                    effort INTEGER NOT NULL DEFAULT 5,
                    tags TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,updated_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_lab_ideas_status ON lab_ideas(status);
                CREATE TABLE IF NOT EXISTS lab_experiments (
                    id TEXT PRIMARY KEY,idea_id TEXT NOT NULL,
                    hypothesis TEXT NOT NULL,metric TEXT NOT NULL,
                    success_criterion TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'planned',
                    observations TEXT NOT NULL DEFAULT '',
                    conclusion TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,updated_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_lab_experiments_idea
                  ON lab_experiments(idea_id,created_at);
                CREATE TABLE IF NOT EXISTS lab_decisions (
                    id TEXT PRIMARY KEY,title TEXT NOT NULL,
                    context TEXT NOT NULL,options_json TEXT NOT NULL,
                    decision TEXT NOT NULL,rationale TEXT NOT NULL,
                    reversible INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS lab_feedback (
                    id TEXT PRIMARY KEY,source TEXT NOT NULL,
                    message TEXT NOT NULL,idea_id TEXT,
                    tags TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT 'new',
                    created_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_lab_feedback_status
                  ON lab_feedback(status,created_at);
            ''')

    def create_idea(self,title:str,problem:str,solution:str,audience:str='',
                    impact:int=5,confidence:int=5,effort:int=5,tags:str=''):
        title=_txt(title,'Title',180)
        problem=_txt(problem,'Problem',2500)
        solution=_txt(solution,'Solution',3500)
        audience=_txt(audience,'Audience',500,True)
        tags=_txt(tags,'Tags',250,True)
        impact=_score(impact,'Impact')
        confidence=_score(confidence,'Confidence')
        effort=_score(effort,'Effort')
        row={'id':_new_id(),'title':title,'problem':problem,'solution':solution,
             'audience':audience,'status':'backlog','impact':impact,
             'confidence':confidence,'effort':effort,'tags':tags,
             'created_at':utcnow(),'updated_at':utcnow()}
        with self.db.connect() as con:
            con.execute('''INSERT INTO lab_ideas VALUES (:id,:title,:problem,:solution,
                :audience,:status,:impact,:confidence,:effort,:tags,:created_at,:updated_at)''',row)
        return {**row,'priority_score':round(impact*confidence/effort,2)}

    def get_idea(self,ident:str):
        with self.db.connect() as con:
            row=con.execute('SELECT * FROM lab_ideas WHERE id=?',(ident,)).fetchone()
        return self._with_score(row) if row else None

    @staticmethod
    def _with_score(row):
        item=dict(row)
        item['priority_score']=round(item['impact']*item['confidence']/item['effort'],2)
        return item

    def ideas(self,query:str='',status:str|None=None,limit:int=100):
        query=_txt(query,'Search',200,True)
        if status is not None and status not in ('backlog','research','testing','ready','paused','discarded'):
            raise SecurityError('Invalid idea status')
        if not 1<=limit<=200:raise SecurityError('Invalid result count')
        where=['(? IS NULL OR status=?)']
        params=[status,status]
        if query:
            term='%'+query.replace('\\','\\\\').replace('%','\\%').replace('_','\\_')+'%'
            where.append('''(title LIKE ? ESCAPE '\\' OR problem LIKE ? ESCAPE '\\'
                          OR solution LIKE ? ESCAPE '\\' OR tags LIKE ? ESCAPE '\\')''')
            params.extend([term]*4)
        sql='SELECT * FROM lab_ideas WHERE '+' AND '.join(where)+' ORDER BY updated_at DESC LIMIT ?'
        with self.db.connect() as con:
            rows=con.execute(sql,(*params,limit)).fetchall()
        return sorted((self._with_score(r) for r in rows),
                      key=lambda x:-x['priority_score'])

    def update_idea(self,ident:str,**updates):
        allowed={'title','problem','solution','audience','impact','confidence','effort','tags','status'}
        if not updates or set(updates)-allowed:
            raise SecurityError('Unsupported update fields')
        sizes={'title':180,'problem':2500,'solution':3500,'audience':500,'tags':250}
        for name,value in updates.items():
            if name in sizes:
                updates[name]=_txt(value,name,sizes[name],name in ('audience','tags'))
            elif name in ('impact','confidence','effort'):
                updates[name]=_score(value,name)
            elif name=='status' and value not in ('backlog','research','testing','ready','paused','discarded'):
                raise SecurityError('Invalid status')
        updates['updated_at']=utcnow()
        changes=','.join(f'{name}=?' for name in updates)
        with self.db.connect() as con:
            result=con.execute(f'UPDATE lab_ideas SET {changes} WHERE id=?',
                               (*updates.values(),ident))
        return bool(result.rowcount)

    def delete_idea(self,ident:str):
        with self.db.connect() as con:
            # Keep historical decisions/experiments only by explicit separate deletes.
            if con.execute('SELECT 1 FROM lab_experiments WHERE idea_id=?',(ident,)).fetchone():
                raise SecurityError('Archive the idea instead of deleting experiments')
            change=con.execute('DELETE FROM lab_ideas WHERE id=?',(ident,))
        return bool(change.rowcount)

    def add_experiment(self,idea_id:str,hypothesis:str,metric:str,success_criterion:str):
        if not self.get_idea(idea_id):raise SecurityError('Idea not found')
        row={'id':_new_id(),'idea_id':idea_id,
             'hypothesis':_txt(hypothesis,'Hypothesis',2000),
             'metric':_txt(metric,'Metric',600),
             'success_criterion':_txt(success_criterion,'Success criterion',1500),
             'status':'planned','observations':'','conclusion':'',
             'created_at':utcnow(),'updated_at':utcnow()}
        with self.db.connect() as con:
            con.execute('''INSERT INTO lab_experiments VALUES
                (:id,:idea_id,:hypothesis,:metric,:success_criterion,
                 :status,:observations,:conclusion,:created_at,:updated_at)''',row)
        return row

    def experiments(self,idea_id:str|None=None,limit:int=100):
        if not 1<=limit<=200:raise SecurityError('Invalid limit')
        with self.db.connect() as con:
            if idea_id:
                rows=con.execute('''SELECT * FROM lab_experiments WHERE idea_id=?
                      ORDER BY created_at DESC LIMIT ?''',(idea_id,limit)).fetchall()
            else:
                rows=con.execute('''SELECT * FROM lab_experiments
                      ORDER BY created_at DESC LIMIT ?''',(limit,)).fetchall()
        return [dict(r) for r in rows]

    def conclude_experiment(self,ident:str,status:str,observations:str='',conclusion:str=''):
        if status not in ('planned','running','completed','inconclusive','stopped'):
            raise SecurityError('Invalid experiment status')
        observations=_txt(observations,'Observations',6000,True)
        conclusion=_txt(conclusion,'Conclusion',3500,True)
        with self.db.connect() as con:
            change=con.execute('''UPDATE lab_experiments
                   SET status=?,observations=?,conclusion=?,updated_at=? WHERE id=?''',
                   (status,observations,conclusion,utcnow(),ident))
        return bool(change.rowcount)

    def record_decision(self,title:str,context:str,options:list[str],
                        decision:str,rationale:str,reversible:bool=True):
        if not isinstance(options,list) or not 1<=len(options)<=15:
            raise SecurityError('Provide 1 to 15 options')
        options=[_txt(o,'Option',500) for o in options]
        if type(reversible) is not bool:raise SecurityError('Reversible must be boolean')
        row={'id':_new_id(),'title':_txt(title,'Title',180),
             'context':_txt(context,'Context',4000),
             'options_json':json.dumps(options,ensure_ascii=False),
             'decision':_txt(decision,'Decision',2000),
             'rationale':_txt(rationale,'Rationale',4000),
             'reversible':int(reversible),'created_at':utcnow()}
        with self.db.connect() as con:
            con.execute('''INSERT INTO lab_decisions VALUES
                         (:id,:title,:context,:options_json,:decision,
                          :rationale,:reversible,:created_at)''',row)
        return self._decision(row)

    @staticmethod
    def _decision(row):
        item=dict(row)
        item['options']=json.loads(item.pop('options_json'))
        return item

    def decisions(self,limit:int=80):
        if not 1<=limit<=200:raise SecurityError('Invalid limit')
        with self.db.connect() as con:
            rows=con.execute('''SELECT * FROM lab_decisions ORDER BY created_at DESC
                                LIMIT ?''',(limit,)).fetchall()
        return [self._decision(r) for r in rows]

    def add_feedback(self,source:str,message:str,idea_id:str|None=None,tags:str=''):
        if idea_id and not self.get_idea(idea_id):
            raise SecurityError('Linked idea not found')
        row={'id':_new_id(),'source':_txt(source,'Source',160),
             'message':_txt(message,'Message',5000),
             'idea_id':idea_id,'tags':_txt(tags,'Tags',250,True),
             'status':'new','created_at':utcnow()}
        with self.db.connect() as con:
            con.execute('''INSERT INTO lab_feedback VALUES
                  (:id,:source,:message,:idea_id,:tags,:status,:created_at)''',row)
        return row

    def feedback(self,status:str|None=None,limit:int=100):
        if status not in (None,'new','reviewed','actioned','archived'):
            raise SecurityError('Invalid feedback status')
        if not 1<=limit<=200:raise SecurityError('Invalid limit')
        with self.db.connect() as con:
            rows=con.execute('''SELECT * FROM lab_feedback WHERE (? IS NULL OR status=?)
                                ORDER BY created_at DESC LIMIT ?''',(status,status,limit)).fetchall()
        return [dict(r) for r in rows]

    def update_feedback(self,ident:str,status:str):
        if status not in ('new','reviewed','actioned','archived'):
            raise SecurityError('Invalid feedback status')
        with self.db.connect() as con:
            change=con.execute('UPDATE lab_feedback SET status=? WHERE id=?',(status,ident))
        return bool(change.rowcount)

    def overview(self):
        with self.db.connect() as con:
            states=con.execute('''SELECT status,COUNT(*) AS count FROM lab_ideas
                                  GROUP BY status ORDER BY status''').fetchall()
            experiment_states=con.execute('''SELECT status,COUNT(*) AS count
                         FROM lab_experiments GROUP BY status ORDER BY status''').fetchall()
            feedback_count=con.execute('''SELECT COUNT(*) FROM lab_feedback
                                          WHERE status='new' ''').fetchone()[0]
            decision_count=con.execute('SELECT COUNT(*) FROM lab_decisions').fetchone()[0]
        return {'ideas':{r['status']:r['count'] for r in states},
                'experiments':{r['status']:r['count'] for r in experiment_states},
                'new_feedback':feedback_count,'decisions':decision_count,
                'top_ideas':self.ideas(limit=5)}
