"""Opt-in domain-specific tools extending the original JARVIS registry.

The backend and language model share exactly the same typed tool functions.
Tools do not provide shell execution, arbitrary network requests or file deletion.
"""
from __future__ import annotations

from datetime import datetime, timezone, timedelta
from typing import Any

from jarvis.tools import ToolDefinition, ToolRegistry, obj, field_str, _str, ToolError
from .store import OperationsStore
from .security import SecurityError


def str_property(description: str) -> dict:
    return {'type':'string','description':description}


def num_property(description: str) -> dict:
    return {'type':'integer','description':description}


def install_advanced_tools(registry: ToolRegistry, store: OperationsStore) -> None:
    """Install safe, literal high-level actions the user can request in chat."""
    def add(name: str, desc: str, fields: dict, required: list[str], callback,
            approve: bool = False) -> None:
        def wrapped(args: dict):
            try:
                return callback(args)
            except SecurityError as exc:
                raise ToolError(str(exc)) from exc
        registry.register(ToolDefinition(name,desc,obj(fields,required),wrapped,approve))

    add('list_projects', 'List projects and progress of their tasks',{},[],lambda a:store.projects())
    add('create_project','Create a named local project in your personal dashboard',
        {'name':str_property('Project title'),'description':str_property('Project goal')},['name'],
        lambda a:store.add_project(_str(a,'name',150),a.get('description','')))
    add('add_project_task','Create a new project task',
        {'project_id':str_property('Project UUID'),'title':str_property('Task description')},
        ['project_id','title'],lambda a:store.add_project_item(_str(a,'project_id',80),_str(a,'title',300)))
    add('project_tasks','List tasks from a project',{'project_id':str_property('Project UUID')},
        ['project_id'],lambda a:store.project_items(_str(a,'project_id',80)))
    add('list_goals','Show user-defined goals and their progress',{},[],lambda a:store.goals())
    add('create_goal','Save a goal and optional target date',
        {'title':str_property('Goal title'),'target_on':str_property('Optional YYYY-MM-DD date')},
        ['title'],lambda a:store.add_goal(_str(a,'title',240),target_on=a.get('target_on')))
    add('update_goal_progress','Set the percentage progress for a specific goal',
        {'goal_id':str_property('Goal UUID'),'progress':num_property('Integer 0 to 100')},
        ['goal_id','progress'],lambda a:{'updated':store.update_goal(_str(a,'goal_id',80),a['progress'])})
    add('list_habits','List habits and recent completion dates',{},[],lambda a:store.habits())
    add('create_habit','Create a positive routine to track',
        {'name':str_property('Habit name'),'days_per_week':num_property('Goal 1 to 7 days')},
        ['name'],lambda a:store.add_habit(_str(a,'name',120),a.get('days_per_week',5)))
    add('check_habit','Mark a specific habit as completed on a specified calendar date',
        {'habit_id':str_property('Habit UUID'),'date':str_property('YYYY-MM-DD')},
        ['habit_id','date'],lambda a:{'checked':store.habit_check(_str(a,'habit_id',80),_str(a,'date',10))})
    add('upcoming_events','List events in the next 30 days',{},[],
        lambda a:store.events(datetime.now(timezone.utc).isoformat(),
                               (datetime.now(timezone.utc)+timedelta(days=30)).isoformat()))
    add('add_calendar_event','Add an event to the local JARVIS calendar (not Google or device calendar)',
        {'title':str_property('Event title'),'start':str_property('ISO date-time with timezone'),
         'end':str_property('ISO date-time with timezone')},['title','start','end'],
        lambda a:store.create_event(_str(a,'title',200),_str(a,'start',60),_str(a,'end',60)))
    add('search_bookmarks','Find user-saved web bookmarks by title or tag',
        {'query':str_property('Keyword or blank for all')},[],
        lambda a:store.bookmarks(a.get('query','')))
    add('save_bookmark','Save a user-provided secure https web link as a private bookmark',
        {'title':str_property('Title'),'url':str_property('Full HTTPS URL')},['title','url'],
        lambda a:store.add_bookmark(_str(a,'title',160),_str(a,'url',2048)))
    add('search_snippets','Search previously saved code or text snippets',
        {'query':str_property('Keywords')},[],lambda a:store.snippets(a.get('query','')))
    add('save_snippet','Save a small code or text snippet in local JARVIS storage',
        {'title':str_property('Snippet title'),'content':str_property('Code or note'),
         'language':str_property('Optional programming language')},['title','content'],
        lambda a:store.add_snippet(_str(a,'title',160),_str(a,'content',20000),a.get('language','text')))
    add('focus_history','Show recent work/focus sessions',{},[],lambda a:store.focus_sessions())
    add('get_personal_dashboard','Show projects, goals, habits, event counts and recent activity',
        {},[],lambda a:store.dashboard())
    add('get_assistant_preferences','Show saved JARVIS preferences',{},[],lambda a:store.preferences())
