"""Private startup idea lab endpoints using typed Pydantic payloads."""
from __future__ import annotations

from typing import Callable

from fastapi import APIRouter,Depends,HTTPException,Query
from pydantic import BaseModel,Field

from .ideas import IdeaLab
from .security import SecurityError


class IdeaCreate(BaseModel):
    title:str=Field(min_length=1,max_length=180)
    problem:str=Field(min_length=1,max_length=2500)
    solution:str=Field(min_length=1,max_length=3500)
    audience:str=Field(default='',max_length=500)
    impact:int=Field(default=5,ge=1,le=10)
    confidence:int=Field(default=5,ge=1,le=10)
    effort:int=Field(default=5,ge=1,le=10)
    tags:str=Field(default='',max_length=250)


class IdeaPatch(BaseModel):
    title:str|None=Field(default=None,min_length=1,max_length=180)
    problem:str|None=Field(default=None,min_length=1,max_length=2500)
    solution:str|None=Field(default=None,min_length=1,max_length=3500)
    audience:str|None=Field(default=None,max_length=500)
    status:str|None=None
    impact:int|None=Field(default=None,ge=1,le=10)
    confidence:int|None=Field(default=None,ge=1,le=10)
    effort:int|None=Field(default=None,ge=1,le=10)
    tags:str|None=Field(default=None,max_length=250)


class ExperimentCreate(BaseModel):
    idea_id:str
    hypothesis:str=Field(min_length=1,max_length=2000)
    metric:str=Field(min_length=1,max_length=600)
    success_criterion:str=Field(min_length=1,max_length=1500)


class ExperimentPatch(BaseModel):
    status:str
    observations:str=Field(default='',max_length=6000)
    conclusion:str=Field(default='',max_length=3500)


class DecisionCreate(BaseModel):
    title:str=Field(min_length=1,max_length=180)
    context:str=Field(min_length=1,max_length=4000)
    options:list[str]=Field(min_length=1,max_length=15)
    decision:str=Field(min_length=1,max_length=2000)
    rationale:str=Field(min_length=1,max_length=4000)
    reversible:bool=True


class FeedbackCreate(BaseModel):
    source:str=Field(min_length=1,max_length=160)
    message:str=Field(min_length=1,max_length=5000)
    idea_id:str|None=None
    tags:str=Field(default='',max_length=250)


class FeedbackPatch(BaseModel):
    status:str


def build_router(lab:IdeaLab,authenticate:Callable):
    router=APIRouter(prefix='/api/lab',tags=['Startup Idea Lab'],
                     dependencies=[Depends(authenticate)])

    def safe(fn,*args,**kwargs):
        try:return fn(*args,**kwargs)
        except SecurityError as exc:raise HTTPException(400,str(exc)) from exc

    @router.get('/overview')
    def overview():return lab.overview()

    @router.get('/ideas')
    def ideas(query:str='',status:str|None=None,
              limit:int=Query(default=100,ge=1,le=200)):
        return safe(lab.ideas,query,status,limit)

    @router.post('/ideas',status_code=201)
    def create_idea(body:IdeaCreate):return safe(lab.create_idea,**body.model_dump())

    @router.get('/ideas/{ident}')
    def get_idea(ident:str):
        idea=lab.get_idea(ident)
        if not idea:raise HTTPException(404,'Idea not found')
        return idea

    @router.patch('/ideas/{ident}')
    def patch_idea(ident:str,body:IdeaPatch):
        changed=safe(lab.update_idea,ident,**body.model_dump(exclude_none=True))
        if not changed:raise HTTPException(404,'Idea not found')
        return {'updated':changed}

    @router.delete('/ideas/{ident}')
    def delete_idea(ident:str):return {'deleted':safe(lab.delete_idea,ident)}

    @router.get('/experiments')
    def experiments(idea_id:str|None=None,limit:int=Query(default=100,ge=1,le=200)):
        return safe(lab.experiments,idea_id,limit)

    @router.post('/experiments',status_code=201)
    def add_experiment(body:ExperimentCreate):
        return safe(lab.add_experiment,**body.model_dump())

    @router.patch('/experiments/{ident}')
    def conclude(ident:str,body:ExperimentPatch):
        return {'updated':safe(lab.conclude_experiment,ident,**body.model_dump())}

    @router.get('/decisions')
    def decisions(limit:int=Query(default=80,ge=1,le=200)):
        return safe(lab.decisions,limit)

    @router.post('/decisions',status_code=201)
    def add_decision(body:DecisionCreate):
        return safe(lab.record_decision,**body.model_dump())

    @router.get('/feedback')
    def feedback(status:str|None=None,limit:int=Query(default=100,ge=1,le=200)):
        return safe(lab.feedback,status,limit)

    @router.post('/feedback',status_code=201)
    def add_feedback(body:FeedbackCreate):
        return safe(lab.add_feedback,**body.model_dump())

    @router.patch('/feedback/{ident}')
    def patch_feedback(ident:str,body:FeedbackPatch):
        return {'updated':safe(lab.update_feedback,ident,body.status)}

    return router
