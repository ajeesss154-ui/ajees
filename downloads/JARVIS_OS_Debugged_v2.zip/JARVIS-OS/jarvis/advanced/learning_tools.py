"""Opt-in study cards and local review management for conversational JARVIS."""
from __future__ import annotations

from jarvis.tools import ToolDefinition,ToolRegistry,obj,field_str,ToolError
from .learning import StudyLibrary
from .security import SecurityError


def install_learning_tools(registry:ToolRegistry,library:StudyLibrary):
    def add(name,description,fields,required,action):
        def wrapped(args):
            try:
                return action(args)
            except SecurityError as exc:
                raise ToolError(str(exc)) from exc
        registry.register(ToolDefinition(name,description,obj(fields,required),wrapped))

    add('study_list_decks','List private study decks and due card counts',{},[],
        lambda _:library.decks())
    add('study_create_deck','Create a study deck of flashcards',
        {'title':field_str('Name of the topic')},['title'],
        lambda a:library.create_deck(a['title']))
    add('study_add_flashcard','Add a question and answer to a private study deck',
        {'deck_id':field_str('Deck UUID'),'question':field_str('Question'),
         'answer':field_str('Correct answer')},['deck_id','question','answer'],
        lambda a:library.add_card(a['deck_id'],a['question'],a['answer']))
    add('study_due_flashcards','List flashcards currently due for review',
        {'deck_id':field_str('Optional deck UUID')},[],
        lambda a:library.due(a.get('deck_id')))
    add('study_statistics','Get summary of flashcards, review counts and due items',{},[],
        lambda _:library.statistics())
