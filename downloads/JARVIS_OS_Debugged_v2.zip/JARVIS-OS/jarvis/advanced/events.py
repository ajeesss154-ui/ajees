"""Small, bounded event stream for status, audit and reminders.

No event may carry access tokens or private file contents. Long-lived SSE clients
receive only operational metadata, and a fresh authentication check is required
at subscription time.
"""
from __future__ import annotations

import asyncio
from collections import deque
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import json
import threading
from typing import AsyncIterator, Any
import uuid


@dataclass(frozen=True)
class Event:
    id: str
    topic: str
    at: str
    body: dict

    def as_sse(self) -> str:
        # Avoid multi-line SSE injection by serializing as JSON.
        content = json.dumps(asdict(self), ensure_ascii=False, separators=(',', ':'))
        return f'id: {self.id}\nevent: jarvis\ndata: {content}\n\n'


class EventHub:
    def __init__(self, max_history: int = 160, max_subscribers: int = 32):
        self.history: deque[Event] = deque(maxlen=max_history)
        self.subscribers: set[asyncio.Queue[Event]] = set()
        self.max_subscribers = max_subscribers
        self.lock = threading.RLock()
        self.counter = 0

    def publish(self, topic: str, body: dict[str, Any]) -> Event:
        if topic not in {'assistant', 'notification', 'system', 'task', 'workflow', 'security'}:
            raise ValueError('Unsupported event topic')
        self.counter += 1
        event = Event(str(self.counter), topic,
                      datetime.now(timezone.utc).isoformat(timespec='seconds'),
                      {str(k): self._safe(v) for k, v in body.items() if k in {
                          'kind', 'id', 'status', 'message', 'name', 'count', 'time',
                      }})
        with self.lock:
            self.history.append(event)
            for queue in list(self.subscribers):
                if queue.full():
                    try:
                        queue.get_nowait()
                    except asyncio.QueueEmpty:
                        pass
                queue.put_nowait(event)
        return event

    @staticmethod
    def _safe(value: Any) -> Any:
        if isinstance(value, (int, bool, float)):
            return value
        if isinstance(value, str):
            return value[:250]
        return None

    def recent(self, count: int = 30) -> list[dict]:
        with self.lock:
            return [asdict(e) for e in list(self.history)[-min(count, 100):]]

    async def stream(self, last_id: str = '') -> AsyncIterator[str]:
        with self.lock:
            if len(self.subscribers) >= self.max_subscribers:
                raise RuntimeError('Too many event subscribers')
            queue: asyncio.Queue[Event] = asyncio.Queue(maxsize=64)
            self.subscribers.add(queue)
            replay = list(self.history)
        try:
            if last_id and last_id.isdecimal():
                for event in replay:
                    if int(event.id) > int(last_id):
                        yield event.as_sse()
            else:
                yield ': connected\n\n'
            while True:
                try:
                    item = await asyncio.wait_for(queue.get(), timeout=20)
                except asyncio.TimeoutError:
                    yield ': heartbeat\n\n'
                    continue
                yield item.as_sse()
        finally:
            with self.lock:
                self.subscribers.discard(queue)
