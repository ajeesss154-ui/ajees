"""Local database backup, restore validation and privacy-aware export.

No cloud upload or automated transmission occurs. Restoring a backup is never
exposed to an AI tool; it is a deliberate offline maintenance operation.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import shutil
import sqlite3
import tempfile
from typing import Iterator
from uuid import uuid4
import zipfile

from jarvis.storage import Database
from .security import SecurityError, is_protected_name, validate_relative_path


class BackupManager:
    def __init__(self, database: Database, data_dir: Path):
        self.db=database
        self.data_dir=Path(data_dir).resolve()
        self.directory=self.data_dir/'backups'
        self.directory.mkdir(parents=True,exist_ok=True)

    def create(self, *, include_workspace: bool = False, workspace: Path | None = None) -> dict:
        """Use SQLite's online backup API for a consistent snapshot."""
        stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
        destination=self.directory/f'jarvis-{stamp}-{uuid4().hex[:8]}.zip'
        with tempfile.TemporaryDirectory(prefix='jarvis-backup-') as tmp:
            db_file=Path(tmp)/'jarvis.sqlite3'
            source=sqlite3.connect(self.db.path)
            target=sqlite3.connect(db_file)
            try:
                source.backup(target)
            finally:
                target.close();source.close()
            manifest={'version':1,'created_at':datetime.now(timezone.utc).isoformat(),
                      'database_sha256':self._sha256(db_file),'workspace_files':[],
                      'includes_workspace':bool(include_workspace)}
            with zipfile.ZipFile(destination,'w',compression=zipfile.ZIP_DEFLATED,
                                 compresslevel=6) as archive:
                archive.write(db_file,'database/jarvis.sqlite3')
                if include_workspace and workspace is not None:
                    root=workspace.resolve()
                    for path in root.rglob('*'):
                        if path.is_symlink() or not path.is_file(): continue
                        if len(manifest['workspace_files'])>=300:break
                        if path.stat().st_size>2*1024*1024:continue
                        rel=path.relative_to(root)
                        resolved=path.resolve()
                        if not resolved.is_relative_to(root):continue
                        if any(is_protected_name(part) for part in rel.parts):continue
                        if any(is_protected_name(part) for part in resolved.relative_to(root).parts):continue
                        name='workspace/'+rel.as_posix()
                        archive.write(path,name)
                        manifest['workspace_files'].append(name)
                archive.writestr('manifest.json',json.dumps(manifest,indent=2))
        return {'filename':destination.name,'size_bytes':destination.stat().st_size,
                'included_files':len(manifest['workspace_files']),
                'sha256':self._sha256(destination)}

    @staticmethod
    def _sha256(path: Path) -> str:
        digest=hashlib.sha256()
        with path.open('rb') as source:
            for chunk in iter(lambda:source.read(128*1024),b''):
                digest.update(chunk)
        return digest.hexdigest()

    def list(self) -> list[dict]:
        backups=[]
        for path in sorted(self.directory.glob('jarvis-*.zip'),reverse=True)[:100]:
            if path.is_symlink() or path.stat().st_size>200*1024*1024: continue
            backups.append({'filename':path.name,'size_bytes':path.stat().st_size,
                            'created_at':datetime.fromtimestamp(path.stat().st_mtime,
                              timezone.utc).isoformat()})
        return backups

    def validate(self, filename: str) -> dict:
        if not filename.startswith('jarvis-') or not filename.endswith('.zip') or '/' in filename or '\\' in filename:
            raise SecurityError('Invalid backup filename')
        path=(self.directory/filename).resolve()
        if not path.is_relative_to(self.directory) or not path.exists():
            raise SecurityError('Backup not found')
        try:
            with zipfile.ZipFile(path,'r') as archive:
                entries=archive.namelist()
                if len(entries)>400 or 'manifest.json' not in entries or 'database/jarvis.sqlite3' not in entries:
                    raise SecurityError('Backup file is incomplete')
                for info in archive.infolist():
                    if info.file_size>100*1024*1024 or info.filename.startswith('/') or '..' in Path(info.filename).parts:
                        raise SecurityError('Unsafe backup archive')
                manifest=json.loads(archive.read('manifest.json'))
                if manifest.get('version')!=1:
                    raise SecurityError('Unsupported backup version')
                digest=hashlib.sha256(archive.read('database/jarvis.sqlite3')).hexdigest()
                return {'valid':digest==manifest.get('database_sha256'),
                        'created_at':manifest['created_at'],
                        'workspace_files':len(manifest.get('workspace_files',[])),
                        'database_sha256':digest}
        except (zipfile.BadZipFile,KeyError,ValueError) as exc:
            raise SecurityError('Damaged backup') from exc

    def delete(self, filename: str) -> bool:
        self.validate(filename)
        (self.directory/filename).unlink()
        return True

    def export_json(self, target: Path, *, include_chat: bool = False) -> dict:
        """Structured export for portability. The token is never exported."""
        tables=['facts','notes','tasks','reminders','projects','project_items','goals',
                'habits','habit_checks','calendar_events','bookmarks','quick_snippets',
                'focus_sessions','workflows','workflow_runs','schedules','assistant_settings']
        if include_chat:tables.append('messages')
        output={'version':1,'exported_at':datetime.now(timezone.utc).isoformat(), 'tables':{}}
        with self.db.connect() as con:
            for table in tables:
                output['tables'][table]=[dict(row) for row in con.execute('SELECT * FROM '+table)]
        target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('x',encoding='utf-8') as fp:
            json.dump(output,fp,indent=2,ensure_ascii=False)
        return {'path':str(target),'records':sum(len(v) for v in output['tables'].values())}
