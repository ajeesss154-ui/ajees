"""Defence-in-depth for a human-approved personal computer assistant.

The API's bearer token is the boundary; language-model instructions are *never*
allowed to redefine the boundary.  The helpers in this file intentionally return
plain validation errors instead of exposing environmental details.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from ipaddress import ip_address, ip_network
import hmac
import json
import re
import secrets
from pathlib import Path
from typing import Any, Collection
from urllib.parse import urlsplit


class SecurityError(ValueError):
    """An operation did not satisfy the local security policy."""


PROTECTED_NAMES = {
    '.env', 'id_rsa', 'id_ed25519', 'credentials.json', 'access_token',
    'secrets.json', 'secret.key', '.aws', '.ssh', '.git', '.gnupg',
}
SENSITIVE_MARKERS = (
    'api_key', 'api-key', 'password', 'passwd', 'secret', 'access_token',
    'authorization', 'client_secret', 'private_key', 'refresh_token',
)
REDACTION_PATTERNS = (
    re.compile(r'(?i)(bearer\s+)[a-z0-9_.=-]{10,}'),
    re.compile(r'(?i)((?:api[_-]?key|password|secret|token)\s*[:=]\s*)\S{6,}'),
    re.compile(r'sk-[a-zA-Z0-9_-]{12,}'),
)


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def secure_compare(a: str, b: str) -> bool:
    """Constant-time token comparison. Both arguments must be strings."""
    if not isinstance(a, str) or not isinstance(b, str):
        return False
    try:
        return hmac.compare_digest(a.encode('utf-8'), b.encode('utf-8'))
    except UnicodeError:
        return False


def redact_secrets(value: str, max_len: int = 2000) -> str:
    """Best-effort display redaction, never an alternative to access control."""
    data = str(value)[:max_len]
    for pattern in REDACTION_PATTERNS:
        if pattern.groups:
            data = pattern.sub(lambda m: m.group(1) + '[REDACTED]', data)
        else:
            data = pattern.sub('[REDACTED]', data)
    return data


def validate_label(raw: str, *, limit: int = 160) -> str:
    if not isinstance(raw, str):
        raise SecurityError('Expected text')
    value = raw.strip()
    if not value or len(value) > limit or '\x00' in value:
        raise SecurityError(f'Enter 1–{limit} printable characters')
    if any(ord(ch) < 32 and ch not in '\n\t' for ch in value):
        raise SecurityError('Control characters are not allowed')
    return value


def validate_slug(raw: str) -> str:
    if not isinstance(raw, str) or not re.fullmatch(r'[a-z][a-z0-9_-]{1,47}', raw):
        raise SecurityError('Use a 2–48-character lowercase slug (letters, numbers, _ or -)')
    return raw


def validate_id(raw: str) -> str:
    if not isinstance(raw, str) or not re.fullmatch(r'[a-f0-9-]{36}', raw):
        raise SecurityError('Expected a UUID identifier')
    return raw


def validate_url(raw: str, *, allow_http: bool = False) -> str:
    """Validation for websites a human chooses to open, not SSRF fetching.

    This rejects local/private targets; URLs are never fetched by this module.
    The human must independently approve launches in the main tool registry.
    """
    raw = validate_label(raw, limit=2048)
    try:
        value = urlsplit(raw)
        port = value.port  # validate port parsing
        host = value.hostname or ''
    except ValueError as exc:
        raise SecurityError('Malformed URL') from exc
    if value.scheme not in ({'https', 'http'} if allow_http else {'https'}):
        raise SecurityError('Use a secure https:// URL')
    if not host or value.username or value.password or port == 0 or len(host) > 253:
        raise SecurityError('URL must not contain credentials or invalid ports')
    if host in {'localhost', 'localhost.localdomain'} or host.endswith('.local'):
        raise SecurityError('Private or local hosts are not supported')
    try:
        parsed = ip_address(host)
    except ValueError:
        # Don't permit DNS-host formats that intentionally look like IP bypasses.
        numeric_parts=host.split('.')
        numeric_host=all(re.fullmatch(r'(?:0x[0-9a-f]+|[0-9]+)', part, re.IGNORECASE)
                         for part in numeric_parts)
        if numeric_host or '..' in host or host.endswith('.'):
            raise SecurityError('Ambiguous host name')
    else:
        if not parsed.is_global:
            raise SecurityError('Private and reserved IP addresses are not supported')
    if any(ch in raw for ch in '\r\n\t\\'):
        raise SecurityError('URL contains prohibited characters')
    return raw


def is_protected_name(name: str) -> bool:
    """Shared filename policy for tools, indexes and optional workspace backups."""
    clean=name.casefold()
    return (clean in PROTECTED_NAMES or clean.startswith('.env.')
            or clean.startswith(('id_rsa', 'id_ed25519'))
            or Path(clean).suffix in {'.pem', '.key', '.p12', '.pfx'})


def validate_relative_path(root: Path, name: str, *, must_exist: bool = False,
                           extension: Collection[str] | None = None) -> Path:
    """Workspace containment enforced after symlink resolution."""
    if not isinstance(name, str) or len(name) > 250 or not name:
        raise SecurityError('Missing or oversized relative path')
    if '\\' in name or '\x00' in name or name.startswith('/') or name.startswith('~'):
        raise SecurityError('Only POSIX-style workspace-relative paths are allowed')
    p = Path(name)
    if any(part in {'..', '.'} or is_protected_name(part) for part in p.parts):
        raise SecurityError('Path is restricted')
    root = root.resolve()
    result = (root / p).resolve()
    if result == root or not result.is_relative_to(root):
        raise SecurityError('Path escapes workspace')
    if any(is_protected_name(part) for part in result.relative_to(root).parts):
        raise SecurityError('Path is restricted')
    if must_exist and not result.exists():
        raise SecurityError('Path not found')
    if extension is not None and result.suffix.lower() not in extension:
        raise SecurityError('Unsupported file type')
    return result


def bounded_json(value: Any, *, max_bytes: int = 15000) -> str:
    try:
        result = json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
    except (TypeError, ValueError) as exc:
        raise SecurityError('Value must be JSON serializable') from exc
    if len(result.encode('utf-8')) > max_bytes:
        raise SecurityError('JSON payload too large')
    return result


@dataclass(frozen=True)
class CapabilityPolicy:
    """Single point of truth for the workflow automation permission set."""
    unattended_tools: frozenset[str] = frozenset({
        'get_time', 'computer_status', 'calculate', 'recall_facts',
        'list_notes', 'search_notes', 'read_note', 'search_knowledge',
        'list_tasks', 'list_reminders', 'list_workspace', 'read_workspace_file',
    })
    scheduled_tools: frozenset[str] = frozenset({
        'get_time', 'computer_status', 'list_tasks', 'list_reminders',
        'recall_facts', 'list_notes',
    })
    max_steps: int = 12
    max_jobs: int = 50

    def check_workflow(self, names: list[str], *, unattended: bool = True) -> None:
        if not names or len(names) > self.max_steps:
            raise SecurityError(f'Workflow requires 1–{self.max_steps} steps')
        allowlist = self.unattended_tools if unattended else self.scheduled_tools
        for tool in names:
            if tool not in allowlist:
                raise SecurityError(f'Tool {tool!r} cannot run in an unattended workflow')


@dataclass
class TokenBucket:
    """Basic in-process token-bucket limiter for a single trusted home server.

    Distributed/routed deployments must use a shared external rate limiter.
    """
    rate: float = 1.0
    burst: float = 12.0
    tokens: float = field(default=12.0)
    last: float = field(default=0.0)

    def take(self, now: float, cost: float = 1.0) -> bool:
        if self.last == 0:
            self.last = now
        self.tokens = min(self.burst, self.tokens + (now - self.last) * self.rate)
        self.last = now
        if self.tokens < cost:
            return False
        self.tokens -= cost
        return True


class RateLimiter:
    def __init__(self, rate: float = 1, burst: int = 12, max_clients: int = 1024):
        self.rate = rate
        self.burst = burst
        self.max_clients = max_clients
        self.clients: dict[str, TokenBucket] = {}

    def permit(self, key: str, now: float, cost: float = 1.0) -> bool:
        if key not in self.clients:
            if len(self.clients) >= self.max_clients:
                # This is not a distributed denial-of-service defence.
                oldest = min(self.clients, key=lambda item: self.clients[item].last)
                del self.clients[oldest]
            self.clients[key] = TokenBucket(self.rate, self.burst, float(self.burst))
        return self.clients[key].take(now, cost)


def create_pairing_code() -> str:
    """Human-readable short-lived pairing code; compare only its stored hash."""
    alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
    return '-'.join(''.join(secrets.choice(alphabet) for _ in range(4)) for _ in range(2))


def safe_nested_lookup(data: dict, dotted: str) -> Any:
    """Read *only* literal keys from JSON data; never evaluate expressions."""
    if not re.fullmatch(r'[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*){0,7}', dotted):
        raise SecurityError('Invalid JSON key selector')
    current: Any = data
    for part in dotted.split('.'):
        if not isinstance(current, dict) or part not in current:
            raise SecurityError('No matching property')
        current = current[part]
    return current


def normalize_origin(origin: str) -> str:
    """Normalize an Origin header while refusing absent, opaque or wildcard origins."""
    if not origin or origin == 'null' or len(origin) > 250:
        raise SecurityError('Missing or untrusted origin')
    u = urlsplit(origin)
    if u.scheme not in {'http', 'https'} or not u.hostname or u.path or u.query or u.fragment:
        raise SecurityError('Invalid browser origin')
    return f'{u.scheme}://{u.netloc.lower()}'
