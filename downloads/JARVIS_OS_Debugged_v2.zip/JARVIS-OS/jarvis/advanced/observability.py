"""Operational measurements, health checks and bounded in-memory telemetry."""
from __future__ import annotations

from collections import Counter, deque
from dataclasses import dataclass
from datetime import datetime, timezone
from statistics import mean, median
import platform
import time
from threading import RLock
from typing import Any

import psutil


@dataclass
class LatencyRecord:
    operation: str
    duration_ms: float
    at: str
    success: bool


class OperationMetrics:
    def __init__(self, limit: int = 600):
        self.limit = limit
        self.records: deque[LatencyRecord] = deque(maxlen=limit)
        self._lock = RLock()

    def record(self, operation: str, seconds: float, success: bool) -> None:
        record = LatencyRecord(operation[:70], round(1000 * max(seconds, 0), 1),
                               datetime.now(timezone.utc).isoformat(timespec='seconds'), success)
        with self._lock:
            self.records.append(record)

    def summary(self) -> dict[str, Any]:
        with self._lock:
            records = list(self.records)
        by_operation: dict[str, list[LatencyRecord]] = {}
        for rec in records:
            by_operation.setdefault(rec.operation, []).append(rec)
        return {'total': len(records), 'operations': [
            {'operation': name, 'count': len(group),
             'success_rate': round(100 * sum(x.success for x in group) / len(group), 1),
             'average_ms': round(mean(x.duration_ms for x in group), 1),
             'median_ms': round(median(x.duration_ms for x in group), 1),
             'max_ms': max(x.duration_ms for x in group)}
            for name, group in sorted(by_operation.items())
        ]}

    def timed(self, name: str):
        metrics = self
        class Timer:
            def __enter__(self):
                self.started = time.monotonic()
                return self
            def __exit__(self, kind, exc, tb):
                metrics.record(name, time.monotonic() - self.started, kind is None)
                return False
        return Timer()


class SystemSampler:
    """Collect lightweight snapshots without needing root privileges."""
    def __init__(self, samples: int = 180):
        self.samples: deque[dict] = deque(maxlen=samples)
        self._lock = RLock()

    def take(self) -> dict:
        virtual = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        net = psutil.net_io_counters()
        snap = {
            'at': datetime.now(timezone.utc).isoformat(timespec='seconds'),
            'cpu': round(psutil.cpu_percent(interval=None), 1),
            'memory': round(virtual.percent, 1),
            'disk': round(disk.percent, 1),
            'network_bytes_sent': net.bytes_sent if net else 0,
            'network_bytes_received': net.bytes_recv if net else 0,
        }
        with self._lock:
            self.samples.append(snap)
        return snap

    def timeseries(self, limit: int = 90) -> list[dict]:
        with self._lock:
            return list(self.samples)[-min(limit, 180):]

    def overview(self) -> dict:
        with self._lock:
            items = list(self.samples)
        if not items:
            return {'samples': 0}
        return {
            'samples': len(items), 'latest': items[-1],
            'cpu_avg': round(mean(item['cpu'] for item in items), 1),
            'memory_avg': round(mean(item['memory'] for item in items), 1),
            'cpu_peak': max(item['cpu'] for item in items),
            'memory_peak': max(item['memory'] for item in items),
            'operating_system': platform.system(),
        }
