"""The agent's local startup-planning commands, with no outside effects."""
from __future__ import annotations

from jarvis.tools import ToolDefinition,ToolRegistry,obj,field_str,ToolError
from .ideas import IdeaLab
from .security import SecurityError


def install_ideas_tools(registry:ToolRegistry,lab:IdeaLab):
    def add(name,desc,props,required,callback):
        def wrapped(args):
            try:return callback(args)
            except SecurityError as exc:raise ToolError(str(exc)) from exc
        registry.register(ToolDefinition(name,desc,obj(props,required),wrapped))

    add('lab_ideas','List scored startup ideas sorted by user-entered priority',
        {},[],lambda _:lab.ideas())
    add('lab_create_idea','Save an idea, problem and proposed solution in the private idea lab',
        {'title':field_str('Idea title'),'problem':field_str('Customer problem'),
         'solution':field_str('Possible solution')},['title','problem','solution'],
        lambda a:lab.create_idea(a['title'],a['problem'],a['solution']))
    add('lab_experiments','List private experiments and hypotheses',
        {'idea_id':field_str('Optional idea UUID')},[],
        lambda a:lab.experiments(a.get('idea_id')))
    add('lab_feedback','List feedback the user has manually saved in JARVIS',
        {},[],lambda _:lab.feedback())
    add('lab_overview','Summarize local idea, experiment and feedback counts',
        {},[],lambda _:lab.overview())
