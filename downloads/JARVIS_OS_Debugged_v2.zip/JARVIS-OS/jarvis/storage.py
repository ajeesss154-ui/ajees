"""SQLite persistence: facts, messages, tasks, reminders and action audit trail.

Uses new connections per operation, parameterized SQL, WAL mode and transactions.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import json
from pathlib import Path
import sqlite3
from typing import Iterator
import uuid


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Database:
    def __init__(self, path: Path | str):
        self.path = str(path)
        self._initialize()

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        con = sqlite3.connect(self.path, timeout=10)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA busy_timeout=10000")
        try:
            yield con
            con.commit()
        except BaseException:
            con.rollback()
            raise
        finally:
            con.close()

    def _initialize(self) -> None:
        with self.connect() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.executescript("""
                CREATE TABLE IF NOT EXISTS messages (
                    id TEXT PRIMARY KEY, session_id TEXT NOT NULL,
                    role TEXT NOT NULL, content TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_messages_session
                    ON messages(session_id, created_at);
                CREATE TABLE IF NOT EXISTS facts (
                    id TEXT PRIMARY KEY, key TEXT NOT NULL COLLATE NOCASE UNIQUE,
                    value TEXT NOT NULL, updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS notes (
                    id TEXT PRIMARY KEY, title TEXT NOT NULL,
                    body TEXT NOT NULL, created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS tasks (
                    id TEXT PRIMARY KEY, title TEXT NOT NULL,
                    completed INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS reminders (
                    id TEXT PRIMARY KEY, text TEXT NOT NULL,
                    due_at TEXT NOT NULL, notified INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS notifications (
                    id TEXT PRIMARY KEY, reminder_id TEXT NOT NULL UNIQUE,
                    text TEXT NOT NULL, created_at TEXT NOT NULL,
                    acknowledged INTEGER NOT NULL DEFAULT 0
                );
                CREATE TABLE IF NOT EXISTS approvals (
                    id TEXT PRIMARY KEY, tool TEXT NOT NULL, args_json TEXT NOT NULL,
                    description TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
                    created_at TEXT NOT NULL, expires_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS audit (
                    id TEXT PRIMARY KEY, tool TEXT NOT NULL, args_json TEXT NOT NULL,
                    status TEXT NOT NULL, result TEXT NOT NULL, created_at TEXT NOT NULL
                );
            """)

    def add_message(self, session: str, role: str, content: str) -> str:
        ident = str(uuid.uuid4())
        with self.connect() as db:
            db.execute("INSERT INTO messages VALUES (?, ?, ?, ?, ?)",
                       (ident, session, role, content[:30000], utcnow()))
        return ident

    def history(self, session: str, limit: int = 16) -> list[dict]:
        with self.connect() as db:
            rows = db.execute("SELECT role, content FROM messages WHERE session_id=? ORDER BY rowid DESC LIMIT ?", (session, limit)).fetchall()
        return [dict(row) for row in reversed(rows)]

    def clear_history(self, session: str) -> int:
        with self.connect() as db:
            cursor = db.execute("DELETE FROM messages WHERE session_id=?", (session,))
        return cursor.rowcount

    def remember(self, key: str, value: str) -> dict:
        ident = str(uuid.uuid4())
        with self.connect() as db:
            db.execute("""INSERT INTO facts VALUES (?, ?, ?, ?)
                          ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at""",
                       (ident, key[:100], value[:1000], utcnow()))
        return {"key": key, "value": value}

    def facts(self, limit: int = 60) -> list[dict]:
        with self.connect() as db:
            rows = db.execute("SELECT key, value FROM facts ORDER BY updated_at DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]

    def forget(self, key: str) -> bool:
        with self.connect() as db:
            cursor = db.execute("DELETE FROM facts WHERE key=?", (key,))
        return bool(cursor.rowcount)

    def save_note(self, title: str, body: str) -> dict:
        obj = {"id": str(uuid.uuid4()), "title": title, "body": body, "created_at": utcnow()}
        with self.connect() as db:
            db.execute("INSERT INTO notes VALUES (:id,:title,:body,:created_at)", obj)
        return obj

    def notes(self, query: str = "", limit: int = 40) -> list[dict]:
        with self.connect() as db:
            if query:
                # Parameterized LIKE; user input is treated as literal characters.
                q = "%" + query.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
                rows = db.execute("""SELECT * FROM notes WHERE title LIKE ? ESCAPE '\\'
                                    OR body LIKE ? ESCAPE '\\' ORDER BY rowid DESC LIMIT ?""", (q, q, limit)).fetchall()
            else:
                rows = db.execute("SELECT * FROM notes ORDER BY rowid DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]

    def read_note(self, note_id: str) -> dict | None:
        with self.connect() as db:
            row = db.execute("SELECT * FROM notes WHERE id=?", (note_id,)).fetchone()
        return dict(row) if row else None

    def add_task(self, title: str) -> dict:
        obj = {"id": str(uuid.uuid4()), "title": title, "completed": 0, "created_at": utcnow()}
        with self.connect() as db:
            db.execute("INSERT INTO tasks VALUES (:id,:title,:completed,:created_at)", obj)
        return obj

    def tasks(self, include_completed: bool = False) -> list[dict]:
        with self.connect() as db:
            rows = db.execute("SELECT * FROM tasks WHERE (? = 1 OR completed = 0) ORDER BY rowid DESC LIMIT 150", (int(include_completed),)).fetchall()
        return [dict(r) for r in rows]

    def complete_task(self, task_id: str) -> bool:
        with self.connect() as db:
            cur = db.execute("UPDATE tasks SET completed=1 WHERE id=? AND completed=0", (task_id,))
        return bool(cur.rowcount)

    def add_reminder(self, text: str, due_at: str) -> dict:
        obj = {"id": str(uuid.uuid4()), "text": text, "due_at": due_at, "notified": 0, "created_at": utcnow()}
        with self.connect() as db:
            db.execute("INSERT INTO reminders VALUES (:id,:text,:due_at,:notified,:created_at)", obj)
        return obj

    def reminders(self, include_notified: bool = False) -> list[dict]:
        with self.connect() as db:
            rows = db.execute("SELECT * FROM reminders WHERE (?=1 OR notified=0) ORDER BY due_at ASC LIMIT 100", (int(include_notified),)).fetchall()
        return [dict(r) for r in rows]

    def due_reminders(self) -> list[dict]:
        """Atomically claim due reminders; timestamps are normalized UTC strings."""
        with self.connect() as db:
            # Claim the write lock before selecting. The background scheduler
            # and notification polling can run concurrently on separate SQLite
            # connections; a deferred SELECT would let both claim the same row.
            db.execute("BEGIN IMMEDIATE")
            rows = db.execute("SELECT * FROM reminders WHERE notified=0 AND due_at<=? ORDER BY due_at LIMIT 30", (utcnow(),)).fetchall()
            for row in rows:
                db.execute("UPDATE reminders SET notified=1 WHERE id=? AND notified=0", (row["id"],))
                db.execute("INSERT OR IGNORE INTO notifications VALUES (?,?,?,?,0)",
                           (str(uuid.uuid4()), row["id"], row["text"], utcnow()))
        return [dict(r) for r in rows]

    def notifications(self) -> list[dict]:
        with self.connect() as db:
            rows = db.execute("SELECT id,text,created_at FROM notifications WHERE acknowledged=0 ORDER BY rowid DESC LIMIT 30").fetchall()
        return [dict(r) for r in rows]

    def acknowledge_notification(self, ident: str) -> bool:
        with self.connect() as db:
            cur = db.execute("UPDATE notifications SET acknowledged=1 WHERE id=?", (ident,))
        return bool(cur.rowcount)

    def add_approval(self, tool: str, args: dict, description: str, expires_at: str) -> dict:
        obj = {"id": str(uuid.uuid4()), "tool": tool, "args_json": json.dumps(args),
               "description": description, "status": "pending", "created_at": utcnow(), "expires_at": expires_at}
        with self.connect() as db:
            db.execute("""INSERT INTO approvals VALUES
                        (:id,:tool,:args_json,:description,:status,:created_at,:expires_at)""", obj)
        return {"id": obj["id"], "description": description, "tool": tool, "expires_at": expires_at}

    def approvals(self) -> list[dict]:
        with self.connect() as db:
            rows = db.execute("SELECT id,tool,description,expires_at FROM approvals WHERE status='pending' AND expires_at>? ORDER BY rowid DESC LIMIT 30", (utcnow(),)).fetchall()
        return [dict(r) for r in rows]

    def decide_approval(self, ident: str, approve: bool) -> dict | None:
        """Atomically claim approval exactly once with an expiry constraint."""
        with self.connect() as db:
            row = db.execute("""UPDATE approvals SET status=?
                WHERE id=? AND status='pending' AND expires_at>?
                RETURNING *""", ("approved" if approve else "denied", ident, utcnow())).fetchone()
            if not row:
                db.execute("UPDATE approvals SET status='expired' WHERE id=? AND status='pending' AND expires_at<=?",
                           (ident, utcnow()))
                return None
            return dict(row)

    def audit(self, tool: str, args: dict, status: str, result: str) -> None:
        # Never log API keys; tools accept only narrow validated parameters.
        with self.connect() as db:
            db.execute("INSERT INTO audit VALUES (?,?,?,?,?,?)",
                       (str(uuid.uuid4()), tool, json.dumps(args)[:3000], status, result[:1000], utcnow()))

    def audit_recent(self) -> list[dict]:
        with self.connect() as db:
            rows = db.execute("SELECT tool,status,result,created_at FROM audit ORDER BY rowid DESC LIMIT 30").fetchall()
        return [dict(row) for row in rows]
