"""JARVIS OS — local-first modular assistant."""
__version__ = "0.1.0"
