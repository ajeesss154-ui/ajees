"""Command-line control for the local JARVIS personal assistant.

Supported commands:
  serve, doctor, token, stats, backup, exports, index, search, selftest, lines

Remote access is intentionally limited to trusted LAN by default; this CLI
never starts an Internet-facing production service or runs arbitrary scripts.
"""
from __future__ import annotations

import argparse
import json
import sys
import os
from pathlib import Path
from datetime import datetime, timezone
import importlib.util
from typing import Any

from .config import Settings
from .storage import Database


def build_parser() -> argparse.ArgumentParser:
    parser=argparse.ArgumentParser(description='JARVIS OS local AI assistant')
    sub=parser.add_subparsers(dest='cmd')
    serve=sub.add_parser('serve',help='Start PC and phone-compatible web UI')
    serve.add_argument('--port',type=int,default=8765)
    serve.add_argument('--lan',action='store_true',help='Trusted private Wi-Fi only; HTTP is unencrypted')
    sub.add_parser('token',help='Show private access token (do not share)')
    sub.add_parser('doctor',help='Check installation and dependencies')
    sub.add_parser('stats',help='Print counts of locally stored records')
    backup=sub.add_parser('backup',help='Create a local SQLite backup archive')
    backup.add_argument('--with-workspace',action='store_true')
    export=sub.add_parser('export',help='Export local records to a new JSON file')
    export.add_argument('--output',required=True,type=Path)
    export.add_argument('--with-chat',action='store_true')
    sub.add_parser('index',help='Refresh local notes/workspace search index')
    search=sub.add_parser('search',help='Search the existing local knowledge index')
    search.add_argument('query',nargs='+')
    search.add_argument('--limit',type=int,default=8)
    sub.add_parser('selftest',help='Run local library and storage smoke checks')
    sub.add_parser('lines',help='Count source lines by file type')
    return parser


def _json(data:Any) -> None:
    print(json.dumps(data,indent=2,ensure_ascii=False,default=str))


def _doctor(settings: Settings) -> dict:
    optional={
        'fastapi':'fastapi',
        'psutil':'psutil',
        'scikit_learn':'sklearn',
        'openai_sdk':'openai',
        'pillow':'PIL',
        'faster_whisper':'faster_whisper',
        'sentence_transformers':'sentence_transformers',
    }
    return {
        'python':sys.version.split()[0],
        'provider':settings.provider,
        'ollama_url':settings.ollama_url,
        'model':settings.ollama_model if settings.provider=='ollama' else settings.openai_model,
        'data_directory':str(settings.data_dir),
        'workspace':str(settings.workspace),
        'access_token':'configured (run jarvis token locally to display it)',
        'modules':{name:importlib.util.find_spec(import_name) is not None
                   for name,import_name in optional.items()},
        'timezone':datetime.now().astimezone().tzname(),
    }


def _stats(settings:Settings) -> dict:
    from .advanced.store import OperationsStore
    db=Database(settings.database_path)
    extra=OperationsStore(db)
    return {
        'extended_dashboard':extra.dashboard(),
        'notes':len(db.notes()),
        'facts':len(db.facts()),
        'tasks':len(db.tasks(include_completed=True)),
        'reminders':len(db.reminders(include_notified=True)),
        'backups':str(settings.data_dir/'backups'),
    }


def _selftest(settings: Settings) -> dict:
    from .intelligence.text import text_profile
    from .intelligence.ranking import BM25
    from .advanced.security import validate_relative_path, CapabilityPolicy
    from .advanced.store import OperationsStore
    from .tools import ToolRegistry
    db=Database(settings.database_path)
    store=OperationsStore(db)
    registry=ToolRegistry(db,settings)
    checks={
        'db_readable':isinstance(db.notes(),list),
        'advanced_store':isinstance(store.dashboard(),dict),
        'get_time':registry.handle('get_time',{},audit=False).get('ok',False),
        'document_analysis':text_profile('Hello from JARVIS')['words']==3,
        'search_ranker':BM25(['python project','calendar reminder']).rank('python')[0][0]==0,
        'workspace_restriction':validate_relative_path(settings.workspace,'demo.md').is_relative_to(settings.workspace),
        'workflow_permissions':'launch_app' not in CapabilityPolicy().unattended_tools,
    }
    return {'ok':all(checks.values()),'checks':checks}


def _count_lines(root:Path) -> dict:
    files={}
    extensions={'.py','.ts','.js','.html','.css','.md','.toml','.sh','.bat','.json','.svg'}
    for path in root.rglob('*'):
        if (not path.is_file() or path.suffix not in extensions
            or any(part in {'.git','.venv','__pycache__','.pytest_cache'} for part in path.parts)):
            continue
        try:
            count=sum(1 for _ in path.open(encoding='utf-8'))
        except (OSError,UnicodeError):continue
        files[path.suffix]=files.get(path.suffix,0)+count
    return {'total':sum(files.values()),'by_extension':dict(sorted(files.items()))}


def _serve(settings:Settings,port:int,lan:bool) -> None:
    if not 1024<=port<=65535:
        raise ValueError('Port must be between 1024 and 65535')
    import uvicorn
    from .api import create_app
    host='0.0.0.0' if lan else '127.0.0.1'
    print('='*72)
    print('JARVIS OS READY — http://127.0.0.1:%d' % port)
    print('PRIVATE ACCESS TOKEN:',settings.access_token)
    print('Never share this token or a screenshot of it.')
    print('='*72)
    if lan:
        print('WARNING: LAN is plain HTTP. Trusted local networks ONLY.')
        print('Phone microphone capture usually requires HTTPS; text works on LAN.')
        print('Do not forward ports or expose this server to the public internet.')
    uvicorn.run(create_app(settings),host=host,port=port,log_level='info')


def main(argv: list[str] | None = None) -> None:
    parser=build_parser()
    args=parser.parse_args(argv)
    settings=Settings()
    try:
        if args.cmd in {None,'serve'}:
            _serve(settings,getattr(args,'port',8765),getattr(args,'lan',False))
        elif args.cmd=='token':
            print(settings.access_token)
        elif args.cmd=='doctor':
            _json(_doctor(settings))
        elif args.cmd=='stats':
            _json(_stats(settings))
        elif args.cmd=='selftest':
            result=_selftest(settings);_json(result)
            if not result['ok']:raise SystemExit(1)
        elif args.cmd=='lines':
            _json(_count_lines(Path(__file__).resolve().parents[1]))
        elif args.cmd=='index':
            from .intelligence.index import LocalIndex
            _json(LocalIndex(Database(settings.database_path),settings.workspace).refresh())
        elif args.cmd=='search':
            from .intelligence.index import LocalIndex
            index=LocalIndex(Database(settings.database_path),settings.workspace)
            _json(index.search(' '.join(args.query),limit=args.limit))
        elif args.cmd=='backup':
            from .advanced.backup import BackupManager
            manager=BackupManager(Database(settings.database_path),settings.data_dir)
            _json(manager.create(include_workspace=args.with_workspace,
                                 workspace=settings.workspace))
        elif args.cmd=='export':
            from .advanced.backup import BackupManager
            from .advanced.store import OperationsStore
            db=Database(settings.database_path)
            OperationsStore(db)
            manager=BackupManager(db,settings.data_dir)
            target=args.output.expanduser().resolve()
            if target.is_relative_to(settings.data_dir):
                raise ValueError('Export outside the private JARVIS data directory')
            _json(manager.export_json(target,include_chat=args.with_chat))
        else:
            parser.print_help()
    except (ValueError,OSError) as exc:
        print('JARVIS:',exc,file=sys.stderr)
        raise SystemExit(2) from exc


if __name__=='__main__':
    main()
