"""Optional tiny ML intent recognizer for basic offline read-only commands.

This is a trained TF-IDF + logistic-regression classifier, not a general LLM.
When sklearn is missing the recognizer simply returns None.
"""
from __future__ import annotations

from dataclasses import dataclass

TRAINING = {
    "time": ["what time is it", "tell me the time", "current date", "today's date", "clock please", "time now", "what day is it", "show the local time"],
    "status": ["check cpu", "computer status", "how much ram is used", "show battery level", "pc performance", "system usage", "my laptop status", "disk usage"],
    "tasks": ["list my tasks", "show todos", "what tasks are open", "unfinished work", "what should i do", "show task list", "my pending tasks", "show my to dos"],
    "notes": ["show my notes", "list recent notes", "what notes did i save", "find my notes", "my note list", "read saved notes", "show notebook", "notes please"],
    "reminders": ["upcoming reminders", "what reminders do i have", "list scheduled reminders", "show reminder list", "my reminders", "check alerts", "pending reminders", "show schedule reminders"],
}


@dataclass(frozen=True)
class Guess:
    label: str
    confidence: float


class OfflineClassifier:
    def __init__(self):
        self.pipeline = None
        try:
            from sklearn.feature_extraction.text import TfidfVectorizer
            from sklearn.linear_model import LogisticRegression
            from sklearn.pipeline import make_pipeline
            x = [s for examples in TRAINING.values() for s in examples]
            y = [label for label, examples in TRAINING.items() for _ in examples]
            self.pipeline = make_pipeline(TfidfVectorizer(ngram_range=(1, 2)),
                                          LogisticRegression(max_iter=500))
            self.pipeline.fit(x, y)
        except ImportError:
            pass

    def predict(self, text: str) -> Guess | None:
        if self.pipeline is None:
            return None
        probabilities = self.pipeline.predict_proba([text])[0]
        i = int(probabilities.argmax())
        return Guess(str(self.pipeline.classes_[i]), float(probabilities[i]))
