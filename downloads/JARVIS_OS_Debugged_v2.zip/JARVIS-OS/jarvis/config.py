"""Configuration and access-token handling."""
from __future__ import annotations

from dataclasses import dataclass, field
import os
from pathlib import Path
import secrets

from dotenv import load_dotenv

load_dotenv()


def _default_dir() -> Path:
    return Path(os.environ.get("JARVIS_DATA_DIR", str(Path.home() / ".jarvis_ai"))).expanduser()


@dataclass(slots=True)
class Settings:
    data_dir: Path = field(default_factory=_default_dir)
    workspace: Path | None = None
    provider: str = field(default_factory=lambda: os.getenv("JARVIS_PROVIDER", "ollama").lower())
    ollama_url: str = field(default_factory=lambda: os.getenv("JARVIS_OLLAMA_URL", "http://127.0.0.1:11434"))
    ollama_model: str = field(default_factory=lambda: os.getenv("JARVIS_OLLAMA_MODEL", "qwen3:4b"))
    openai_model: str = field(default_factory=lambda: os.getenv("JARVIS_OPENAI_MODEL", "gpt-4.1-mini"))
    openai_api_key: str = field(default_factory=lambda: os.getenv("OPENAI_API_KEY", ""))
    access_token: str = field(default_factory=lambda: os.getenv("JARVIS_ACCESS_TOKEN", ""))
    enable_ml_fallback: bool = True

    def __post_init__(self) -> None:
        self.data_dir = Path(self.data_dir).expanduser().resolve()
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.workspace = Path(self.workspace or os.getenv("JARVIS_WORKSPACE", str(self.data_dir / "workspace"))).expanduser().resolve()
        self.workspace.mkdir(parents=True, exist_ok=True)
        if self.provider not in {"ollama", "openai"}:
            raise ValueError("JARVIS_PROVIDER must be 'ollama' or 'openai'")
        if not self.access_token:
            path = self.data_dir / "access_token"
            if path.exists():
                self.access_token = path.read_text(encoding="utf-8").strip()
            else:
                self.access_token = secrets.token_urlsafe(32)
                try:
                    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                    with os.fdopen(fd, "w", encoding="utf-8") as out:
                        out.write(self.access_token + "\n")
                except FileExistsError:
                    self.access_token = path.read_text(encoding="utf-8").strip()
            if not self.access_token:
                raise ValueError("Access-token file is empty")
        if (not isinstance(self.access_token, str)
                or not 16 <= len(self.access_token) <= 512
                or any(not 33 <= ord(char) <= 126 for char in self.access_token)):
            raise ValueError("Access token must contain 16–512 printable ASCII characters without spaces; use a long random token")

    @property
    def database_path(self) -> Path:
        return self.data_dir / "jarvis.sqlite3"
