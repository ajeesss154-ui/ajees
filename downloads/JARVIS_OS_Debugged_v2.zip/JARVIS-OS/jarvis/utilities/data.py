"""JSON and CSV table transformations performed entirely in memory.

This module deliberately has no file or network access.  It is suitable for
model tool calling because inputs/outputs are bounded and data-only.  Functions
operate on a list of row dictionaries, with a tight row/column size budget.
"""
from __future__ import annotations

import csv
from collections import Counter, defaultdict
from datetime import datetime
import io
import json
import math
import re
from statistics import mean, median
from typing import Any

from .core import UtilityError, UtilityRegistry, S, I, N, B, A, O


def _rows(value: list, maximum: int = 500) -> list[dict]:
    if not isinstance(value, list) or len(value) > maximum:
        raise UtilityError('Expected a table with up to 500 rows')
    if any(not isinstance(row, dict) for row in value):
        raise UtilityError('Each row must be an object')
    if any(len(row) > 40 for row in value):
        raise UtilityError('A row cannot have more than 40 fields')
    return value


def _columns(rows: list[dict]) -> list[str]:
    return list(dict.fromkeys(k for row in rows for k in row if isinstance(k, str)))


def _number(v: Any) -> float:
    if type(v) in (float, int) and math.isfinite(v):
        return float(v)
    if isinstance(v, str) and re.fullmatch(r'\s*[-+]?\d+(?:\.\d+)?\s*', v):
        f = float(v)
        if math.isfinite(f):
            return f
    raise UtilityError('Expected a finite numeric field')


def _scalar(v: Any) -> str:
    if v is None:
        return ''
    if isinstance(v, (dict, list)):
        return json.dumps(v, ensure_ascii=False, sort_keys=True)
    return str(v)


def register(reg: UtilityRegistry) -> None:
    @reg.register('data', 'parse_json', 'Validate and decode a JSON text value',
                  {'text': S('JSON document', max_length=15000)})
    def parse_json(text):
        try:
            return json.loads(text)
        except json.JSONDecodeError as exc:
            raise UtilityError(f'Invalid JSON at line {exc.lineno}, column {exc.colno}') from exc

    @reg.register('data', 'format_json', 'Pretty-print a bounded JSON value',
                  {'value': O('Object to format'), 'indent': I('Indent spaces', False, 2, 0, 6)})
    def format_json(value, indent):
        return json.dumps(value, indent=indent, sort_keys=True, ensure_ascii=False)

    @reg.register('data', 'json_extract_path', 'Read a nested JSON object by a simple dotted path',
                  {'value': O('Source document'), 'path': S('Dot-separated keys', max_length=300)})
    def json_extract_path(value, path):
        node = value
        for key in path.split('.'):
            if isinstance(node, dict):
                if key not in node:
                    raise UtilityError('Path not found: ' + key)
                node = node[key]
            elif isinstance(node, list) and key.isdigit() and int(key) < len(node):
                node = node[int(key)]
            else:
                raise UtilityError('Path not found: ' + key)
        return node

    @reg.register('data', 'json_object_diff', 'Show changed, added and removed top-level keys',
                  {'before': O('Earlier object'), 'after': O('Later object')})
    def json_object_diff(before, after):
        b, a = set(before), set(after)
        return {'added': {k: after[k] for k in sorted(a-b)},
                'removed': {k: before[k] for k in sorted(b-a)},
                'changed': {k: {'before': before[k], 'after': after[k]}
                            for k in sorted(a & b) if before[k] != after[k]}}

    @reg.register('data', 'parse_csv', 'Parse simple comma-separated data into row objects',
                  {'text': S('CSV content', max_length=15000),
                   'delimiter': S('Field delimiter', False, ',', min_length=1, max_length=1)})
    def parse_csv(text, delimiter):
        source = io.StringIO(text)
        reader = csv.DictReader(source, delimiter=delimiter)
        if reader.fieldnames is None or len(reader.fieldnames) > 40:
            raise UtilityError('CSV header is missing or has too many columns')
        result = []
        for row in reader:
            if len(result) >= 500:
                raise UtilityError('Too many CSV rows')
            if None in row:
                raise UtilityError('Inconsistent number of columns')
            result.append(row)
        return {'columns': reader.fieldnames, 'rows': result, 'count': len(result)}

    @reg.register('data', 'make_csv', 'Convert a JSON table into escaped CSV text',
                  {'rows': A('Rows to encode', max_length=500),
                   'delimiter': S('Delimiter', False, ',', min_length=1, max_length=1)})
    def make_csv(rows, delimiter):
        data = _rows(rows)
        cols = _columns(data)
        stream = io.StringIO()
        writer = csv.DictWriter(stream, fieldnames=cols, delimiter=delimiter, extrasaction='ignore')
        writer.writeheader()
        for row in data:
            writer.writerow({k: _scalar(v) for k, v in row.items()})
        return stream.getvalue()

    @reg.register('data', 'table_columns', 'List all columns present in a JSON table',
                  {'rows': A('Table of row objects')})
    def table_columns(rows):
        data = _rows(rows)
        return {'columns': _columns(data), 'rows': len(data)}

    @reg.register('data', 'table_select', 'Select and reorder table columns',
                  {'rows': A('Rows'), 'columns': A('Desired field names', min_length=1, max_length=40)})
    def table_select(rows, columns):
        if any(not isinstance(c, str) for c in columns):
            raise UtilityError('Columns must be names')
        return [{c: row.get(c) for c in columns} for row in _rows(rows)]

    @reg.register('data', 'table_take', 'Take a bounded slice of rows',
                  {'rows': A('Rows'), 'start': I('Start index', False, 0, 0, 500),
                   'count': I('Maximum returned rows', False, 20, 0, 200)})
    def table_take(rows, start, count):
        return _rows(rows)[start:start+count]

    @reg.register('data', 'table_sort', 'Sort a table on a column, sorting missing values last',
                  {'rows': A('Rows'), 'column': S('Sort column'),
                   'descending': B('Reverse sort order', False, False)})
    def table_sort(rows, column, descending):
        data = _rows(rows)
        def key(row):
            val = row.get(column)
            if val is None:
                return (1, '', '')
            if isinstance(val, (float, int)) and type(val) is not bool:
                return (0, 'number', float(val))
            return (0, type(val).__name__, str(val).casefold())
        nonmissing = [r for r in data if r.get(column) is not None]
        missing = [r for r in data if r.get(column) is None]
        return sorted(nonmissing, key=key, reverse=descending) + missing

    @reg.register('data', 'table_filter_equal', 'Filter rows by exact value for a named column',
                  {'rows': A('Rows'), 'column': S('Field name'),
                   'value': S('Desired text value'),
                   'case_sensitive': B('Exact case match', False, False)})
    def table_filter_equal(rows, column, value, case_sensitive):
        def match(v):
            lhs = _scalar(v)
            return lhs == value if case_sensitive else lhs.casefold() == value.casefold()
        return [row for row in _rows(rows) if match(row.get(column))]

    @reg.register('data', 'table_filter_numeric', 'Filter rows based on a number comparison',
                  {'rows': A('Rows'), 'column': S('Field name'),
                   'comparison': S('Comparison', choices=('gt','gte','lt','lte','eq','neq')),
                   'value': N('Numeric threshold')})
    def table_filter_numeric(rows, column, comparison, value):
        ops = {'gt': lambda x: x > value, 'gte': lambda x: x >= value,
               'lt': lambda x: x < value, 'lte': lambda x: x <= value,
               'eq': lambda x: x == value, 'neq': lambda x: x != value}
        result = []
        for row in _rows(rows):
            try:
                num = _number(row.get(column))
            except UtilityError:
                continue
            if ops[comparison](num):
                result.append(row)
        return result

    @reg.register('data', 'table_unique', 'Find unique values in one table column',
                  {'rows': A('Rows'), 'column': S('Field')})
    def table_unique(rows, column):
        values = [_scalar(row.get(column)) for row in _rows(rows)]
        return list(dict.fromkeys(values))

    @reg.register('data', 'table_distinct', 'Remove duplicate complete JSON rows',
                  {'rows': A('Rows')})
    def table_distinct(rows):
        seen, result = set(), []
        for row in _rows(rows):
            key = json.dumps(row, sort_keys=True, ensure_ascii=False)
            if key not in seen:
                seen.add(key)
                result.append(row)
        return result

    @reg.register('data', 'table_column_sum', 'Add a numeric column, ignoring empty values',
                  {'rows': A('Rows'), 'column': S('Field')})
    def table_column_sum(rows, column):
        values = [_number(row[column]) for row in _rows(rows) if row.get(column) not in (None, '')]
        return {'count': len(values), 'sum': sum(values)}

    @reg.register('data', 'table_column_average', 'Average a numeric column, ignoring empty values',
                  {'rows': A('Rows'), 'column': S('Field')})
    def table_column_average(rows, column):
        values = [_number(row[column]) for row in _rows(rows) if row.get(column) not in (None, '')]
        return {'count': len(values), 'average': mean(values) if values else None}

    @reg.register('data', 'table_column_statistics', 'Numeric count, sum, mean, median and range',
                  {'rows': A('Rows'), 'column': S('Field')})
    def table_column_statistics(rows, column):
        values = [_number(row[column]) for row in _rows(rows) if row.get(column) not in (None, '')]
        return ({'count': 0, 'sum': 0, 'mean': None, 'min': None, 'max': None, 'median': None}
                if not values else {'count': len(values), 'sum': sum(values),
                                    'mean': mean(values), 'min': min(values),
                                    'max': max(values), 'median': median(values)})

    @reg.register('data', 'table_value_counts', 'Count occurrences of each value in a column',
                  {'rows': A('Rows'), 'column': S('Field'),
                   'limit': I('Results limit', False, 30, 1, 100)})
    def table_value_counts(rows, column, limit):
        counter = Counter(_scalar(r.get(column)) for r in _rows(rows))
        return [{'value': value, 'count': count} for value, count in counter.most_common(limit)]

    @reg.register('data', 'table_group_sum', 'Sum a numeric column grouped by a category',
                  {'rows': A('Rows'), 'group_by': S('Category field'),
                   'value_column': S('Numeric field')})
    def table_group_sum(rows, group_by, value_column):
        totals = defaultdict(float)
        for row in _rows(rows):
            if row.get(value_column) not in (None, ''):
                totals[_scalar(row.get(group_by))] += _number(row[value_column])
        return [{'group': k, 'sum': round(v, 8)} for k, v in sorted(totals.items())]

    @reg.register('data', 'table_group_count', 'Count records grouped by a categorical field',
                  {'rows': A('Rows'), 'column': S('Category field')})
    def table_group_count(rows, column):
        counter = Counter(_scalar(row.get(column)) for row in _rows(rows))
        return [{'group': k, 'count': v} for k, v in sorted(counter.items())]

    @reg.register('data', 'table_rename_column', 'Rename one field in every row without changing values',
                  {'rows': A('Rows'), 'before': S('Old name'), 'after': S('New name')})
    def table_rename_column(rows, before, after):
        if before == after:
            return _rows(rows)
        if any(after in row for row in rows):
            raise UtilityError('Destination field already exists')
        return [{after if k == before else k: v for k, v in row.items()} for row in _rows(rows)]

    @reg.register('data', 'table_fill_missing', 'Replace absent or null fields with a chosen value',
                  {'rows': A('Rows'), 'column': S('Field'),
                   'value': S('Replacement text')})
    def table_fill_missing(rows, column, value):
        return [{**row, column: row.get(column) if row.get(column) not in (None, '') else value}
                for row in _rows(rows)]

    @reg.register('data', 'table_add_constant', 'Add a fixed text field to every record',
                  {'rows': A('Rows'), 'column': S('New field name'),
                   'value': S('Assigned value')})
    def table_add_constant(rows, column, value):
        data = _rows(rows)
        if any(column in row for row in data):
            raise UtilityError('Field already exists')
        return [{**row, column: value} for row in data]

    @reg.register('data', 'table_drop_empty', 'Remove rows whose specified fields are all empty',
                  {'rows': A('Rows'), 'columns': A('Field names', min_length=1, max_length=40)})
    def table_drop_empty(rows, columns):
        return [row for row in _rows(rows) if any(row.get(c) not in (None, '') for c in columns)]

    @reg.register('data', 'table_pivot_counts', 'Count combinations of two categorical fields',
                  {'rows': A('Rows'), 'row_field': S('Rows'), 'column_field': S('Columns')})
    def table_pivot_counts(rows, row_field, column_field):
        data = _rows(rows)
        out = defaultdict(Counter)
        cols = set()
        for row in data:
            r, c = _scalar(row.get(row_field)), _scalar(row.get(column_field))
            out[r][c] += 1
            cols.add(c)
        if len(out) > 50 or len(cols) > 50:
            raise UtilityError('Pivot has too many categories')
        return {'columns': sorted(cols),
                'rows': [{'category': r, **{c: n.get(c, 0) for c in sorted(cols)}}
                         for r, n in sorted(out.items())]}

    @reg.register('data', 'table_join', 'Join two small tables on an exact string key',
                  {'left': A('Left table', max_length=200),
                   'right': A('Right table', max_length=200),
                   'key': S('Common join field')})
    def table_join(left, right, key):
        l, r = _rows(left, 200), _rows(right, 200)
        lookup = defaultdict(list)
        for row in r:
            lookup[_scalar(row.get(key))].append(row)
        result = []
        for row in l:
            for match in lookup.get(_scalar(row.get(key)), []):
                merged = dict(row)
                for col, val in match.items():
                    if col != key:
                        merged[col if col not in merged else 'right_' + col] = val
                result.append(merged)
                if len(result) > 500:
                    raise UtilityError('Join result contains too many rows')
        return result

    @reg.register('data', 'table_transpose', 'Transpose a small matrix of lists',
                  {'matrix': A('Rectangular matrix', max_length=100)})
    def table_transpose(matrix):
        if any(not isinstance(row, list) or len(row) > 100 for row in matrix):
            raise UtilityError('Expected a small matrix')
        if len({len(row) for row in matrix}) > 1:
            raise UtilityError('Matrix must be rectangular')
        return list(map(list, zip(*matrix))) if matrix else []

    @reg.register('data', 'table_cross_tab', 'Produce frequency counts for combinations of columns',
                  {'rows': A('Rows'), 'columns': A('Fields to group', min_length=1, max_length=5)})
    def table_cross_tab(rows, columns):
        if not all(isinstance(c, str) for c in columns):
            raise UtilityError('Column names must be strings')
        grouped = Counter(tuple(_scalar(row.get(c)) for c in columns) for row in _rows(rows))
        return [{**dict(zip(columns, group)), 'count': count}
                for group, count in grouped.most_common(200)]

    @reg.register('data', 'table_date_bucket', 'Group ISO date strings by month',
                  {'rows': A('Rows'), 'date_column': S('ISO date field')})
    def table_date_bucket(rows, date_column):
        counter = Counter()
        for row in _rows(rows):
            value = row.get(date_column)
            if value:
                try:
                    dt = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
                except ValueError as exc:
                    raise UtilityError('Every nonempty date must be ISO formatted') from exc
                counter[dt.strftime('%Y-%m')] += 1
        return [{'month': month, 'count': counter[month]} for month in sorted(counter)]
