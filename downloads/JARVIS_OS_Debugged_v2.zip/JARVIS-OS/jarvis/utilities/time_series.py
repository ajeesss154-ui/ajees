"""Small, explainable, local time-series and signal analysis utilities.

Functions operate on modest explicit numeric arrays. These are descriptive
methods, not market predictions, medical interpretations, or real-time feeds.
"""
from __future__ import annotations

from collections import Counter
import math
import statistics as stats
from typing import Any

from .core import UtilityError, UtilityRegistry, A, I, N, B


def _values(series: list, min_size: int = 1) -> list[float]:
    if not isinstance(series, list) or not min_size <= len(series) <= 500:
        raise UtilityError(f'Expected {min_size} to 500 numbers')
    if any(type(x) not in (int, float) or not math.isfinite(x) for x in series):
        raise UtilityError('Series must contain finite numbers')
    return [float(x) for x in series]


def _pair(a,b):
    x, y = _values(a), _values(b)
    if len(x) != len(y):
        raise UtilityError('Series lengths must agree')
    return x, y


def _moving_average(values, window):
    if not 1 <= window <= len(values):
        raise UtilityError('Invalid smoothing window')
    return [sum(values[i-window+1:i+1])/window for i in range(window-1, len(values))]


def _ema(values, span):
    if not 1 <= span <= len(values):
        raise UtilityError('Span must be between one and input length')
    alpha=2/(span+1)
    out=[values[0]]
    for value in values[1:]:
        out.append(alpha*value+(1-alpha)*out[-1])
    return out


def _autocorrelation(v, lag):
    if not 1 <= lag < len(v):
        raise UtilityError('Lag must be in range 1..n-1')
    center=stats.mean(v)
    numerator=sum((v[t]-center)*(v[t-lag]-center) for t in range(lag,len(v)))
    denominator=sum((x-center)**2 for x in v)
    return numerator/denominator if denominator else None


def _ols(x, y):
    mx,my=stats.mean(x),stats.mean(y)
    denominator=sum((a-mx)**2 for a in x)
    if denominator==0:
        raise UtilityError('X values need variation')
    slope=sum((a-mx)*(b-my) for a,b in zip(x,y))/denominator
    intercept=my-slope*mx
    return slope,intercept


def register(reg: UtilityRegistry) -> None:
    @reg.register('time_series','series_differences','Compute successive first differences',
                  {'values':A('Time-ordered numbers',min_length=2)})
    def series_differences(values):
        v=_values(values,2)
        return [b-a for a,b in zip(v,v[1:])]

    @reg.register('time_series','series_percent_change','Percentage growth from each observation to the next',
                  {'values':A('Time-ordered numbers',min_length=2)})
    def series_percent_change(values):
        v=_values(values,2)
        return [100*(b-a)/abs(a) if a else None for a,b in zip(v,v[1:])]

    @reg.register('time_series','series_cumulative_sum','Running total across observations',
                  {'values':A('Numbers',min_length=1)})
    def series_cumulative_sum(values):
        result=[]
        acc=0.
        for val in _values(values):
            acc+=val
            result.append(acc)
        return result

    @reg.register('time_series','series_cumulative_product','Running product across observations',
                  {'values':A('Numbers',min_length=1)})
    def series_cumulative_product(values):
        result=[]
        acc=1.
        for val in _values(values):
            acc*=val
            if not math.isfinite(acc) or abs(acc)>1e100:
                raise UtilityError('Running product is too large')
            result.append(acc)
        return result

    @reg.register('time_series','series_moving_average','Trailing simple moving average over a fixed window',
                  {'values':A('Observations',min_length=1),
                   'window':I('Window length',minimum=1,maximum=500)})
    def series_moving_average(values,window):
        return _moving_average(_values(values),window)

    @reg.register('time_series','series_exponential_average','Exponentially weighted moving average (EMA)',
                  {'values':A('Observations',min_length=1),
                   'span':I('Smoothing span',minimum=1,maximum=500)})
    def series_exponential_average(values,span):
        return _ema(_values(values),span)

    @reg.register('time_series','series_rolling_minimum','Minimum over each trailing observation window',
                  {'values':A('Observations',min_length=1),
                   'window':I('Window size',minimum=1,maximum=500)})
    def series_rolling_minimum(values,window):
        v=_values(values)
        if window>len(v):raise UtilityError('Window exceeds input length')
        return [min(v[i-window:i]) for i in range(window,len(v)+1)]

    @reg.register('time_series','series_rolling_maximum','Maximum over each trailing observation window',
                  {'values':A('Observations',min_length=1),
                   'window':I('Window size',minimum=1,maximum=500)})
    def series_rolling_maximum(values,window):
        v=_values(values)
        if window>len(v):raise UtilityError('Window exceeds input length')
        return [max(v[i-window:i]) for i in range(window,len(v)+1)]

    @reg.register('time_series','series_rolling_stddev','Sample standard deviation in each rolling window',
                  {'values':A('Observations',min_length=2),
                   'window':I('Window size',minimum=2,maximum=500)})
    def series_rolling_stddev(values,window):
        v=_values(values,2)
        if window>len(v):raise UtilityError('Window exceeds input length')
        return [stats.stdev(v[i-window:i]) for i in range(window,len(v)+1)]

    @reg.register('time_series','series_normalize_minmax','Scale finite observations to a 0..1 range',
                  {'values':A('Observations',min_length=1)})
    def series_normalize_minmax(values):
        v=_values(values)
        delta=max(v)-min(v)
        return [(x-min(v))/delta if delta else 0 for x in v]

    @reg.register('time_series','series_standardize','Transform observations into z-score units',
                  {'values':A('Observations',min_length=2)})
    def series_standardize(values):
        v=_values(values,2)
        mu=stats.mean(v)
        sigma=stats.pstdev(v)
        return [(x-mu)/sigma if sigma else 0 for x in v]

    @reg.register('time_series','series_linear_trend','Fit a least-squares time trend across equal intervals',
                  {'values':A('Observed series',min_length=2)})
    def series_linear_trend(values):
        v=_values(values,2)
        x=list(range(len(v)))
        slope,intercept=_ols(x,v)
        predicted=[slope*day+intercept for day in x]
        error=sum((a-b)**2 for a,b in zip(v,predicted))
        total=sum((a-stats.mean(v))**2 for a in v)
        return {'slope_per_step':slope,'intercept':intercept,
                'fitted':predicted,'r_squared':1-error/total if total else 1}

    @reg.register('time_series','series_detrend','Subtract the least-squares linear trend from a series',
                  {'values':A('Observed series',min_length=2)})
    def series_detrend(values):
        v=_values(values,2)
        slope,intercept=_ols(list(range(len(v))),v)
        return [value-(intercept+slope*index) for index,value in enumerate(v)]

    @reg.register('time_series','series_autocorrelation','Lagged autocorrelation of a time series',
                  {'values':A('Observations',min_length=2),
                   'lag':I('Positive lag',minimum=1,maximum=499)})
    def series_autocorrelation(values,lag):
        return _autocorrelation(_values(values,2),lag)

    @reg.register('time_series','series_lag_table','Autocorrelation values for a range of lags',
                  {'values':A('Observations',min_length=3),
                   'max_lag':I('Maximum lag',False,5,1,100)})
    def series_lag_table(values,max_lag):
        v=_values(values,3)
        if max_lag>=len(v):raise UtilityError('Maximum lag must be smaller than length')
        return [{'lag':lag,'correlation':_autocorrelation(v,lag)} for lag in range(1,max_lag+1)]

    @reg.register('time_series','series_cross_correlation','Pearson correlation of two aligned series',
                  {'first':A('First series',min_length=2),
                   'second':A('Second series',min_length=2)})
    def series_cross_correlation(first,second):
        a,b=_pair(first,second)
        if len(a)<2:raise UtilityError('Need at least two values')
        ma,mb=stats.mean(a),stats.mean(b)
        numerator=sum((x-ma)*(y-mb) for x,y in zip(a,b))
        denom=math.sqrt(sum((x-ma)**2 for x in a)*sum((y-mb)**2 for y in b))
        return numerator/denom if denom else None

    @reg.register('time_series','series_rebase','Rebase a series to an index value of 100',
                  {'values':A('Observations',min_length=1)})
    def series_rebase(values):
        v=_values(values)
        if v[0]==0:raise UtilityError('First value must be nonzero')
        return [100*x/v[0] for x in v]

    @reg.register('time_series','series_drawdown','Compute drop relative to running maximum, in percent',
                  {'values':A('Positive observed values',min_length=1)})
    def series_drawdown(values):
        v=_values(values)
        if any(x<=0 for x in v):raise UtilityError('Drawdown needs positive observations')
        peak=-math.inf
        result=[]
        for value in v:
            peak=max(peak,value)
            result.append(100*(value-peak)/peak)
        return result

    @reg.register('time_series','series_peak_trough','Return indices and values of min and max observations',
                  {'values':A('Observations',min_length=1)})
    def series_peak_trough(values):
        v=_values(values)
        return {'maximum':{'index':v.index(max(v)),'value':max(v)},
                'minimum':{'index':v.index(min(v)),'value':min(v)}}

    @reg.register('time_series','series_resample_chunks','Aggregate adjacent values into non-overlapping chunks',
                  {'values':A('Series',min_length=1),
                   'size':I('Observations per chunk',minimum=1,maximum=500),
                   'method':B('Use sum instead of mean',False,False)})
    def series_resample_chunks(values,size,method):
        v=_values(values)
        return [sum(v[i:i+size]) if method else stats.mean(v[i:i+size])
                for i in range(0,len(v),size)]

    @reg.register('time_series','series_momentum','Subtract observation from k steps earlier',
                  {'values':A('Series',min_length=2),
                   'period':I('Number of periods back',minimum=1,maximum=499)})
    def series_momentum(values,period):
        v=_values(values,2)
        if period>=len(v):raise UtilityError('Period exceeds series length')
        return [v[i]-v[i-period] for i in range(period,len(v))]

    @reg.register('time_series','series_forecast_linear','Extrapolate a fitted linear trend with explicit caveat',
                  {'values':A('Historical values',min_length=3),
                   'steps':I('Number of forecast steps',False,5,1,30)})
    def series_forecast_linear(values,steps):
        v=_values(values,3)
        slope,intercept=_ols(list(range(len(v))),v)
        return {'forecast':[intercept+slope*(len(v)+t) for t in range(steps)],
                'method':'naive linear extrapolation; not a reliable prediction'}

    @reg.register('time_series','series_forecast_last','Last-observation-carried-forward baseline forecast',
                  {'values':A('Historical data',min_length=1),
                   'steps':I('Future steps',False,5,1,30)})
    def series_forecast_last(values,steps):
        v=_values(values)
        return {'forecast':[v[-1]]*steps,'method':'naive constant baseline'}

    @reg.register('time_series','series_forecast_average','Constant-mean baseline forecast',
                  {'values':A('Historical data',min_length=1),
                   'steps':I('Steps ahead',False,5,1,30)})
    def series_forecast_average(values,steps):
        v=_values(values)
        return {'forecast':[stats.mean(v)]*steps,'method':'historical-mean baseline'}

    @reg.register('time_series','series_anomaly_zscore','Flag values exceeding a standard z-score threshold',
                  {'values':A('Observed values',min_length=3),
                   'threshold':N('Absolute z threshold',False,2.5,0.5,10)})
    def series_anomaly_zscore(values,threshold):
        v=_values(values,3)
        mean=stats.mean(v)
        std=stats.pstdev(v)
        if std==0:return []
        return [{'index':i,'value':x,'z_score':(x-mean)/std} for i,x in enumerate(v)
                if abs((x-mean)/std)>threshold]

    @reg.register('time_series','series_anomaly_iqr','Flag values outside the interquartile fence',
                  {'values':A('Observed values',min_length=4),
                   'multiplier':N('IQR multiplier',False,1.5,0.5,10)})
    def series_anomaly_iqr(values,multiplier):
        v=_values(values,4)
        low,q2,high=stats.quantiles(v,n=4,method='inclusive')
        iqr=high-low
        lower,upper=low-multiplier*iqr,high+multiplier*iqr
        return {'bounds':[lower,upper],
                'outliers':[{'index':i,'value':x} for i,x in enumerate(v) if x<lower or x>upper]}

    @reg.register('time_series','series_zero_crossings','Count crossings between negative and positive values',
                  {'values':A('Values',min_length=2)})
    def series_zero_crossings(values):
        v=_values(values,2)
        indices=[i for i in range(1,len(v)) if v[i-1]*v[i]<0]
        return {'count':len(indices),'indices':indices}

    @reg.register('time_series','series_run_lengths','Compute consecutive runs of equal categorical values',
                  {'values':A('Categorical sequence',min_length=1)})
    def series_run_lengths(values):
        result=[]
        for v in values:
            if isinstance(v,(list,dict)):
                raise UtilityError('Run-length values must be scalars')
            if result and result[-1]['value']==v:
                result[-1]['length']+=1
            else:
                result.append({'value':v,'length':1})
        return result

    @reg.register('time_series','series_centered_smoothing','Centered mean smoothing for an odd-width window',
                  {'values':A('Values',min_length=3),
                   'window':I('Odd window',False,3,3,99)})
    def series_centered_smoothing(values,window):
        v=_values(values,3)
        if window%2!=1 or window>len(v):
            raise UtilityError('Window must be odd and at most series length')
        half=window//2
        return [None]*half+[stats.mean(v[i-half:i+half+1])
                            for i in range(half,len(v)-half)]+[None]*half

    @reg.register('time_series','series_largest_changes','List the largest absolute changes between neighboring values',
                  {'values':A('Values',min_length=2),
                   'limit':I('Maximum changes',False,5,1,30)})
    def series_largest_changes(values,limit):
        v=_values(values,2)
        changes=[{'from_index':i,'to_index':i+1,'change':v[i+1]-v[i]}
                 for i in range(len(v)-1)]
        return sorted(changes,key=lambda item:abs(item['change']),reverse=True)[:limit]
