"""Descriptive statistics and small-dataset exploratory analysis.

No external datasets are downloaded. Correlation does not imply causation.
No statistical output should be presented as a medical diagnosis or guarantee.
"""
from __future__ import annotations

from collections import Counter
from itertools import combinations
import math
from statistics import mean,median,multimode
from typing import Any

from .core import UtilityRegistry,UtilityError,S,I,N,B,A,O


def _values(data:list,*,minimum:int=1,maximum:int=10000) -> list[float]:
    if not minimum<=len(data)<=maximum:raise UtilityError('Unsupported number of samples')
    if any(type(value) not in (float,int) or not math.isfinite(value) for value in data):
        raise UtilityError('Every sample must be a finite number')
    return [float(value) for value in data]


def _quantile(values:list[float],q:float) -> float:
    if not 0<=q<=1:raise UtilityError('Quantile must be between 0 and 1')
    data=sorted(values)
    if len(data)==1:return data[0]
    position=q*(len(data)-1)
    low=math.floor(position);high=math.ceil(position)
    return data[low]*(high-position)+data[high]*(position-low) if high!=low else data[low]


def _variance(values:list[float],sample:bool) -> float:
    if sample and len(values)<2:raise UtilityError('Sample variance requires 2+ values')
    avg=mean(values)
    return sum((x-avg)**2 for x in values)/(len(values)-(1 if sample else 0))


def _pearson(x:list[float],y:list[float]) -> float:
    if len(x)!=len(y) or len(x)<2:raise UtilityError('Paired series need equal lengths of 2+')
    mean_x,mean_y=mean(x),mean(y)
    a=[v-mean_x for v in x];b=[v-mean_y for v in y]
    denominator=math.sqrt(sum(v*v for v in a)*sum(v*v for v in b))
    if not denominator:raise UtilityError('Correlation undefined for constant series')
    return sum(i*j for i,j in zip(a,b))/denominator


def _ranks(values:list[float]) -> list[float]:
    """Average ranks for ties, starting at 1."""
    order=sorted(enumerate(values),key=lambda item:item[1])
    ranks=[0.0]*len(values)
    i=0
    while i<len(order):
        j=i+1
        while j<len(order) and order[j][1]==order[i][1]:j+=1
        rank=(i+1+j)/2
        for k in range(i,j):ranks[order[k][0]]=rank
        i=j
    return ranks


def _linear_regression(x:list[float],y:list[float]) -> tuple[float,float,float]:
    if len(x)!=len(y) or len(x)<2:raise UtilityError('Need paired observations')
    mx,my=mean(x),mean(y)
    xx=sum((v-mx)**2 for v in x)
    if xx==0:raise UtilityError('All x values are the same')
    slope=sum((a-mx)*(b-my) for a,b in zip(x,y))/xx
    intercept=my-slope*mx
    try:r=_pearson(x,y)
    except UtilityError:r=0.0
    return slope,intercept,r*r


def register(reg:UtilityRegistry) -> None:
    @reg.register('statistics','mean_median_mode','Calculate mean median and modes',
                  {'values':A('Numeric samples',min_length=1,max_length=5000)})
    def mean_median_mode(values):
        x=_values(values)
        return {'count':len(x),'mean':mean(x),'median':median(x),
                'modes':multimode(x)[:50],'min':min(x),'max':max(x)}

    @reg.register('statistics','variance','Sample or population variance and standard deviation',
                  {'values':A('Numeric samples',min_length=1,max_length=5000),
                   'sample':B('Use sample n-1 denominator',False,True)})
    def variance(values,sample):
        x=_values(values)
        var=_variance(x,sample)
        return {'variance':var,'standard_deviation':math.sqrt(var),'sample':sample}

    @reg.register('statistics','quantile','Find a linearly interpolated quantile',
                  {'values':A('Numeric samples',min_length=1,max_length=5000),
                   'quantile':N('Fraction between 0 and 1',minimum=0,maximum=1)})
    def quantile(values,quantile):
        return {'quantile':quantile,'value':_quantile(_values(values),quantile)}

    @reg.register('statistics','five_number_summary','Find minimum quartiles median and maximum',
                  {'values':A('Numeric samples',min_length=1,max_length=5000)})
    def five_number_summary(values):
        x=_values(values)
        return {'min':min(x),'q1':_quantile(x,.25),'median':median(x),
                'q3':_quantile(x,.75),'max':max(x)}

    @reg.register('statistics','interquartile_range','Calculate IQR and Tukey outlier fences',
                  {'values':A('Numeric samples',min_length=2,max_length=5000)})
    def interquartile_range(values):
        x=_values(values,minimum=2)
        q1,q3=_quantile(x,.25),_quantile(x,.75)
        iqr=q3-q1
        lower,upper=q1-1.5*iqr,q3+1.5*iqr
        return {'iqr':iqr,'lower_fence':lower,'upper_fence':upper,
                'outliers':[v for v in x if v<lower or v>upper][:200]}

    @reg.register('statistics','z_scores','Standardize samples using population deviation',
                  {'values':A('Numeric samples',min_length=2,max_length=2000)})
    def z_scores(values):
        x=_values(values,minimum=2)
        avg=mean(x);sd=math.sqrt(_variance(x,False))
        if sd==0:raise UtilityError('All values are constant')
        return [round((value-avg)/sd,6) for value in x]

    @reg.register('statistics','standard_error','Compute standard error of sample mean',
                  {'values':A('Numeric samples',min_length=2,max_length=5000)})
    def standard_error(values):
        x=_values(values,minimum=2)
        return math.sqrt(_variance(x,True)/len(x))

    @reg.register('statistics','pearson_correlation','Compute Pearson linear correlation for paired data',
                  {'first':A('First numeric series',min_length=2,max_length=5000),
                   'second':A('Second numeric series',min_length=2,max_length=5000)})
    def pearson_correlation(first,second):
        return {'r':round(_pearson(_values(first),_values(second)),6),
                'note':'Correlation describes association, not causation.'}

    @reg.register('statistics','spearman_correlation','Compute Spearman rank correlation with tie averaging',
                  {'first':A('First numeric series',min_length=2,max_length=5000),
                   'second':A('Second numeric series',min_length=2,max_length=5000)})
    def spearman_correlation(first,second):
        x,y=_values(first),_values(second)
        return {'rho':round(_pearson(_ranks(x),_ranks(y)),6)}

    @reg.register('statistics','linear_regression','Fit least-squares slope and intercept for simple regression',
                  {'x':A('Numeric x series',min_length=2,max_length=5000),
                   'y':A('Numeric y series',min_length=2,max_length=5000)})
    def linear_regression(x,y):
        slope,intercept,r2=_linear_regression(_values(x),_values(y))
        return {'slope':slope,'intercept':intercept,'r_squared':r2}

    @reg.register('statistics','regression_predict','Predict y using fitted line from paired training data',
                  {'x':A('Training x series',min_length=2,max_length=5000),
                   'y':A('Training y series',min_length=2,max_length=5000),
                   'predict_x':N('New x')})
    def regression_predict(x,y,predict_x):
        slope,intercept,r2=_linear_regression(_values(x),_values(y))
        return {'predicted_y':slope*predict_x+intercept,
                'r_squared':r2,'extrapolation_warning':predict_x<min(x) or predict_x>max(x)}

    @reg.register('statistics','moving_average','Compute sliding simple moving averages',
                  {'values':A('Numeric time series',min_length=1,max_length=5000),
                   'window':I('Number of samples per window',minimum=1,maximum=1000)})
    def moving_average(values,window):
        x=_values(values)
        if window>len(x):raise UtilityError('Window exceeds series length')
        output=[];total=sum(x[:window]);output.append(total/window)
        for i in range(window,len(x)):
            total+=x[i]-x[i-window]
            output.append(total/window)
        return {'window':window,'values':[round(v,6) for v in output]}

    @reg.register('statistics','exponential_moving_average','Compute exponential weighted moving average',
                  {'values':A('Numeric time series',min_length=1,max_length=5000),
                   'alpha':N('Smoothing constant',minimum=.00001,maximum=1)})
    def exponential_moving_average(values,alpha):
        x=_values(values)
        result=[x[0]]
        for value in x[1:]:result.append(alpha*value+(1-alpha)*result[-1])
        return [round(v,6) for v in result]

    @reg.register('statistics','cumulative_sum','Calculate running totals for a numeric list',
                  {'values':A('Numeric values',min_length=1,max_length=5000)})
    def cumulative_sum(values):
        x=_values(values);answer=[];running=0.0
        for value in x:running+=value;answer.append(round(running,8))
        return answer

    @reg.register('statistics','cumulative_product','Calculate bounded running products',
                  {'values':A('Numeric values',min_length=1,max_length=500)})
    def cumulative_product(values):
        x=_values(values);answer=[];product=1.0
        for value in x:
            product*=value
            if not math.isfinite(product) or abs(product)>1e15:
                raise UtilityError('Running product exceeds safe range')
            answer.append(product)
        return answer

    @reg.register('statistics','histogram','Build a fixed-width histogram for numeric data',
                  {'values':A('Numeric samples',min_length=1,max_length=5000),
                   'bins':I('Bin count',False,10,1,100)})
    def histogram(values,bins):
        x=_values(values);minimum=min(x);maximum=max(x)
        if minimum==maximum:return {'edges':[minimum,maximum],'counts':[len(x)]}
        width=(maximum-minimum)/bins
        counts=[0]*bins
        for value in x:
            idx=min(int((value-minimum)/width),bins-1)
            counts[idx]+=1
        return {'edges':[round(minimum+i*width,8) for i in range(bins+1)],
                'counts':counts}

    @reg.register('statistics','frequency_table','Count occurrences of categorical labels',
                  {'values':A('Categories or labels',min_length=1,max_length=3000)})
    def frequency_table(values):
        if any(type(v) not in (str,int,float,bool) for v in values):
            raise UtilityError('Only primitive category values supported')
        counts=Counter(map(str,values))
        return [{'value':name,'count':cnt,'percent':round(100*cnt/len(values),2)}
                for name,cnt in counts.most_common(300)]

    @reg.register('statistics','population_range','Get count min max span and mean from numeric data',
                  {'values':A('Numeric samples',min_length=1,max_length=5000)})
    def population_range(values):
        x=_values(values)
        return {'count':len(x),'minimum':min(x),'maximum':max(x),
                'range':max(x)-min(x),'mean':mean(x)}

    @reg.register('statistics','mean_absolute_deviation','Compute average absolute deviation around the mean',
                  {'values':A('Numeric samples',min_length=1,max_length=5000)})
    def mean_absolute_deviation(values):
        x=_values(values)
        avg=mean(x)
        return sum(abs(value-avg) for value in x)/len(x)

    @reg.register('statistics','median_absolute_deviation','Compute median absolute deviation from sample median',
                  {'values':A('Numeric samples',min_length=1,max_length=5000)})
    def median_absolute_deviation(values):
        x=_values(values);middle=median(x)
        return median([abs(value-middle) for value in x])

    @reg.register('statistics','coefficient_of_variation','Compute standard deviation relative to mean',
                  {'values':A('Numeric samples',min_length=2,max_length=5000)})
    def coefficient_of_variation(values):
        x=_values(values,minimum=2)
        avg=mean(x)
        if avg==0:raise UtilityError('Mean is zero')
        return {'percent':round(math.sqrt(_variance(x,True))/abs(avg)*100,5)}

    @reg.register('statistics','normalize_minmax','Map a numeric series to a selected range',
                  {'values':A('Numeric samples',min_length=1,max_length=5000),
                   'lower':N('Target lower bound',False,0),
                   'upper':N('Target upper bound',False,1)})
    def normalize_minmax(values,lower,upper):
        x=_values(values)
        if upper<lower:raise UtilityError('Upper bound must be >= lower')
        a,b=min(x),max(x)
        if a==b:return [lower]*len(x)
        return [round(lower+(v-a)/(b-a)*(upper-lower),6) for v in x]

    @reg.register('statistics','geometric_mean','Calculate geometric mean for positive values',
                  {'values':A('Positive numbers',min_length=1,max_length=5000)})
    def geometric_mean(values):
        x=_values(values)
        if any(v<=0 for v in x):raise UtilityError('Geometric mean requires positive values')
        return math.exp(sum(math.log(v) for v in x)/len(x))

    @reg.register('statistics','harmonic_mean','Calculate harmonic mean for positive values',
                  {'values':A('Positive numbers',min_length=1,max_length=5000)})
    def harmonic_mean(values):
        x=_values(values)
        if any(v<=0 for v in x):raise UtilityError('Harmonic mean requires positive values')
        return len(x)/sum(1/v for v in x)

    @reg.register('statistics','root_mean_square','Calculate root-mean-square of numeric values',
                  {'values':A('Numbers',min_length=1,max_length=5000)})
    def root_mean_square(values):
        x=_values(values)
        return math.sqrt(sum(v*v for v in x)/len(x))

    @reg.register('statistics','covariance','Compute sample or population covariance',
                  {'first':A('Numeric series',min_length=2,max_length=5000),
                   'second':A('Paired numeric series',min_length=2,max_length=5000),
                   'sample':B('Sample covariance',False,True)})
    def covariance(first,second,sample):
        x,y=_values(first,minimum=2),_values(second,minimum=2)
        if len(x)!=len(y):raise UtilityError('Series must have equal lengths')
        return sum((a-mean(x))*(b-mean(y)) for a,b in zip(x,y))/(len(x)-(1 if sample else 0))

    @reg.register('statistics','percentile_rank','Percent of observations less than or equal to a given value',
                  {'values':A('Numeric samples',min_length=1,max_length=5000),
                   'value':N('Value to compare')})
    def percentile_rank(values,value):
        x=_values(values)
        return round(100*sum(item<=value for item in x)/len(x),4)

    @reg.register('statistics','correlation_matrix','Compute correlations among several same-length series',
                  {'series':A('List of numeric series',min_length=2,max_length=25)})
    def correlation_matrix(series):
        data=[_values(s,minimum=2,maximum=5000) for s in series]
        if len(set(map(len,data)))!=1:raise UtilityError('All series must have the same length')
        matrix=[]
        for row in data:
            line=[]
            for column in data:
                try:r=_pearson(row,column)
                except UtilityError:r=None
                line.append(round(r,5) if r is not None else None)
            matrix.append(line)
        return matrix

    @reg.register('statistics','value_growth_rate','Compute growth rates between consecutive measurements',
                  {'values':A('Numeric series',min_length=2,max_length=5000)})
    def value_growth_rate(values):
        x=_values(values,minimum=2)
        return [None if x[i-1]==0 else round((x[i]-x[i-1])/abs(x[i-1])*100,5)
                for i in range(1,len(x))]

    @reg.register('statistics','percent_of_total','Calculate percent share for each nonnegative contribution',
                  {'values':A('Nonnegative numeric values',min_length=1,max_length=5000)})
    def percent_of_total(values):
        x=_values(values)
        if any(v<0 for v in x) or sum(x)==0:raise UtilityError('Provide nonnegative values with a nonzero sum')
        total=sum(x)
        return [round(100*v/total,4) for v in x]
