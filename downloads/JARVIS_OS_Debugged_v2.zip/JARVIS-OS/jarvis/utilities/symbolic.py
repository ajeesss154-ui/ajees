"""Safe, bounded symbolic algebra with an optional SymPy backend.

Submitted expressions are parsed using Python's standard AST and converted
node by node to known mathematical functions. No eval, compile, arbitrary
SymPy parser context, attribute access, or arbitrary code execution is allowed.
This is a learning aid and not a formal proof engine.
"""
from __future__ import annotations

import ast
import math
import operator
from typing import Any

from .core import UtilityError, UtilityRegistry, S, I, N, A


_NAMES=('x','y','z','t','a','b','c','pi','E')
_FUNCTIONS=('sin','cos','tan','asin','acos','atan','sinh','cosh','tanh',
            'log','ln','exp','sqrt','abs')


def _sympy():
    try:
        import sympy as sp
        return sp
    except ImportError as exc:
        raise UtilityError('Symbolic tools need the optional SymPy package: pip install sympy') from exc


def _parse(expression: str, vars=('x',)):
    sp=_sympy()
    if not isinstance(expression,str) or len(expression)>500 or not expression.strip():
        raise UtilityError('Expression must be nonempty and at most 500 characters')
    source=expression.replace('^','**')
    try:
        tree=ast.parse(source,mode='eval')
    except SyntaxError as exc:
        raise UtilityError('Invalid mathematical expression') from exc
    all_nodes=list(ast.walk(tree))
    if len(all_nodes)>180:
        raise UtilityError('Mathematical expression is too complex')
    symbols={name:sp.Symbol(name, real=True) for name in ('x','y','z','t','a','b','c')}
    constants={'pi':sp.pi,'E':sp.E}
    functions={'sin':sp.sin,'cos':sp.cos,'tan':sp.tan,
               'asin':sp.asin,'acos':sp.acos,'atan':sp.atan,
               'sinh':sp.sinh,'cosh':sp.cosh,'tanh':sp.tanh,
               'log':sp.log,'ln':sp.log,'exp':sp.exp,'sqrt':sp.sqrt,
               'abs':sp.Abs}
    binops={ast.Add:operator.add,ast.Sub:operator.sub,
            ast.Mult:operator.mul,ast.Div:operator.truediv,
            ast.Pow:operator.pow}
    def walk(node,depth=0):
        if depth>22:
            raise UtilityError('Expression nesting is too deep')
        if isinstance(node,ast.Expression):
            return walk(node.body,depth+1)
        if isinstance(node,ast.Constant) and type(node.value) in (int,float):
            if not math.isfinite(node.value) or abs(node.value)>10000:
                raise UtilityError('Constants must be finite and within range')
            return sp.Integer(node.value) if type(node.value) is int else sp.Float(node.value)
        if isinstance(node,ast.Name):
            if node.id in symbols:
                return symbols[node.id]
            if node.id in constants:
                return constants[node.id]
            raise UtilityError('Unknown symbol: '+node.id[:80])
        if isinstance(node,ast.UnaryOp) and isinstance(node.op,(ast.UAdd,ast.USub)):
            value=walk(node.operand,depth+1)
            return value if isinstance(node.op,ast.UAdd) else -value
        if isinstance(node,ast.BinOp) and type(node.op) in binops:
            if isinstance(node.op,ast.Pow):
                # Require small integer or half-integer numeric exponents.
                expnode=node.right
                if isinstance(expnode,ast.UnaryOp):
                    raise UtilityError('Use a nonnegative bounded power, or reciprocal')
                if not isinstance(expnode,ast.Constant) or type(expnode.value) not in (int,float):
                    raise UtilityError('Power must be a small numeric literal')
                if not -10 <= expnode.value <= 10:
                    raise UtilityError('Power must be between -10 and 10')
            lhs=walk(node.left,depth+1)
            rhs=walk(node.right,depth+1)
            return binops[type(node.op)](lhs,rhs)
        if isinstance(node,ast.Call) and isinstance(node.func,ast.Name):
            if node.func.id not in functions or len(node.args)!=1 or node.keywords:
                raise UtilityError('Only allowlisted single-argument math functions are supported')
            return functions[node.func.id](walk(node.args[0],depth+1))
        raise UtilityError('Only numbers, symbols and mathematical operators are allowed')
    result=walk(tree)
    if not result.free_symbols.issubset(set(symbols.values())):
        raise UtilityError('Unsupported symbol')
    if len(str(result))>2500:
        raise UtilityError('Expression expanded beyond size limit')
    return sp,result,symbols


def _plain(result) -> str:
    text=str(result)
    if len(text)>10000:
        raise UtilityError('Result exceeds maximum length')
    return text


def _variable(name,symbols):
    if name not in symbols:
        raise UtilityError('Variable must be x, y, z, t, a, b or c')
    return symbols[name]


def register(reg:UtilityRegistry) -> None:
    @reg.register('symbolic','math_simplify','Simplify an algebraic expression using optional SymPy',
                  {'expression':S('Expression using x, sin(x), x**2, etc.',max_length=500)})
    def math_simplify(expression):
        sp,expr,_=_parse(expression)
        return {'original':_plain(expr),'simplified':_plain(sp.simplify(expr))}

    @reg.register('symbolic','math_expand','Expand products and integer powers',
                  {'expression':S('Algebraic expression',max_length=500)})
    def math_expand(expression):
        sp,expr,_=_parse(expression)
        return _plain(sp.expand(expr))

    @reg.register('symbolic','math_factor','Factor a bounded polynomial expression',
                  {'expression':S('Polynomial to factor',max_length=500)})
    def math_factor(expression):
        sp,expr,_=_parse(expression)
        if not expr.is_polynomial():
            raise UtilityError('Factoring supports polynomials only')
        if len(expr.free_symbols)>2:
            raise UtilityError('At most two variables supported for factoring')
        return _plain(sp.factor(expr))

    @reg.register('symbolic','math_derivative','Compute a first or higher-order derivative',
                  {'expression':S('Function, e.g. (x**2+3)**2',max_length=500),
                   'variable':S('Differentiate with respect to',False,'x',choices=('x','y','z','t')),
                   'order':I('Derivative order',False,1,1,5)})
    def math_derivative(expression,variable,order):
        sp,expr,names=_parse(expression)
        result=sp.diff(expr,names[variable],order)
        return {'expression':_plain(expr),'variable':variable,'order':order,
                'derivative':_plain(sp.simplify(result)),
                'notation':f'd^{order}/d{variable}^{order}',
                'note':'Symbolic result; ask the conversational assistant for a step-by-step explanation.'}

    @reg.register('symbolic','math_indefinite_integral','Compute a simple symbolic indefinite integral',
                  {'expression':S('Integrand',max_length=300),
                   'variable':S('Integrating variable',False,'x',choices=('x','y','z','t'))})
    def math_indefinite_integral(expression,variable):
        sp,expr,names=_parse(expression)
        if len(str(expr))>300:
            raise UtilityError('Integrand too complex')
        answer=sp.integrate(expr,names[variable],risch=True)
        if answer.has(sp.Integral):
            return {'integral':None,'message':'No elementary result found by the restricted integrator'}
        return {'integral':_plain(answer)+' + C', 'variable':variable}

    @reg.register('symbolic','math_definite_integral','Compute a definite integral over a bounded numeric interval',
                  {'expression':S('Integrand',max_length=300),
                   'lower':N('Lower limit',minimum=-1000,maximum=1000),
                   'upper':N('Upper limit',minimum=-1000,maximum=1000)})
    def math_definite_integral(expression,lower,upper):
        sp,expr,names=_parse(expression)
        if not expr.free_symbols.issubset({names['x']}):
            raise UtilityError('Integral must use x only')
        answer=sp.integrate(expr,(names['x'],lower,upper))
        if answer.has(sp.Integral):
            return {'result':None,'message':'Could not calculate a closed-form result'}
        return {'exact':_plain(answer),'decimal':float(answer.evalf(10)) if answer.is_real else None}

    @reg.register('symbolic','math_solve_polynomial','Solve a univariate polynomial equation expression = 0',
                  {'expression':S('Polynomial expression',max_length=300),
                   'variable':S('Unknown variable',False,'x',choices=('x','y','z','t'))})
    def math_solve_polynomial(expression,variable):
        sp,expr,names=_parse(expression)
        x=names[variable]
        if not expr.is_polynomial(x) or not expr.free_symbols.issubset({x}):
            raise UtilityError('Provide a single-variable polynomial')
        poly=sp.Poly(expr,x)
        if poly.is_zero:
            return {'roots':['all real numbers'], 'approximate':[], 'degree':None}
        if poly.degree()>5:
            raise UtilityError('Maximum supported polynomial degree is five')
        values=sp.solve(poly.as_expr(),x)
        return {'roots':[_plain(v) for v in values],
                'approximate':[str(v.evalf(9)) for v in values],
                'degree':int(poly.degree())}

    @reg.register('symbolic','math_evaluate','Substitute one numeric variable and evaluate expression',
                  {'expression':S('Expression',max_length=500),
                   'variable':S('Variable',False,'x',choices=('x','y','z','t')),
                   'value':N('Substitution value',minimum=-10000,maximum=10000)})
    def math_evaluate(expression,variable,value):
        sp,expr,names=_parse(expression)
        x=_variable(variable,names)
        answer=expr.subs(x,value)
        if answer.free_symbols:
            raise UtilityError('Other variables remain; provide one-variable expression')
        numeric=complex(answer.evalf(10))
        if not math.isfinite(numeric.real) or not math.isfinite(numeric.imag):
            raise UtilityError('Result is not finite')
        return {'exact':_plain(answer), 'real':numeric.real,'imaginary':numeric.imag}

    @reg.register('symbolic','math_limit','Calculate a univariate one-sided or two-sided limit',
                  {'expression':S('Expression',max_length=250),
                   'point':N('Value x approaches',minimum=-1000,maximum=1000),
                   'direction':S('Approach direction',False,'both',choices=('left','right','both'))})
    def math_limit(expression,point,direction):
        sp,expr,names=_parse(expression)
        if not expr.free_symbols.issubset({names['x']}):
            raise UtilityError('Limit must involve x only')
        mark={'left':'-','right':'+'}.get(direction)
        if direction=='both':
            left=sp.limit(expr,names['x'],point,dir='-')
            right=sp.limit(expr,names['x'],point,dir='+')
            return {'exists':left==right,'left':_plain(left),'right':_plain(right),
                    'limit':_plain(left) if left==right else None}
        return {'limit':_plain(sp.limit(expr,names['x'],point,dir=mark)), 'direction':direction}

    @reg.register('symbolic','math_taylor_series','Compute a truncated Taylor series at zero or another point',
                  {'expression':S('Expression',max_length=250),
                   'point':N('Expansion point',False,0,-20,20),
                   'order':I('Terms through order n-1',False,5,1,10)})
    def math_taylor_series(expression,point,order):
        sp,expr,names=_parse(expression)
        if not expr.free_symbols.issubset({names['x']}):
            raise UtilityError('Series must contain only x')
        result=sp.series(expr,names['x'],point,order)
        return {'series':_plain(result),'polynomial':_plain(result.removeO())}

    @reg.register('symbolic','math_partial_derivative','Compute a multivariable partial derivative',
                  {'expression':S('Expression in x, y or z',max_length=300),
                   'variable':S('Partial derivative variable',choices=('x','y','z'))})
    def math_partial_derivative(expression,variable):
        sp,expr,names=_parse(expression)
        return _plain(sp.diff(expr,names[variable]))

    @reg.register('symbolic','math_gradient','Calculate gradient of a scalar function in up to three variables',
                  {'expression':S('Expression in x, y, z',max_length=300),
                   'variables':A('Variable names in order',False,['x','y'],min_length=1,max_length=3)})
    def math_gradient(expression,variables):
        sp,expr,names=_parse(expression)
        if any(v not in ('x','y','z') for v in variables):
            raise UtilityError('Only x, y and z supported')
        return {v:_plain(sp.diff(expr,names[v])) for v in variables}

    @reg.register('symbolic','math_hessian','Compute the Hessian matrix of a scalar function',
                  {'expression':S('Expression',max_length=300),
                   'variables':A('Variables',False,['x','y'],min_length=1,max_length=3)})
    def math_hessian(expression,variables):
        sp,expr,names=_parse(expression)
        if any(v not in ('x','y','z') for v in variables):
            raise UtilityError('Only x, y, z supported')
        return [[_plain(sp.diff(expr,names[v],names[w])) for w in variables]
                for v in variables]

    @reg.register('symbolic','math_substitute','Replace one symbol with a number',
                  {'expression':S('Expression',max_length=300),
                   'variable':S('Symbol',choices=('x','y','z','t','a','b','c')),
                   'value':N('Numeric replacement',minimum=-10000,maximum=10000)})
    def math_substitute(expression,variable,value):
        sp,expr,names=_parse(expression)
        return _plain(expr.subs(names[variable],value))

    @reg.register('symbolic','math_polynomial_coefficients','Extract polynomial coefficients from highest to lowest degree',
                  {'expression':S('Polynomial',max_length=300),
                   'variable':S('Variable',False,'x',choices=('x','y','z','t'))})
    def math_polynomial_coefficients(expression,variable):
        sp,expr,names=_parse(expression)
        x=names[variable]
        if not expr.is_polynomial(x) or not expr.free_symbols.issubset({x}):
            raise UtilityError('Expression must be a single-variable polynomial')
        poly=sp.Poly(expr,x)
        if poly.is_zero:
            return {'degree':None,'coefficients':['0']}
        if poly.degree()>20:raise UtilityError('Polynomial degree too high')
        return {'degree':int(poly.degree()),'coefficients':[_plain(c) for c in poly.all_coeffs()]}

    @reg.register('symbolic','math_numeric_derivative','Estimate derivative using centered finite differences',
                  {'expression':S('Function of x',max_length=300),
                   'at':N('Point',minimum=-10000,maximum=10000),
                   'step':N('Finite difference step',False,0.0001,1e-7,0.1)})
    def math_numeric_derivative(expression,at,step):
        sp,expr,names=_parse(expression)
        if not expr.free_symbols.issubset({names['x']}):
            raise UtilityError('Function must use x only')
        fn=sp.lambdify(names['x'],expr,modules=['math'])
        try:
            estimate=(fn(at+step)-fn(at-step))/(2*step)
        except (ValueError,ZeroDivisionError,OverflowError) as exc:
            raise UtilityError('Numerical derivative could not be evaluated') from exc
        if not math.isfinite(estimate):
            raise UtilityError('Derivative is not finite')
        return {'approximation':estimate,'step':step,
                'note':'Numerical approximation; accuracy depends on the step and function'}
