"""Robust arithmetic helpers for education, budgets and everyday quantities."""
from __future__ import annotations

from decimal import Decimal,ROUND_HALF_UP,getcontext
from fractions import Fraction
import math
from math import gcd
from functools import reduce
from typing import Any

from .core import UtilityRegistry, UtilityError, S,I,N,B,A,O


def _numeric_sequence(values:list,*,minimum:int=1,maximum:int=5000) -> list[float]:
    if not minimum<=len(values)<=maximum:raise UtilityError('Invalid number of values')
    if any(type(x) not in (int,float) or not math.isfinite(float(x)) for x in values):
        raise UtilityError('All values must be finite numbers')
    return [float(x) for x in values]


def _decimal(value:Any) -> Decimal:
    if type(value) not in (float,int,str):raise UtilityError('Invalid decimal number')
    try:
        d=Decimal(str(value))
    except Exception as exc:raise UtilityError('Invalid decimal number') from exc
    if not d.is_finite():raise UtilityError('Number must be finite')
    return d


def register(reg:UtilityRegistry) -> None:
    @reg.register('numbers','percent_of','Calculate a percentage of any positive or negative number',
                  {'part':N('The percentage'),'whole':N('The amount')},
                  ('20 percent of 450',))
    def percent_of(part,whole):
        return round(whole*part/100,8)

    @reg.register('numbers','percent_change','Calculate the relative percentage change',
                  {'before':N('Original value'),'after':N('Updated value')})
    def percent_change(before,after):
        if before==0:raise UtilityError('Original value must be nonzero')
        return {'change_percent':round((after-before)/abs(before)*100,5),
                'direction':'increase' if after>before else 'decrease' if after<before else 'unchanged'}

    @reg.register('numbers','percentage_difference','Compare two measurements symmetrically',
                  {'first':N('First amount'),'second':N('Second amount')})
    def percentage_difference(first,second):
        denominator=(abs(first)+abs(second))/2
        return round(100*abs(first-second)/denominator,5) if denominator else 0.0

    @reg.register('numbers','simple_interest','Calculate non-compound interest, not investment advice',
                  {'principal':N('Initial principal',minimum=0),
                   'annual_percent':N('Annual interest percentage'),
                   'years':N('Number of years',minimum=0)})
    def simple_interest(principal,annual_percent,years):
        interest=principal*annual_percent/100*years
        return {'interest':round(interest,2),'final':round(principal+interest,2)}

    @reg.register('numbers','compound_growth','Compute compounded hypothetical growth',
                  {'principal':N('Initial value',minimum=0),
                   'annual_percent':N('Annual growth rate'),
                   'years':N('Years',minimum=0,maximum=100),
                   'periods':I('Compounding periods per year',False,12,1,365)})
    def compound_growth(principal,annual_percent,years,periods):
        base=1+annual_percent/100/periods
        if base<0:raise UtilityError('Rate too negative for compounding formula')
        result=principal*base**(periods*years)
        if not math.isfinite(result) or result>1e15:
            raise UtilityError('Result exceeds supported range')
        return {'final':round(result,2),'change':round(result-principal,2)}

    @reg.register('numbers','equal_split','Divide a bill or quantity equally',
                  {'total':N('Total amount'),'people':I('Number of people',minimum=1,maximum=10000)})
    def equal_split(total,people):
        share=_decimal(total)/people
        return {'share':float(share.quantize(Decimal('.01'),rounding=ROUND_HALF_UP)),
                'exact_share':str(share)}

    @reg.register('numbers','discount_price','Apply a discount percentage',
                  {'original':N('Original price',minimum=0),
                   'discount_percent':N('Discount',minimum=0,maximum=100)})
    def discount_price(original,discount_percent):
        savings=original*discount_percent/100
        return {'final':round(original-savings,2),'savings':round(savings,2)}

    @reg.register('numbers','tax_addition','Add a percentage-based tax as a mathematical operation',
                  {'subtotal':N('Subtotal',minimum=0),
                   'tax_percent':N('Tax rate',minimum=0,maximum=100)})
    def tax_addition(subtotal,tax_percent):
        tax=subtotal*tax_percent/100
        return {'tax':round(tax,2),'total':round(subtotal+tax,2)}

    @reg.register('numbers','tip_calculator','Calculate a total with a user-chosen gratuity',
                  {'bill':N('Bill amount',minimum=0),
                   'tip_percent':N('Tip percentage',minimum=0,maximum=100),
                   'people':I('People sharing the bill',False,1,1,10000)})
    def tip_calculator(bill,tip_percent,people):
        tip=bill*tip_percent/100
        total=bill+tip
        return {'tip':round(tip,2),'total':round(total,2),'per_person':round(total/people,2)}

    @reg.register('numbers','ratio_simplify','Reduce an integer ratio using the greatest common divisor',
                  {'a':I('First integer'),'b':I('Second integer')})
    def ratio_simplify(a,b):
        if not a and not b:raise UtilityError('0:0 is undefined')
        divisor=gcd(a,b)
        return {'a':a//divisor,'b':b//divisor,'label':f'{a//divisor}:{b//divisor}'}

    @reg.register('numbers','fraction_operations','Add, subtract, multiply or divide two rational numbers',
                  {'left':S('First fraction, e.g. 3/4'),'right':S('Second fraction, e.g. 1/2'),
                   'operation':S('Operation',choices=('add','subtract','multiply','divide'))})
    def fraction_operations(left,right,operation):
        try:
            x,y=Fraction(left),Fraction(right)
        except (ValueError,ZeroDivisionError) as exc:raise UtilityError('Invalid fraction') from exc
        if operation=='add':answer=x+y
        elif operation=='subtract':answer=x-y
        elif operation=='multiply':answer=x*y
        else:
            if not y:raise UtilityError('Cannot divide by zero')
            answer=x/y
        return {'fraction':str(answer),'decimal':float(answer)}

    @reg.register('numbers','gcd_lcm','Compute the greatest common divisor and least common multiple',
                  {'values':A('Integer values',min_length=2,max_length=100)})
    def gcd_lcm(values):
        if any(type(x) is not int for x in values):raise UtilityError('Values must be integers')
        g=reduce(gcd,values)
        l=reduce(lambda a,b:abs(a*b)//gcd(a,b) if a and b else 0,values,1)
        return {'gcd':g,'lcm':l}

    @reg.register('numbers','prime_check','Check whether an integer is prime using trial division',
                  {'value':I('Integer to check',minimum=0,maximum=10**12)})
    def prime_check(value):
        if value<2:return {'prime':False}
        if value in {2,3}:return {'prime':True}
        if value%2==0 or value%3==0:return {'prime':False}
        factor=5
        while factor*factor<=value:
            if value%factor==0 or value%(factor+2)==0:
                return {'prime':False,'divisor':factor if value%factor==0 else factor+2}
            factor+=6
        return {'prime':True}

    @reg.register('numbers','prime_factors','Find prime factors of a moderate integer',
                  {'value':I('Positive integer',minimum=2,maximum=10**10)})
    def prime_factors(value):
        n=value;factors=[]
        divisor=2
        while divisor*divisor<=n:
            while n%divisor==0:
                factors.append(divisor);n//=divisor
            divisor=3 if divisor==2 else divisor+2
        if n>1:factors.append(n)
        return factors

    @reg.register('numbers','fibonacci','Generate the first N Fibonacci numbers',
                  {'count':I('Number of terms',minimum=1,maximum=200)})
    def fibonacci(count):
        result=[];a,b=0,1
        for _ in range(count):result.append(a);a,b=b,a+b
        return result

    @reg.register('numbers','factorial','Calculate factorial n! for a bounded nonnegative integer',
                  {'n':I('Integer',minimum=0,maximum=1000)})
    def factorial(n):
        result=math.factorial(n)
        return {'digits':len(str(result)),'value':str(result) if n<=200 else None}

    @reg.register('numbers','arithmetic_sequence','Produce a finite arithmetic progression',
                  {'start':N('First term'),'difference':N('Common difference'),
                   'count':I('Terms',minimum=1,maximum=1000)})
    def arithmetic_sequence(start,difference,count):
        values=[round(start+difference*i,8) for i in range(count)]
        return {'values':values,'sum':round(sum(values),8)}

    @reg.register('numbers','geometric_sequence','Produce a bounded geometric progression',
                  {'start':N('First term'),'ratio':N('Common ratio',minimum=-100,maximum=100),
                   'count':I('Terms',minimum=1,maximum=100)})
    def geometric_sequence(start,ratio,count):
        values=[];n=start
        for _ in range(count):
            if not math.isfinite(n) or abs(n)>1e12:raise UtilityError('Sequence exceeds supported size')
            values.append(round(n,8));n*=ratio
        return {'values':values,'sum':round(sum(values),8)}

    @reg.register('numbers','quadratic_roots','Solve a real quadratic equation ax²+bx+c=0',
                  {'a':N('Coefficient a'),'b':N('Coefficient b'),'c':N('Coefficient c')})
    def quadratic_roots(a,b,c):
        if a==0:
            if b==0:raise UtilityError('Not a solvable linear/quadratic equation')
            return {'type':'linear','roots':[-c/b]}
        discr=b*b-4*a*c
        if discr>=0:
            sq=math.sqrt(discr)
            return {'type':'real','discriminant':discr,
                    'roots':[round((-b+sq)/(2*a),9),round((-b-sq)/(2*a),9)]}
        return {'type':'complex','discriminant':discr,
                'real':round(-b/(2*a),9),'imaginary_magnitude':round(math.sqrt(-discr)/abs(2*a),9)}

    @reg.register('numbers','distance_2d','Calculate Euclidean distance between two 2D points',
                  {'x1':N('X 1'),'y1':N('Y 1'),'x2':N('X 2'),'y2':N('Y 2')})
    def distance_2d(x1,y1,x2,y2):
        return math.hypot(x2-x1,y2-y1)

    @reg.register('numbers','circle_area','Circle area and circumference for a positive radius',
                  {'radius':N('Radius',minimum=0)})
    def circle_area(radius):
        return {'area':math.pi*radius*radius,'circumference':2*math.pi*radius}

    @reg.register('numbers','triangle_area','Triangle area using base and height',
                  {'base':N('Base',minimum=0),'height':N('Height',minimum=0)})
    def triangle_area(base,height):
        return base*height/2

    @reg.register('numbers','pythagorean','Solve a right triangle hypotenuse from two sides',
                  {'a':N('First leg',minimum=0),'b':N('Second leg',minimum=0)})
    def pythagorean(a,b):
        return {'hypotenuse':math.hypot(a,b),'area':a*b/2}

    @reg.register('numbers','linear_interpolation','Find a point on a line between two measurements',
                  {'x0':N('Start X'),'y0':N('Start Y'),
                   'x1':N('End X'),'y1':N('End Y'),'x':N('Query X')})
    def linear_interpolation(x0,y0,x1,y1,x):
        if x0==x1:raise UtilityError('X coordinates must differ')
        t=(x-x0)/(x1-x0)
        return {'y':y0+t*(y1-y0),'fraction':t}

    @reg.register('numbers','weighted_average','Calculate weighted arithmetic mean',
                  {'values':A('Numeric values',min_length=1,max_length=200),
                   'weights':A('Nonnegative weights',min_length=1,max_length=200)})
    def weighted_average(values,weights):
        a=_numeric_sequence(values);b=_numeric_sequence(weights)
        if len(a)!=len(b) or any(x<0 for x in b) or not sum(b):
            raise UtilityError('Weights must match values and sum to more than zero')
        return round(sum(x*y for x,y in zip(a,b))/sum(b),8)

    @reg.register('numbers','round_significant','Round a finite number to N significant digits',
                  {'value':N('Number'),'digits':I('Significant digits',minimum=1,maximum=12)})
    def round_significant(value,digits):
        if value==0:return 0
        places=digits-1-int(math.floor(math.log10(abs(value))))
        return round(value,places)

    @reg.register('numbers','clamp_number','Constrain a value between two numbers',
                  {'value':N('Input'),'minimum':N('Lower limit'),'maximum':N('Upper limit')})
    def clamp_number(value,minimum,maximum):
        if minimum>maximum:raise UtilityError('Minimum must not exceed maximum')
        return max(minimum,min(maximum,value))

    @reg.register('numbers','number_to_base','Convert an integer to binary, octal or hexadecimal',
                  {'value':I('Integer'),'base':I('Base',minimum=2,maximum=36)})
    def number_to_base(value,base):
        digits='0123456789abcdefghijklmnopqrstuvwxyz'
        if value==0:return '0'
        sign='-' if value<0 else ''
        n=abs(value);out=''
        while n:
            n,index=divmod(n,base)
            out=digits[index]+out
        return sign+out

    @reg.register('numbers','base_to_number','Parse a base-2 to base-36 integer',
                  {'text':S('Digit string',max_length=100),'base':I('Base',minimum=2,maximum=36)})
    def base_to_number(text,base):
        if len(text)>100:raise UtilityError('Too many digits')
        try:return int(text,base)
        except ValueError as exc:raise UtilityError('Invalid digits for this base') from exc

    @reg.register('numbers','integer_bit_count','Count 1 bits in a nonnegative integer',
                  {'value':I('Integer',minimum=0)})
    def integer_bit_count(value):
        return {'ones':value.bit_count(),'binary':bin(value)[2:]}

    @reg.register('numbers','proportion','Solve a proportion a/b=c/d for missing d',
                  {'a':N('Known numerator'),'b':N('Known denominator'),'c':N('Known second numerator')})
    def proportion(a,b,c):
        if a==0:raise UtilityError('Cannot solve with a=0')
        return {'d':b*c/a}
