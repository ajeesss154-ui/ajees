"""Probability and combinatorics for offline explanations and calculations.

All operations bound trial counts to avoid expensive computations. Simulations
have a fixed random seed so results are reproducible and don't imply a
statistical prediction of future events.
"""
from __future__ import annotations

from collections import Counter
from fractions import Fraction
import itertools
import math
import random
import statistics

from .core import UtilityError, UtilityRegistry, S, I, N, A, B


def _probability(p):
    if type(p) not in (float, int) or not math.isfinite(p) or not 0 <= p <= 1:
        raise UtilityError('Probability must be between 0 and 1')
    return float(p)


def _numbers(values, low=1, high=300):
    if not low <= len(values) <= high:
        raise UtilityError('Invalid number of values')
    if any(type(v) not in (int, float) or not math.isfinite(v) for v in values):
        raise UtilityError('Expected finite numbers')
    return [float(v) for v in values]


def _binomial(n, k, p):
    return math.comb(n, k)*p**k*(1-p)**(n-k)


def _choose_distribution(values, weights, sample_count, seed):
    if len(values) != len(weights):
        raise UtilityError('Values and weights must have equal length')
    if any(w < 0 for w in weights) or sum(weights) == 0:
        raise UtilityError('Weights must be nonnegative and not all zero')
    rng = random.Random(seed)
    return rng.choices(values, weights=weights, k=sample_count)


def register(reg: UtilityRegistry) -> None:
    @reg.register('probability', 'factorial_probability', 'Factorial of a bounded nonnegative integer',
                  {'n': I('Value', minimum=0, maximum=100)})
    def factorial(n):
        return math.factorial(n)

    @reg.register('probability', 'combinations', 'Number of ways to select k items without order',
                  {'n': I('Total items', minimum=0, maximum=1000),
                   'k': I('Selected items', minimum=0, maximum=1000)})
    def combinations(n, k):
        if k > n:
            raise UtilityError('k cannot exceed n')
        return math.comb(n, k)

    @reg.register('probability', 'permutations', 'Ordered arrangements of k selected items',
                  {'n': I('Total items', minimum=0, maximum=1000),
                   'k': I('Selected items', minimum=0, maximum=1000)})
    def permutations(n, k):
        if k > n:
            raise UtilityError('k cannot exceed n')
        return math.perm(n, k)

    @reg.register('probability', 'probability_not', 'Compute the complement of an event probability',
                  {'p': N('Event probability', minimum=0, maximum=1)})
    def probability_not(p):
        return 1-p

    @reg.register('probability', 'independent_and', 'Probability of independent events both occurring',
                  {'p': N('First probability', minimum=0, maximum=1),
                   'q': N('Second probability', minimum=0, maximum=1)})
    def independent_and(p, q):
        return p*q

    @reg.register('probability', 'independent_or', 'Probability that either independent event occurs',
                  {'p': N('First probability', minimum=0, maximum=1),
                   'q': N('Second probability', minimum=0, maximum=1)})
    def independent_or(p, q):
        return p+q-p*q

    @reg.register('probability', 'conditional_probability', 'Compute P(A given B) from joint and marginal probabilities',
                  {'joint': N('P(A and B)', minimum=0, maximum=1),
                   'given': N('P(B)', minimum=0, maximum=1)})
    def conditional_probability(joint, given):
        if given <= 0 or joint > given:
            raise UtilityError('Probabilities must satisfy 0 <= joint <= given and given > 0')
        return joint/given

    @reg.register('probability', 'bayes_rule', 'Update a prior probability using sensitivity and false-positive rate',
                  {'prior': N('Prior P(H)', minimum=0, maximum=1),
                   'sensitivity': N('P(E given H)', minimum=0, maximum=1),
                   'false_positive': N('P(E given not H)', minimum=0, maximum=1)})
    def bayes_rule(prior, sensitivity, false_positive):
        numerator=prior*sensitivity
        denominator=numerator+(1-prior)*false_positive
        if denominator == 0:
            raise UtilityError('Evidence has zero probability')
        return {'posterior': numerator/denominator,
                'evidence_probability': denominator}

    @reg.register('probability', 'binomial_exact', 'Binomial probability of exactly k successes',
                  {'trials': I('Independent trials', minimum=0, maximum=1000),
                   'successes': I('Success count', minimum=0, maximum=1000),
                   'p': N('Success chance', minimum=0, maximum=1)})
    def binomial_exact(trials, successes, p):
        if successes > trials:
            raise UtilityError('Successes exceed trials')
        return _binomial(trials, successes, p)

    @reg.register('probability', 'binomial_at_least', 'Binomial probability of at least k successes',
                  {'trials': I('Trials', minimum=0, maximum=1000),
                   'successes': I('Minimum successes', minimum=0, maximum=1000),
                   'p': N('Success probability', minimum=0, maximum=1)})
    def binomial_at_least(trials, successes, p):
        if successes > trials:
            return 0.
        if successes == 0:
            return 1.
        # Compute lower tail if it has fewer terms to reduce numerical work.
        if successes <= trials/2:
            return max(0., min(1., 1-sum(_binomial(trials, k, p) for k in range(successes))))
        return max(0., min(1., sum(_binomial(trials, k, p) for k in range(successes, trials+1))))

    @reg.register('probability', 'binomial_mean_variance', 'Expected value and variance of a binomial distribution',
                  {'trials': I('Number of trials', minimum=0, maximum=1000000),
                   'p': N('Success probability', minimum=0, maximum=1)})
    def binomial_mean_variance(trials, p):
        return {'mean': trials*p, 'variance': trials*p*(1-p),
                'stddev': math.sqrt(trials*p*(1-p))}

    @reg.register('probability', 'poisson_exact', 'Poisson probability of exactly k events',
                  {'rate': N('Expected number of events', minimum=0, maximum=100),
                   'count': I('Number of observed events', minimum=0, maximum=300)})
    def poisson_exact(rate, count):
        return math.exp(-rate)*rate**count/math.factorial(count) if rate else float(count == 0)

    @reg.register('probability', 'geometric_exact', 'Probability first success occurs on a chosen trial',
                  {'p': N('Success chance', minimum=0, maximum=1),
                   'trial': I('Trial number', minimum=1, maximum=1000000)})
    def geometric_exact(p, trial):
        return (1-p)**(trial-1)*p

    @reg.register('probability', 'uniform_probability', 'Probability of a subinterval in a uniform range',
                  {'minimum': N('Minimum'), 'maximum': N('Maximum'),
                   'event_low': N('Event lower limit'),
                   'event_high': N('Event upper limit')})
    def uniform_probability(minimum, maximum, event_low, event_high):
        if maximum <= minimum or event_high < event_low:
            raise UtilityError('Invalid interval endpoints')
        overlap = max(0, min(maximum,event_high)-max(minimum,event_low))
        return overlap/(maximum-minimum)

    @reg.register('probability', 'normal_zscore', 'Convert a measurement to standard deviation units',
                  {'value': N('Observation'), 'mean': N('Population mean'),
                   'stddev': N('Population standard deviation', minimum=0)})
    def normal_zscore(value, mean, stddev):
        if stddev == 0:
            raise UtilityError('Standard deviation must exceed zero')
        return (value-mean)/stddev

    @reg.register('probability', 'normal_cdf', 'Cumulative normal probability for a z-score',
                  {'z': N('Z score', minimum=-50, maximum=50)})
    def normal_cdf(z):
        return 0.5*(1+math.erf(z/math.sqrt(2)))

    @reg.register('probability', 'normal_interval', 'Probability between two z-scores',
                  {'low': N('Lower z score', minimum=-50, maximum=50),
                   'high': N('Upper z score', minimum=-50, maximum=50)})
    def normal_interval(low, high):
        if low > high:
            raise UtilityError('Low must not exceed high')
        cdf=lambda z: 0.5*(1+math.erf(z/math.sqrt(2)))
        return cdf(high)-cdf(low)

    @reg.register('probability', 'expected_value', 'Compute expectation of a discrete probability distribution',
                  {'values': A('Possible outcomes', min_length=1),
                   'probabilities': A('Corresponding probabilities', min_length=1)})
    def expected_value(values, probabilities):
        x, ps = _numbers(values), _numbers(probabilities)
        if len(x) != len(ps) or any(p < 0 or p > 1 for p in ps):
            raise UtilityError('Each outcome needs a probability in [0,1]')
        if abs(sum(ps)-1) > 1e-7:
            raise UtilityError('Probabilities must sum to one')
        avg = sum(a*p for a,p in zip(x,ps))
        variance = sum(p*(a-avg)**2 for a,p in zip(x,ps))
        return {'expected_value': avg, 'variance': variance, 'stddev': math.sqrt(variance)}

    @reg.register('probability', 'shannon_entropy', 'Compute Shannon information entropy in bits',
                  {'probabilities': A('Probabilities', min_length=1)})
    def shannon_entropy(probabilities):
        ps = _numbers(probabilities)
        if any(p < 0 or p > 1 for p in ps) or abs(sum(ps)-1)>1e-7:
            raise UtilityError('Probabilities must be nonnegative and sum to one')
        return -sum(p*math.log2(p) for p in ps if p)

    @reg.register('probability', 'birthday_collision', 'Approximate chance two people share a birthday',
                  {'people': I('Group size', minimum=0, maximum=365)})
    def birthday_collision(people):
        no_collision = 1.0
        for i in range(people):
            no_collision *= (365-i)/365
        return {'probability': 1-no_collision, 'assumptions': '365 equally likely birthdays; excludes leap day'}

    @reg.register('probability', 'sample_mean_standard_error', 'Estimate standard error for a sample average',
                  {'stddev': N('Sample standard deviation', minimum=0),
                   'sample_size': I('Number of observations', minimum=1, maximum=10000000)})
    def sample_mean_standard_error(stddev, sample_size):
        return stddev/math.sqrt(sample_size)

    @reg.register('probability', 'sample_proportion_interval', 'Wilson interval for a sample percentage',
                  {'successes': I('Number of successes', minimum=0, maximum=1000000),
                   'trials': I('Total trials', minimum=1, maximum=1000000),
                   'z': N('Critical z value', False, 1.96, 0.1, 6)})
    def sample_proportion_interval(successes, trials, z):
        if successes > trials:
            raise UtilityError('Successes exceed trials')
        p=successes/trials
        denominator=1+z*z/trials
        center=(p+z*z/(2*trials))/denominator
        half=z*math.sqrt((p*(1-p)+z*z/(4*trials))/trials)/denominator
        return {'observed': p, 'lower': max(0.,center-half), 'upper': min(1.,center+half),
                'method': 'Wilson score interval'}

    @reg.register('probability', 'dice_sum_distribution', 'Exact discrete distribution for small fair dice sums',
                  {'dice': I('Number of dice', minimum=1, maximum=5),
                   'sides': I('Faces per die', False, 6, 2, 20)})
    def dice_sum_distribution(dice, sides):
        dist=Counter({0:1})
        for _ in range(dice):
            new=Counter()
            for total,ways in dist.items():
                for face in range(1,sides+1):
                    new[total+face]+=ways
            dist=new
        combinations=sides**dice
        return [{'sum':total,'ways':dist[total],'probability':dist[total]/combinations}
                for total in sorted(dist)]

    @reg.register('probability', 'coin_toss_distribution', 'Distribution of heads across a fixed number of fair flips',
                  {'flips': I('Number of flips', minimum=0, maximum=100)})
    def coin_toss_distribution(flips):
        return [{'heads':k,'probability':math.comb(flips,k)/2**flips} for k in range(flips+1)]

    @reg.register('probability', 'simulate_discrete', 'Reproducible weighted random sampling for education',
                  {'values': A('Possible outcomes', min_length=1, max_length=40),
                   'weights': A('Nonnegative weights', min_length=1, max_length=40),
                   'count': I('Number of draws', False, 100, 1, 1000),
                   'seed': I('Random seed', False, 42, -100000, 100000)})
    def simulate_discrete(values, weights, count, seed):
        if any(type(w) not in (float,int) or not math.isfinite(w) for w in weights):
            raise UtilityError('Weights must be finite numbers')
        result=_choose_distribution(values, weights, count, seed)
        return {'draws':result[:50], 'frequency':dict(Counter(str(x) for x in result)),
                'seed':seed, 'total':count}

    @reg.register('probability', 'bootstrap_mean', 'Compute deterministic bootstrap means for a small sample',
                  {'values': A('Input observations', min_length=2, max_length=150),
                   'replicates': I('Replicates', False, 100, 10, 500),
                   'seed': I('Random seed', False, 42, -100000, 100000)})
    def bootstrap_mean(values, replicates, seed):
        nums=_numbers(values,2,150)
        rng=random.Random(seed)
        draws=[statistics.mean(rng.choices(nums,k=len(nums))) for _ in range(replicates)]
        draws.sort()
        return {'bootstrap_mean':statistics.mean(draws),
                'approx_95_percentile_interval':[draws[int(.025*(replicates-1))],
                                                   draws[int(.975*(replicates-1))]],
                'replicates':replicates}

    @reg.register('probability', 'hypergeometric_exact', 'Probability of k successes sampled without replacement',
                  {'population': I('Total population', minimum=1, maximum=10000),
                   'positive': I('Positive items in population', minimum=0, maximum=10000),
                   'draws': I('Number of draws', minimum=0, maximum=10000),
                   'successes': I('Observed positive draws', minimum=0, maximum=10000)})
    def hypergeometric_exact(population, positive, draws, successes):
        if positive>population or draws>population:
            raise UtilityError('Counts exceed population')
        if successes>positive or successes>draws or draws-successes>population-positive:
            return 0.
        return math.comb(positive,successes)*math.comb(population-positive,draws-successes)/math.comb(population,draws)

    @reg.register('probability', 'odds_to_probability', 'Convert positive odds ratio to probability',
                  {'odds': N('Odds for vs against', minimum=0, maximum=1e12)})
    def odds_to_probability(odds):
        return odds/(1+odds)

    @reg.register('probability', 'probability_to_odds', 'Convert event probability into odds for vs against',
                  {'probability': N('Probability', minimum=0, maximum=1)})
    def probability_to_odds(probability):
        return {'odds':probability/(1-probability) if probability<1 else None,
                'infinite':probability==1}
