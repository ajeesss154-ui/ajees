"""A typed, deterministic registry of harmless assistant utility skills.

Design assumptions
------------------
* Utilities are pure functions, never device-control or file-system actions.
* A skill declares its exact parameters and primitive types at registration.
* Every user-supplied input is bounded and type-validated before execution.
* No dynamic imports, eval, shell commands or arbitrary HTTP are supported.
* Exceptions are returned as brief user-facing errors without stack traces.

Higher-level workflow automation uses the separate approval policy; it does
not automatically acquire these skills as a way to bypass OS restrictions.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import inspect
import json
import math
from collections import defaultdict
from typing import Any, Callable, Literal


class UtilityError(ValueError):
    pass


@dataclass(frozen=True)
class Arg:
    description: str
    type: Literal['string','integer','number','boolean','array','object']
    required: bool = True
    default: Any = None
    min_value: float | None = None
    max_value: float | None = None
    min_length: int = 0
    max_length: int = 5000
    choices: tuple[Any,...] = ()

    def to_schema(self) -> dict:
        result={'type':self.type,'description':self.description}
        if self.min_value is not None:result['minimum']=self.min_value
        if self.max_value is not None:result['maximum']=self.max_value
        if self.type=='string':
            result['minLength']=self.min_length
            result['maxLength']=self.max_length
        if self.choices:result['enum']=list(self.choices)
        return result

    def validate(self,name:str,value:Any) -> Any:
        expected=self.type
        if expected=='integer' and type(value) is not int:
            raise UtilityError(f'{name} must be an integer')
        if expected=='number' and (type(value) not in (float,int)):
            raise UtilityError(f'{name} must be numeric')
        if expected=='boolean' and type(value) is not bool:
            raise UtilityError(f'{name} must be boolean')
        if expected=='string' and not isinstance(value,str):
            raise UtilityError(f'{name} must be text')
        if expected=='array' and not isinstance(value,list):
            raise UtilityError(f'{name} must be a list')
        if expected=='object' and not isinstance(value,dict):
            raise UtilityError(f'{name} must be an object')
        if type(value) in (int,float):
            if not math.isfinite(value):
                raise UtilityError(f'{name} must be a finite number')
            if self.min_value is not None and value<self.min_value:
                raise UtilityError(f'{name} is below the minimum')
            if self.max_value is not None and value>self.max_value:
                raise UtilityError(f'{name} exceeds the maximum')
        if isinstance(value,(str,list,dict)):
            if len(value)<self.min_length or len(value)>self.max_length:
                raise UtilityError(f'{name} length must be {self.min_length} to {self.max_length}')
        if self.choices and value not in self.choices:
            raise UtilityError(f'{name} must be one of {self.choices}')
        if isinstance(value,(list,dict)):
            try:
                size=len(json.dumps(value,allow_nan=False,ensure_ascii=False))
            except (TypeError,ValueError,RecursionError) as exc:
                raise UtilityError(f'{name} must contain JSON values') from exc
            if size>20000:raise UtilityError(f'{name} contains too much data')
        return value


@dataclass(frozen=True)
class Utility:
    name: str
    category: str
    description: str
    args: dict[str,Arg]
    run: Callable[...,Any]
    examples: tuple[str,...] = ()

    def documentation(self) -> dict:
        return {'name':self.name,'category':self.category,
                'description':self.description,
                'parameters':{'type':'object',
                              'properties':{k:v.to_schema() for k,v in self.args.items()},
                              'required':[k for k,v in self.args.items() if v.required],
                              'additionalProperties':False},
                'examples':list(self.examples)}


class UtilityRegistry:
    def __init__(self):
        self._skills:dict[str,Utility]={}
        self._invocations:dict[str,int]=defaultdict(int)

    def add(self,skill:Utility) -> None:
        if skill.name in self._skills:raise UtilityError('Duplicate utility name')
        if len(skill.name)>70 or not all(ch in 'abcdefghijklmnopqrstuvwxyz0123456789_'
                                         for ch in skill.name):
            raise UtilityError('Invalid utility name')
        signature=inspect.signature(skill.run)
        for parameter in skill.args:
            if parameter not in signature.parameters:
                raise UtilityError('A documented argument is not accepted by the function')
        self._skills[skill.name]=skill

    def register(self, category:str, name:str, description:str,
                 args:dict[str,Arg], examples:tuple[str,...]=()):
        def decorator(callback):
            self.add(Utility(name,category,description,args,callback,examples))
            return callback
        return decorator

    def execute(self,name:str,params:dict[str,Any]) -> dict:
        if name not in self._skills:
            raise UtilityError('Unknown utility: '+str(name)[:80])
        if not isinstance(params,dict):raise UtilityError('Input must be a JSON object')
        skill=self._skills[name]
        if set(params)-set(skill.args):raise UtilityError('Unsupported parameter')
        missing=[key for key,arg in skill.args.items() if arg.required and key not in params]
        if missing:raise UtilityError('Missing parameters: '+', '.join(missing))
        values={}
        for key,arg in skill.args.items():
            raw=params.get(key,arg.default)
            values[key]=arg.validate(key,raw)
        try:
            answer=skill.run(**values)
            encoded=json.dumps(answer,ensure_ascii=False,allow_nan=False,default=str)
        except UtilityError:raise
        except (TypeError,ValueError,ArithmeticError,OverflowError,RecursionError) as exc:
            raise UtilityError('Utility error: '+str(exc)[:180]) from exc
        if len(encoded)>100000:raise UtilityError('Output is too large')
        self._invocations[name]+=1
        return {'utility':name,'category':skill.category,'result':answer}

    def catalog(self,category:str|None=None) -> list[dict]:
        records=(skill.documentation() for skill in self._skills.values()
                 if category is None or skill.category==category)
        return sorted(records,key=lambda item:item['name'])

    def categories(self) -> list[dict]:
        counts={}
        for skill in self._skills.values():
            counts[skill.category]=counts.get(skill.category,0)+1
        return [{'name':name,'count':count} for name,count in sorted(counts.items())]

    def get(self,name:str) -> Utility|None:
        return self._skills.get(name)

    def stats(self) -> dict:
        return {'skills':len(self._skills),
                'invocations':dict(sorted(self._invocations.items())),
                'categories':self.categories()}


def S(description:str, required:bool=True, default: str='',
      min_length:int=0,max_length:int=5000,choices=()) -> Arg:
    return Arg(description,'string',required,default,min_length=min_length,
               max_length=max_length,choices=tuple(choices))


def I(description:str, required:bool=True, default:int=0,
      minimum:int|None=None,maximum:int|None=None) -> Arg:
    return Arg(description,'integer',required,default,min_value=minimum,max_value=maximum)


def N(description:str, required:bool=True, default:float=0.0,
      minimum:float|None=None,maximum:float|None=None) -> Arg:
    return Arg(description,'number',required,default,min_value=minimum,max_value=maximum)


def B(description:str, required:bool=True, default:bool=False) -> Arg:
    return Arg(description,'boolean',required,default)


def A(description:str, required:bool=True, default=None,
      min_length:int=0,max_length:int=300) -> Arg:
    return Arg(description,'array',required,[] if default is None else default,
               min_length=min_length,max_length=max_length)


def O(description:str, required:bool=True, default=None) -> Arg:
    return Arg(description,'object',required,{} if default is None else default)
