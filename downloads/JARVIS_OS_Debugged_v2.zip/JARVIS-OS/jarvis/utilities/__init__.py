"""Pure, allowlisted, offline helper tools for the JARVIS brain."""
