"""Explicit SI/imperial conversions for quantities, no live exchange rates."""
from __future__ import annotations

from math import pi,isfinite
from typing import Any

from .core import UtilityRegistry,UtilityError,S,I,N,B,A,O


UNITS={
    'length':{
        'm':1,'km':1000,'cm':.01,'mm':.001,'um':1e-6,'nm':1e-9,
        'in':.0254,'ft':.3048,'yd':.9144,'mi':1609.344,'nmi':1852,
    },
    'mass':{
        'kg':1,'g':.001,'mg':1e-6,'t':1000,
        'lb':0.45359237,'oz':0.028349523125,'stone':6.35029318,
    },
    'area':{
        'm2':1,'km2':1e6,'cm2':.0001,'mm2':1e-6,
        'ft2':.09290304,'in2':0.00064516,'acre':4046.8564224,'ha':10000,
    },
    'volume':{
        'm3':1,'l':.001,'ml':1e-6,'cm3':1e-6,'ft3':.028316846592,
        'in3':1.6387064e-5,'us_gal':.003785411784,'us_qt':.000946352946,
        'us_cup':.0002365882365,'us_floz':2.95735295625e-5,
    },
    'time':{
        's':1,'ms':.001,'us':1e-6,'min':60,'h':3600,'d':86400,'wk':604800,
    },
    'speed':{
        'm/s':1,'km/h':1/3.6,'mph':0.44704,'knot':0.51444444444,'ft/s':.3048,
    },
    'pressure':{
        'pa':1,'kpa':1000,'mpa':1e6,'bar':1e5,'atm':101325,'psi':6894.7572932,
    },
    'energy':{
        'j':1,'kj':1000,'mj':1e6,'wh':3600,'kwh':3.6e6,'cal':4.184,'kcal':4184,'btu':1055.05585262,
    },
    'power':{
        'w':1,'kw':1000,'mw':1e6,'hp':745.699871582,
    },
    'frequency':{
        'hz':1,'khz':1000,'mhz':1e6,'ghz':1e9,'rpm':1/60,
    },
    'storage':{
        'b':1,'kb':1000,'mb':1e6,'gb':1e9,'tb':1e12,
        'kib':1024,'mib':1024**2,'gib':1024**3,'tib':1024**4,
    },
    'angle':{
        'rad':1,'deg':pi/180,'turn':2*pi,'grad':pi/200,
    },
    'electric_current':{
        'a':1,'ma':.001,'ua':1e-6,
    },
    'electric_voltage':{
        'v':1,'kv':1000,'mv':.001,
    },
    'electrical_resistance':{
        'ohm':1,'kohm':1000,'mohm':1e6,
    },
}


def _convert(value:float,category:str,origin:str,destination:str) -> float:
    if category not in UNITS:raise UtilityError('Unknown unit category')
    units=UNITS[category]
    if origin not in units or destination not in units:
        raise UtilityError('Unknown units for category')
    result=value*units[origin]/units[destination]
    if not isfinite(result):raise UtilityError('Value exceeds supported range')
    return result


def _temperature(value:float,origin:str,destination:str) -> float:
    names={'c','f','k'}
    if origin not in names or destination not in names:
        raise UtilityError('Temperature unit must be c, f or k')
    kelvin={'c':lambda x:x+273.15,'f':lambda x:(x+459.67)*5/9,'k':lambda x:x}[origin](value)
    if kelvin<0:raise UtilityError('Temperature cannot be below absolute zero')
    return {'c':lambda x:x-273.15,'f':lambda x:x*9/5-459.67,'k':lambda x:x}[destination](kelvin)


def register(reg:UtilityRegistry) -> None:
    @reg.register('measure','convert_units','Convert between defined units in a physical category',
                  {'value':N('Numeric amount'),'category':S('One of the unit categories'),
                   'origin':S('Source symbol'),'destination':S('Target symbol')})
    def convert_units(value,category,origin,destination):
        return {'value':round(_convert(value,category,origin,destination),10),
                'unit':destination,'category':category}

    @reg.register('measure','list_units','List accepted symbols for each conversion category',
                  {'category':S('Category, or blank for all',False,'')})
    def list_units(category):
        if not category:return {name:sorted(table) for name,table in UNITS.items()}
        if category not in UNITS:raise UtilityError('Unknown unit category')
        return sorted(UNITS[category])

    @reg.register('measure','convert_temperature','Convert Celsius Fahrenheit and Kelvin',
                  {'value':N('Temperature'),'origin':S('c, f or k'),
                   'destination':S('c, f or k')})
    def convert_temperature(value,origin,destination):
        return {'value':round(_temperature(value,origin.lower(),destination.lower()),5),
                'unit':destination.lower()}

    @reg.register('measure','pace_from_time','Calculate minutes per km from minutes and distance',
                  {'minutes':N('Elapsed minutes',minimum=0),
                   'kilometers':N('Distance in km',minimum=.0000001)})
    def pace_from_time(minutes,kilometers):
        pace=minutes/kilometers
        return {'minutes_per_km':round(pace,3),
                'pace_label':f'{int(pace):02}:{round((pace%1)*60):02}/km'}

    @reg.register('measure','speed_from_distance','Calculate average speed from time and distance',
                  {'kilometers':N('Distance in km',minimum=0),
                   'hours':N('Elapsed hours',minimum=.000001)})
    def speed_from_distance(kilometers,hours):
        return {'kilometers_per_hour':round(kilometers/hours,5),
                'meters_per_second':round(kilometers/hours/3.6,5)}

    @reg.register('measure','distance_from_speed','Calculate distance traveled at constant speed',
                  {'kilometers_per_hour':N('Average speed',minimum=0),
                   'hours':N('Elapsed hours',minimum=0)})
    def distance_from_speed(kilometers_per_hour,hours):
        return {'distance_km':round(kilometers_per_hour*hours,6)}

    @reg.register('measure','cylinder_volume','Compute cylinder volume in input cubic units',
                  {'radius':N('Base radius',minimum=0),'height':N('Height',minimum=0)})
    def cylinder_volume(radius,height):
        return pi*radius*radius*height

    @reg.register('measure','sphere_volume','Compute sphere volume and surface area',
                  {'radius':N('Sphere radius',minimum=0)})
    def sphere_volume(radius):
        return {'volume':4/3*pi*radius**3,'surface_area':4*pi*radius*radius}

    @reg.register('measure','cone_volume','Compute cone volume',
                  {'radius':N('Base radius',minimum=0),'height':N('Cone height',minimum=0)})
    def cone_volume(radius,height):
        return pi*radius*radius*height/3

    @reg.register('measure','cuboid_volume','Compute cuboid volume and surface area',
                  {'length':N('Length',minimum=0),'width':N('Width',minimum=0),
                   'height':N('Height',minimum=0)})
    def cuboid_volume(length,width,height):
        return {'volume':length*width*height,
                'surface_area':2*(length*width+length*height+width*height)}

    @reg.register('measure','hyperspace_data_size','Estimate storage for uncompressed images in bytes',
                  {'width':I('Width pixels',minimum=1,maximum=16384),
                   'height':I('Height pixels',minimum=1,maximum=16384),
                   'channels':I('Color channels',False,3,1,4),
                   'bits_per_channel':I('Channel bit depth',False,8,1,32)})
    def hyperspace_data_size(width,height,channels,bits_per_channel):
        bits=width*height*channels*bits_per_channel
        return {'bits':bits,'bytes':(bits+7)//8,'mebibytes':round(bits/8/1024**2,3),
                'compressed_size':'unknown (depends on image content)'}

    @reg.register('measure','download_time_estimate','Estimate download time without network measurement',
                  {'size_megabytes':N('File size MB decimal',minimum=0),
                   'bandwidth_megabits_per_second':N('Mbps',minimum=.001)})
    def download_time_estimate(size_megabytes,bandwidth_megabits_per_second):
        seconds=size_megabytes*8/bandwidth_megabits_per_second
        return {'seconds':round(seconds,2),'minutes':round(seconds/60,2),
                'note':'Ideal mathematical estimate; real networks incur overhead.'}

    @reg.register('measure','aspect_ratio','Simplify pixel aspect ratio',
                  {'width':I('Width',minimum=1),'height':I('Height',minimum=1)})
    def aspect_ratio(width,height):
        from math import gcd
        common=gcd(width,height)
        return {'width_ratio':width//common,'height_ratio':height//common,
                'decimal_ratio':round(width/height,6)}

    @reg.register('measure','pixel_density','Compute approximate pixels per inch for a display',
                  {'width_px':I('Horizontal pixels',minimum=1),
                   'height_px':I('Vertical pixels',minimum=1),
                   'diagonal_inches':N('Diagonal screen size',minimum=.01)})
    def pixel_density(width_px,height_px,diagonal_inches):
        return {'ppi':round((width_px**2+height_px**2)**.5/diagonal_inches,2)}

    @reg.register('measure','file_size_format','Format a byte count in binary or decimal units',
                  {'bytes':I('Byte count',minimum=0),
                   'binary':B('Use KiB MiB GiB instead of kB MB GB',False,True)})
    def file_size_format(bytes,binary):
        names=['B','KiB','MiB','GiB','TiB','PiB'] if binary else ['B','kB','MB','GB','TB','PB']
        divisor=1024 if binary else 1000
        value=float(bytes)
        index=0
        while value>=divisor and index<len(names)-1:
            value/=divisor;index+=1
        return {'text':f'{value:.2f} {names[index]}','unit':names[index],'value':round(value,2)}

    @reg.register('measure','bytes_to_bits','Convert bytes to bits',
                  {'bytes':I('Byte count',minimum=0)})
    def bytes_to_bits(bytes):
        return bytes*8

    @reg.register('measure','bits_to_bytes','Convert bit count to full and remaining bytes',
                  {'bits':I('Bit count',minimum=0)})
    def bits_to_bytes(bits):
        complete,remaining=divmod(bits,8)
        return {'whole_bytes':complete,'remaining_bits':remaining,
                'rounded_up_bytes':(bits+7)//8}

    @reg.register('measure','rescale_image','Rescale an image to fit within given bounds, preserving aspect ratio',
                  {'width':I('Original width',minimum=1,maximum=100000),
                   'height':I('Original height',minimum=1,maximum=100000),
                   'max_width':I('Target width',minimum=1,maximum=100000),
                   'max_height':I('Target height',minimum=1,maximum=100000),
                   'upscale':B('Allow enlarging the original',False,False)})
    def rescale_image(width,height,max_width,max_height,upscale):
        factor=min(max_width/width,max_height/height)
        if not upscale:factor=min(1,factor)
        return {'width':max(1,round(width*factor)),
                'height':max(1,round(height*factor)),'scale':round(factor,5)}

    @reg.register('measure','power_energy','Calculate energy from constant power and elapsed time',
                  {'watts':N('Power in W',minimum=0),
                   'hours':N('Duration in hours',minimum=0)})
    def power_energy(watts,hours):
        return {'watt_hours':watts*hours,'kilowatt_hours':watts*hours/1000,
                'joules':watts*hours*3600}

    @reg.register('measure','electric_ohms_law','Solve voltage current or resistance from the other two',
                  {'volts':N('Voltage, 0 if unknown',False,0),
                   'amps':N('Current, 0 if unknown',False,0),
                   'ohms':N('Resistance, 0 if unknown',False,0),
                   'solve_for':S('One of volts amps ohms',choices=('volts','amps','ohms'))})
    def electric_ohms_law(volts,amps,ohms,solve_for):
        if solve_for=='volts':return {'volts':amps*ohms}
        if solve_for=='amps':
            if ohms==0:raise UtilityError('Resistance cannot be zero')
            return {'amps':volts/ohms}
        if amps==0:raise UtilityError('Current cannot be zero')
        return {'ohms':volts/amps}
