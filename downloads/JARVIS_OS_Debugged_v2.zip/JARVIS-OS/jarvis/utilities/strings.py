"""Text utilities for notes, document drafting and natural-language commands."""
from __future__ import annotations

from collections import Counter
from difflib import SequenceMatcher,get_close_matches,unified_diff
import hashlib
import html
import json
import re
import textwrap
import unicodedata
from urllib.parse import quote,unquote,parse_qsl,urlencode,urlsplit

from .core import UtilityRegistry,UtilityError,S,I,N,B,A,O
from jarvis.intelligence.text import (
    normalize,tokens,sentences,keywords,text_profile,extract_entities,
    detect_language_hint,deduplicate,top_phrases,highlight_offsets,
    repeated_sentences
)
from jarvis.intelligence.summarize import summarize,compare_documents


def _slug(text:str) -> str:
    text=unicodedata.normalize('NFKD',text)
    text=text.encode('ascii','ignore').decode('ascii').lower()
    text=re.sub(r'[^a-z0-9]+','-',text)
    return text.strip('-')[:100]


def _style(text:str,style:str) -> str:
    words=re.findall(r'[A-Za-z0-9]+',unicodedata.normalize('NFKD',text))
    if not words:return ''
    if style=='snake':return '_'.join(w.lower() for w in words)
    if style=='kebab':return '-'.join(w.lower() for w in words)
    if style=='camel':return words[0].lower()+''.join(w.title() for w in words[1:])
    if style=='pascal':return ''.join(w.title() for w in words)
    if style=='title':return ' '.join(w.title() for w in words)
    if style=='constant':return '_'.join(w.upper() for w in words)
    raise UtilityError('Unknown case style')


def _word_wrap(text:str,width:int,preserve:bool) -> str:
    return '\n'.join(textwrap.fill(paragraph,width=width,
                     break_long_words=False,replace_whitespace=not preserve)
                     if paragraph.strip() else '' for paragraph in text.splitlines())


def register(reg:UtilityRegistry) -> None:
    @reg.register('strings','text_stats','Profile word count sentences and document traits',
                  {'text':S('Text to analyze')})
    def text_stats(text):
        return text_profile(text)

    @reg.register('strings','top_keywords','Extract common non-stopword terms from a passage',
                  {'text':S('Passage'),'limit':I('Keyword count',False,12,1,50)})
    def top_keywords(text,limit):
        return keywords(text,limit)

    @reg.register('strings','text_summary','Select source sentences as a short extractive summary',
                  {'text':S('Passage'),'sentences_count':I('Number of sentences',False,4,1,20)})
    def text_summary(text,sentences_count):
        return summarize(text,sentences_count=sentences_count)

    @reg.register('strings','text_similarity','Compare two passages using lexical similarity and shared keywords',
                  {'first':S('First passage'),'second':S('Second passage')})
    def text_similarity(first,second):
        return compare_documents(first,second)

    @reg.register('strings','extract_patterns','Extract explicit date email URL hashtag and time patterns',
                  {'text':S('Passage')})
    def extract_patterns(text):
        return extract_entities(text)

    @reg.register('strings','language_script_hint','Detect which common writing script is most visible',
                  {'text':S('Passage')})
    def language_script_hint(text):
        return {'script_hint':detect_language_hint(text),'not_full_language_detection':True}

    @reg.register('strings','normalize_text','Standardize Unicode whitespace and optionally case',
                  {'text':S('Text'),'casefold':B('Convert to casefolded lowercase',False,True)})
    def normalize_text(text,casefold):
        return normalize(text,casefold=casefold)

    @reg.register('strings','slugify','Create a URL-friendly ASCII slug from a title',
                  {'text':S('Title or phrase')})
    def slugify(text):
        return _slug(text)

    @reg.register('strings','case_transform','Transform labels into snake kebab camel pascal title or constant case',
                  {'text':S('Text'),
                   'style':S('Style',choices=('snake','kebab','camel','pascal','title','constant'))})
    def case_transform(text,style):
        return _style(text,style)

    @reg.register('strings','text_wrap','Wrap plain text to a specified column width',
                  {'text':S('Plain text'),
                   'width':I('Columns',False,80,20,200),
                   'preserve_whitespace':B('Preserve whitespace',False,False)})
    def text_wrap(text,width,preserve_whitespace):
        return _word_wrap(text,width,preserve_whitespace)

    @reg.register('strings','line_numbers','Prefix each line with its line number',
                  {'text':S('Multiline text'),'start':I('Starting number',False,1,0,100000)})
    def line_numbers(text,start):
        return '\n'.join(f'{number:4} | {line}' for number,line in enumerate(text.splitlines(),start))

    @reg.register('strings','remove_empty_lines','Filter blank lines from a passage',
                  {'text':S('Multiline text')})
    def remove_empty_lines(text):
        return '\n'.join(line for line in text.splitlines() if line.strip())

    @reg.register('strings','deduplicate_lines','Remove repeated lines while preserving first occurrence',
                  {'text':S('Multiline text'),
                   'ignore_case':B('Compare case insensitively',False,True)})
    def deduplicate_lines(text,ignore_case):
        seen=set();output=[]
        for line in text.splitlines():
            key=line.casefold() if ignore_case else line
            if key in seen:continue
            output.append(line);seen.add(key)
        return '\n'.join(output)

    @reg.register('strings','sort_lines','Sort a list of lines alphabetically',
                  {'text':S('Multiline text'),'reverse':B('Descending order',False,False),
                   'casefold':B('Case insensitive',False,True)})
    def sort_lines(text,reverse,casefold):
        return '\n'.join(sorted(text.splitlines(),reverse=reverse,
                                key=str.casefold if casefold else None))

    @reg.register('strings','word_frequency','Count words within a passage',
                  {'text':S('Passage'),
                   'limit':I('Maximum frequency rows',False,40,1,300)})
    def word_frequency(text,limit):
        return [{'word':word,'count':count}
                for word,count in Counter(tokens(text,minimum=1)).most_common(limit)]

    @reg.register('strings','common_words','Find words present in both texts',
                  {'first':S('First text'),'second':S('Second text')})
    def common_words(first,second):
        a,b=set(tokens(first,stopwords=True)),set(tokens(second,stopwords=True))
        return {'common':sorted(a&b),'only_first':sorted(a-b),'only_second':sorted(b-a)}

    @reg.register('strings','sentence_split','Split a passage into sentences with their order preserved',
                  {'text':S('Passage')})
    def sentence_split(text):
        return sentences(text,limit=100)

    @reg.register('strings','paragraph_split','Split text on empty lines',
                  {'text':S('Multiline text')})
    def paragraph_split(text):
        return [part.strip() for part in re.split(r'\n\s*\n',text) if part.strip()]

    @reg.register('strings','character_count','Count Unicode codepoints by broad category',
                  {'text':S('Passage')})
    def character_count(text):
        result=Counter(unicodedata.category(ch)[0] for ch in text)
        return {'letters':result['L'],'numbers':result['N'],
                'punctuation':result['P'],'symbols':result['S'],
                'whitespace':sum(ch.isspace() for ch in text),
                'total':len(text)}

    @reg.register('strings','text_diff','Create a unified line-by-line difference between text versions',
                  {'before':S('Original'),'after':S('Updated')})
    def text_diff(before,after):
        return '\n'.join(list(unified_diff(before.splitlines(),after.splitlines(),
                              fromfile='before',tofile='after',lineterm=''))[:400])

    @reg.register('strings','fuzzy_titles','Find close candidate titles for a supplied name',
                  {'query':S('Title'),'candidates':A('List of titles',min_length=1,max_length=300),
                   'limit':I('Result count',False,5,1,20)})
    def fuzzy_titles(query,candidates,limit):
        if any(not isinstance(x,str) for x in candidates):
            raise UtilityError('Candidates must be strings')
        choices=get_close_matches(query,candidates,n=limit,cutoff=.2)
        return [{'title':name,'similarity':round(SequenceMatcher(None,query.lower(),name.lower()).ratio(),3)}
                for name in choices]

    @reg.register('strings','literal_find','Find exact substring positions without regular expressions',
                  {'text':S('Text'),'needle':S('Search term',min_length=1,max_length=100),
                   'ignore_case':B('Case insensitive',False,True)})
    def literal_find(text,needle,ignore_case):
        if ignore_case:text=text.lower();needle=needle.lower()
        matches=[];start=0
        while len(matches)<100:
            pos=text.find(needle,start)
            if pos<0:break
            matches.append(pos);start=pos+max(1,len(needle))
        return {'positions':matches,'matches':len(matches)}

    @reg.register('strings','replace_literal','Replace literal text with another substring',
                  {'text':S('Input'),'old':S('Exact old text',min_length=1,max_length=200),
                   'new':S('Replacement'),
                   'limit':I('Maximum replacements',False,100,0,1000)})
    def replace_literal(text,old,new,limit):
        result=text.replace(old,new,limit)
        if len(result)>20000:raise UtilityError('Result too large')
        return result

    @reg.register('strings','html_escape','Escape HTML special characters for safe display',
                  {'text':S('Text')})
    def html_escape(text):
        return html.escape(text,quote=True)

    @reg.register('strings','url_encode_component','Percent-encode one URL path component',
                  {'text':S('Text')})
    def url_encode_component(text):
        return quote(text,safe='')

    @reg.register('strings','url_decode_component','Decode percent-encoded URL text',
                  {'text':S('Encoded text')})
    def url_decode_component(text):
        return unquote(text,errors='replace')

    @reg.register('strings','parse_querystring','Extract query-string parameters without issuing HTTP requests',
                  {'text':S('URL query string')})
    def parse_querystring(text):
        if len(text)>5000:raise UtilityError('Query string too long')
        parts=parse_qsl(text.lstrip('?'),keep_blank_values=True,max_num_fields=200)
        return [{'key':name,'value':value} for name,value in parts]

    @reg.register('strings','build_querystring','Build URL query string from key-value pairs',
                  {'items':A('Pairs as objects with key and value',min_length=1,max_length=200)})
    def build_querystring(items):
        pairs=[]
        for item in items:
            if not isinstance(item,dict) or not isinstance(item.get('key'),str):
                raise UtilityError('Expected objects with key and value')
            pairs.append((item['key'],str(item.get('value',''))))
        return urlencode(pairs)

    @reg.register('strings','extract_urls','List HTTP(S) URLs visibly present in plain text',
                  {'text':S('Passage')})
    def extract_urls(text):
        return extract_entities(text)['urls']

    @reg.register('strings','hash_sha256','Compute SHA-256 digest for plain text, not passwords',
                  {'text':S('Input text')})
    def hash_sha256(text):
        return hashlib.sha256(text.encode('utf-8')).hexdigest()

    @reg.register('strings','palindrome_check','Check if alphanumeric characters read identically backwards',
                  {'text':S('Phrase')})
    def palindrome_check(text):
        clean=''.join(ch.lower() for ch in text if ch.isalnum())
        return {'palindrome':clean==clean[::-1],'normalized':clean}

    @reg.register('strings','anagram_check','Check whether two phrases use the same alphanumeric characters',
                  {'first':S('Phrase 1'),'second':S('Phrase 2')})
    def anagram_check(first,second):
        clean=lambda s:Counter(ch.lower() for ch in s if ch.isalnum())
        return {'anagrams':clean(first)==clean(second)}

    @reg.register('strings','initials','Make initials from a short phrase',
                  {'text':S('Name or phrase'),
                   'limit':I('Maximum initials',False,6,1,20)})
    def initials(text,limit):
        return ''.join(part[0].upper() for part in re.findall(r'\w+',text)[:limit])

    @reg.register('strings','mask_identifier','Mask characters of a user-supplied non-secret identifier',
                  {'text':S('Identifier'),'keep_last':I('Trailing visible characters',False,4,0,20)})
    def mask_identifier(text,keep_last):
        prefix=max(0,len(text)-keep_last)
        return '*'*prefix+text[prefix:]

    @reg.register('strings','extract_headings','Extract Markdown headings from an outline',
                  {'text':S('Markdown text')})
    def extract_headings(text):
        rows=[]
        for number,line in enumerate(text.splitlines(),1):
            match=re.match(r'^(#{1,6})\s+(.+)$',line)
            if match:rows.append({'line':number,'level':len(match[1]),'title':match[2]})
        return rows[:200]

    @reg.register('strings','markdown_toc','Create a simple Markdown table of contents',
                  {'text':S('Markdown document')})
    def markdown_toc(text):
        headings=[]
        for line in text.splitlines():
            match=re.match(r'^(#{1,6})\s+(.+)$',line)
            if not match:continue
            level=len(match[1]);title=match[2].strip()
            link=_slug(title)
            headings.append('  '*(level-1)+f'- [{title}](#{link})')
        return '\n'.join(headings[:200])

    @reg.register('strings','detect_repetitions','Show repeated full sentences',
                  {'text':S('Document')})
    def detect_repetitions(text):
        return repeated_sentences(text)

    @reg.register('strings','top_bigrams','List common adjacent two-word phrases',
                  {'text':S('Passage'),
                   'limit':I('Phrase count',False,10,1,30)})
    def top_bigrams(text,limit):
        return [{'phrase':phrase,'count':count}
                for phrase,count in top_phrases(text,2,limit)]
