"""Offline static code analysis helpers, without executing provided source.

All code is parsed as data. No exec, eval, subprocess, dependency install,
import of submitted modules, or access to the host filesystem is allowed.
"""
from __future__ import annotations

import ast
from collections import Counter, defaultdict
import difflib
import keyword
import re
import tokenize
from io import BytesIO

from .core import UtilityError, UtilityRegistry, S, I, A, B


def _tree(source: str):
    if len(source) > 12000:
        raise UtilityError('Source exceeds 12000 characters')
    try:
        tree = ast.parse(source)
    except (SyntaxError, ValueError) as exc:
        lineno = getattr(exc, 'lineno', None)
        message = getattr(exc, 'msg', 'Invalid source')
        raise UtilityError(f'Syntax error on line {lineno}: {message}') from exc
    if sum(1 for _ in ast.walk(tree)) > 12000:
        raise UtilityError('Too many AST nodes')
    return tree


def _pos(node):
    return {'line': getattr(node, 'lineno', None),
            'end_line': getattr(node, 'end_lineno', None)}


def _flatten_functions(tree):
    functions = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            pos = _pos(node)
            args = [a.arg for a in node.args.posonlyargs + node.args.args + node.args.kwonlyargs]
            functions.append({'name': node.name, 'async': isinstance(node, ast.AsyncFunctionDef),
                              'arguments': args, 'decorators': len(node.decorator_list), **pos})
    return sorted(functions, key=lambda f: f['line'])


def _literal_imports(tree):
    result = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                result.append({'module': alias.name, 'alias': alias.asname,
                               'line': node.lineno, 'relative': False})
        elif isinstance(node, ast.ImportFrom):
            result.append({'module': node.module or '',
                           'names': [alias.name for alias in node.names],
                           'line': node.lineno, 'relative': bool(node.level)})
    return sorted(result, key=lambda item: item['line'])


def _complexity(node):
    branching = (ast.If, ast.For, ast.AsyncFor, ast.While, ast.ExceptHandler,
                 ast.IfExp, ast.Assert, ast.With, ast.AsyncWith)
    score = 1
    for sub in ast.walk(node):
        if sub is node:
            continue
        if isinstance(sub, branching):
            score += 1
        if isinstance(sub, ast.BoolOp):
            score += max(0, len(sub.values)-1)
    return score


def _line_breakdown(text: str):
    lines = text.splitlines()
    blank = sum(not line.strip() for line in lines)
    comments = sum(line.lstrip().startswith('#') for line in lines)
    return {'lines': len(lines), 'blank': blank, 'full_line_comments': comments,
            'nonblank': len(lines)-blank, 'characters': len(text),
            'maximum_line_length': max((len(line) for line in lines), default=0)}


def register(reg: UtilityRegistry) -> None:
    @reg.register('software', 'python_syntax_check', 'Parse Python source and report syntax errors without running code',
                  {'source': S('Source text', max_length=12000)})
    def python_syntax_check(source):
        try:
            _tree(source)
            return {'valid': True, **_line_breakdown(source)}
        except UtilityError as exc:
            return {'valid': False, 'message': str(exc)}

    @reg.register('software', 'python_functions', 'List functions, arguments, line ranges and async markers',
                  {'source': S('Source text', max_length=12000)})
    def python_functions(source):
        return _flatten_functions(_tree(source))

    @reg.register('software', 'python_classes', 'Extract classes, bases, methods, and source line numbers',
                  {'source': S('Source text', max_length=12000)})
    def python_classes(source):
        tree = _tree(source)
        return [{'name': cls.name, 'bases': [ast.unparse(b)[:120] for b in cls.bases],
                 'methods': [f.name for f in cls.body
                             if isinstance(f, (ast.FunctionDef, ast.AsyncFunctionDef))],
                 **_pos(cls)} for cls in ast.walk(tree) if isinstance(cls, ast.ClassDef)]

    @reg.register('software', 'python_imports', 'Extract literal import statements without importing packages',
                  {'source': S('Source', max_length=12000)})
    def python_imports(source):
        return _literal_imports(_tree(source))

    @reg.register('software', 'python_docstrings', 'Collect module, class and function docstrings',
                  {'source': S('Source', max_length=12000)})
    def python_docstrings(source):
        tree = _tree(source)
        result = [{'kind': 'module', 'name': '<module>', 'doc': ast.get_docstring(tree)}]
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                result.append({'kind': 'class' if isinstance(node, ast.ClassDef) else 'function',
                               'name': node.name, 'line': node.lineno,
                               'doc': ast.get_docstring(node)})
        return [entry for entry in result if entry['doc']]

    @reg.register('software', 'python_complexity', 'Estimate branch-based cyclomatic complexity of Python functions',
                  {'source': S('Source', max_length=12000)})
    def python_complexity(source):
        tree = _tree(source)
        result = []
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                result.append({'function': node.name, 'line': node.lineno,
                               'complexity_estimate': _complexity(node)})
        return result

    @reg.register('software', 'python_assignment_names', 'List variables assigned in Python source',
                  {'source': S('Source', max_length=12000)})
    def python_assignment_names(source):
        tree = _tree(source)
        counts = Counter()
        for node in ast.walk(tree):
            if isinstance(node, ast.Name) and isinstance(node.ctx, (ast.Store, ast.Del)):
                counts[node.id] += 1
        return [{'name': name, 'assignments': count} for name, count in sorted(counts.items())]

    @reg.register('software', 'python_definition_outline', 'Produce a class/function declaration outline',
                  {'source': S('Source', max_length=12000)})
    def python_definition_outline(source):
        result = []
        def children(container, prefix='', depth=0):
            if depth > 12:
                return
            for n in container.body:
                if isinstance(n, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
                    kind = 'class' if isinstance(n, ast.ClassDef) else ('async def' if isinstance(n, ast.AsyncFunctionDef) else 'def')
                    result.append({'kind': kind, 'qualified_name': prefix+n.name, 'line': n.lineno,
                                   'depth': depth})
                    children(n, prefix+n.name+'.', depth+1)
        children(_tree(source))
        return result

    @reg.register('software', 'python_ast_counts', 'Count syntax node types in a Python file',
                  {'source': S('Source', max_length=12000)})
    def python_ast_counts(source):
        return dict(sorted(Counter(type(node).__name__ for node in ast.walk(_tree(source))).items()))

    @reg.register('software', 'python_todo_comments', 'Locate TODO and FIXME comments',
                  {'source': S('Source text', max_length=12000)})
    def python_todo_comments(source):
        result = []
        for idx, line in enumerate(source.splitlines(), 1):
            if re.search(r'#.*\b(?:TODO|FIXME)\b', line, re.IGNORECASE):
                result.append({'line': idx, 'text': line.strip()[:200]})
        return result

    @reg.register('software', 'python_keyword_check', 'Check Python keyword and identifier rules',
                  {'name': S('Candidate variable or function name', max_length=100)})
    def python_keyword_check(name):
        return {'identifier': name.isidentifier(), 'reserved': keyword.iskeyword(name),
                'valid_variable': name.isidentifier() and not keyword.iskeyword(name),
                'soft_keyword': keyword.issoftkeyword(name)}

    @reg.register('software', 'python_format_import_suggestions', 'Suggest grouping import modules by name',
                  {'source': S('Source', max_length=12000)})
    def python_format_import_suggestions(source):
        found = _literal_imports(_tree(source))
        names = sorted(set(item['module'] for item in found if not item['relative']))
        return {'modules': names, 'count': len(names)}

    @reg.register('software', 'source_diff', 'Generate a bounded unified diff for two text versions',
                  {'before': S('Earlier text', max_length=10000),
                   'after': S('New text', max_length=10000),
                   'context': I('Context lines', False, 3, 0, 10)})
    def source_diff(before, after, context):
        diff = list(difflib.unified_diff(before.splitlines(), after.splitlines(),
                                         fromfile='before', tofile='after', lineterm='', n=context))
        return {'changed': before != after, 'diff': '\n'.join(diff)[:20000], 'lines': len(diff)}

    @reg.register('software', 'source_lines', 'Count blank and nonblank source lines',
                  {'source': S('Source', max_length=12000)})
    def source_lines(source):
        return _line_breakdown(source)

    @reg.register('software', 'source_indent_profile', 'Summarize indentation widths in source text',
                  {'source': S('Source text', max_length=12000)})
    def source_indent_profile(source):
        counts = Counter(len(row)-len(row.lstrip(' ')) for row in source.splitlines() if row.strip())
        tabs = sum('\t' in row[:len(row)-len(row.lstrip())] for row in source.splitlines())
        return {'spaces': dict(sorted(counts.items())), 'lines_with_tabs': tabs}

    @reg.register('software', 'source_extract_urls', 'Find links appearing in an arbitrary text input',
                  {'source': S('Text to inspect', max_length=12000)})
    def source_extract_urls(source):
        return list(dict.fromkeys(re.findall(r'https?://[^\s<>()"\']{1,250}', source)))[:100]

    @reg.register('software', 'source_find_repeated_lines', 'Count repeated nonempty lines of pasted source',
                  {'source': S('Source', max_length=12000),
                   'minimum': I('Minimum repetitions', False, 2, 2, 20)})
    def source_find_repeated_lines(source, minimum):
        counter = Counter(line.strip() for line in source.splitlines() if line.strip())
        return [{'line': line[:200], 'occurrences': count} for line, count in counter.most_common(50) if count >= minimum]

    @reg.register('software', 'source_bracket_balance', 'Check raw bracket balances for plain text, not a parser',
                  {'source': S('Text', max_length=12000)})
    def source_bracket_balance(source):
        opens = {'(': ')', '[': ']', '{': '}'}
        closes = {right: left for left, right in opens.items()}
        stack = []
        for i, ch in enumerate(source):
            if ch in opens:
                stack.append((ch, i))
            elif ch in closes:
                if not stack or stack[-1][0] != closes[ch]:
                    return {'balanced': False, 'position': i, 'reason': 'unexpected closing bracket'}
                stack.pop()
        return ({'balanced': True} if not stack else
                {'balanced': False, 'position': stack[-1][1], 'reason': 'unclosed bracket'})

    @reg.register('software', 'source_trailing_space_lines', 'Report source lines with trailing whitespace',
                  {'source': S('Source text', max_length=12000)})
    def source_trailing_space_lines(source):
        return [index for index, row in enumerate(source.splitlines(), 1) if row.rstrip() != row]

    @reg.register('software', 'python_call_names', 'List function call names statically from Python source',
                  {'source': S('Source', max_length=12000)})
    def python_call_names(source):
        calls = Counter()
        for node in ast.walk(_tree(source)):
            if isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name):
                    calls[node.func.id] += 1
                elif isinstance(node.func, ast.Attribute):
                    calls[node.func.attr] += 1
        return [{'name': name, 'count': count} for name, count in calls.most_common(100)]

    @reg.register('software', 'python_constant_values', 'List simple module-level constant assignments',
                  {'source': S('Source', max_length=12000)})
    def python_constant_values(source):
        result = []
        for node in _tree(source).body:
            if isinstance(node, ast.Assign) and isinstance(node.value, ast.Constant):
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id.isupper():
                        result.append({'name': target.id, 'value': str(node.value.value)[:200]})
        return result

    @reg.register('software', 'python_unused_import_candidates', 'Find imports whose names are not referenced elsewhere in the AST',
                  {'source': S('Source', max_length=12000)})
    def python_unused_import_candidates(source):
        tree = _tree(source)
        loaded = Counter(node.id for node in ast.walk(tree) if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load))
        candidates = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    name = alias.asname or alias.name.split('.')[0]
                    if loaded[name] == 0:
                        candidates.append({'name': name, 'line': node.lineno})
            elif isinstance(node, ast.ImportFrom):
                for alias in node.names:
                    name = alias.asname or alias.name
                    if name != '*' and loaded[name] == 0:
                        candidates.append({'name': name, 'line': node.lineno})
        return candidates

    @reg.register('software', 'python_mutable_default_candidates', 'Find literal list/dict/set defaults in function definitions',
                  {'source': S('Source', max_length=12000)})
    def python_mutable_default_candidates(source):
        suspects = []
        for node in ast.walk(_tree(source)):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                for default in node.args.defaults + [d for d in node.args.kw_defaults if d is not None]:
                    if isinstance(default, (ast.List, ast.Dict, ast.Set)):
                        suspects.append({'function': node.name, 'line': default.lineno,
                                         'type': type(default).__name__})
        return suspects

    @reg.register('software', 'python_broad_exception_candidates', 'Find bare excepts and broad exception handlers',
                  {'source': S('Source', max_length=12000)})
    def python_broad_exception_candidates(source):
        flagged = []
        for node in ast.walk(_tree(source)):
            if isinstance(node, ast.ExceptHandler):
                kind = ast.unparse(node.type) if node.type else 'bare except'
                if kind in {'bare except', 'Exception', 'BaseException'}:
                    flagged.append({'line': node.lineno, 'handler': kind})
        return flagged
