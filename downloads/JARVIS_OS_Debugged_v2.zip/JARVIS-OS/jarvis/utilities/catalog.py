"""Single-source registry for all deterministic, bounded local skills."""
from __future__ import annotations

from functools import lru_cache

from .core import UtilityRegistry
from . import numbers, dates, measure, statistics, strings, data, graphs, software, probability, time_series, symbolic


@lru_cache(maxsize=1)
def build_utility_registry() -> UtilityRegistry:
    registry = UtilityRegistry()
    # Explicit modules; user input never controls imports.
    for module in (numbers, dates, measure, statistics, strings, data,
                   graphs, software, probability, time_series, symbolic):
        module.register(registry)
    return registry
