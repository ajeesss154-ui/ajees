"""Private JSON REST API for offline utility skills.

A caller can inspect a tool's parameter schema and submit JSON to it.
This is intentionally not a general Python interpreter or shell endpoint.
"""
from __future__ import annotations

import json
from typing import Callable, Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field, model_validator

from .catalog import build_utility_registry
from .core import UtilityError


class UtilityRun(BaseModel):
    name: str = Field(min_length=1, max_length=70)
    arguments: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode='after')
    def input_budget(self):
        if len(json.dumps(self.arguments, ensure_ascii=False, default=str)) > 25000:
            raise ValueError('Input is larger than the 25 KB utility budget')
        return self


def build_router(authenticate: Callable) -> APIRouter:
    router = APIRouter(prefix='/api/utilities', tags=['Offline Skills'],
                       dependencies=[Depends(authenticate)])
    registry = build_utility_registry()

    @router.get('/categories')
    def categories():
        return registry.categories()

    @router.get('/catalog')
    def catalog(category: str | None = Query(default=None, max_length=40)):
        return registry.catalog(category)

    @router.get('/stats')
    def stats():
        return registry.stats()

    @router.get('/catalog/{name}')
    def definition(name: str):
        skill = registry.get(name)
        if not skill:
            raise HTTPException(404, 'Unknown utility')
        return skill.documentation()

    @router.post('/run')
    def run(input: UtilityRun):
        try:
            return registry.execute(input.name, input.arguments)
        except UtilityError as exc:
            raise HTTPException(400, str(exc)) from exc

    return router
