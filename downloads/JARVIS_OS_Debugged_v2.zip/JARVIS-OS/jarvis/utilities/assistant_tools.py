"""Single model-facing entry point to the read-only deterministic skill catalog.

One tool with a named skill avoids exposing hundreds of separate tool definitions
to small local models. No submitted Python code or arbitrary host command runs.
"""
from __future__ import annotations

import json

from jarvis.tools import ToolDefinition, ToolRegistry, obj, field_str, ToolError
from .catalog import build_utility_registry
from .core import UtilityError


def install_utility_tools(registry: ToolRegistry) -> None:
    skills = build_utility_registry()
    names = ', '.join(c['name'] for c in skills.categories())

    def invoke(args: dict):
        name = args.get('name')
        raw = args.get('arguments_json')
        if not isinstance(name, str) or len(name) > 70:
            raise ToolError('Expected a valid utility name')
        if not isinstance(raw, str) or len(raw) > 25000:
            raise ToolError('Utility parameters exceed limit')
        try:
            arguments = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ToolError('Utility arguments must be a JSON object') from exc
        try:
            return skills.execute(name, arguments)
        except UtilityError as exc:
            raise ToolError(str(exc)) from exc

    registry.register(ToolDefinition(
        'run_local_utility',
        ('Compute a deterministic offline utility by name. Available categories: '+names+
         '. Use the /api/utilities/catalog endpoint to discover exact names and JSON schemas.'),
        obj({'name': field_str('Exact local utility skill name'),
             'arguments_json': field_str('JSON object containing the skill parameters')},
            ['name', 'arguments_json']),
        invoke, requires_approval=False))
