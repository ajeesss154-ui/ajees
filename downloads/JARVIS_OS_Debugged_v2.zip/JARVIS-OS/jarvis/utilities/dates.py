"""Timezone-aware date/time and calendar arithmetic, independent of cloud APIs."""
from __future__ import annotations

from datetime import datetime,date,time,timedelta,timezone
from zoneinfo import ZoneInfo,ZoneInfoNotFoundError
import calendar
import re
from typing import Any

from .core import UtilityRegistry, UtilityError,S,I,N,B,A,O


def _parse_date(raw:str) -> date:
    try:return date.fromisoformat(raw)
    except ValueError as exc:raise UtilityError('Use ISO date YYYY-MM-DD') from exc


def _parse_datetime(raw:str) -> datetime:
    try:dt=datetime.fromisoformat(raw.replace('Z','+00:00'))
    except ValueError as exc:raise UtilityError('Use ISO 8601 datetime') from exc
    if dt.tzinfo is None:raise UtilityError('Datetime must have a timezone offset')
    return dt


def _tz(name:str) -> ZoneInfo:
    try:return ZoneInfo(name)
    except (ZoneInfoNotFoundError,ValueError,KeyError) as exc:
        raise UtilityError('Unknown IANA timezone') from exc


def _delta_to_dict(td:timedelta) -> dict:
    seconds=int(td.total_seconds())
    sign=-1 if seconds<0 else 1
    left=abs(seconds)
    days,left=divmod(left,86400)
    hours,left=divmod(left,3600)
    minutes,seconds=divmod(left,60)
    return {'sign':sign,'days':days,'hours':hours,'minutes':minutes,'seconds':seconds}


def _add_months(d:date,count:int) -> date:
    year=(d.year*12+d.month-1+count)//12
    month=(d.month-1+count)%12+1
    if not 1<=year<=9999:raise UtilityError('Date exceeds supported year range')
    return date(year,month,min(d.day,calendar.monthrange(year,month)[1]))


def register(reg:UtilityRegistry) -> None:
    @reg.register('dates','days_between','Calculate signed calendar days between two ISO dates',
                  {'start':S('YYYY-MM-DD'),'end':S('YYYY-MM-DD')})
    def days_between(start,end):
        return {'days':(_parse_date(end)-_parse_date(start)).days}

    @reg.register('dates','add_days','Add or subtract calendar days',
                  {'date':S('YYYY-MM-DD'),'days':I('Signed number of days',minimum=-365000,maximum=365000)})
    def add_days(date,days):
        try:return (_parse_date(date)+timedelta(days=days)).isoformat()
        except OverflowError as exc:raise UtilityError('Date outside supported range') from exc

    @reg.register('dates','add_months','Add calendar months, clamping day to month length',
                  {'date':S('YYYY-MM-DD'),'months':I('Signed number of months',minimum=-12000,maximum=12000)})
    def add_months(date,months):
        return _add_months(_parse_date(date),months).isoformat()

    @reg.register('dates','start_end_of_month','Get first and last day of a month',
                  {'date':S('A date within the month')})
    def start_end_of_month(date):
        d=_parse_date(date)
        return {'first':d.replace(day=1).isoformat(),
                'last':d.replace(day=calendar.monthrange(d.year,d.month)[1]).isoformat(),
                'days':calendar.monthrange(d.year,d.month)[1]}

    @reg.register('dates','weekday','Read weekday name and ISO weekday number for a date',
                  {'date':S('YYYY-MM-DD')})
    def weekday(date):
        d=_parse_date(date)
        return {'name':d.strftime('%A'),'iso_number':d.isoweekday(),'weekend':d.isoweekday()>5}

    @reg.register('dates','iso_week','Read ISO week, weekday and week-numbering year',
                  {'date':S('YYYY-MM-DD')})
    def iso_week(date):
        value=_parse_date(date).isocalendar()
        return {'year':value.year,'week':value.week,'weekday':value.weekday}

    @reg.register('dates','leap_year','Check Gregorian leap-year status',
                  {'year':I('Year',minimum=1,maximum=9999)})
    def leap_year(year):
        return {'year':year,'leap':calendar.isleap(year),
                'february_days':29 if calendar.isleap(year) else 28}

    @reg.register('dates','calendar_month','Create a month grid of dates and empty cells',
                  {'year':I('Year',minimum=1,maximum=9999),
                   'month':I('Month',minimum=1,maximum=12),
                   'monday_first':B('Start weeks on Monday',False,True)})
    def calendar_month(year,month,monday_first):
        cal=calendar.Calendar(firstweekday=0 if monday_first else 6)
        return {'year':year,'month':month,
                'weeks':[[d.isoformat() if d.month==month else None
                          for d in week] for week in cal.monthdatescalendar(year,month)]}

    @reg.register('dates','business_days','Count weekdays Monday–Friday in inclusive date range, not holidays',
                  {'start':S('YYYY-MM-DD'),'end':S('YYYY-MM-DD')})
    def business_days(start,end):
        first,last=_parse_date(start),_parse_date(end)
        if last<first:raise UtilityError('End must not be before start')
        days=(last-first).days+1
        if days>36500:raise UtilityError('Range exceeds 100 years')
        weeks,remainder=divmod(days,7)
        count=weeks*5
        for i in range(remainder):
            if (first.weekday()+i)%7<5:count+=1
        return {'business_days':count,'calendar_days':days,'excludes_holidays':False}

    @reg.register('dates','add_business_days','Advance a specified number of weekdays',
                  {'start':S('YYYY-MM-DD'),'days':I('Signed weekdays',minimum=-10000,maximum=10000)})
    def add_business_days(start,days):
        current=_parse_date(start);direction=1 if days>=0 else -1
        remaining=abs(days)
        while remaining:
            current+=timedelta(days=direction)
            if current.weekday()<5:remaining-=1
        return current.isoformat()

    @reg.register('dates','timezone_convert','Convert an explicit timestamp between IANA timezones',
                  {'timestamp':S('ISO datetime with UTC offset'),
                   'destination':S('IANA zone name, e.g. Asia/Kolkata')})
    def timezone_convert(timestamp,destination):
        target=_parse_datetime(timestamp).astimezone(_tz(destination))
        return {'local':target.isoformat(),'offset':target.utcoffset().total_seconds()/3600,
                'timezone':destination}

    @reg.register('dates','datetime_difference','Calculate a signed difference between instants',
                  {'start':S('ISO datetime with offset'),'end':S('ISO datetime with offset')})
    def datetime_difference(start,end):
        return _delta_to_dict(_parse_datetime(end)-_parse_datetime(start))

    @reg.register('dates','minutes_to_duration','Display total minutes as days, hours and minutes',
                  {'minutes':I('Total signed minutes',minimum=-10000000,maximum=10000000)})
    def minutes_to_duration(minutes):
        return _delta_to_dict(timedelta(minutes=minutes))

    @reg.register('dates','time_block_count','Count complete focus blocks fitting into available minutes',
                  {'available_minutes':I('Available time',minimum=0,maximum=10080),
                   'work_minutes':I('Work block length',minimum=1,maximum=240),
                   'break_minutes':I('Rest block length',False,5,0,120)})
    def time_block_count(available_minutes,work_minutes,break_minutes):
        if available_minutes<work_minutes:return {'complete_blocks':0,'work_minutes':0,'break_minutes':0}
        blocks=(available_minutes+break_minutes)//(work_minutes+break_minutes)
        return {'complete_blocks':blocks,'work_minutes':blocks*work_minutes,
                'break_minutes':(blocks-1)*break_minutes}

    @reg.register('dates','deadline_progress','Measure date-based progress through a known project timeline',
                  {'started':S('YYYY-MM-DD'),'deadline':S('YYYY-MM-DD'),
                   'current':S('YYYY-MM-DD')})
    def deadline_progress(started,deadline,current):
        start,end,now=map(_parse_date,(started,deadline,current))
        span=(end-start).days
        if span<=0:raise UtilityError('Deadline must be later than start')
        elapsed=(now-start).days
        return {'elapsed_days':elapsed,'total_days':span,
                'elapsed_percent':round(100*max(0,min(span,elapsed))/span,2),
                'days_remaining':(end-now).days}

    @reg.register('dates','nth_weekday','Find the Nth specified weekday in a calendar month',
                  {'year':I('Year',minimum=1,maximum=9999),
                   'month':I('Month',minimum=1,maximum=12),
                   'weekday':I('Monday=0 through Sunday=6',minimum=0,maximum=6),
                   'occurrence':I('Nth occurrence, 1–5',minimum=1,maximum=5)})
    def nth_weekday(year,month,weekday,occurrence):
        first=date(year,month,1)
        offset=(weekday-first.weekday())%7
        day=1+offset+7*(occurrence-1)
        if day>calendar.monthrange(year,month)[1]:raise UtilityError('That occurrence does not exist')
        return date(year,month,day).isoformat()

    @reg.register('dates','date_range','Generate an inclusive list of dates in a short interval',
                  {'start':S('YYYY-MM-DD'),'end':S('YYYY-MM-DD'),
                   'every_days':I('Interval in days',False,1,1,365)})
    def date_range(start,end,every_days):
        first,last=_parse_date(start),_parse_date(end)
        count=(last-first).days
        if count<0 or count>400:raise UtilityError('Date span must be 0–400 days')
        return [(first+timedelta(days=i)).isoformat() for i in range(0,count+1,every_days)]

    @reg.register('dates','time_slot_schedule','Make fixed-duration study or work slots',
                  {'start':S('ISO timestamp with timezone'),'number':I('Slots',minimum=1,maximum=24),
                   'slot_minutes':I('Time per slot',minimum=5,maximum=240),
                   'break_minutes':I('Break after each slot',False,10,0,120)})
    def time_slot_schedule(start,number,slot_minutes,break_minutes):
        start_at=_parse_datetime(start);result=[]
        for i in range(number):
            end_at=start_at+timedelta(minutes=slot_minutes)
            result.append({'slot':i+1,'start':start_at.isoformat(),'end':end_at.isoformat()})
            start_at=end_at+timedelta(minutes=break_minutes)
        return result

    @reg.register('dates','overlap_time_ranges','Find intersection of two timezone-aware intervals',
                  {'first_start':S('Timestamp'),'first_end':S('Timestamp'),
                   'second_start':S('Timestamp'),'second_end':S('Timestamp')})
    def overlap_time_ranges(first_start,first_end,second_start,second_end):
        a,b,c,d=map(_parse_datetime,(first_start,first_end,second_start,second_end))
        if a>b or c>d:raise UtilityError('End cannot precede start')
        lower=max(a,c);upper=min(b,d)
        if upper<=lower:return {'overlap':False,'seconds':0}
        return {'overlap':True,'start':lower.isoformat(),'end':upper.isoformat(),
                'seconds':int((upper-lower).total_seconds())}

    @reg.register('dates','parse_time_hhmm','Parse 24-hour clock time to elapsed minutes',
                  {'time':S('HH:MM')})
    def parse_time_hhmm(time):
        match=re.fullmatch(r'([01]\d|2[0-3]):([0-5]\d)',time)
        if not match:raise UtilityError('Use time HH:MM in 24-hour clock')
        return {'hours':int(match[1]),'minutes':int(match[2]),
                'minutes_since_midnight':int(match[1])*60+int(match[2])}

    @reg.register('dates','format_time_hhmm','Convert minutes since midnight to HH:MM, wrapping each day',
                  {'minutes':I('Minutes',minimum=-100000,maximum=100000)})
    def format_time_hhmm(minutes):
        total=minutes%1440
        return f'{total//60:02}:{total%60:02}'
