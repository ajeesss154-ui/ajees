"""Bounded graph algorithms for dependencies, schedules, and path planning.

The graph tools do not inspect the computer or network. Nodes are short user-
supplied labels, edges are small JSON arrays, and algorithms are deterministic.
"""
from __future__ import annotations

from collections import Counter, defaultdict, deque
import heapq
import math
from typing import Any

from .core import UtilityError, UtilityRegistry, S, I, N, A, B


def _graph(nodes: list, edges: list, directed: bool = True, weighted: bool = False):
    if not isinstance(nodes, list) or len(nodes) > 150:
        raise UtilityError('At most 150 graph nodes')
    if any(not isinstance(n, str) or not n or len(n) > 100 for n in nodes):
        raise UtilityError('Node IDs must be short text strings')
    if len(set(nodes)) != len(nodes):
        raise UtilityError('Duplicate graph node')
    if not isinstance(edges, list) or len(edges) > 1000:
        raise UtilityError('At most 1000 graph edges')
    adj = {n: [] for n in nodes}
    for entry in edges:
        if not isinstance(entry, list) or len(entry) != (3 if weighted else 2):
            raise UtilityError('Edge must have two node labels and optional weight')
        src, dst = entry[:2]
        if src not in adj or dst not in adj:
            raise UtilityError('Edge references an unknown node')
        cost = entry[2] if weighted else 1
        if type(cost) not in (float, int) or not math.isfinite(cost):
            raise UtilityError('Weight must be finite')
        if weighted and cost < 0:
            raise UtilityError('Negative edge weights are unsupported')
        adj[src].append((dst, cost))
        if not directed:
            adj[dst].append((src, cost))
    return adj


def _bfs(adj: dict, start: str):
    queue = deque([start])
    distance = {start: 0}
    parents = {start: None}
    while queue:
        node = queue.popleft()
        for neighbor, _ in adj[node]:
            if neighbor not in distance:
                distance[neighbor] = distance[node] + 1
                parents[neighbor] = node
                queue.append(neighbor)
    return distance, parents


def _path(parents: dict, target: str):
    if target not in parents:
        return []
    nodes = []
    while target is not None:
        nodes.append(target)
        target = parents[target]
    return nodes[::-1]


def _toposort(adj: dict):
    degree = {node: 0 for node in adj}
    for neighbors in adj.values():
        for destination, _ in neighbors:
            degree[destination] += 1
    queue = deque(sorted(n for n, k in degree.items() if not k))
    result = []
    while queue:
        node = queue.popleft()
        result.append(node)
        for successor, _ in adj[node]:
            degree[successor] -= 1
            if degree[successor] == 0:
                queue.append(successor)
    if len(result) != len(adj):
        raise UtilityError('Graph contains a directed cycle')
    return result


def _dijkstra(adj: dict, source: str):
    heap = [(0., source)]
    distance = {source: 0.}
    parent = {source: None}
    while heap:
        cost, node = heapq.heappop(heap)
        if cost != distance[node]:
            continue
        for neighbor, weight in adj[node]:
            newcost = cost + weight
            if newcost < distance.get(neighbor, float('inf')):
                distance[neighbor] = newcost
                parent[neighbor] = node
                heapq.heappush(heap, (newcost, neighbor))
    return distance, parent


def _components(adj: dict) -> list[list[str]]:
    seen = set()
    result = []
    for node in adj:
        if node in seen:
            continue
        component = []
        queue = deque([node])
        seen.add(node)
        while queue:
            current = queue.popleft()
            component.append(current)
            for neighbor, _ in adj[current]:
                if neighbor not in seen:
                    seen.add(neighbor)
                    queue.append(neighbor)
        result.append(sorted(component))
    return sorted(result, key=lambda c: (-len(c), c))


def register(reg: UtilityRegistry) -> None:
    @reg.register('graphs', 'graph_shortest_path', 'Shortest unweighted path between two nodes',
                  {'nodes': A('Node labels'), 'edges': A('Node pairs', max_length=1000),
                   'source': S('Start node'), 'target': S('End node'),
                   'directed': B('Use directed edges', False, False)})
    def graph_shortest_path(nodes, edges, source, target, directed):
        adj = _graph(nodes, edges, directed=directed)
        if source not in adj or target not in adj:
            raise UtilityError('Unknown source or destination')
        distance, parent = _bfs(adj, source)
        return {'path': _path(parent, target), 'distance': distance.get(target),
                'reachable': target in distance}

    @reg.register('graphs', 'graph_weighted_shortest_path', 'Dijkstra shortest path with positive weights',
                  {'nodes': A('Node labels'), 'edges': A('Triples [from,to,cost]', max_length=1000),
                   'source': S('Start'), 'target': S('End'),
                   'directed': B('Direction matters', False, False)})
    def graph_weighted_shortest_path(nodes, edges, source, target, directed):
        adj = _graph(nodes, edges, directed=directed, weighted=True)
        if source not in adj or target not in adj:
            raise UtilityError('Unknown start or end')
        dist, parents = _dijkstra(adj, source)
        return {'path': _path(parents, target), 'distance': dist.get(target)}

    @reg.register('graphs', 'graph_reachable', 'List nodes reachable from a given node',
                  {'nodes': A('Node labels'), 'edges': A('Edges', max_length=1000),
                   'source': S('Start'), 'directed': B('Directed graph', False, True)})
    def graph_reachable(nodes, edges, source, directed):
        adj = _graph(nodes, edges, directed=directed)
        if source not in adj:
            raise UtilityError('Unknown node')
        dist, _ = _bfs(adj, source)
        return {'reachable': sorted(dist), 'distance_in_edges': dist}

    @reg.register('graphs', 'graph_components', 'Connected components in an undirected graph',
                  {'nodes': A('Nodes'), 'edges': A('Edges', max_length=1000)})
    def graph_components(nodes, edges):
        components = _components(_graph(nodes, edges, directed=False))
        return {'components': components, 'count': len(components)}

    @reg.register('graphs', 'graph_topological_order', 'Order prerequisites in a directed acyclic graph',
                  {'nodes': A('Nodes'), 'edges': A('Pairs [prerequisite,dependent]', max_length=1000)})
    def graph_topological_order(nodes, edges):
        return _toposort(_graph(nodes, edges, directed=True))

    @reg.register('graphs', 'graph_has_cycle', 'Test directed graph for a dependency cycle',
                  {'nodes': A('Nodes'), 'edges': A('Edges', max_length=1000)})
    def graph_has_cycle(nodes, edges):
        try:
            _toposort(_graph(nodes, edges))
            return {'has_cycle': False}
        except UtilityError as exc:
            if 'cycle' in str(exc):
                return {'has_cycle': True}
            raise

    @reg.register('graphs', 'graph_degree', 'Compute degree statistics of graph nodes',
                  {'nodes': A('Nodes'), 'edges': A('Edges', max_length=1000),
                   'directed': B('Directed graph', False, True)})
    def graph_degree(nodes, edges, directed):
        adj = _graph(nodes, edges, directed=directed)
        outgoing = {n: len(neighbors) for n, neighbors in adj.items()}
        incoming = Counter()
        for neighbors in adj.values():
            for n, _ in neighbors:
                incoming[n] += 1
        return [{'node': n, 'out': outgoing[n], 'in': incoming[n]}
                for n in nodes]

    @reg.register('graphs', 'graph_adjacency_list', 'Represent an edge list as a node-neighbor dictionary',
                  {'nodes': A('Nodes'), 'edges': A('Edges', max_length=1000),
                   'directed': B('Directed graph', False, False)})
    def graph_adjacency_list(nodes, edges, directed):
        adj = _graph(nodes, edges, directed=directed)
        return {n: [dest for dest, _ in neighbors] for n, neighbors in adj.items()}

    @reg.register('graphs', 'graph_adjacency_matrix', 'Create a small binary adjacency matrix',
                  {'nodes': A('Nodes', max_length=50), 'edges': A('Edges', max_length=1000),
                   'directed': B('Directed graph', False, False)})
    def graph_adjacency_matrix(nodes, edges, directed):
        adj = _graph(nodes, edges, directed=directed)
        return {'nodes': nodes,
                'matrix': [[int(any(n == d for d, _ in adj[src])) for n in nodes] for src in nodes]}

    @reg.register('graphs', 'graph_edges_from_matrix', 'Convert an adjacency matrix into an edge list',
                  {'nodes': A('Nodes', max_length=50), 'matrix': A('Binary matrix', max_length=50)})
    def graph_edges_from_matrix(nodes, matrix):
        if len(nodes) != len(matrix):
            raise UtilityError('Matrix dimension mismatch')
        if any(not isinstance(row, list) or len(row) != len(nodes) for row in matrix):
            raise UtilityError('Matrix must be square')
        return [[nodes[i], nodes[j]] for i, row in enumerate(matrix)
                for j, cell in enumerate(row) if cell]

    @reg.register('graphs', 'graph_bipartite', 'Check whether an undirected graph can be two-colored',
                  {'nodes': A('Nodes'), 'edges': A('Edges', max_length=1000)})
    def graph_bipartite(nodes, edges):
        adj = _graph(nodes, edges, directed=False)
        color = {}
        for node in nodes:
            if node in color:
                continue
            color[node] = 0
            queue = deque([node])
            while queue:
                n = queue.popleft()
                for m, _ in adj[n]:
                    if m not in color:
                        color[m] = 1 - color[n]
                        queue.append(m)
                    elif color[m] == color[n]:
                        return {'bipartite': False}
        return {'bipartite': True, 'groups': [[n for n, c in color.items() if c == v] for v in (0, 1)]}

    @reg.register('graphs', 'graph_critical_path', 'Calculate a dependency path for tasks with durations',
                  {'tasks': A('Objects with id, duration, dependencies', max_length=100)})
    def graph_critical_path(tasks):
        if any(not isinstance(t, dict) for t in tasks):
            raise UtilityError('Tasks must be objects')
        labels = [t.get('id') for t in tasks]
        if any(not isinstance(label, str) or not label for label in labels):
            raise UtilityError('Each task needs a string ID')
        dependencies = []
        durations = {}
        for task in tasks:
            duration = task.get('duration')
            if type(duration) not in (float, int) or duration < 0 or duration > 1e6:
                raise UtilityError('Duration must be nonnegative numeric')
            durations[task['id']] = duration
            deps = task.get('dependencies', [])
            if not isinstance(deps, list):
                raise UtilityError('Dependencies must be a list')
            dependencies.extend([[dep, task['id']] for dep in deps])
        adj = _graph(labels, dependencies)
        order = _toposort(adj)
        start = {n: 0 for n in labels}
        predecessor = {n: None for n in labels}
        for node in order:
            for successor, _ in adj[node]:
                end = start[node] + durations[node]
                if end > start[successor]:
                    start[successor] = end
                    predecessor[successor] = node
        if not order:
            return {'total_duration': 0, 'critical_path': [], 'schedule': []}
        final = max(order, key=lambda n: start[n] + durations[n])
        chain = []
        step = final
        while step is not None:
            chain.append(step)
            step = predecessor[step]
        return {'total_duration': start[final] + durations[final],
                'critical_path': chain[::-1],
                'schedule': [{'task': n, 'start': start[n], 'end': start[n] + durations[n]}
                             for n in order]}

    @reg.register('graphs', 'graph_dependency_levels', 'Group dependent tasks into parallelizable levels',
                  {'nodes': A('Task names'), 'edges': A('Prerequisite pairs', max_length=1000)})
    def graph_dependency_levels(nodes, edges):
        adj = _graph(nodes, edges)
        order = _toposort(adj)
        level = {node: 0 for node in nodes}
        for n in order:
            for m, _ in adj[n]:
                level[m] = max(level[m], level[n] + 1)
        return [[n for n in order if level[n] == lvl] for lvl in range(max(level.values(), default=-1) + 1)]

    @reg.register('graphs', 'graph_closeness', 'Estimate closeness centrality using shortest hop counts',
                  {'nodes': A('Nodes'), 'edges': A('Edges', max_length=1000)})
    def graph_closeness(nodes, edges):
        adj = _graph(nodes, edges, directed=False)
        result = {}
        for node in nodes:
            distance, _ = _bfs(adj, node)
            result[node] = round((len(distance)-1) / sum(distance.values()), 6) if sum(distance.values()) else 0
        return result

    @reg.register('graphs', 'graph_density', 'Calculate the density of a graph',
                  {'nodes': A('Nodes'), 'edges': A('Edges', max_length=1000),
                   'directed': B('Directed', False, False)})
    def graph_density(nodes, edges, directed):
        _graph(nodes, edges, directed)
        n = len(nodes)
        edge_set = set((a,b) if directed else tuple(sorted((a,b))) for a,b in edges)
        possible = n*(n-1) if directed else n*(n-1)/2
        return {'nodes': n, 'edges': len(edge_set),
                'density': round(len(edge_set)/possible, 8) if possible else 0}
