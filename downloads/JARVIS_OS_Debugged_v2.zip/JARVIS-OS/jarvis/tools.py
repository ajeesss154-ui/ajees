"""Allowlisted computer-control tools with explicit approval for device actions.

The model cannot execute arbitrary shell commands, navigate outside the workspace,
read browser profiles or use arbitrary Python code. Tool JSON is never trusted.
"""
from __future__ import annotations

import ast
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
import json
import math
import operator
from pathlib import Path
import platform
import shutil
import subprocess
from typing import Callable, Any
from urllib.parse import urlsplit
import webbrowser

import psutil

from .storage import Database, utcnow
from .config import Settings
from .retrieval import KnowledgeSearch
from .advanced.security import SecurityError, validate_relative_path


class ToolError(Exception):
    pass


@dataclass(slots=True)
class ToolDefinition:
    name: str
    description: str
    parameters: dict
    handler: Callable[[dict], Any]
    requires_approval: bool = False

    def schema(self) -> dict:
        return {"type": "function", "function": {
            "name": self.name, "description": self.description,
            "parameters": self.parameters,
        }}


def obj(properties: dict, required: list[str] | None = None) -> dict:
    return {"type": "object", "properties": properties,
            "required": required or [], "additionalProperties": False}


def field_str(description: str) -> dict:
    return {"type": "string", "description": description}


def _str(args: dict, key: str, maximum: int = 1000) -> str:
    v = args.get(key)
    if not isinstance(v, str) or not v.strip() or len(v) > maximum:
        raise ToolError(f"'{key}' must be a nonempty string up to {maximum} characters")
    return v.strip()


def _bool(args: dict, key: str, default: bool = False) -> bool:
    v = args.get(key, default)
    if not isinstance(v, bool):
        raise ToolError(f"'{key}' must be boolean")
    return v


_OPERATORS = {
    ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
    ast.Div: operator.truediv, ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod, ast.Pow: operator.pow,
    ast.UAdd: operator.pos, ast.USub: operator.neg,
}


def safe_calculate(expression: str) -> int | float:
    """Evaluate basic arithmetic safely without eval()."""
    if len(expression) > 120:
        raise ToolError("Expression too long")
    try:
        tree = ast.parse(expression, mode="eval")
    except SyntaxError as exc:
        raise ToolError("Invalid arithmetic expression") from exc

    def walk(node: ast.AST, depth: int = 0) -> int | float:
        if depth > 15:
            raise ToolError("Too deeply nested")
        if isinstance(node, ast.Expression):
            return walk(node.body, depth + 1)
        if isinstance(node, ast.Constant) and type(node.value) in {int, float}:
            if abs(node.value) > 1e12:
                raise ToolError("Number too large")
            return node.value
        if isinstance(node, ast.UnaryOp) and type(node.op) in (ast.UAdd, ast.USub):
            return _OPERATORS[type(node.op)](walk(node.operand, depth + 1))
        if isinstance(node, ast.BinOp) and type(node.op) in _OPERATORS:
            lhs, rhs = walk(node.left, depth + 1), walk(node.right, depth + 1)
            if isinstance(node.op, ast.Pow) and (abs(rhs) > 10 or abs(lhs) > 1e6):
                raise ToolError("Power exceeds safe limit")
            try:
                result = _OPERATORS[type(node.op)](lhs, rhs)
            except (OverflowError, ZeroDivisionError) as exc:
                raise ToolError("Math error: " + str(exc)) from exc
            if not math.isfinite(float(result)) or abs(result) > 1e15:
                raise ToolError("Result exceeds safe limit")
            return result
        raise ToolError("Only arithmetic operations are permitted")

    return walk(tree)


def parse_due_at(raw: str) -> str:
    """Require an explicit ISO timestamp with UTC offset (no ambiguous local time)."""
    try:
        dt = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ToolError("Use ISO datetime such as 2026-11-01T15:30:00+05:30") from exc
    if dt.tzinfo is None:
        raise ToolError("Reminder must include timezone offset, e.g. +05:30")
    if dt <= datetime.now(timezone.utc):
        raise ToolError("Reminder time must be in the future")
    if dt > datetime.now(timezone.utc) + timedelta(days=365 * 5):
        raise ToolError("Reminder is too far into the future")
    return dt.astimezone(timezone.utc).isoformat(timespec="seconds")


# Only explicit applications from this mapping can be launched, without shell=True.
APP_ALIASES = {
    "windows": {
        "calculator": ["calc.exe"], "notepad": ["notepad.exe"],
        "file manager": ["explorer.exe"], "vscode": ["code.cmd"],
    },
    "darwin": {
        "calculator": ["open", "-a", "Calculator"],
        "text editor": ["open", "-a", "TextEdit"],
        "file manager": ["open", "-a", "Finder"],
        "vscode": ["open", "-a", "Visual Studio Code"],
    },
    "linux": {
        "calculator": ["gnome-calculator"],
        "text editor": ["gedit"], "file manager": ["xdg-open", "."],
        "vscode": ["code"],
    },
}


class ToolRegistry:
    def __init__(self, db: Database, settings: Settings):
        self.db = db
        self.settings = settings
        self._tools: dict[str, ToolDefinition] = {}
        self._register_defaults()

    def register(self, spec: ToolDefinition) -> None:
        if spec.name in self._tools:
            raise ValueError(f"Duplicate tool: {spec.name}")
        self._tools[spec.name] = spec

    def schemas(self) -> list[dict]:
        return [spec.schema() for spec in self._tools.values()]

    def catalog(self) -> list[dict]:
        return [{"name": t.name, "description": t.description, "approval": t.requires_approval} for t in self._tools.values()]

    def handle(self, name: str, args: dict, approved: bool = False, audit: bool = True) -> dict:
        if name not in self._tools:
            return {"error": f"Unknown tool: {name}"}
        if not isinstance(args, dict):
            return {"error": "Tool arguments must be an object"}
        tool = self._tools[name]
        spec = tool.parameters
        unknown = set(args) - set(spec["properties"])
        missing = set(spec["required"]) - set(args)
        if unknown or missing:
            return {"error": f"Invalid arguments: unknown={sorted(unknown)}, missing={sorted(missing)}"}
        for key, value in args.items():
            typ = spec["properties"][key]["type"]
            if typ == "string" and not isinstance(value, str):
                return {"error": f"{key} must be a string"}
            if typ == "boolean" and not isinstance(value, bool):
                return {"error": f"{key} must be a boolean"}
            # JSON integers do not include booleans, strings, or fractional
            # numbers. Python's bool subclasses int, so check the exact type.
            if typ == "integer" and type(value) is not int:
                return {"error": f"{key} must be an integer"}
            if typ == "number" and (type(value) not in {int, float}
                                    or not math.isfinite(value)):
                return {"error": f"{key} must be a finite number"}
            if isinstance(value, str) and len(value) > 50000:
                return {"error": f"{key} is too long"}
        if tool.requires_approval and not approved:
            expires = (datetime.now(timezone.utc) + timedelta(minutes=10)).isoformat(timespec="seconds")
            pending = self.db.add_approval(name, args,
                f"{name.replace('_', ' ')}: {json.dumps(args, ensure_ascii=False)[:200]}", expires)
            if audit:
                self.db.audit(name, args, "pending", "Waiting for user approval")
            return {"approval_required": True, **pending}
        try:
            result = tool.handler(args)
            if audit:
                self.db.audit(name, args, "success", json.dumps(result, default=str))
            return {"ok": True, "result": result}
        except (ToolError, OSError, ValueError, TypeError) as exc:
            if audit:
                self.db.audit(name, args, "error", str(exc))
            return {"error": str(exc)}

    def _workspace_path(self, raw: str, may_exist: bool = True) -> Path:
        try:
            return validate_relative_path(self.settings.workspace, raw, must_exist=may_exist)
        except SecurityError as exc:
            raise ToolError(str(exc)) from exc

    def _register_defaults(self) -> None:
        def reg(name: str, desc: str, props: dict, required: list[str], fn: Callable, approval: bool = False):
            self.register(ToolDefinition(name, desc, obj(props, required), fn, approval))

        reg("get_time", "Current local date, time and timezone on the server computer", {}, [],
            lambda _: {"local_time": datetime.now().astimezone().isoformat(timespec="seconds")})

        def computer_status(_: dict) -> dict:
            try:
                battery = psutil.sensors_battery()
            except OSError:
                # Some Linux containers have no /sys/class/power_supply directory.
                battery = None
            mem = psutil.virtual_memory()
            return {
                "platform": platform.platform(), "cpu_percent": psutil.cpu_percent(interval=0.1),
                "cpu_logical_cores": psutil.cpu_count(),
                "ram_total_gb": round(mem.total / (1024**3), 2),
                "ram_used_percent": mem.percent,
                "battery_percent": battery.percent if battery else None,
                "battery_plugged_in": battery.power_plugged if battery else None,
                "disk_usage_percent": psutil.disk_usage(str(self.settings.workspace)).percent,
            }
        reg("computer_status", "Read CPU, RAM, battery, disk and OS telemetry", {}, [], computer_status)

        reg("calculate", "Safely calculate an arithmetic expression", {"expression": field_str("Example: (18+5)*3")}, ["expression"],
            lambda a: {"expression": _str(a, "expression", 120), "answer": safe_calculate(_str(a, "expression", 120))})

        reg("remember_fact", "Remember a short user-requested fact (not passwords or secrets)",
            {"key": field_str("Fact key"), "value": field_str("Fact to save")}, ["key", "value"],
            lambda a: self.db.remember(_str(a, "key", 100), _str(a, "value", 1000)))
        reg("recall_facts", "List saved user facts", {}, [], lambda a: self.db.facts())
        reg("forget_fact", "Forget one previously saved fact by key", {"key": field_str("Key of fact")}, ["key"],
            lambda a: {"forgotten": self.db.forget(_str(a, "key", 100))})

        reg("add_note", "Save a new private note", {"title": field_str("Short note title"), "body": field_str("Note body")}, ["title", "body"],
            lambda a: self.db.save_note(_str(a, "title", 120), _str(a, "body", 20000)))
        reg("search_notes", "Find saved notes by title or body", {"query": field_str("Search term")}, ["query"],
            lambda a: self.db.notes(_str(a, "query", 200)))
        reg("list_notes", "List recent private notes", {}, [], lambda a: self.db.notes())
        reg("read_note", "Read a note by its ID", {"note_id": field_str("Exact UUID from list_notes")}, ["note_id"],
            lambda a: self.db.read_note(_str(a, "note_id", 80)) or {"error": "Not found"})
        knowledge = KnowledgeSearch(self.db, self.settings.workspace)
        reg("search_knowledge", "Find relevant excerpts using TF-IDF ML from user notes and workspace files (not the whole PC)",
            {"query": field_str("Natural-language topic or keyword query")}, ["query"],
            lambda a: knowledge.search(_str(a, "query", 350)))

        reg("create_task", "Create a to-do task", {"title": field_str("Task description")}, ["title"],
            lambda a: self.db.add_task(_str(a, "title", 300)))
        reg("list_tasks", "Show open to-dos or all tasks", {"include_completed": {"type": "boolean"}}, [],
            lambda a: self.db.tasks(_bool(a, "include_completed")))
        reg("complete_task", "Complete a task by ID", {"task_id": field_str("Exact task ID")}, ["task_id"],
            lambda a: {"completed": self.db.complete_task(_str(a, "task_id", 80))})

        reg("set_reminder", "Schedule a reminder while JARVIS server is running. Requires ISO date/time with timezone offset.",
            {"text": field_str("Reminder text"), "due_at": field_str("Future ISO datetime with UTC offset, e.g. 2026-11-01T09:00:00+05:30")},
            ["text", "due_at"], lambda a: self.db.add_reminder(_str(a, "text", 500), parse_due_at(_str(a, "due_at", 40))))
        reg("list_reminders", "List upcoming reminders", {}, [], lambda a: self.db.reminders())

        def list_workspace(a: dict) -> list[dict]:
            root = self.settings.workspace.resolve()
            raw = a.get("path", "")
            folder = root if not raw else self._workspace_path(_str(a, "path", 200))
            if not folder.is_dir():
                raise ToolError("Not a folder")
            if not folder.is_relative_to(root):
                raise ToolError("Outside workspace")
            contents = []
            for entry in sorted(folder.iterdir())[:100]:
                if entry.is_symlink() or not entry.resolve().is_relative_to(root):
                    continue
                try:
                    self._workspace_path(str(entry.relative_to(root)))
                except ToolError:
                    continue
                contents.append({"name": str(entry.relative_to(root)), "folder": entry.is_dir(),
                                 "size_bytes": entry.stat().st_size if entry.is_file() else None})
            return contents
        reg("list_workspace", "List files in the restricted JARVIS workspace", {"path": field_str("Optional relative folder")}, [], list_workspace)

        def read_workspace(a: dict) -> dict:
            file = self._workspace_path(_str(a, "path", 250))
            if not file.is_file() or file.suffix.lower() not in {".txt", ".md", ".py", ".json", ".csv", ".yaml", ".yml"}:
                raise ToolError("Only common text files are readable")
            if file.stat().st_size > 80000:
                raise ToolError("File is too large (80 KB max)")
            return {"path": str(file.relative_to(self.settings.workspace)), "content": file.read_text(encoding="utf-8")}
        reg("read_workspace_file", "Read a small text file from the restricted workspace", {"path": field_str("Relative path")}, ["path"], read_workspace)

        def save_workspace(a: dict) -> dict:
            path = self._workspace_path(_str(a, "path", 250), may_exist=False)
            content = _str(a, "content", 50000)
            if path.suffix.lower() not in {".txt", ".md", ".py", ".json", ".csv", ".yaml", ".yml"}:
                raise ToolError("Only text files may be created")
            path.parent.mkdir(parents=True, exist_ok=True)
            try:
                with path.open("x", encoding="utf-8") as f:
                    f.write(content)
            except FileExistsError as exc:
                raise ToolError("File already exists; overwriting is disabled") from exc
            return {"created": str(path.relative_to(self.settings.workspace))}
        reg("create_workspace_file", "Create a NEW text file in workspace (cannot overwrite; needs approval)",
            {"path": field_str("Relative new file path"), "content": field_str("Text file contents")},
            ["path", "content"], save_workspace, True)

        def open_site(a: dict) -> dict:
            raw = _str(a, "url", 2048)
            url = urlsplit(raw)
            if url.scheme not in {"https", "http"} or not url.hostname or url.username or url.password:
                raise ToolError("Only full http:// or https:// URLs without credentials")
            if url.port is not None and not (1 <= url.port <= 65535):
                raise ToolError("Invalid port")
            if not webbrowser.open(raw):
                raise ToolError("No browser accepted the request. Check your default browser settings.")
            return {"requested_on_server_computer": raw,
                    "message": "The browser accepted the request. Check the browser to confirm the page opened."}
        reg("open_website", "Open a website on the PC running JARVIS (requires approval)",
            {"url": field_str("Full https:// URL")}, ["url"], open_site, True)

        def launch(a: dict) -> dict:
            name = _str(a, "name", 60).lower()
            system = platform.system().lower()
            aliases = APP_ALIASES.get(system, {})
            if name not in aliases:
                raise ToolError("Supported apps on this OS: " + ", ".join(aliases))
            command = aliases[name]
            if not shutil.which(command[0]):
                raise ToolError(f"{name} not installed or not on PATH")
            subprocess.Popen(command, cwd=str(self.settings.workspace),
                             stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             shell=False, start_new_session=True)
            return {"launched_on_server_computer": name}
        reg("launch_app", "Launch an allowlisted PC app: calculator, text editor, file manager or vscode (requires approval)",
            {"name": field_str("One listed app name")}, ["name"], launch, True)
