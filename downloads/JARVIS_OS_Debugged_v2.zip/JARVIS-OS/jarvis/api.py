"""FastAPI server: one backend, mobile-friendly interface, bearer-token auth.

Not designed for public Internet exposure. Run behind HTTPS and proper accounts
before making it a public multi-user service.
"""
from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
import hmac
import json
from pathlib import Path
import time

from fastapi import Depends, FastAPI, HTTPException, Request, status
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from .agent import JarvisAgent, AgentDeps
from .config import Settings
from .schemas import ChatRequest, ChatResponse, ApprovalResponse, NoteInput, TaskInput, ReminderInput, SessionResponse
from .storage import Database
from .tools import ToolRegistry, parse_due_at, ToolError
from .advanced.store import OperationsStore
from .advanced.workflows import WorkflowEngine
from .advanced.backup import BackupManager
from .advanced.events import EventHub
from .advanced.observability import OperationMetrics, SystemSampler
from .advanced.assistant_tools import install_advanced_tools
from .advanced.api import APIContext, build_router
from .advanced.security import RateLimiter
from .intelligence.index import LocalIndex
from .intelligence.context import ContextAssembler
from .intelligence.api import build_router as build_knowledge_router
from .perception.api import build_router as build_perception_router
from .utilities.api import build_router as build_utilities_router
from .utilities.assistant_tools import install_utility_tools
from .utilities.catalog import build_utility_registry
from .advanced.learning import StudyLibrary
from .advanced.learning_tools import install_learning_tools
from .advanced.learning_api import build_router as build_learning_router
from .advanced.ideas import IdeaLab
from .advanced.ideas_tools import install_ideas_tools
from .advanced.ideas_api import build_router as build_ideas_router

STATIC = Path(__file__).parent / "static"
SECURITY = HTTPBearer(auto_error=False)


def create_app(settings: Settings | None = None, provider=None) -> FastAPI:
    settings = settings or Settings()
    db = Database(settings.database_path)
    registry = ToolRegistry(db, settings)
    ops = OperationsStore(db)
    study = StudyLibrary(db)
    ideas = IdeaLab(db)
    install_advanced_tools(registry, ops)
    install_learning_tools(registry, study)
    install_ideas_tools(registry, ideas)
    install_utility_tools(registry)
    hub = EventHub()
    metrics = OperationMetrics()
    sampler = SystemSampler()
    workflows = WorkflowEngine(ops, registry, hub, metrics)
    backups = BackupManager(db, settings.data_dir)
    knowledge_index = LocalIndex(db, settings.workspace)
    knowledge_context = ContextAssembler(db, knowledge_index)
    limiter = RateLimiter(rate=1.0, burst=10)
    agent = JarvisAgent(AgentDeps(db, registry, settings), provider=provider)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        async def reminders_loop():
            while True:
                due = db.due_reminders()
                for notice in due:
                    hub.publish('notification', {'kind': 'reminder', 'id': notice['id'], 'status': 'due'})
                # Schedule only allowlisted read-only operations, while server runs.
                await asyncio.to_thread(workflows.tick)
                sampler.take()
                await asyncio.sleep(15)
        worker = asyncio.create_task(reminders_loop())
        try:
            yield
        finally:
            worker.cancel()
            try:
                await worker
            except asyncio.CancelledError:
                pass

    app = FastAPI(title="JARVIS OS", version="0.2.0", lifespan=lifespan)
    app.state.db = db
    app.state.agent = agent
    app.state.registry = registry
    app.state.settings = settings
    app.state.advanced = ops
    app.state.workflows = workflows
    app.state.events = hub
    app.state.knowledge_index = knowledge_index
    app.state.utilities = build_utility_registry()
    app.state.study = study
    app.state.idea_lab = ideas

    def auth(credentials: HTTPAuthorizationCredentials | None = Depends(SECURITY)):
        if not credentials or not hmac.compare_digest(credentials.credentials.encode("utf-8"), settings.access_token.encode("utf-8")):
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid access token")
        return True

    app.include_router(build_router(APIContext(ops, workflows, backups, hub, metrics,
                                              sampler, settings.workspace), auth))
    app.include_router(build_knowledge_router(knowledge_index, knowledge_context, auth))
    app.include_router(build_perception_router(auth, settings.ollama_url))
    app.include_router(build_utilities_router(auth))
    app.include_router(build_learning_router(study,auth))
    app.include_router(build_ideas_router(ideas,auth))

    @app.get("/api/health")
    def health():
        return {"status": "ok"}

    @app.get("/api/me", response_model=SessionResponse)
    def me(_=Depends(auth)):
        return {"valid": True, "provider": settings.provider,
                "model": settings.ollama_model if settings.provider == "ollama" else settings.openai_model,
                "workspace": str(settings.workspace)}

    @app.post("/api/chat", response_model=ChatResponse)
    async def chat(input: ChatRequest, _=Depends(auth)):
        # Prevent accidental request storms on an exposed private LAN server.
        if not limiter.permit('chat', time.monotonic(), cost=1.0):
            raise HTTPException(429, 'Too many requests, try again shortly')
        with metrics.timed('chat'):
            answer = await agent.chat(input.message, input.session_id)
        hub.publish('assistant', {'kind': 'chat', 'status': 'completed'})
        return answer

    @app.get("/api/history/{session_id}")
    def history(session_id: str, _=Depends(auth)):
        if len(session_id) > 80:
            raise HTTPException(400, "Invalid session")
        return db.history(session_id, limit=60)

    @app.delete("/api/history/{session_id}")
    def clear_history(session_id: str, _=Depends(auth)):
        return {"deleted": db.clear_history(session_id)}

    @app.get("/api/tools")
    def tools(_=Depends(auth)):
        return registry.catalog()

    @app.get("/api/status")
    def status_info(_=Depends(auth)):
        # Dashboard polling should not create thousands of audit records per day.
        return registry.handle("computer_status", {}, audit=False)

    @app.get("/api/facts")
    def facts(_=Depends(auth)):
        return db.facts()

    @app.get("/api/tasks")
    def tasks(_=Depends(auth)):
        return db.tasks(include_completed=True)

    @app.post("/api/tasks", status_code=201)
    def create_task(item: TaskInput, _=Depends(auth)):
        return db.add_task(item.title.strip())

    @app.post("/api/tasks/{task_id}/complete")
    def complete_task(task_id: str, _=Depends(auth)):
        return {"completed": db.complete_task(task_id)}

    @app.get("/api/notes")
    def notes(_=Depends(auth)):
        return db.notes()

    @app.post("/api/notes", status_code=201)
    def save_note(note: NoteInput, _=Depends(auth)):
        return db.save_note(note.title.strip(), note.body)

    @app.get("/api/reminders")
    def reminders(_=Depends(auth)):
        return db.reminders()

    @app.post("/api/reminders", status_code=201)
    def add_reminder(item: ReminderInput, _=Depends(auth)):
        try:
            return db.add_reminder(item.text, parse_due_at(item.due_at))
        except ToolError as exc:
            raise HTTPException(400, str(exc)) from exc

    @app.get("/api/notifications")
    def notifications(_=Depends(auth)):
        # Catch up immediately even if the 15-second timer hasn't fired.
        db.due_reminders()
        return db.notifications()

    @app.post("/api/notifications/{ident}/ack")
    def ack(ident: str, _=Depends(auth)):
        return {"acknowledged": db.acknowledge_notification(ident)}

    @app.get("/api/approvals")
    def approvals(_=Depends(auth)):
        return db.approvals()

    @app.post("/api/approvals/{ident}/approve", response_model=ApprovalResponse)
    def approve(ident: str, _=Depends(auth)):
        item = db.decide_approval(ident, approve=True)
        if not item:
            raise HTTPException(404, "Unknown, expired or already decided approval")
        result = registry.handle(item["tool"], json.loads(item["args_json"]), approved=True)
        return {"id": ident, "status": "completed" if result.get("ok") else "error",
                "message": json.dumps(result, ensure_ascii=False)}

    @app.post("/api/approvals/{ident}/deny", response_model=ApprovalResponse)
    def deny(ident: str, _=Depends(auth)):
        item = db.decide_approval(ident, approve=False)
        if not item:
            raise HTTPException(404, "Unknown, expired or already decided approval")
        db.audit(item["tool"], json.loads(item["args_json"]), "denied", "Rejected by user")
        return {"id": ident, "status": "denied", "message": "Action rejected"}

    @app.get("/api/audit")
    def audit(_=Depends(auth)):
        return db.audit_recent()

    # The front-end is public static HTML, but all private data/actions are token-protected.
    @app.get("/")
    def index():
        return FileResponse(STATIC / "index.html")

    app.mount("/static", StaticFiles(directory=STATIC), name="static")
    return app
