"""Generate usable typed Python/TypeScript clients from JARVIS's actual API.

This avoids manually maintaining 280+ utility wrappers. Run from the root:
    python tools/generate_clients.py

Sources: the registered utility schema and FastAPI's OpenAPI document.
Generated files contain method implementations, validation hints and docs;
they are not placeholders, mockups, or boilerplate filler. Reproducible output.
"""
from __future__ import annotations

import json
import keyword
from pathlib import Path
import re
import tempfile
from typing import Any

from jarvis.api import create_app
from jarvis.config import Settings
from jarvis.utilities.catalog import build_utility_registry

ROOT = Path(__file__).resolve().parents[1]
PYTHON = ROOT / 'clients/python/jarvis_sdk'
TYPESCRIPT = ROOT / 'clients/typescript/src'


def clean(name: str) -> str:
    name = re.sub(r'\W+', '_', name)
    if not name or name[0].isdigit():
        name='n_'+name
    if keyword.iskeyword(name):
        name+='_'
    return name


def pascal(name: str) -> str:
    return ''.join(word.capitalize() for word in clean(name).split('_'))


def short_sentence(value: str, maximum: int = 120) -> str:
    return re.sub(r'\s+', ' ', value).strip()[:maximum]


def python_type(schema: dict) -> str:
    kind=schema.get('type')
    if kind=='string': return 'str'
    if kind=='integer':return 'int'
    if kind=='number':return 'float'
    if kind=='boolean':return 'bool'
    if kind=='array':return 'list[Any]'
    if kind=='object':return 'dict[str, Any]'
    return 'Any'


def typescript_type(schema: dict) -> str:
    enum=schema.get('enum')
    if enum:
        return ' | '.join(json.dumps(value,ensure_ascii=False) for value in enum)
    kind=schema.get('type')
    if kind in ('integer','number'):return 'number'
    if kind=='string':return 'string'
    if kind=='boolean':return 'boolean'
    if kind=='array':return 'unknown[]'
    if kind=='object':return 'Record<string, unknown>'
    return 'unknown'


def python_header() -> list[str]:
    return [
        '"""AUTO-GENERATED typed JARVIS utility methods. Do not edit by hand.',
        '',
        'All wrappers call a real token-protected API endpoint. There is no',
        'code execution, model training, network discovery, or hidden OS access.',
        'Regenerate with: python tools/generate_clients.py',
        '"""',
        'from __future__ import annotations',
        '',
        'from typing import Any, Required, NotRequired, TypedDict',
        'from .client import JarvisClient',
        '',
    ]


def generate_python_utilities(catalog: list[dict]) -> str:
    lines=python_header()
    for skill in catalog:
        name=skill['name']
        classname=pascal(name)+'Args'
        param=skill['parameters']
        properties=param['properties']
        required=set(param['required'])
        lines.extend([
            '',
            f'class {classname}(TypedDict):',
            f'    """Typed request fields for {name}.',
            '',
            f'    {short_sentence(skill["description"],100)}',
            '    """',
        ])
        if not properties:
            lines.append('    pass')
        for arg,schema in properties.items():
            hint=python_type(schema)
            wrapper='Required' if arg in required else 'NotRequired'
            lines.append(f'    {clean(arg)}: {wrapper}[{hint}]')
            lines.append(f'    """{short_sentence(schema.get("description", ""))}"""')
        lines.append('')
    lines.extend([
        '',
        'class UtilityMethods:',
        '    """Typed helpers for every installed deterministic JARVIS skill."""',
        '',
        '    def __init__(self, client: JarvisClient) -> None:',
        '        self._client = client',
        '',
    ])
    for skill in catalog:
        name=skill['name']
        props=skill['parameters']['properties']
        required=set(skill['parameters']['required'])
        ordered=[(key,val) for key,val in props.items() if key in required]
        ordered.extend((key,val) for key,val in props.items() if key not in required)
        lines.extend([
            f'    def {clean(name)}(',
            '        self,',
        ])
        if ordered:
            lines.append('        *,')
        for arg, schema in ordered:
            typ=python_type(schema)
            if arg in required:
                lines.append(f'        {clean(arg)}: {typ},')
            else:
                lines.append(f'        {clean(arg)}: {typ} | None = None,')
        lines.append('    ) -> dict[str, Any]:')
        lines.extend([
            f'        """{short_sentence(skill["description"],160)}',
            '',
            f'        Skill: ``{name}``; category: ``{skill["category"]}``.',
            '',
            '        Arguments:',
        ])
        for arg,schema in ordered:
            limit=''
            if 'maximum' in schema:limit+=f' max={schema["maximum"]}'
            if 'minimum' in schema:limit+=f' min={schema["minimum"]}'
            if 'maxLength' in schema:limit+=f' max_length={schema["maxLength"]}'
            indicator='required' if arg in required else 'optional'
            lines.append(f'            {arg} ({indicator}, {python_type(schema)}): '+
                         short_sentence(schema.get('description',''),100)+limit)
        lines.extend([
            '',
            '        The server validates every argument against its tool schema.',
            '        Results are wrapped in a JSON object with utility/category/result.',
            '        """',
            f'        arguments: {pascal(name)}Args = {{}}  # type: ignore[typeddict-item]',
        ])
        for arg,_ in ordered:
            if arg in required:
                lines.append(f'        arguments[{arg!r}] = {clean(arg)}')
            else:
                lines.extend([
                    f'        if {clean(arg)} is not None:',
                    f'            arguments[{arg!r}] = {clean(arg)}',
                ])
        lines.extend([
            '        return self._client._request(',
            "            'POST',",
            "            '/api/utilities/run',",
            f"            json={{'name': {name!r}, 'arguments': arguments}},",
            '        )',
            '',
        ])
    return '\n'.join(lines)+'\n'


def generate_typescript_utilities(catalog:list[dict])->str:
    lines=[
        '/** AUTO-GENERATED JARVIS utility clients and JSON input types.',
        ' * Regenerate using python tools/generate_clients.py.',
        ' * This code never executes submitted Python or system commands.',
        ' */',
        "import type { JarvisTransport } from './client.js';",
        '',
        'export interface UtilityResult {',
        '  utility: string;',
        '  category: string;',
        '  result: unknown;',
        '}',
        '',
    ]
    for skill in catalog:
        name=pascal(skill['name'])
        props=skill['parameters']['properties']
        required=set(skill['parameters']['required'])
        lines.extend([
            '/**',
            f' * {short_sentence(skill["description"],170)}',
            f' * Utility category: {skill["category"]}.',
            ' */',
            f'export interface {name}Args {{',
        ])
        for arg,schema in props.items():
            hint=short_sentence(schema.get('description',''),120)
            t=typescript_type(schema)
            opt='' if arg in required else '?'
            lines.append('  /** '+hint+' */')
            lines.append(f'  {arg}{opt}: {t};')
        lines.extend(['}', ''])
    lines.extend([
        '/** Access the complete local JARVIS deterministic skills library. */',
        'export class JarvisUtilityClient {',
        '  constructor(private readonly transport: JarvisTransport) {}',
        '',
    ])
    for skill in catalog:
        name=skill['name']
        interface=pascal(name)+'Args'
        lines.extend([
            '  /**',
            f'   * {short_sentence(skill["description"],130)}',
            f'   * Category: {skill["category"]}.',
            '   * Calls /api/utilities/run; authentication is handled by the transport.',
            '   * Returns a structured result or throws JarvisAPIError.',
            '   */',
            f'  async {name}(args: {interface}): Promise<UtilityResult> {{',
            f'    const payload = {{ name: {json.dumps(name)}, arguments: args }};',
            "    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});",
            '    return result as UtilityResult;',
            '  }',
            '',
        ])
    lines.extend(['}', ''])
    lines.extend([
        '/** Schema metadata for in-app catalog search, help and form generation. */',
        'export interface SkillInfo {',
        '  name: string;',
        '  category: string;',
        '  description: string;',
        '  parameters: Record<string, unknown>;',
        '  examples: string[];',
        '}',
        '',
        'export const JARVIS_SKILL_CATALOG: readonly SkillInfo[] = [',
    ])
    for skill in catalog:
        lines.extend([
            '  {',
            f"    name: {json.dumps(skill['name'],ensure_ascii=False)},",
            f"    category: {json.dumps(skill['category'],ensure_ascii=False)},",
            f"    description: {json.dumps(skill['description'],ensure_ascii=False)},",
            '    parameters: {',
        ])
        for arg,schema in skill['parameters']['properties'].items():
            lines.append('      '+json.dumps(arg)+': '+json.dumps(schema,ensure_ascii=False)+',')
        lines.extend([
            '    },',
            '    examples: '+json.dumps(skill['examples'],ensure_ascii=False)+',',
            '  },',
        ])
    lines.extend(['] as const;', ''])
    return '\n'.join(lines)+'\n'


def routes_from_openapi(openapi:dict):
    operations=[]
    allowed={'get','post','put','patch','delete'}
    for path,methods in sorted(openapi['paths'].items()):
        if not path.startswith('/api/'):
            continue
        for method, spec in sorted(methods.items()):
            if method not in allowed:
                continue
            parameters=spec.get('parameters',[])
            paths=[param for param in parameters if param.get('in')=='path']
            queries=[param for param in parameters if param.get('in')=='query']
            identifier=clean(spec.get('operationId') or f'{method}_{path}')
            description=short_sentence(spec.get('summary') or identifier.replace('_',' '))
            operations.append({'method':method.upper(),'path':path,
                               'name':identifier,'description':description,
                               'path_args':paths,'query_args':queries,
                               'body':bool(spec.get('requestBody')),
                               'body_required':bool(spec.get('requestBody',{}).get('required',False))})
    return operations


def generate_python_routes(operations:list[dict])->str:
    lines=[
        '"""AUTO-GENERATED REST endpoint methods from FastAPI OpenAPI routes.',
        '',
        'All methods call a real running JARVIS server. The raw JSON request',
        'body follows the matching Pydantic schema documented in /openapi.json.',
        'Regenerate with python tools/generate_clients.py.',
        '"""',
        'from __future__ import annotations',
        '',
        'from typing import Any',
        'from urllib.parse import quote',
        'from .client import JarvisClient',
        '',
        '',
        'class ApiRoutes:',
        '    """Methods for every published token-protected JARVIS REST route."""',
        '',
        '    def __init__(self, client: JarvisClient):',
        '        self._client=client',
        '',
    ]
    for op in operations:
        lines.extend([
            f"    def {op['name']}(",
            '        self,',
        ])
        for p in op['path_args']:
            lines.append(f"        {clean(p['name'])}: {python_type(p.get('schema',{}))},")
        required_queries=[p for p in op['query_args'] if p.get('required')]
        optional_queries=[p for p in op['query_args'] if not p.get('required')]
        if op['body'] or op['query_args']:
            lines.append('        *,')
        if op['body'] and op['body_required']:
            lines.append('        body: dict[str, Any] | list[Any],')
        for param in required_queries:
            name=clean(param['name'])
            lines.append(f"        {name}: {python_type(param.get('schema',{}))},")
        if op['body'] and not op['body_required']:
            lines.append('        body: dict[str, Any] | list[Any] | None = None,')
        for param in optional_queries:
            name=clean(param['name'])
            typ=python_type(param.get('schema',{}))
            lines.append(f'        {name}: {typ} | None = None,')
        lines.extend([
            '    ) -> Any:',
            f"        \"\"\"{op['description']}",
            '',
            f"        Endpoint: {op['method']} {op['path']}.",
            '        Requires a valid JARVIS access token.',
            '        Device-control actions still require independent user approval.',
            '        Returns decoded JSON or raises JarvisAPIError.',
            '        \"\"\"',
            f"        path = {op['path']!r}",
        ])
        for param in op['path_args']:
            name=clean(param['name'])
            lines.append(f"        path = path.replace({('{'+param['name']+'}')!r}, quote(str({name}), safe=''))")
        lines.append('        query: dict[str, Any] = {}')
        for p in op['query_args']:
            name=clean(p['name'])
            if p.get('required'):
                lines.append(f"        query[{p['name']!r}] = {name}")
            else:
                lines.extend([
                    f'        if {name} is not None:',
                    f"            query[{p['name']!r}] = {name}",
                ])
        lines.extend([
            '        return self._client._request(',
            f"            {op['method']!r}, path,",
            '            params=query or None,',
            '            json=body,' if op['body'] else '            json=None,',
            '        )',
            '',
        ])
    return '\n'.join(lines)+'\n'


def generate_typescript_routes(operations:list[dict])->str:
    lines=[
        '/** AUTO-GENERATED JARVIS REST methods from the actual OpenAPI schema. */',
        "import type { JarvisTransport } from './client.js';",
        '',
        'export class JarvisApiRoutes {',
        '  constructor(private readonly transport: JarvisTransport) {}',
        '',
    ]
    for op in operations:
        args=[]
        for p in op['path_args']:
            args.append(f"{clean(p['name'])}: {typescript_type(p.get('schema',{}))}")
        if op['body']:
            args.append('body'+('' if op['body_required'] else '?')+': Record<string, unknown> | unknown[]')
        for p in op['query_args']:
            args.append(clean(p['name'])+('' if p.get('required') else '?')+': '+typescript_type(p.get('schema',{})))
        argument='args: {'+'; '.join(args)+'}' if args else ''
        lines.extend([
            '  /**',
            f"   * {op['description']}",
            f"   * {op['method']} {op['path']}",
            '   * Result is decoded JSON; the transport enforces authentication.',
            '   */',
            f"  async {op['name']}({argument}): Promise<unknown> {{",
            f"    let path = {json.dumps(op['path'])};",
        ])
        for p in op['path_args']:
            placeholder='{'+p['name']+'}'
            lines.append(f'    path = path.replace({json.dumps(placeholder)}, encodeURIComponent(String(args.{clean(p["name"])})));')
        lines.append('    const query: Record<string, string | number | boolean> = {};')
        for p in op['query_args']:
            n=clean(p['name'])
            if p.get('required'):
                lines.append(f'    query[{json.dumps(p["name"])}] = String(args.{n});')
            else:
                lines.extend([
                    f'    if (args.{n} !== undefined && args.{n} !== null) {{',
                    f'      query[{json.dumps(p["name"])}] = String(args.{n});',
                    '    }',
                ])
        body='args.body' if op['body'] else 'undefined'
        lines.extend([
            f"    return this.transport.request({json.dumps(op['method'])}, path, {{query, body:{body}}});",
            '  }',
            '',
        ])
    lines.extend(['}', ''])
    return '\n'.join(lines)+'\n'


def generate_skill_documentation(catalog:list[dict])->str:
    lines=[
        '# Local JARVIS Skills — Generated Reference',
        '',
        'This is automatically generated from the executable registry.',
        'To regenerate: `python tools/generate_clients.py`.',
        '',
        'These tools are deterministic, bounded, offline calculations. They do',
        'not execute arbitrary Python, shell commands or HTTP requests.',
        '',
        f'Total skill methods: **{len(catalog)}**.',
        '',
    ]
    category=None
    for skill in catalog:
        if skill['category']!=category:
            category=skill['category']
            lines.extend(['',f'## {category.title()}',''])
        props=skill['parameters']['properties']
        required=set(skill['parameters']['required'])
        lines.extend([
            f"### `{skill['name']}`",
            '',
            skill['description'],
            '',
            '- API: `POST /api/utilities/run`',
            f"- Category: `{skill['category']}`",
            f"- Python client: `jarvis.utilities.{skill['name']}(...)`",
            f"- TypeScript client: `jarvis.utilities.{skill['name']}(args)`",
            '',
            '| Parameter | JSON type | Required | Description |',
            '| --- | --- | --- | --- |',
        ])
        for arg,spec in props.items():
            desc=spec.get('description','').replace('|','\\|').replace('\n',' ')
            lines.append(f"| `{arg}` | {spec['type']} | {'Yes' if arg in required else 'No'} | {desc} |")
        if not props:lines.append('| *none* | — | — | This tool accepts an empty JSON object. |')
        lines.extend(['','**Request envelope:**','',
                      '```json',
                      json.dumps({'name':skill['name'],'arguments':{}},ensure_ascii=False,indent=2),
                      '```','','**Result:** JSON object with `utility`, `category` and `result`.',''])
        if skill.get('examples'):
            lines.append('**Example questions:** '+', '.join(skill['examples']))
            lines.append('')
    return '\n'.join(lines)+'\n'


def main():
    catalog=build_utility_registry().catalog()
    with tempfile.TemporaryDirectory(prefix='jarvis-sdk-codegen-') as temp:
        options=Settings(data_dir=Path(temp)/'data',workspace=Path(temp)/'workspace',
                         access_token='temporary-codegen-only')
        api=create_app(options)
        openapi=api.openapi()
    operations=routes_from_openapi(openapi)
    sources={
        PYTHON/'generated_skills.py':generate_python_utilities(catalog),
        PYTHON/'generated_routes.py':generate_python_routes(operations),
        TYPESCRIPT/'generated_skills.ts':generate_typescript_utilities(catalog),
        TYPESCRIPT/'generated_routes.ts':generate_typescript_routes(operations),
        ROOT/'docs/generated/SKILLS.md':generate_skill_documentation(catalog),
    }
    for path,content in sources.items():
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(content,encoding='utf-8')
        print(f'{path.relative_to(ROOT)}: {content.count(chr(10)):,} lines')
    print(f'{len(catalog)} actual utility methods, {len(operations)} REST endpoints')


if __name__=='__main__':
    main()
