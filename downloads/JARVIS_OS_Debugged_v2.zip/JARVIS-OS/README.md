# JARVIS OS — PC & Mobile AI Command Center

A working, expandable **JARVIS-inspired personal AI assistant**, written primarily in
Python, with a high-tech desktop/mobile browser interface. This is **version 0.2**, an expanded, tested foundation with a large functional
Python backend, responsive browser UI, and generated developer client SDKs.
The project passes automated tests but is **not** movie-level general AI.

![JARVIS OS](jarvis/static/icon.svg)

## Run the corrected copy

Start with [RUN_ON_WINDOWS.md](RUN_ON_WINDOWS.md). The review fixes and validation are recorded in [DEBUG_REPORT.md](DEBUG_REPORT.md).

## Expanded features in version 0.2

- **Advanced project management**: create projects and project tasks, track goals,
  habits, focus sessions, bookmarks, and a local calendar.
- **Personal workflows**: create and validate safe workflows, schedule permitted
  read-only checks, record metrics, and export/backup private data.
- **Startup Idea Lab**: capture ideas, score opportunities, run experiments and
  organize research feedback.
- **Study decks**: create flashcard decks and review cards with local spaced repetition.
- **283 offline utility skills** across 11 categories, including arithmetic,
  probability, dates, unit conversions, statistics, text, data tables, graphs,
  static code inspection, time series and optional symbolic maths.
- **Developer SDKs**: generated, installable Python and TypeScript clients for
  real REST APIs and every offline skill; see [`clients/README.md`](clients/README.md).
- **Knowledge intelligence**: indexed local search, document analysis, extraction
  and summaries, optionally using local sentence embeddings.
- **Optional perception**: local image description and WAV speech transcription
  when the required model/dependency is installed.
- **New dashboard sections**: Projects, Goals & Habits, Calendar, Workflows,
  Insights, Startup Lab, Study Decks and a searchable Offline Skills interface.

### Additional installed components (optional)

```bash
python -m pip install -e '.[math]'       # symbolic calculus / SymPy
python -m pip install -e '.[speech]'     # local speech recognition
python -m pip install -e '.[vision]'     # image-processing support
python -m pip install -e '.[embeddings]' # local semantic embeddings
```

The optional components may also require separately downloaded models and
additional hardware memory. The base version works without them.


- Ollama **local conversational model** (`qwen3:4b`, supports tools) or optional cloud
  OpenAI-compatible chat function-calling through the Python OpenAI SDK.
- **AI tool calling**: asks tools for time, PC CPU/RAM/disk/battery, calculations,
  notes, tasks, reminders, remembered facts, and sandboxed workspace files.
- **AI/ML knowledge search**: local TF-IDF retrieval over saved notes and safe
  text files inside the JARVIS workspace (no external data upload for indexing).
- **Controlled PC actions**: opening sites or allowlisted apps (calculator, text
  editor, file manager, VS Code) requires explicit **user approval** in the UI.
- **Local database** with conversation history, notes, memory, task status,
  reminders, notifications and an action audit log.
- **Optional lightweight machine learning** fallback for five read-only intents
  if a proper AI model is unavailable (`pip install -e '.[ml]'`).
- **Browser-based voice input and speech output**, where supported by browser.
  This does not guarantee offline speech recognition.
- **One dashboard** for PC and mobile, with a token-protected API.

## Quick start (Python 3.11+)

1. Install [Python](https://www.python.org/downloads/) and
   [Ollama](https://ollama.com/download).
2. In a terminal, from this project's folder:

   **Windows (PowerShell):**

   ```powershell
   py -3 -m venv .venv
   .\.venv\Scripts\python.exe -m pip install -e ".[ml]"
   ollama pull qwen3:4b
   .\.venv\Scripts\python.exe -m jarvis serve
   ```

   **macOS / Linux:**

   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   python -m pip install -e '.[ml]'
   ollama pull qwen3:4b
   jarvis serve
   ```

3. If Ollama is not already running, launch it. By default its server listens on
   `127.0.0.1:11434`.
4. Open **http://127.0.0.1:8765** on your computer. Enter the private access
   token printed in the `jarvis serve` terminal. Retrieve it later using `jarvis token`.

A local model uses CPU/RAM and may be slow on older computers. `qwen3:4b` is
roughly a 2.5-GB model download; real RAM requirements vary by device and
runtime. You can use a smaller supported Ollama tool-calling model if needed.

### Optional cloud brain

Install optional dependencies and create a `.env` file from `.env.example`:

```bash
python -m pip install -e '.[openai,ml]'
```

```dotenv
JARVIS_PROVIDER=openai
OPENAI_API_KEY=your_private_key_here
JARVIS_OPENAI_MODEL=gpt-4.1-mini
```

**This may incur API charges**. Do not commit `.env` or share API keys.

## Phone access on your private Wi-Fi

1. Start your PC server with `jarvis serve --lan`.
2. Find your computer's **local Wi-Fi IP** (for example `192.168.1.20`).
3. On a phone on the **same trusted Wi-Fi**, open
   `http://YOUR-PC-IP:8765`, and enter the access token.
4. If the OS firewall asks, allow **only private/local networks**.

**Important**: This is plain HTTP. Do not port-forward it, expose it on the public
Internet or use it on untrusted public Wi-Fi. Deploy HTTPS and robust account/device
authentication before using it outside a local trusted network. Browser microphone
capture usually requires HTTPS on a phone; text chat and device dashboard continue
to work on LAN HTTP. The phone controls the PC *through the PC server*. It does
not yet directly control Android apps, messages or phone settings.

## Example commands

- "JARVIS, show me my CPU, RAM and battery status."
- "Remember that my startup research folder is in the workspace."
- "Create a task: prototype my AI assistant's landing page."
- "Make a note called Ideas with a list of startup features."
- "Remind me tomorrow at 8 PM to review my project."
- "Search my notes and workspace for ideas about AI assistants."
- "List the files in your workspace."
- "Create a new README in the workspace." → user must approve.
- "Open https://github.com on my computer." → user must approve.
- "Open calculator on my computer." → user must approve.

The AI may not always interpret commands perfectly. Use explicit wording, and
check the on-screen result rather than assuming an action was executed.

## Configuration reference

| Setting | Default | Notes |
|---|---|---|
| `JARVIS_PROVIDER` | `ollama` | `ollama` or `openai` |
| `JARVIS_OLLAMA_URL` | `http://127.0.0.1:11434` | local Ollama API |
| `JARVIS_OLLAMA_MODEL` | `qwen3:4b` | install using `ollama pull` |
| `JARVIS_OPENAI_MODEL` | `gpt-4.1-mini` | model if using OpenAI |
| `OPENAI_API_KEY` | unset | only for cloud mode |
| `JARVIS_DATA_DIR` | `~/.jarvis_ai` | SQLite db + access token |
| `JARVIS_WORKSPACE` | `~/.jarvis_ai/workspace` | only user files the model may read |
| `JARVIS_ACCESS_TOKEN` | generated automatically | override with a long secret |

## Python and TypeScript developer APIs

JARVIS exposes a token-protected local REST API under `/api` and publishes
`/openapi.json`. The `clients/python` and `clients/typescript` folders contain
typed generated method wrappers for the implemented endpoints and utilities.
They are developer interfaces, **not** separate autonomous models.
Regenerate them with `python tools/generate_clients.py` after changing the API.
A complete, searchable utility reference is in `docs/generated/SKILLS.md`.

## Development and testing

```bash
pip install -e '.[dev,ml]'
pytest -q
python -m compileall jarvis
jarvis doctor
jarvis lines    # includes .py/.ts/.js and documentation
```

Do not run JARVIS as an administrator/root. It should only have the same privileges
as your logged-in user, and you should confirm every proposed computer action.

For API routes, module structure, security assumptions and the roadmap to a much
larger system, read [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).

## Current limitations

- **An expanded local-first prototype**, not full Marvel-movie JARVIS or
  independently trained general AI. Some source code (the developer SDK) is
  generated from the real API and utility schemas.
- Browser voice input is browser-dependent; no production wake word. An optional
  separate local WAV transcription service is provided but may require model setup.
- App launching is limited to a fixed set, and only on the **host PC**.
- No unattended remote computer control, SMS, phone OS access or camera access.
- No cloud hosting, zero-trust security, automatic updates or multi-user isolation.
- Reminders deliver in the browser after the server is running and the client
  connects; there are no Android push notifications while the app is closed.

## License

MIT. See `LICENSE`.
