# Run this JARVIS project on Windows

This ZIP contains a Python/FastAPI application. It runs a server on your PC and displays the interface in your browser. Python 3.11 or newer is supported; Python 3.12 is a good choice. Node.js is needed only for the optional TypeScript developer SDK.

## Easiest launch

1. Install Python from https://www.python.org/downloads/ and enable **Add Python to PATH**. Reopen your terminal afterward.
2. Extract **all** files from the corrected ZIP. Open the `JARVIS-OS` folder containing `pyproject.toml`.
3. Double-click **start_windows.bat**. It creates a private `.venv`, installs the application, and starts the server. Keep that terminal open.
4. Open **http://127.0.0.1:8765** in Chrome or Edge.
5. Copy the private access token displayed in your own server terminal into the browser's **Access token** box. Do not share that token.

## Full AI conversation using a free local model

Install Ollama for Windows from https://ollama.com/download/windows. Open a new PowerShell window and run:

```powershell
ollama pull qwen3:4b
```

Keep Ollama running. This downloads a model of roughly a few GB and needs sufficient free disk space and RAM; CPU inference can be slow on older PCs. You can select a different compatible tool-calling Ollama model with `JARVIS_OLLAMA_MODEL` in `.env`.

The application can start without a model. Manual notes/tasks/dashboard/tools still work, but general AI conversations need a configured provider. Missing-model mode is explicitly labeled and provides only limited basic commands.

## PowerShell commands instead of double-clicking

Open PowerShell or the VS Code terminal **inside the extracted `JARVIS-OS` folder**, then run:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e ".[ml]"
.\.venv\Scripts\python.exe -m jarvis serve
```

The virtual environment must use Python 3.11+. These commands invoke its interpreter directly, so PowerShell script activation and execution-policy changes are unnecessary.

Useful checks:

```powershell
.\.venv\Scripts\python.exe -m jarvis doctor
.\.venv\Scripts\python.exe -m jarvis selftest
```

To start again later, double-click `start_windows.bat` or run the final `python.exe -m jarvis serve` command above. Press Ctrl+C in the server terminal to stop it.

## Optional OpenAI provider

```powershell
.\.venv\Scripts\python.exe -m pip install -e ".[openai]"
Copy-Item .env.example .env
notepad .env
```

Set `JARVIS_PROVIDER=openai`, `OPENAI_API_KEY` to your own key, and `JARVIS_OPENAI_MODEL` as appropriate. Restart the server. Preserve an existing `.env` rather than overwriting it. OpenAI API billing is separate from a chat subscription. The implemented providers in this archive are Ollama and OpenAI.

## Android phone access

Run on the PC:

```powershell
.\.venv\Scripts\python.exe -m jarvis serve --lan
```

Keep the PC running, connect the phone to the same trusted Wi-Fi, and open `http://YOUR-PC-WIFI-IP:8765` on the phone. Enter your private token there. This is a remote browser interface to the PC server; this archive contains no native Android APK. Phone microphone recognition may require HTTPS. PC actions affect the computer hosting the server.

The server is intended for a private, single-user setup. LAN mode uses unencrypted HTTP; use it only on a trusted private network and do not port-forward it onto the internet.

## Common startup issues

- **`py` is not recognized:** install Python with its launcher/PATH option, reopen PowerShell, and try again. If only `python` is available, use `python -m venv .venv` instead.
- **Wrong Python version:** use a supported Python interpreter to create a fresh virtual environment. Python 3.11+ is required.
- **Model connection unavailable:** ensure Ollama is running and the configured model appears in `ollama list`.
- **Port 8765 is busy:** stop the older server or use `python.exe -m jarvis serve --port 8766`, then open the matching browser address.
- **Invalid token:** obtain the current token locally with `python.exe -m jarvis token` and reconnect. Custom tokens must contain 16–512 non-whitespace ASCII characters; the generated default is longer than 32 characters.
- **Optional image/speech/embedding features unavailable:** install the corresponding documented extras and models. They are not included in the base installation.
