import test from 'node:test';
import assert from 'node:assert/strict';
import {JarvisTransport, JarvisAPIError} from '../dist/client.js';

test('generated ESM SDK executes utility and route methods with bearer authentication', async () => {
  const original=globalThis.fetch; const calls=[];
  globalThis.fetch=async (url,options)=>{calls.push({url:String(url),options});return Response.json({utility:'percent_of',result:50});};
  try {
    const client=new JarvisTransport('private test token','https://jarvis.example');
    assert.equal((await client.utilities.percent_of({part:20,whole:250})).result,50);
    await client.routes.health_api_health_get();
    assert.equal(calls[0].url,'https://jarvis.example/api/utilities/run');
    assert.equal(calls[0].options.headers.Authorization,'Bearer private test token');
    assert.equal(calls[0].options.redirect,'error');
    assert.deepEqual(JSON.parse(calls[0].options.body),{name:'percent_of',arguments:{part:20,whole:250}});
    assert.equal(calls[1].url,'https://jarvis.example/api/health');
  } finally {globalThis.fetch=original;}
});

test('URLs and paths cannot silently move the request outside the API',async()=>{
  assert.throws(()=>new JarvisTransport('token','https://jarvis.example/?wrong=1'),/query or fragment/);
  assert.throws(()=>new JarvisTransport('token','https://jarvis.example/#wrong'),/query or fragment/);
  assert.throws(()=>new JarvisTransport('token','http://remote.example'),/HTTPS/);
  const client=new JarvisTransport('token');
  for(const path of ['/api/../private','/api/%2e%2e/private','/api/health#ignored','https://elsewhere.example/api/health','/api/..\\private']) {
    await assert.rejects(client.request('GET',path),/Only JARVIS/);
  }
  await assert.rejects(client.request('TRACE','/api/health'),/Unsupported/);
});

test('server errors become typed errors and preserve status',async()=>{
  const original=globalThis.fetch;
  globalThis.fetch=async()=>Response.json({detail:'Invalid arguments'},{status:422});
  try {await assert.rejects(new JarvisTransport('token').routes.health_api_health_get(),e=>e instanceof JarvisAPIError&&e.status===422&&e.message.includes('Invalid arguments'));}
  finally {globalThis.fetch=original;}
});
