/** AUTO-GENERATED JARVIS utility clients and JSON input types.
 * Regenerate using python tools/generate_clients.py.
 * This code never executes submitted Python or system commands.
 */
import type { JarvisTransport } from './client.js';

export interface UtilityResult {
  utility: string;
  category: string;
  result: unknown;
}

/**
 * Advance a specified number of weekdays
 * Utility category: dates.
 */
export interface AddBusinessDaysArgs {
  /** YYYY-MM-DD */
  start: string;
  /** Signed weekdays */
  days: number;
}

/**
 * Add or subtract calendar days
 * Utility category: dates.
 */
export interface AddDaysArgs {
  /** YYYY-MM-DD */
  date: string;
  /** Signed number of days */
  days: number;
}

/**
 * Add calendar months, clamping day to month length
 * Utility category: dates.
 */
export interface AddMonthsArgs {
  /** YYYY-MM-DD */
  date: string;
  /** Signed number of months */
  months: number;
}

/**
 * Check whether two phrases use the same alphanumeric characters
 * Utility category: strings.
 */
export interface AnagramCheckArgs {
  /** Phrase 1 */
  first: string;
  /** Phrase 2 */
  second: string;
}

/**
 * Produce a finite arithmetic progression
 * Utility category: numbers.
 */
export interface ArithmeticSequenceArgs {
  /** First term */
  start: number;
  /** Common difference */
  difference: number;
  /** Terms */
  count: number;
}

/**
 * Simplify pixel aspect ratio
 * Utility category: measure.
 */
export interface AspectRatioArgs {
  /** Width */
  width: number;
  /** Height */
  height: number;
}

/**
 * Parse a base-2 to base-36 integer
 * Utility category: numbers.
 */
export interface BaseToNumberArgs {
  /** Digit string */
  text: string;
  /** Base */
  base: number;
}

/**
 * Update a prior probability using sensitivity and false-positive rate
 * Utility category: probability.
 */
export interface BayesRuleArgs {
  /** Prior P(H) */
  prior: number;
  /** P(E given H) */
  sensitivity: number;
  /** P(E given not H) */
  false_positive: number;
}

/**
 * Binomial probability of at least k successes
 * Utility category: probability.
 */
export interface BinomialAtLeastArgs {
  /** Trials */
  trials: number;
  /** Minimum successes */
  successes: number;
  /** Success probability */
  p: number;
}

/**
 * Binomial probability of exactly k successes
 * Utility category: probability.
 */
export interface BinomialExactArgs {
  /** Independent trials */
  trials: number;
  /** Success count */
  successes: number;
  /** Success chance */
  p: number;
}

/**
 * Expected value and variance of a binomial distribution
 * Utility category: probability.
 */
export interface BinomialMeanVarianceArgs {
  /** Number of trials */
  trials: number;
  /** Success probability */
  p: number;
}

/**
 * Approximate chance two people share a birthday
 * Utility category: probability.
 */
export interface BirthdayCollisionArgs {
  /** Group size */
  people: number;
}

/**
 * Convert bit count to full and remaining bytes
 * Utility category: measure.
 */
export interface BitsToBytesArgs {
  /** Bit count */
  bits: number;
}

/**
 * Compute deterministic bootstrap means for a small sample
 * Utility category: probability.
 */
export interface BootstrapMeanArgs {
  /** Input observations */
  values: unknown[];
  /** Replicates */
  replicates?: number;
  /** Random seed */
  seed?: number;
}

/**
 * Build URL query string from key-value pairs
 * Utility category: strings.
 */
export interface BuildQuerystringArgs {
  /** Pairs as objects with key and value */
  items: unknown[];
}

/**
 * Count weekdays Monday–Friday in inclusive date range, not holidays
 * Utility category: dates.
 */
export interface BusinessDaysArgs {
  /** YYYY-MM-DD */
  start: string;
  /** YYYY-MM-DD */
  end: string;
}

/**
 * Convert bytes to bits
 * Utility category: measure.
 */
export interface BytesToBitsArgs {
  /** Byte count */
  bytes: number;
}

/**
 * Create a month grid of dates and empty cells
 * Utility category: dates.
 */
export interface CalendarMonthArgs {
  /** Year */
  year: number;
  /** Month */
  month: number;
  /** Start weeks on Monday */
  monday_first?: boolean;
}

/**
 * Transform labels into snake kebab camel pascal title or constant case
 * Utility category: strings.
 */
export interface CaseTransformArgs {
  /** Text */
  text: string;
  /** Style */
  style: "snake" | "kebab" | "camel" | "pascal" | "title" | "constant";
}

/**
 * Count Unicode codepoints by broad category
 * Utility category: strings.
 */
export interface CharacterCountArgs {
  /** Passage */
  text: string;
}

/**
 * Circle area and circumference for a positive radius
 * Utility category: numbers.
 */
export interface CircleAreaArgs {
  /** Radius */
  radius: number;
}

/**
 * Constrain a value between two numbers
 * Utility category: numbers.
 */
export interface ClampNumberArgs {
  /** Input */
  value: number;
  /** Lower limit */
  minimum: number;
  /** Upper limit */
  maximum: number;
}

/**
 * Compute standard deviation relative to mean
 * Utility category: statistics.
 */
export interface CoefficientOfVariationArgs {
  /** Numeric samples */
  values: unknown[];
}

/**
 * Distribution of heads across a fixed number of fair flips
 * Utility category: probability.
 */
export interface CoinTossDistributionArgs {
  /** Number of flips */
  flips: number;
}

/**
 * Number of ways to select k items without order
 * Utility category: probability.
 */
export interface CombinationsArgs {
  /** Total items */
  n: number;
  /** Selected items */
  k: number;
}

/**
 * Find words present in both texts
 * Utility category: strings.
 */
export interface CommonWordsArgs {
  /** First text */
  first: string;
  /** Second text */
  second: string;
}

/**
 * Compute compounded hypothetical growth
 * Utility category: numbers.
 */
export interface CompoundGrowthArgs {
  /** Initial value */
  principal: number;
  /** Annual growth rate */
  annual_percent: number;
  /** Years */
  years: number;
  /** Compounding periods per year */
  periods?: number;
}

/**
 * Compute P(A given B) from joint and marginal probabilities
 * Utility category: probability.
 */
export interface ConditionalProbabilityArgs {
  /** P(A and B) */
  joint: number;
  /** P(B) */
  given: number;
}

/**
 * Compute cone volume
 * Utility category: measure.
 */
export interface ConeVolumeArgs {
  /** Base radius */
  radius: number;
  /** Cone height */
  height: number;
}

/**
 * Convert Celsius Fahrenheit and Kelvin
 * Utility category: measure.
 */
export interface ConvertTemperatureArgs {
  /** Temperature */
  value: number;
  /** c, f or k */
  origin: string;
  /** c, f or k */
  destination: string;
}

/**
 * Convert between defined units in a physical category
 * Utility category: measure.
 */
export interface ConvertUnitsArgs {
  /** Numeric amount */
  value: number;
  /** One of the unit categories */
  category: string;
  /** Source symbol */
  origin: string;
  /** Target symbol */
  destination: string;
}

/**
 * Compute correlations among several same-length series
 * Utility category: statistics.
 */
export interface CorrelationMatrixArgs {
  /** List of numeric series */
  series: unknown[];
}

/**
 * Compute sample or population covariance
 * Utility category: statistics.
 */
export interface CovarianceArgs {
  /** Numeric series */
  first: unknown[];
  /** Paired numeric series */
  second: unknown[];
  /** Sample covariance */
  sample?: boolean;
}

/**
 * Compute cuboid volume and surface area
 * Utility category: measure.
 */
export interface CuboidVolumeArgs {
  /** Length */
  length: number;
  /** Width */
  width: number;
  /** Height */
  height: number;
}

/**
 * Calculate bounded running products
 * Utility category: statistics.
 */
export interface CumulativeProductArgs {
  /** Numeric values */
  values: unknown[];
}

/**
 * Calculate running totals for a numeric list
 * Utility category: statistics.
 */
export interface CumulativeSumArgs {
  /** Numeric values */
  values: unknown[];
}

/**
 * Compute cylinder volume in input cubic units
 * Utility category: measure.
 */
export interface CylinderVolumeArgs {
  /** Base radius */
  radius: number;
  /** Height */
  height: number;
}

/**
 * Generate an inclusive list of dates in a short interval
 * Utility category: dates.
 */
export interface DateRangeArgs {
  /** YYYY-MM-DD */
  start: string;
  /** YYYY-MM-DD */
  end: string;
  /** Interval in days */
  every_days?: number;
}

/**
 * Calculate a signed difference between instants
 * Utility category: dates.
 */
export interface DatetimeDifferenceArgs {
  /** ISO datetime with offset */
  start: string;
  /** ISO datetime with offset */
  end: string;
}

/**
 * Calculate signed calendar days between two ISO dates
 * Utility category: dates.
 */
export interface DaysBetweenArgs {
  /** YYYY-MM-DD */
  start: string;
  /** YYYY-MM-DD */
  end: string;
}

/**
 * Measure date-based progress through a known project timeline
 * Utility category: dates.
 */
export interface DeadlineProgressArgs {
  /** YYYY-MM-DD */
  started: string;
  /** YYYY-MM-DD */
  deadline: string;
  /** YYYY-MM-DD */
  current: string;
}

/**
 * Remove repeated lines while preserving first occurrence
 * Utility category: strings.
 */
export interface DeduplicateLinesArgs {
  /** Multiline text */
  text: string;
  /** Compare case insensitively */
  ignore_case?: boolean;
}

/**
 * Show repeated full sentences
 * Utility category: strings.
 */
export interface DetectRepetitionsArgs {
  /** Document */
  text: string;
}

/**
 * Exact discrete distribution for small fair dice sums
 * Utility category: probability.
 */
export interface DiceSumDistributionArgs {
  /** Number of dice */
  dice: number;
  /** Faces per die */
  sides?: number;
}

/**
 * Apply a discount percentage
 * Utility category: numbers.
 */
export interface DiscountPriceArgs {
  /** Original price */
  original: number;
  /** Discount */
  discount_percent: number;
}

/**
 * Calculate Euclidean distance between two 2D points
 * Utility category: numbers.
 */
export interface Distance2dArgs {
  /** X 1 */
  x1: number;
  /** Y 1 */
  y1: number;
  /** X 2 */
  x2: number;
  /** Y 2 */
  y2: number;
}

/**
 * Calculate distance traveled at constant speed
 * Utility category: measure.
 */
export interface DistanceFromSpeedArgs {
  /** Average speed */
  kilometers_per_hour: number;
  /** Elapsed hours */
  hours: number;
}

/**
 * Estimate download time without network measurement
 * Utility category: measure.
 */
export interface DownloadTimeEstimateArgs {
  /** File size MB decimal */
  size_megabytes: number;
  /** Mbps */
  bandwidth_megabits_per_second: number;
}

/**
 * Solve voltage current or resistance from the other two
 * Utility category: measure.
 */
export interface ElectricOhmsLawArgs {
  /** Voltage, 0 if unknown */
  volts?: number;
  /** Current, 0 if unknown */
  amps?: number;
  /** Resistance, 0 if unknown */
  ohms?: number;
  /** One of volts amps ohms */
  solve_for: "volts" | "amps" | "ohms";
}

/**
 * Divide a bill or quantity equally
 * Utility category: numbers.
 */
export interface EqualSplitArgs {
  /** Total amount */
  total: number;
  /** Number of people */
  people: number;
}

/**
 * Compute expectation of a discrete probability distribution
 * Utility category: probability.
 */
export interface ExpectedValueArgs {
  /** Possible outcomes */
  values: unknown[];
  /** Corresponding probabilities */
  probabilities: unknown[];
}

/**
 * Compute exponential weighted moving average
 * Utility category: statistics.
 */
export interface ExponentialMovingAverageArgs {
  /** Numeric time series */
  values: unknown[];
  /** Smoothing constant */
  alpha: number;
}

/**
 * Extract Markdown headings from an outline
 * Utility category: strings.
 */
export interface ExtractHeadingsArgs {
  /** Markdown text */
  text: string;
}

/**
 * Extract explicit date email URL hashtag and time patterns
 * Utility category: strings.
 */
export interface ExtractPatternsArgs {
  /** Passage */
  text: string;
}

/**
 * List HTTP(S) URLs visibly present in plain text
 * Utility category: strings.
 */
export interface ExtractUrlsArgs {
  /** Passage */
  text: string;
}

/**
 * Calculate factorial n! for a bounded nonnegative integer
 * Utility category: numbers.
 */
export interface FactorialArgs {
  /** Integer */
  n: number;
}

/**
 * Factorial of a bounded nonnegative integer
 * Utility category: probability.
 */
export interface FactorialProbabilityArgs {
  /** Value */
  n: number;
}

/**
 * Generate the first N Fibonacci numbers
 * Utility category: numbers.
 */
export interface FibonacciArgs {
  /** Number of terms */
  count: number;
}

/**
 * Format a byte count in binary or decimal units
 * Utility category: measure.
 */
export interface FileSizeFormatArgs {
  /** Byte count */
  bytes: number;
  /** Use KiB MiB GiB instead of kB MB GB */
  binary?: boolean;
}

/**
 * Find minimum quartiles median and maximum
 * Utility category: statistics.
 */
export interface FiveNumberSummaryArgs {
  /** Numeric samples */
  values: unknown[];
}

/**
 * Pretty-print a bounded JSON value
 * Utility category: data.
 */
export interface FormatJsonArgs {
  /** Object to format */
  value: Record<string, unknown>;
  /** Indent spaces */
  indent?: number;
}

/**
 * Convert minutes since midnight to HH:MM, wrapping each day
 * Utility category: dates.
 */
export interface FormatTimeHhmmArgs {
  /** Minutes */
  minutes: number;
}

/**
 * Add, subtract, multiply or divide two rational numbers
 * Utility category: numbers.
 */
export interface FractionOperationsArgs {
  /** First fraction, e.g. 3/4 */
  left: string;
  /** Second fraction, e.g. 1/2 */
  right: string;
  /** Operation */
  operation: "add" | "subtract" | "multiply" | "divide";
}

/**
 * Count occurrences of categorical labels
 * Utility category: statistics.
 */
export interface FrequencyTableArgs {
  /** Categories or labels */
  values: unknown[];
}

/**
 * Find close candidate titles for a supplied name
 * Utility category: strings.
 */
export interface FuzzyTitlesArgs {
  /** Title */
  query: string;
  /** List of titles */
  candidates: unknown[];
  /** Result count */
  limit?: number;
}

/**
 * Compute the greatest common divisor and least common multiple
 * Utility category: numbers.
 */
export interface GcdLcmArgs {
  /** Integer values */
  values: unknown[];
}

/**
 * Probability first success occurs on a chosen trial
 * Utility category: probability.
 */
export interface GeometricExactArgs {
  /** Success chance */
  p: number;
  /** Trial number */
  trial: number;
}

/**
 * Calculate geometric mean for positive values
 * Utility category: statistics.
 */
export interface GeometricMeanArgs {
  /** Positive numbers */
  values: unknown[];
}

/**
 * Produce a bounded geometric progression
 * Utility category: numbers.
 */
export interface GeometricSequenceArgs {
  /** First term */
  start: number;
  /** Common ratio */
  ratio: number;
  /** Terms */
  count: number;
}

/**
 * Represent an edge list as a node-neighbor dictionary
 * Utility category: graphs.
 */
export interface GraphAdjacencyListArgs {
  /** Nodes */
  nodes: unknown[];
  /** Edges */
  edges: unknown[];
  /** Directed graph */
  directed?: boolean;
}

/**
 * Create a small binary adjacency matrix
 * Utility category: graphs.
 */
export interface GraphAdjacencyMatrixArgs {
  /** Nodes */
  nodes: unknown[];
  /** Edges */
  edges: unknown[];
  /** Directed graph */
  directed?: boolean;
}

/**
 * Check whether an undirected graph can be two-colored
 * Utility category: graphs.
 */
export interface GraphBipartiteArgs {
  /** Nodes */
  nodes: unknown[];
  /** Edges */
  edges: unknown[];
}

/**
 * Estimate closeness centrality using shortest hop counts
 * Utility category: graphs.
 */
export interface GraphClosenessArgs {
  /** Nodes */
  nodes: unknown[];
  /** Edges */
  edges: unknown[];
}

/**
 * Connected components in an undirected graph
 * Utility category: graphs.
 */
export interface GraphComponentsArgs {
  /** Nodes */
  nodes: unknown[];
  /** Edges */
  edges: unknown[];
}

/**
 * Calculate a dependency path for tasks with durations
 * Utility category: graphs.
 */
export interface GraphCriticalPathArgs {
  /** Objects with id, duration, dependencies */
  tasks: unknown[];
}

/**
 * Compute degree statistics of graph nodes
 * Utility category: graphs.
 */
export interface GraphDegreeArgs {
  /** Nodes */
  nodes: unknown[];
  /** Edges */
  edges: unknown[];
  /** Directed graph */
  directed?: boolean;
}

/**
 * Calculate the density of a graph
 * Utility category: graphs.
 */
export interface GraphDensityArgs {
  /** Nodes */
  nodes: unknown[];
  /** Edges */
  edges: unknown[];
  /** Directed */
  directed?: boolean;
}

/**
 * Group dependent tasks into parallelizable levels
 * Utility category: graphs.
 */
export interface GraphDependencyLevelsArgs {
  /** Task names */
  nodes: unknown[];
  /** Prerequisite pairs */
  edges: unknown[];
}

/**
 * Convert an adjacency matrix into an edge list
 * Utility category: graphs.
 */
export interface GraphEdgesFromMatrixArgs {
  /** Nodes */
  nodes: unknown[];
  /** Binary matrix */
  matrix: unknown[];
}

/**
 * Test directed graph for a dependency cycle
 * Utility category: graphs.
 */
export interface GraphHasCycleArgs {
  /** Nodes */
  nodes: unknown[];
  /** Edges */
  edges: unknown[];
}

/**
 * List nodes reachable from a given node
 * Utility category: graphs.
 */
export interface GraphReachableArgs {
  /** Node labels */
  nodes: unknown[];
  /** Edges */
  edges: unknown[];
  /** Start */
  source: string;
  /** Directed graph */
  directed?: boolean;
}

/**
 * Shortest unweighted path between two nodes
 * Utility category: graphs.
 */
export interface GraphShortestPathArgs {
  /** Node labels */
  nodes: unknown[];
  /** Node pairs */
  edges: unknown[];
  /** Start node */
  source: string;
  /** End node */
  target: string;
  /** Use directed edges */
  directed?: boolean;
}

/**
 * Order prerequisites in a directed acyclic graph
 * Utility category: graphs.
 */
export interface GraphTopologicalOrderArgs {
  /** Nodes */
  nodes: unknown[];
  /** Pairs [prerequisite,dependent] */
  edges: unknown[];
}

/**
 * Dijkstra shortest path with positive weights
 * Utility category: graphs.
 */
export interface GraphWeightedShortestPathArgs {
  /** Node labels */
  nodes: unknown[];
  /** Triples [from,to,cost] */
  edges: unknown[];
  /** Start */
  source: string;
  /** End */
  target: string;
  /** Direction matters */
  directed?: boolean;
}

/**
 * Calculate harmonic mean for positive values
 * Utility category: statistics.
 */
export interface HarmonicMeanArgs {
  /** Positive numbers */
  values: unknown[];
}

/**
 * Compute SHA-256 digest for plain text, not passwords
 * Utility category: strings.
 */
export interface HashSha256Args {
  /** Input text */
  text: string;
}

/**
 * Build a fixed-width histogram for numeric data
 * Utility category: statistics.
 */
export interface HistogramArgs {
  /** Numeric samples */
  values: unknown[];
  /** Bin count */
  bins?: number;
}

/**
 * Escape HTML special characters for safe display
 * Utility category: strings.
 */
export interface HtmlEscapeArgs {
  /** Text */
  text: string;
}

/**
 * Probability of k successes sampled without replacement
 * Utility category: probability.
 */
export interface HypergeometricExactArgs {
  /** Total population */
  population: number;
  /** Positive items in population */
  positive: number;
  /** Number of draws */
  draws: number;
  /** Observed positive draws */
  successes: number;
}

/**
 * Estimate storage for uncompressed images in bytes
 * Utility category: measure.
 */
export interface HyperspaceDataSizeArgs {
  /** Width pixels */
  width: number;
  /** Height pixels */
  height: number;
  /** Color channels */
  channels?: number;
  /** Channel bit depth */
  bits_per_channel?: number;
}

/**
 * Probability of independent events both occurring
 * Utility category: probability.
 */
export interface IndependentAndArgs {
  /** First probability */
  p: number;
  /** Second probability */
  q: number;
}

/**
 * Probability that either independent event occurs
 * Utility category: probability.
 */
export interface IndependentOrArgs {
  /** First probability */
  p: number;
  /** Second probability */
  q: number;
}

/**
 * Make initials from a short phrase
 * Utility category: strings.
 */
export interface InitialsArgs {
  /** Name or phrase */
  text: string;
  /** Maximum initials */
  limit?: number;
}

/**
 * Count 1 bits in a nonnegative integer
 * Utility category: numbers.
 */
export interface IntegerBitCountArgs {
  /** Integer */
  value: number;
}

/**
 * Calculate IQR and Tukey outlier fences
 * Utility category: statistics.
 */
export interface InterquartileRangeArgs {
  /** Numeric samples */
  values: unknown[];
}

/**
 * Read ISO week, weekday and week-numbering year
 * Utility category: dates.
 */
export interface IsoWeekArgs {
  /** YYYY-MM-DD */
  date: string;
}

/**
 * Read a nested JSON object by a simple dotted path
 * Utility category: data.
 */
export interface JsonExtractPathArgs {
  /** Source document */
  value: Record<string, unknown>;
  /** Dot-separated keys */
  path: string;
}

/**
 * Show changed, added and removed top-level keys
 * Utility category: data.
 */
export interface JsonObjectDiffArgs {
  /** Earlier object */
  before: Record<string, unknown>;
  /** Later object */
  after: Record<string, unknown>;
}

/**
 * Detect which common writing script is most visible
 * Utility category: strings.
 */
export interface LanguageScriptHintArgs {
  /** Passage */
  text: string;
}

/**
 * Check Gregorian leap-year status
 * Utility category: dates.
 */
export interface LeapYearArgs {
  /** Year */
  year: number;
}

/**
 * Prefix each line with its line number
 * Utility category: strings.
 */
export interface LineNumbersArgs {
  /** Multiline text */
  text: string;
  /** Starting number */
  start?: number;
}

/**
 * Find a point on a line between two measurements
 * Utility category: numbers.
 */
export interface LinearInterpolationArgs {
  /** Start X */
  x0: number;
  /** Start Y */
  y0: number;
  /** End X */
  x1: number;
  /** End Y */
  y1: number;
  /** Query X */
  x: number;
}

/**
 * Fit least-squares slope and intercept for simple regression
 * Utility category: statistics.
 */
export interface LinearRegressionArgs {
  /** Numeric x series */
  x: unknown[];
  /** Numeric y series */
  y: unknown[];
}

/**
 * List accepted symbols for each conversion category
 * Utility category: measure.
 */
export interface ListUnitsArgs {
  /** Category, or blank for all */
  category?: string;
}

/**
 * Find exact substring positions without regular expressions
 * Utility category: strings.
 */
export interface LiteralFindArgs {
  /** Text */
  text: string;
  /** Search term */
  needle: string;
  /** Case insensitive */
  ignore_case?: boolean;
}

/**
 * Convert a JSON table into escaped CSV text
 * Utility category: data.
 */
export interface MakeCsvArgs {
  /** Rows to encode */
  rows: unknown[];
  /** Delimiter */
  delimiter?: string;
}

/**
 * Create a simple Markdown table of contents
 * Utility category: strings.
 */
export interface MarkdownTocArgs {
  /** Markdown document */
  text: string;
}

/**
 * Mask characters of a user-supplied non-secret identifier
 * Utility category: strings.
 */
export interface MaskIdentifierArgs {
  /** Identifier */
  text: string;
  /** Trailing visible characters */
  keep_last?: number;
}

/**
 * Compute a definite integral over a bounded numeric interval
 * Utility category: symbolic.
 */
export interface MathDefiniteIntegralArgs {
  /** Integrand */
  expression: string;
  /** Lower limit */
  lower: number;
  /** Upper limit */
  upper: number;
}

/**
 * Compute a first or higher-order derivative
 * Utility category: symbolic.
 */
export interface MathDerivativeArgs {
  /** Function, e.g. (x**2+3)**2 */
  expression: string;
  /** Differentiate with respect to */
  variable?: "x" | "y" | "z" | "t";
  /** Derivative order */
  order?: number;
}

/**
 * Substitute one numeric variable and evaluate expression
 * Utility category: symbolic.
 */
export interface MathEvaluateArgs {
  /** Expression */
  expression: string;
  /** Variable */
  variable?: "x" | "y" | "z" | "t";
  /** Substitution value */
  value: number;
}

/**
 * Expand products and integer powers
 * Utility category: symbolic.
 */
export interface MathExpandArgs {
  /** Algebraic expression */
  expression: string;
}

/**
 * Factor a bounded polynomial expression
 * Utility category: symbolic.
 */
export interface MathFactorArgs {
  /** Polynomial to factor */
  expression: string;
}

/**
 * Calculate gradient of a scalar function in up to three variables
 * Utility category: symbolic.
 */
export interface MathGradientArgs {
  /** Expression in x, y, z */
  expression: string;
  /** Variable names in order */
  variables?: unknown[];
}

/**
 * Compute the Hessian matrix of a scalar function
 * Utility category: symbolic.
 */
export interface MathHessianArgs {
  /** Expression */
  expression: string;
  /** Variables */
  variables?: unknown[];
}

/**
 * Compute a simple symbolic indefinite integral
 * Utility category: symbolic.
 */
export interface MathIndefiniteIntegralArgs {
  /** Integrand */
  expression: string;
  /** Integrating variable */
  variable?: "x" | "y" | "z" | "t";
}

/**
 * Calculate a univariate one-sided or two-sided limit
 * Utility category: symbolic.
 */
export interface MathLimitArgs {
  /** Expression */
  expression: string;
  /** Value x approaches */
  point: number;
  /** Approach direction */
  direction?: "left" | "right" | "both";
}

/**
 * Estimate derivative using centered finite differences
 * Utility category: symbolic.
 */
export interface MathNumericDerivativeArgs {
  /** Function of x */
  expression: string;
  /** Point */
  at: number;
  /** Finite difference step */
  step?: number;
}

/**
 * Compute a multivariable partial derivative
 * Utility category: symbolic.
 */
export interface MathPartialDerivativeArgs {
  /** Expression in x, y or z */
  expression: string;
  /** Partial derivative variable */
  variable: "x" | "y" | "z";
}

/**
 * Extract polynomial coefficients from highest to lowest degree
 * Utility category: symbolic.
 */
export interface MathPolynomialCoefficientsArgs {
  /** Polynomial */
  expression: string;
  /** Variable */
  variable?: "x" | "y" | "z" | "t";
}

/**
 * Simplify an algebraic expression using optional SymPy
 * Utility category: symbolic.
 */
export interface MathSimplifyArgs {
  /** Expression using x, sin(x), x**2, etc. */
  expression: string;
}

/**
 * Solve a univariate polynomial equation expression = 0
 * Utility category: symbolic.
 */
export interface MathSolvePolynomialArgs {
  /** Polynomial expression */
  expression: string;
  /** Unknown variable */
  variable?: "x" | "y" | "z" | "t";
}

/**
 * Replace one symbol with a number
 * Utility category: symbolic.
 */
export interface MathSubstituteArgs {
  /** Expression */
  expression: string;
  /** Symbol */
  variable: "x" | "y" | "z" | "t" | "a" | "b" | "c";
  /** Numeric replacement */
  value: number;
}

/**
 * Compute a truncated Taylor series at zero or another point
 * Utility category: symbolic.
 */
export interface MathTaylorSeriesArgs {
  /** Expression */
  expression: string;
  /** Expansion point */
  point?: number;
  /** Terms through order n-1 */
  order?: number;
}

/**
 * Compute average absolute deviation around the mean
 * Utility category: statistics.
 */
export interface MeanAbsoluteDeviationArgs {
  /** Numeric samples */
  values: unknown[];
}

/**
 * Calculate mean median and modes
 * Utility category: statistics.
 */
export interface MeanMedianModeArgs {
  /** Numeric samples */
  values: unknown[];
}

/**
 * Compute median absolute deviation from sample median
 * Utility category: statistics.
 */
export interface MedianAbsoluteDeviationArgs {
  /** Numeric samples */
  values: unknown[];
}

/**
 * Display total minutes as days, hours and minutes
 * Utility category: dates.
 */
export interface MinutesToDurationArgs {
  /** Total signed minutes */
  minutes: number;
}

/**
 * Compute sliding simple moving averages
 * Utility category: statistics.
 */
export interface MovingAverageArgs {
  /** Numeric time series */
  values: unknown[];
  /** Number of samples per window */
  window: number;
}

/**
 * Cumulative normal probability for a z-score
 * Utility category: probability.
 */
export interface NormalCdfArgs {
  /** Z score */
  z: number;
}

/**
 * Probability between two z-scores
 * Utility category: probability.
 */
export interface NormalIntervalArgs {
  /** Lower z score */
  low: number;
  /** Upper z score */
  high: number;
}

/**
 * Convert a measurement to standard deviation units
 * Utility category: probability.
 */
export interface NormalZscoreArgs {
  /** Observation */
  value: number;
  /** Population mean */
  mean: number;
  /** Population standard deviation */
  stddev: number;
}

/**
 * Map a numeric series to a selected range
 * Utility category: statistics.
 */
export interface NormalizeMinmaxArgs {
  /** Numeric samples */
  values: unknown[];
  /** Target lower bound */
  lower?: number;
  /** Target upper bound */
  upper?: number;
}

/**
 * Standardize Unicode whitespace and optionally case
 * Utility category: strings.
 */
export interface NormalizeTextArgs {
  /** Text */
  text: string;
  /** Convert to casefolded lowercase */
  casefold?: boolean;
}

/**
 * Find the Nth specified weekday in a calendar month
 * Utility category: dates.
 */
export interface NthWeekdayArgs {
  /** Year */
  year: number;
  /** Month */
  month: number;
  /** Monday=0 through Sunday=6 */
  weekday: number;
  /** Nth occurrence, 1–5 */
  occurrence: number;
}

/**
 * Convert an integer to binary, octal or hexadecimal
 * Utility category: numbers.
 */
export interface NumberToBaseArgs {
  /** Integer */
  value: number;
  /** Base */
  base: number;
}

/**
 * Convert positive odds ratio to probability
 * Utility category: probability.
 */
export interface OddsToProbabilityArgs {
  /** Odds for vs against */
  odds: number;
}

/**
 * Find intersection of two timezone-aware intervals
 * Utility category: dates.
 */
export interface OverlapTimeRangesArgs {
  /** Timestamp */
  first_start: string;
  /** Timestamp */
  first_end: string;
  /** Timestamp */
  second_start: string;
  /** Timestamp */
  second_end: string;
}

/**
 * Calculate minutes per km from minutes and distance
 * Utility category: measure.
 */
export interface PaceFromTimeArgs {
  /** Elapsed minutes */
  minutes: number;
  /** Distance in km */
  kilometers: number;
}

/**
 * Check if alphanumeric characters read identically backwards
 * Utility category: strings.
 */
export interface PalindromeCheckArgs {
  /** Phrase */
  text: string;
}

/**
 * Split text on empty lines
 * Utility category: strings.
 */
export interface ParagraphSplitArgs {
  /** Multiline text */
  text: string;
}

/**
 * Parse simple comma-separated data into row objects
 * Utility category: data.
 */
export interface ParseCsvArgs {
  /** CSV content */
  text: string;
  /** Field delimiter */
  delimiter?: string;
}

/**
 * Validate and decode a JSON text value
 * Utility category: data.
 */
export interface ParseJsonArgs {
  /** JSON document */
  text: string;
}

/**
 * Extract query-string parameters without issuing HTTP requests
 * Utility category: strings.
 */
export interface ParseQuerystringArgs {
  /** URL query string */
  text: string;
}

/**
 * Parse 24-hour clock time to elapsed minutes
 * Utility category: dates.
 */
export interface ParseTimeHhmmArgs {
  /** HH:MM */
  time: string;
}

/**
 * Compute Pearson linear correlation for paired data
 * Utility category: statistics.
 */
export interface PearsonCorrelationArgs {
  /** First numeric series */
  first: unknown[];
  /** Second numeric series */
  second: unknown[];
}

/**
 * Calculate the relative percentage change
 * Utility category: numbers.
 */
export interface PercentChangeArgs {
  /** Original value */
  before: number;
  /** Updated value */
  after: number;
}

/**
 * Calculate a percentage of any positive or negative number
 * Utility category: numbers.
 */
export interface PercentOfArgs {
  /** The percentage */
  part: number;
  /** The amount */
  whole: number;
}

/**
 * Calculate percent share for each nonnegative contribution
 * Utility category: statistics.
 */
export interface PercentOfTotalArgs {
  /** Nonnegative numeric values */
  values: unknown[];
}

/**
 * Compare two measurements symmetrically
 * Utility category: numbers.
 */
export interface PercentageDifferenceArgs {
  /** First amount */
  first: number;
  /** Second amount */
  second: number;
}

/**
 * Percent of observations less than or equal to a given value
 * Utility category: statistics.
 */
export interface PercentileRankArgs {
  /** Numeric samples */
  values: unknown[];
  /** Value to compare */
  value: number;
}

/**
 * Ordered arrangements of k selected items
 * Utility category: probability.
 */
export interface PermutationsArgs {
  /** Total items */
  n: number;
  /** Selected items */
  k: number;
}

/**
 * Compute approximate pixels per inch for a display
 * Utility category: measure.
 */
export interface PixelDensityArgs {
  /** Horizontal pixels */
  width_px: number;
  /** Vertical pixels */
  height_px: number;
  /** Diagonal screen size */
  diagonal_inches: number;
}

/**
 * Poisson probability of exactly k events
 * Utility category: probability.
 */
export interface PoissonExactArgs {
  /** Expected number of events */
  rate: number;
  /** Number of observed events */
  count: number;
}

/**
 * Get count min max span and mean from numeric data
 * Utility category: statistics.
 */
export interface PopulationRangeArgs {
  /** Numeric samples */
  values: unknown[];
}

/**
 * Calculate energy from constant power and elapsed time
 * Utility category: measure.
 */
export interface PowerEnergyArgs {
  /** Power in W */
  watts: number;
  /** Duration in hours */
  hours: number;
}

/**
 * Check whether an integer is prime using trial division
 * Utility category: numbers.
 */
export interface PrimeCheckArgs {
  /** Integer to check */
  value: number;
}

/**
 * Find prime factors of a moderate integer
 * Utility category: numbers.
 */
export interface PrimeFactorsArgs {
  /** Positive integer */
  value: number;
}

/**
 * Compute the complement of an event probability
 * Utility category: probability.
 */
export interface ProbabilityNotArgs {
  /** Event probability */
  p: number;
}

/**
 * Convert event probability into odds for vs against
 * Utility category: probability.
 */
export interface ProbabilityToOddsArgs {
  /** Probability */
  probability: number;
}

/**
 * Solve a proportion a/b=c/d for missing d
 * Utility category: numbers.
 */
export interface ProportionArgs {
  /** Known numerator */
  a: number;
  /** Known denominator */
  b: number;
  /** Known second numerator */
  c: number;
}

/**
 * Solve a right triangle hypotenuse from two sides
 * Utility category: numbers.
 */
export interface PythagoreanArgs {
  /** First leg */
  a: number;
  /** Second leg */
  b: number;
}

/**
 * List variables assigned in Python source
 * Utility category: software.
 */
export interface PythonAssignmentNamesArgs {
  /** Source */
  source: string;
}

/**
 * Count syntax node types in a Python file
 * Utility category: software.
 */
export interface PythonAstCountsArgs {
  /** Source */
  source: string;
}

/**
 * Find bare excepts and broad exception handlers
 * Utility category: software.
 */
export interface PythonBroadExceptionCandidatesArgs {
  /** Source */
  source: string;
}

/**
 * List function call names statically from Python source
 * Utility category: software.
 */
export interface PythonCallNamesArgs {
  /** Source */
  source: string;
}

/**
 * Extract classes, bases, methods, and source line numbers
 * Utility category: software.
 */
export interface PythonClassesArgs {
  /** Source text */
  source: string;
}

/**
 * Estimate branch-based cyclomatic complexity of Python functions
 * Utility category: software.
 */
export interface PythonComplexityArgs {
  /** Source */
  source: string;
}

/**
 * List simple module-level constant assignments
 * Utility category: software.
 */
export interface PythonConstantValuesArgs {
  /** Source */
  source: string;
}

/**
 * Produce a class/function declaration outline
 * Utility category: software.
 */
export interface PythonDefinitionOutlineArgs {
  /** Source */
  source: string;
}

/**
 * Collect module, class and function docstrings
 * Utility category: software.
 */
export interface PythonDocstringsArgs {
  /** Source */
  source: string;
}

/**
 * Suggest grouping import modules by name
 * Utility category: software.
 */
export interface PythonFormatImportSuggestionsArgs {
  /** Source */
  source: string;
}

/**
 * List functions, arguments, line ranges and async markers
 * Utility category: software.
 */
export interface PythonFunctionsArgs {
  /** Source text */
  source: string;
}

/**
 * Extract literal import statements without importing packages
 * Utility category: software.
 */
export interface PythonImportsArgs {
  /** Source */
  source: string;
}

/**
 * Check Python keyword and identifier rules
 * Utility category: software.
 */
export interface PythonKeywordCheckArgs {
  /** Candidate variable or function name */
  name: string;
}

/**
 * Find literal list/dict/set defaults in function definitions
 * Utility category: software.
 */
export interface PythonMutableDefaultCandidatesArgs {
  /** Source */
  source: string;
}

/**
 * Parse Python source and report syntax errors without running code
 * Utility category: software.
 */
export interface PythonSyntaxCheckArgs {
  /** Source text */
  source: string;
}

/**
 * Locate TODO and FIXME comments
 * Utility category: software.
 */
export interface PythonTodoCommentsArgs {
  /** Source text */
  source: string;
}

/**
 * Find imports whose names are not referenced elsewhere in the AST
 * Utility category: software.
 */
export interface PythonUnusedImportCandidatesArgs {
  /** Source */
  source: string;
}

/**
 * Solve a real quadratic equation ax²+bx+c=0
 * Utility category: numbers.
 */
export interface QuadraticRootsArgs {
  /** Coefficient a */
  a: number;
  /** Coefficient b */
  b: number;
  /** Coefficient c */
  c: number;
}

/**
 * Find a linearly interpolated quantile
 * Utility category: statistics.
 */
export interface QuantileArgs {
  /** Numeric samples */
  values: unknown[];
  /** Fraction between 0 and 1 */
  quantile: number;
}

/**
 * Reduce an integer ratio using the greatest common divisor
 * Utility category: numbers.
 */
export interface RatioSimplifyArgs {
  /** First integer */
  a: number;
  /** Second integer */
  b: number;
}

/**
 * Predict y using fitted line from paired training data
 * Utility category: statistics.
 */
export interface RegressionPredictArgs {
  /** Training x series */
  x: unknown[];
  /** Training y series */
  y: unknown[];
  /** New x */
  predict_x: number;
}

/**
 * Filter blank lines from a passage
 * Utility category: strings.
 */
export interface RemoveEmptyLinesArgs {
  /** Multiline text */
  text: string;
}

/**
 * Replace literal text with another substring
 * Utility category: strings.
 */
export interface ReplaceLiteralArgs {
  /** Input */
  text: string;
  /** Exact old text */
  old: string;
  /** Replacement */
  new: string;
  /** Maximum replacements */
  limit?: number;
}

/**
 * Rescale an image to fit within given bounds, preserving aspect ratio
 * Utility category: measure.
 */
export interface RescaleImageArgs {
  /** Original width */
  width: number;
  /** Original height */
  height: number;
  /** Target width */
  max_width: number;
  /** Target height */
  max_height: number;
  /** Allow enlarging the original */
  upscale?: boolean;
}

/**
 * Calculate root-mean-square of numeric values
 * Utility category: statistics.
 */
export interface RootMeanSquareArgs {
  /** Numbers */
  values: unknown[];
}

/**
 * Round a finite number to N significant digits
 * Utility category: numbers.
 */
export interface RoundSignificantArgs {
  /** Number */
  value: number;
  /** Significant digits */
  digits: number;
}

/**
 * Estimate standard error for a sample average
 * Utility category: probability.
 */
export interface SampleMeanStandardErrorArgs {
  /** Sample standard deviation */
  stddev: number;
  /** Number of observations */
  sample_size: number;
}

/**
 * Wilson interval for a sample percentage
 * Utility category: probability.
 */
export interface SampleProportionIntervalArgs {
  /** Number of successes */
  successes: number;
  /** Total trials */
  trials: number;
  /** Critical z value */
  z?: number;
}

/**
 * Split a passage into sentences with their order preserved
 * Utility category: strings.
 */
export interface SentenceSplitArgs {
  /** Passage */
  text: string;
}

/**
 * Flag values outside the interquartile fence
 * Utility category: time_series.
 */
export interface SeriesAnomalyIqrArgs {
  /** Observed values */
  values: unknown[];
  /** IQR multiplier */
  multiplier?: number;
}

/**
 * Flag values exceeding a standard z-score threshold
 * Utility category: time_series.
 */
export interface SeriesAnomalyZscoreArgs {
  /** Observed values */
  values: unknown[];
  /** Absolute z threshold */
  threshold?: number;
}

/**
 * Lagged autocorrelation of a time series
 * Utility category: time_series.
 */
export interface SeriesAutocorrelationArgs {
  /** Observations */
  values: unknown[];
  /** Positive lag */
  lag: number;
}

/**
 * Centered mean smoothing for an odd-width window
 * Utility category: time_series.
 */
export interface SeriesCenteredSmoothingArgs {
  /** Values */
  values: unknown[];
  /** Odd window */
  window?: number;
}

/**
 * Pearson correlation of two aligned series
 * Utility category: time_series.
 */
export interface SeriesCrossCorrelationArgs {
  /** First series */
  first: unknown[];
  /** Second series */
  second: unknown[];
}

/**
 * Running product across observations
 * Utility category: time_series.
 */
export interface SeriesCumulativeProductArgs {
  /** Numbers */
  values: unknown[];
}

/**
 * Running total across observations
 * Utility category: time_series.
 */
export interface SeriesCumulativeSumArgs {
  /** Numbers */
  values: unknown[];
}

/**
 * Subtract the least-squares linear trend from a series
 * Utility category: time_series.
 */
export interface SeriesDetrendArgs {
  /** Observed series */
  values: unknown[];
}

/**
 * Compute successive first differences
 * Utility category: time_series.
 */
export interface SeriesDifferencesArgs {
  /** Time-ordered numbers */
  values: unknown[];
}

/**
 * Compute drop relative to running maximum, in percent
 * Utility category: time_series.
 */
export interface SeriesDrawdownArgs {
  /** Positive observed values */
  values: unknown[];
}

/**
 * Exponentially weighted moving average (EMA)
 * Utility category: time_series.
 */
export interface SeriesExponentialAverageArgs {
  /** Observations */
  values: unknown[];
  /** Smoothing span */
  span: number;
}

/**
 * Constant-mean baseline forecast
 * Utility category: time_series.
 */
export interface SeriesForecastAverageArgs {
  /** Historical data */
  values: unknown[];
  /** Steps ahead */
  steps?: number;
}

/**
 * Last-observation-carried-forward baseline forecast
 * Utility category: time_series.
 */
export interface SeriesForecastLastArgs {
  /** Historical data */
  values: unknown[];
  /** Future steps */
  steps?: number;
}

/**
 * Extrapolate a fitted linear trend with explicit caveat
 * Utility category: time_series.
 */
export interface SeriesForecastLinearArgs {
  /** Historical values */
  values: unknown[];
  /** Number of forecast steps */
  steps?: number;
}

/**
 * Autocorrelation values for a range of lags
 * Utility category: time_series.
 */
export interface SeriesLagTableArgs {
  /** Observations */
  values: unknown[];
  /** Maximum lag */
  max_lag?: number;
}

/**
 * List the largest absolute changes between neighboring values
 * Utility category: time_series.
 */
export interface SeriesLargestChangesArgs {
  /** Values */
  values: unknown[];
  /** Maximum changes */
  limit?: number;
}

/**
 * Fit a least-squares time trend across equal intervals
 * Utility category: time_series.
 */
export interface SeriesLinearTrendArgs {
  /** Observed series */
  values: unknown[];
}

/**
 * Subtract observation from k steps earlier
 * Utility category: time_series.
 */
export interface SeriesMomentumArgs {
  /** Series */
  values: unknown[];
  /** Number of periods back */
  period: number;
}

/**
 * Trailing simple moving average over a fixed window
 * Utility category: time_series.
 */
export interface SeriesMovingAverageArgs {
  /** Observations */
  values: unknown[];
  /** Window length */
  window: number;
}

/**
 * Scale finite observations to a 0..1 range
 * Utility category: time_series.
 */
export interface SeriesNormalizeMinmaxArgs {
  /** Observations */
  values: unknown[];
}

/**
 * Return indices and values of min and max observations
 * Utility category: time_series.
 */
export interface SeriesPeakTroughArgs {
  /** Observations */
  values: unknown[];
}

/**
 * Percentage growth from each observation to the next
 * Utility category: time_series.
 */
export interface SeriesPercentChangeArgs {
  /** Time-ordered numbers */
  values: unknown[];
}

/**
 * Rebase a series to an index value of 100
 * Utility category: time_series.
 */
export interface SeriesRebaseArgs {
  /** Observations */
  values: unknown[];
}

/**
 * Aggregate adjacent values into non-overlapping chunks
 * Utility category: time_series.
 */
export interface SeriesResampleChunksArgs {
  /** Series */
  values: unknown[];
  /** Observations per chunk */
  size: number;
  /** Use sum instead of mean */
  method?: boolean;
}

/**
 * Maximum over each trailing observation window
 * Utility category: time_series.
 */
export interface SeriesRollingMaximumArgs {
  /** Observations */
  values: unknown[];
  /** Window size */
  window: number;
}

/**
 * Minimum over each trailing observation window
 * Utility category: time_series.
 */
export interface SeriesRollingMinimumArgs {
  /** Observations */
  values: unknown[];
  /** Window size */
  window: number;
}

/**
 * Sample standard deviation in each rolling window
 * Utility category: time_series.
 */
export interface SeriesRollingStddevArgs {
  /** Observations */
  values: unknown[];
  /** Window size */
  window: number;
}

/**
 * Compute consecutive runs of equal categorical values
 * Utility category: time_series.
 */
export interface SeriesRunLengthsArgs {
  /** Categorical sequence */
  values: unknown[];
}

/**
 * Transform observations into z-score units
 * Utility category: time_series.
 */
export interface SeriesStandardizeArgs {
  /** Observations */
  values: unknown[];
}

/**
 * Count crossings between negative and positive values
 * Utility category: time_series.
 */
export interface SeriesZeroCrossingsArgs {
  /** Values */
  values: unknown[];
}

/**
 * Compute Shannon information entropy in bits
 * Utility category: probability.
 */
export interface ShannonEntropyArgs {
  /** Probabilities */
  probabilities: unknown[];
}

/**
 * Calculate non-compound interest, not investment advice
 * Utility category: numbers.
 */
export interface SimpleInterestArgs {
  /** Initial principal */
  principal: number;
  /** Annual interest percentage */
  annual_percent: number;
  /** Number of years */
  years: number;
}

/**
 * Reproducible weighted random sampling for education
 * Utility category: probability.
 */
export interface SimulateDiscreteArgs {
  /** Possible outcomes */
  values: unknown[];
  /** Nonnegative weights */
  weights: unknown[];
  /** Number of draws */
  count?: number;
  /** Random seed */
  seed?: number;
}

/**
 * Create a URL-friendly ASCII slug from a title
 * Utility category: strings.
 */
export interface SlugifyArgs {
  /** Title or phrase */
  text: string;
}

/**
 * Sort a list of lines alphabetically
 * Utility category: strings.
 */
export interface SortLinesArgs {
  /** Multiline text */
  text: string;
  /** Descending order */
  reverse?: boolean;
  /** Case insensitive */
  casefold?: boolean;
}

/**
 * Check raw bracket balances for plain text, not a parser
 * Utility category: software.
 */
export interface SourceBracketBalanceArgs {
  /** Text */
  source: string;
}

/**
 * Generate a bounded unified diff for two text versions
 * Utility category: software.
 */
export interface SourceDiffArgs {
  /** Earlier text */
  before: string;
  /** New text */
  after: string;
  /** Context lines */
  context?: number;
}

/**
 * Find links appearing in an arbitrary text input
 * Utility category: software.
 */
export interface SourceExtractUrlsArgs {
  /** Text to inspect */
  source: string;
}

/**
 * Count repeated nonempty lines of pasted source
 * Utility category: software.
 */
export interface SourceFindRepeatedLinesArgs {
  /** Source */
  source: string;
  /** Minimum repetitions */
  minimum?: number;
}

/**
 * Summarize indentation widths in source text
 * Utility category: software.
 */
export interface SourceIndentProfileArgs {
  /** Source text */
  source: string;
}

/**
 * Count blank and nonblank source lines
 * Utility category: software.
 */
export interface SourceLinesArgs {
  /** Source */
  source: string;
}

/**
 * Report source lines with trailing whitespace
 * Utility category: software.
 */
export interface SourceTrailingSpaceLinesArgs {
  /** Source text */
  source: string;
}

/**
 * Compute Spearman rank correlation with tie averaging
 * Utility category: statistics.
 */
export interface SpearmanCorrelationArgs {
  /** First numeric series */
  first: unknown[];
  /** Second numeric series */
  second: unknown[];
}

/**
 * Calculate average speed from time and distance
 * Utility category: measure.
 */
export interface SpeedFromDistanceArgs {
  /** Distance in km */
  kilometers: number;
  /** Elapsed hours */
  hours: number;
}

/**
 * Compute sphere volume and surface area
 * Utility category: measure.
 */
export interface SphereVolumeArgs {
  /** Sphere radius */
  radius: number;
}

/**
 * Compute standard error of sample mean
 * Utility category: statistics.
 */
export interface StandardErrorArgs {
  /** Numeric samples */
  values: unknown[];
}

/**
 * Get first and last day of a month
 * Utility category: dates.
 */
export interface StartEndOfMonthArgs {
  /** A date within the month */
  date: string;
}

/**
 * Add a fixed text field to every record
 * Utility category: data.
 */
export interface TableAddConstantArgs {
  /** Rows */
  rows: unknown[];
  /** New field name */
  column: string;
  /** Assigned value */
  value: string;
}

/**
 * Average a numeric column, ignoring empty values
 * Utility category: data.
 */
export interface TableColumnAverageArgs {
  /** Rows */
  rows: unknown[];
  /** Field */
  column: string;
}

/**
 * Numeric count, sum, mean, median and range
 * Utility category: data.
 */
export interface TableColumnStatisticsArgs {
  /** Rows */
  rows: unknown[];
  /** Field */
  column: string;
}

/**
 * Add a numeric column, ignoring empty values
 * Utility category: data.
 */
export interface TableColumnSumArgs {
  /** Rows */
  rows: unknown[];
  /** Field */
  column: string;
}

/**
 * List all columns present in a JSON table
 * Utility category: data.
 */
export interface TableColumnsArgs {
  /** Table of row objects */
  rows: unknown[];
}

/**
 * Produce frequency counts for combinations of columns
 * Utility category: data.
 */
export interface TableCrossTabArgs {
  /** Rows */
  rows: unknown[];
  /** Fields to group */
  columns: unknown[];
}

/**
 * Group ISO date strings by month
 * Utility category: data.
 */
export interface TableDateBucketArgs {
  /** Rows */
  rows: unknown[];
  /** ISO date field */
  date_column: string;
}

/**
 * Remove duplicate complete JSON rows
 * Utility category: data.
 */
export interface TableDistinctArgs {
  /** Rows */
  rows: unknown[];
}

/**
 * Remove rows whose specified fields are all empty
 * Utility category: data.
 */
export interface TableDropEmptyArgs {
  /** Rows */
  rows: unknown[];
  /** Field names */
  columns: unknown[];
}

/**
 * Replace absent or null fields with a chosen value
 * Utility category: data.
 */
export interface TableFillMissingArgs {
  /** Rows */
  rows: unknown[];
  /** Field */
  column: string;
  /** Replacement text */
  value: string;
}

/**
 * Filter rows by exact value for a named column
 * Utility category: data.
 */
export interface TableFilterEqualArgs {
  /** Rows */
  rows: unknown[];
  /** Field name */
  column: string;
  /** Desired text value */
  value: string;
  /** Exact case match */
  case_sensitive?: boolean;
}

/**
 * Filter rows based on a number comparison
 * Utility category: data.
 */
export interface TableFilterNumericArgs {
  /** Rows */
  rows: unknown[];
  /** Field name */
  column: string;
  /** Comparison */
  comparison: "gt" | "gte" | "lt" | "lte" | "eq" | "neq";
  /** Numeric threshold */
  value: number;
}

/**
 * Count records grouped by a categorical field
 * Utility category: data.
 */
export interface TableGroupCountArgs {
  /** Rows */
  rows: unknown[];
  /** Category field */
  column: string;
}

/**
 * Sum a numeric column grouped by a category
 * Utility category: data.
 */
export interface TableGroupSumArgs {
  /** Rows */
  rows: unknown[];
  /** Category field */
  group_by: string;
  /** Numeric field */
  value_column: string;
}

/**
 * Join two small tables on an exact string key
 * Utility category: data.
 */
export interface TableJoinArgs {
  /** Left table */
  left: unknown[];
  /** Right table */
  right: unknown[];
  /** Common join field */
  key: string;
}

/**
 * Count combinations of two categorical fields
 * Utility category: data.
 */
export interface TablePivotCountsArgs {
  /** Rows */
  rows: unknown[];
  /** Rows */
  row_field: string;
  /** Columns */
  column_field: string;
}

/**
 * Rename one field in every row without changing values
 * Utility category: data.
 */
export interface TableRenameColumnArgs {
  /** Rows */
  rows: unknown[];
  /** Old name */
  before: string;
  /** New name */
  after: string;
}

/**
 * Select and reorder table columns
 * Utility category: data.
 */
export interface TableSelectArgs {
  /** Rows */
  rows: unknown[];
  /** Desired field names */
  columns: unknown[];
}

/**
 * Sort a table on a column, sorting missing values last
 * Utility category: data.
 */
export interface TableSortArgs {
  /** Rows */
  rows: unknown[];
  /** Sort column */
  column: string;
  /** Reverse sort order */
  descending?: boolean;
}

/**
 * Take a bounded slice of rows
 * Utility category: data.
 */
export interface TableTakeArgs {
  /** Rows */
  rows: unknown[];
  /** Start index */
  start?: number;
  /** Maximum returned rows */
  count?: number;
}

/**
 * Transpose a small matrix of lists
 * Utility category: data.
 */
export interface TableTransposeArgs {
  /** Rectangular matrix */
  matrix: unknown[];
}

/**
 * Find unique values in one table column
 * Utility category: data.
 */
export interface TableUniqueArgs {
  /** Rows */
  rows: unknown[];
  /** Field */
  column: string;
}

/**
 * Count occurrences of each value in a column
 * Utility category: data.
 */
export interface TableValueCountsArgs {
  /** Rows */
  rows: unknown[];
  /** Field */
  column: string;
  /** Results limit */
  limit?: number;
}

/**
 * Add a percentage-based tax as a mathematical operation
 * Utility category: numbers.
 */
export interface TaxAdditionArgs {
  /** Subtotal */
  subtotal: number;
  /** Tax rate */
  tax_percent: number;
}

/**
 * Create a unified line-by-line difference between text versions
 * Utility category: strings.
 */
export interface TextDiffArgs {
  /** Original */
  before: string;
  /** Updated */
  after: string;
}

/**
 * Compare two passages using lexical similarity and shared keywords
 * Utility category: strings.
 */
export interface TextSimilarityArgs {
  /** First passage */
  first: string;
  /** Second passage */
  second: string;
}

/**
 * Profile word count sentences and document traits
 * Utility category: strings.
 */
export interface TextStatsArgs {
  /** Text to analyze */
  text: string;
}

/**
 * Select source sentences as a short extractive summary
 * Utility category: strings.
 */
export interface TextSummaryArgs {
  /** Passage */
  text: string;
  /** Number of sentences */
  sentences_count?: number;
}

/**
 * Wrap plain text to a specified column width
 * Utility category: strings.
 */
export interface TextWrapArgs {
  /** Plain text */
  text: string;
  /** Columns */
  width?: number;
  /** Preserve whitespace */
  preserve_whitespace?: boolean;
}

/**
 * Count complete focus blocks fitting into available minutes
 * Utility category: dates.
 */
export interface TimeBlockCountArgs {
  /** Available time */
  available_minutes: number;
  /** Work block length */
  work_minutes: number;
  /** Rest block length */
  break_minutes?: number;
}

/**
 * Make fixed-duration study or work slots
 * Utility category: dates.
 */
export interface TimeSlotScheduleArgs {
  /** ISO timestamp with timezone */
  start: string;
  /** Slots */
  number: number;
  /** Time per slot */
  slot_minutes: number;
  /** Break after each slot */
  break_minutes?: number;
}

/**
 * Convert an explicit timestamp between IANA timezones
 * Utility category: dates.
 */
export interface TimezoneConvertArgs {
  /** ISO datetime with UTC offset */
  timestamp: string;
  /** IANA zone name, e.g. Asia/Kolkata */
  destination: string;
}

/**
 * Calculate a total with a user-chosen gratuity
 * Utility category: numbers.
 */
export interface TipCalculatorArgs {
  /** Bill amount */
  bill: number;
  /** Tip percentage */
  tip_percent: number;
  /** People sharing the bill */
  people?: number;
}

/**
 * List common adjacent two-word phrases
 * Utility category: strings.
 */
export interface TopBigramsArgs {
  /** Passage */
  text: string;
  /** Phrase count */
  limit?: number;
}

/**
 * Extract common non-stopword terms from a passage
 * Utility category: strings.
 */
export interface TopKeywordsArgs {
  /** Passage */
  text: string;
  /** Keyword count */
  limit?: number;
}

/**
 * Triangle area using base and height
 * Utility category: numbers.
 */
export interface TriangleAreaArgs {
  /** Base */
  base: number;
  /** Height */
  height: number;
}

/**
 * Probability of a subinterval in a uniform range
 * Utility category: probability.
 */
export interface UniformProbabilityArgs {
  /** Minimum */
  minimum: number;
  /** Maximum */
  maximum: number;
  /** Event lower limit */
  event_low: number;
  /** Event upper limit */
  event_high: number;
}

/**
 * Decode percent-encoded URL text
 * Utility category: strings.
 */
export interface UrlDecodeComponentArgs {
  /** Encoded text */
  text: string;
}

/**
 * Percent-encode one URL path component
 * Utility category: strings.
 */
export interface UrlEncodeComponentArgs {
  /** Text */
  text: string;
}

/**
 * Compute growth rates between consecutive measurements
 * Utility category: statistics.
 */
export interface ValueGrowthRateArgs {
  /** Numeric series */
  values: unknown[];
}

/**
 * Sample or population variance and standard deviation
 * Utility category: statistics.
 */
export interface VarianceArgs {
  /** Numeric samples */
  values: unknown[];
  /** Use sample n-1 denominator */
  sample?: boolean;
}

/**
 * Read weekday name and ISO weekday number for a date
 * Utility category: dates.
 */
export interface WeekdayArgs {
  /** YYYY-MM-DD */
  date: string;
}

/**
 * Calculate weighted arithmetic mean
 * Utility category: numbers.
 */
export interface WeightedAverageArgs {
  /** Numeric values */
  values: unknown[];
  /** Nonnegative weights */
  weights: unknown[];
}

/**
 * Count words within a passage
 * Utility category: strings.
 */
export interface WordFrequencyArgs {
  /** Passage */
  text: string;
  /** Maximum frequency rows */
  limit?: number;
}

/**
 * Standardize samples using population deviation
 * Utility category: statistics.
 */
export interface ZScoresArgs {
  /** Numeric samples */
  values: unknown[];
}

/** Access the complete local JARVIS deterministic skills library. */
export class JarvisUtilityClient {
  constructor(private readonly transport: JarvisTransport) {}

  /**
   * Advance a specified number of weekdays
   * Category: dates.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async add_business_days(args: AddBusinessDaysArgs): Promise<UtilityResult> {
    const payload = { name: "add_business_days", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Add or subtract calendar days
   * Category: dates.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async add_days(args: AddDaysArgs): Promise<UtilityResult> {
    const payload = { name: "add_days", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Add calendar months, clamping day to month length
   * Category: dates.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async add_months(args: AddMonthsArgs): Promise<UtilityResult> {
    const payload = { name: "add_months", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Check whether two phrases use the same alphanumeric characters
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async anagram_check(args: AnagramCheckArgs): Promise<UtilityResult> {
    const payload = { name: "anagram_check", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Produce a finite arithmetic progression
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async arithmetic_sequence(args: ArithmeticSequenceArgs): Promise<UtilityResult> {
    const payload = { name: "arithmetic_sequence", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Simplify pixel aspect ratio
   * Category: measure.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async aspect_ratio(args: AspectRatioArgs): Promise<UtilityResult> {
    const payload = { name: "aspect_ratio", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Parse a base-2 to base-36 integer
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async base_to_number(args: BaseToNumberArgs): Promise<UtilityResult> {
    const payload = { name: "base_to_number", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Update a prior probability using sensitivity and false-positive rate
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async bayes_rule(args: BayesRuleArgs): Promise<UtilityResult> {
    const payload = { name: "bayes_rule", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Binomial probability of at least k successes
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async binomial_at_least(args: BinomialAtLeastArgs): Promise<UtilityResult> {
    const payload = { name: "binomial_at_least", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Binomial probability of exactly k successes
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async binomial_exact(args: BinomialExactArgs): Promise<UtilityResult> {
    const payload = { name: "binomial_exact", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Expected value and variance of a binomial distribution
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async binomial_mean_variance(args: BinomialMeanVarianceArgs): Promise<UtilityResult> {
    const payload = { name: "binomial_mean_variance", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Approximate chance two people share a birthday
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async birthday_collision(args: BirthdayCollisionArgs): Promise<UtilityResult> {
    const payload = { name: "birthday_collision", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Convert bit count to full and remaining bytes
   * Category: measure.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async bits_to_bytes(args: BitsToBytesArgs): Promise<UtilityResult> {
    const payload = { name: "bits_to_bytes", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute deterministic bootstrap means for a small sample
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async bootstrap_mean(args: BootstrapMeanArgs): Promise<UtilityResult> {
    const payload = { name: "bootstrap_mean", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Build URL query string from key-value pairs
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async build_querystring(args: BuildQuerystringArgs): Promise<UtilityResult> {
    const payload = { name: "build_querystring", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Count weekdays Monday–Friday in inclusive date range, not holidays
   * Category: dates.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async business_days(args: BusinessDaysArgs): Promise<UtilityResult> {
    const payload = { name: "business_days", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Convert bytes to bits
   * Category: measure.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async bytes_to_bits(args: BytesToBitsArgs): Promise<UtilityResult> {
    const payload = { name: "bytes_to_bits", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Create a month grid of dates and empty cells
   * Category: dates.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async calendar_month(args: CalendarMonthArgs): Promise<UtilityResult> {
    const payload = { name: "calendar_month", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Transform labels into snake kebab camel pascal title or constant case
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async case_transform(args: CaseTransformArgs): Promise<UtilityResult> {
    const payload = { name: "case_transform", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Count Unicode codepoints by broad category
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async character_count(args: CharacterCountArgs): Promise<UtilityResult> {
    const payload = { name: "character_count", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Circle area and circumference for a positive radius
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async circle_area(args: CircleAreaArgs): Promise<UtilityResult> {
    const payload = { name: "circle_area", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Constrain a value between two numbers
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async clamp_number(args: ClampNumberArgs): Promise<UtilityResult> {
    const payload = { name: "clamp_number", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute standard deviation relative to mean
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async coefficient_of_variation(args: CoefficientOfVariationArgs): Promise<UtilityResult> {
    const payload = { name: "coefficient_of_variation", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Distribution of heads across a fixed number of fair flips
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async coin_toss_distribution(args: CoinTossDistributionArgs): Promise<UtilityResult> {
    const payload = { name: "coin_toss_distribution", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Number of ways to select k items without order
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async combinations(args: CombinationsArgs): Promise<UtilityResult> {
    const payload = { name: "combinations", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Find words present in both texts
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async common_words(args: CommonWordsArgs): Promise<UtilityResult> {
    const payload = { name: "common_words", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute compounded hypothetical growth
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async compound_growth(args: CompoundGrowthArgs): Promise<UtilityResult> {
    const payload = { name: "compound_growth", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute P(A given B) from joint and marginal probabilities
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async conditional_probability(args: ConditionalProbabilityArgs): Promise<UtilityResult> {
    const payload = { name: "conditional_probability", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute cone volume
   * Category: measure.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async cone_volume(args: ConeVolumeArgs): Promise<UtilityResult> {
    const payload = { name: "cone_volume", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Convert Celsius Fahrenheit and Kelvin
   * Category: measure.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async convert_temperature(args: ConvertTemperatureArgs): Promise<UtilityResult> {
    const payload = { name: "convert_temperature", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Convert between defined units in a physical category
   * Category: measure.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async convert_units(args: ConvertUnitsArgs): Promise<UtilityResult> {
    const payload = { name: "convert_units", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute correlations among several same-length series
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async correlation_matrix(args: CorrelationMatrixArgs): Promise<UtilityResult> {
    const payload = { name: "correlation_matrix", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute sample or population covariance
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async covariance(args: CovarianceArgs): Promise<UtilityResult> {
    const payload = { name: "covariance", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute cuboid volume and surface area
   * Category: measure.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async cuboid_volume(args: CuboidVolumeArgs): Promise<UtilityResult> {
    const payload = { name: "cuboid_volume", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Calculate bounded running products
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async cumulative_product(args: CumulativeProductArgs): Promise<UtilityResult> {
    const payload = { name: "cumulative_product", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Calculate running totals for a numeric list
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async cumulative_sum(args: CumulativeSumArgs): Promise<UtilityResult> {
    const payload = { name: "cumulative_sum", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute cylinder volume in input cubic units
   * Category: measure.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async cylinder_volume(args: CylinderVolumeArgs): Promise<UtilityResult> {
    const payload = { name: "cylinder_volume", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Generate an inclusive list of dates in a short interval
   * Category: dates.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async date_range(args: DateRangeArgs): Promise<UtilityResult> {
    const payload = { name: "date_range", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Calculate a signed difference between instants
   * Category: dates.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async datetime_difference(args: DatetimeDifferenceArgs): Promise<UtilityResult> {
    const payload = { name: "datetime_difference", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Calculate signed calendar days between two ISO dates
   * Category: dates.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async days_between(args: DaysBetweenArgs): Promise<UtilityResult> {
    const payload = { name: "days_between", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Measure date-based progress through a known project timeline
   * Category: dates.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async deadline_progress(args: DeadlineProgressArgs): Promise<UtilityResult> {
    const payload = { name: "deadline_progress", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Remove repeated lines while preserving first occurrence
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async deduplicate_lines(args: DeduplicateLinesArgs): Promise<UtilityResult> {
    const payload = { name: "deduplicate_lines", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Show repeated full sentences
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async detect_repetitions(args: DetectRepetitionsArgs): Promise<UtilityResult> {
    const payload = { name: "detect_repetitions", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Exact discrete distribution for small fair dice sums
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async dice_sum_distribution(args: DiceSumDistributionArgs): Promise<UtilityResult> {
    const payload = { name: "dice_sum_distribution", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Apply a discount percentage
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async discount_price(args: DiscountPriceArgs): Promise<UtilityResult> {
    const payload = { name: "discount_price", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Calculate Euclidean distance between two 2D points
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async distance_2d(args: Distance2dArgs): Promise<UtilityResult> {
    const payload = { name: "distance_2d", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Calculate distance traveled at constant speed
   * Category: measure.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async distance_from_speed(args: DistanceFromSpeedArgs): Promise<UtilityResult> {
    const payload = { name: "distance_from_speed", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Estimate download time without network measurement
   * Category: measure.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async download_time_estimate(args: DownloadTimeEstimateArgs): Promise<UtilityResult> {
    const payload = { name: "download_time_estimate", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Solve voltage current or resistance from the other two
   * Category: measure.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async electric_ohms_law(args: ElectricOhmsLawArgs): Promise<UtilityResult> {
    const payload = { name: "electric_ohms_law", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Divide a bill or quantity equally
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async equal_split(args: EqualSplitArgs): Promise<UtilityResult> {
    const payload = { name: "equal_split", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute expectation of a discrete probability distribution
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async expected_value(args: ExpectedValueArgs): Promise<UtilityResult> {
    const payload = { name: "expected_value", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute exponential weighted moving average
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async exponential_moving_average(args: ExponentialMovingAverageArgs): Promise<UtilityResult> {
    const payload = { name: "exponential_moving_average", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Extract Markdown headings from an outline
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async extract_headings(args: ExtractHeadingsArgs): Promise<UtilityResult> {
    const payload = { name: "extract_headings", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Extract explicit date email URL hashtag and time patterns
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async extract_patterns(args: ExtractPatternsArgs): Promise<UtilityResult> {
    const payload = { name: "extract_patterns", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * List HTTP(S) URLs visibly present in plain text
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async extract_urls(args: ExtractUrlsArgs): Promise<UtilityResult> {
    const payload = { name: "extract_urls", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Calculate factorial n! for a bounded nonnegative integer
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async factorial(args: FactorialArgs): Promise<UtilityResult> {
    const payload = { name: "factorial", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Factorial of a bounded nonnegative integer
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async factorial_probability(args: FactorialProbabilityArgs): Promise<UtilityResult> {
    const payload = { name: "factorial_probability", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Generate the first N Fibonacci numbers
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async fibonacci(args: FibonacciArgs): Promise<UtilityResult> {
    const payload = { name: "fibonacci", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Format a byte count in binary or decimal units
   * Category: measure.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async file_size_format(args: FileSizeFormatArgs): Promise<UtilityResult> {
    const payload = { name: "file_size_format", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Find minimum quartiles median and maximum
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async five_number_summary(args: FiveNumberSummaryArgs): Promise<UtilityResult> {
    const payload = { name: "five_number_summary", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Pretty-print a bounded JSON value
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async format_json(args: FormatJsonArgs): Promise<UtilityResult> {
    const payload = { name: "format_json", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Convert minutes since midnight to HH:MM, wrapping each day
   * Category: dates.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async format_time_hhmm(args: FormatTimeHhmmArgs): Promise<UtilityResult> {
    const payload = { name: "format_time_hhmm", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Add, subtract, multiply or divide two rational numbers
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async fraction_operations(args: FractionOperationsArgs): Promise<UtilityResult> {
    const payload = { name: "fraction_operations", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Count occurrences of categorical labels
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async frequency_table(args: FrequencyTableArgs): Promise<UtilityResult> {
    const payload = { name: "frequency_table", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Find close candidate titles for a supplied name
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async fuzzy_titles(args: FuzzyTitlesArgs): Promise<UtilityResult> {
    const payload = { name: "fuzzy_titles", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute the greatest common divisor and least common multiple
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async gcd_lcm(args: GcdLcmArgs): Promise<UtilityResult> {
    const payload = { name: "gcd_lcm", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Probability first success occurs on a chosen trial
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async geometric_exact(args: GeometricExactArgs): Promise<UtilityResult> {
    const payload = { name: "geometric_exact", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Calculate geometric mean for positive values
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async geometric_mean(args: GeometricMeanArgs): Promise<UtilityResult> {
    const payload = { name: "geometric_mean", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Produce a bounded geometric progression
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async geometric_sequence(args: GeometricSequenceArgs): Promise<UtilityResult> {
    const payload = { name: "geometric_sequence", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Represent an edge list as a node-neighbor dictionary
   * Category: graphs.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async graph_adjacency_list(args: GraphAdjacencyListArgs): Promise<UtilityResult> {
    const payload = { name: "graph_adjacency_list", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Create a small binary adjacency matrix
   * Category: graphs.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async graph_adjacency_matrix(args: GraphAdjacencyMatrixArgs): Promise<UtilityResult> {
    const payload = { name: "graph_adjacency_matrix", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Check whether an undirected graph can be two-colored
   * Category: graphs.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async graph_bipartite(args: GraphBipartiteArgs): Promise<UtilityResult> {
    const payload = { name: "graph_bipartite", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Estimate closeness centrality using shortest hop counts
   * Category: graphs.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async graph_closeness(args: GraphClosenessArgs): Promise<UtilityResult> {
    const payload = { name: "graph_closeness", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Connected components in an undirected graph
   * Category: graphs.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async graph_components(args: GraphComponentsArgs): Promise<UtilityResult> {
    const payload = { name: "graph_components", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Calculate a dependency path for tasks with durations
   * Category: graphs.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async graph_critical_path(args: GraphCriticalPathArgs): Promise<UtilityResult> {
    const payload = { name: "graph_critical_path", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute degree statistics of graph nodes
   * Category: graphs.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async graph_degree(args: GraphDegreeArgs): Promise<UtilityResult> {
    const payload = { name: "graph_degree", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Calculate the density of a graph
   * Category: graphs.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async graph_density(args: GraphDensityArgs): Promise<UtilityResult> {
    const payload = { name: "graph_density", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Group dependent tasks into parallelizable levels
   * Category: graphs.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async graph_dependency_levels(args: GraphDependencyLevelsArgs): Promise<UtilityResult> {
    const payload = { name: "graph_dependency_levels", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Convert an adjacency matrix into an edge list
   * Category: graphs.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async graph_edges_from_matrix(args: GraphEdgesFromMatrixArgs): Promise<UtilityResult> {
    const payload = { name: "graph_edges_from_matrix", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Test directed graph for a dependency cycle
   * Category: graphs.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async graph_has_cycle(args: GraphHasCycleArgs): Promise<UtilityResult> {
    const payload = { name: "graph_has_cycle", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * List nodes reachable from a given node
   * Category: graphs.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async graph_reachable(args: GraphReachableArgs): Promise<UtilityResult> {
    const payload = { name: "graph_reachable", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Shortest unweighted path between two nodes
   * Category: graphs.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async graph_shortest_path(args: GraphShortestPathArgs): Promise<UtilityResult> {
    const payload = { name: "graph_shortest_path", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Order prerequisites in a directed acyclic graph
   * Category: graphs.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async graph_topological_order(args: GraphTopologicalOrderArgs): Promise<UtilityResult> {
    const payload = { name: "graph_topological_order", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Dijkstra shortest path with positive weights
   * Category: graphs.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async graph_weighted_shortest_path(args: GraphWeightedShortestPathArgs): Promise<UtilityResult> {
    const payload = { name: "graph_weighted_shortest_path", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Calculate harmonic mean for positive values
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async harmonic_mean(args: HarmonicMeanArgs): Promise<UtilityResult> {
    const payload = { name: "harmonic_mean", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute SHA-256 digest for plain text, not passwords
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async hash_sha256(args: HashSha256Args): Promise<UtilityResult> {
    const payload = { name: "hash_sha256", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Build a fixed-width histogram for numeric data
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async histogram(args: HistogramArgs): Promise<UtilityResult> {
    const payload = { name: "histogram", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Escape HTML special characters for safe display
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async html_escape(args: HtmlEscapeArgs): Promise<UtilityResult> {
    const payload = { name: "html_escape", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Probability of k successes sampled without replacement
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async hypergeometric_exact(args: HypergeometricExactArgs): Promise<UtilityResult> {
    const payload = { name: "hypergeometric_exact", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Estimate storage for uncompressed images in bytes
   * Category: measure.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async hyperspace_data_size(args: HyperspaceDataSizeArgs): Promise<UtilityResult> {
    const payload = { name: "hyperspace_data_size", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Probability of independent events both occurring
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async independent_and(args: IndependentAndArgs): Promise<UtilityResult> {
    const payload = { name: "independent_and", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Probability that either independent event occurs
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async independent_or(args: IndependentOrArgs): Promise<UtilityResult> {
    const payload = { name: "independent_or", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Make initials from a short phrase
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async initials(args: InitialsArgs): Promise<UtilityResult> {
    const payload = { name: "initials", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Count 1 bits in a nonnegative integer
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async integer_bit_count(args: IntegerBitCountArgs): Promise<UtilityResult> {
    const payload = { name: "integer_bit_count", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Calculate IQR and Tukey outlier fences
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async interquartile_range(args: InterquartileRangeArgs): Promise<UtilityResult> {
    const payload = { name: "interquartile_range", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Read ISO week, weekday and week-numbering year
   * Category: dates.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async iso_week(args: IsoWeekArgs): Promise<UtilityResult> {
    const payload = { name: "iso_week", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Read a nested JSON object by a simple dotted path
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async json_extract_path(args: JsonExtractPathArgs): Promise<UtilityResult> {
    const payload = { name: "json_extract_path", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Show changed, added and removed top-level keys
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async json_object_diff(args: JsonObjectDiffArgs): Promise<UtilityResult> {
    const payload = { name: "json_object_diff", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Detect which common writing script is most visible
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async language_script_hint(args: LanguageScriptHintArgs): Promise<UtilityResult> {
    const payload = { name: "language_script_hint", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Check Gregorian leap-year status
   * Category: dates.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async leap_year(args: LeapYearArgs): Promise<UtilityResult> {
    const payload = { name: "leap_year", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Prefix each line with its line number
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async line_numbers(args: LineNumbersArgs): Promise<UtilityResult> {
    const payload = { name: "line_numbers", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Find a point on a line between two measurements
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async linear_interpolation(args: LinearInterpolationArgs): Promise<UtilityResult> {
    const payload = { name: "linear_interpolation", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Fit least-squares slope and intercept for simple regression
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async linear_regression(args: LinearRegressionArgs): Promise<UtilityResult> {
    const payload = { name: "linear_regression", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * List accepted symbols for each conversion category
   * Category: measure.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async list_units(args: ListUnitsArgs): Promise<UtilityResult> {
    const payload = { name: "list_units", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Find exact substring positions without regular expressions
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async literal_find(args: LiteralFindArgs): Promise<UtilityResult> {
    const payload = { name: "literal_find", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Convert a JSON table into escaped CSV text
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async make_csv(args: MakeCsvArgs): Promise<UtilityResult> {
    const payload = { name: "make_csv", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Create a simple Markdown table of contents
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async markdown_toc(args: MarkdownTocArgs): Promise<UtilityResult> {
    const payload = { name: "markdown_toc", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Mask characters of a user-supplied non-secret identifier
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async mask_identifier(args: MaskIdentifierArgs): Promise<UtilityResult> {
    const payload = { name: "mask_identifier", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute a definite integral over a bounded numeric interval
   * Category: symbolic.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async math_definite_integral(args: MathDefiniteIntegralArgs): Promise<UtilityResult> {
    const payload = { name: "math_definite_integral", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute a first or higher-order derivative
   * Category: symbolic.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async math_derivative(args: MathDerivativeArgs): Promise<UtilityResult> {
    const payload = { name: "math_derivative", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Substitute one numeric variable and evaluate expression
   * Category: symbolic.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async math_evaluate(args: MathEvaluateArgs): Promise<UtilityResult> {
    const payload = { name: "math_evaluate", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Expand products and integer powers
   * Category: symbolic.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async math_expand(args: MathExpandArgs): Promise<UtilityResult> {
    const payload = { name: "math_expand", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Factor a bounded polynomial expression
   * Category: symbolic.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async math_factor(args: MathFactorArgs): Promise<UtilityResult> {
    const payload = { name: "math_factor", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Calculate gradient of a scalar function in up to three variables
   * Category: symbolic.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async math_gradient(args: MathGradientArgs): Promise<UtilityResult> {
    const payload = { name: "math_gradient", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute the Hessian matrix of a scalar function
   * Category: symbolic.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async math_hessian(args: MathHessianArgs): Promise<UtilityResult> {
    const payload = { name: "math_hessian", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute a simple symbolic indefinite integral
   * Category: symbolic.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async math_indefinite_integral(args: MathIndefiniteIntegralArgs): Promise<UtilityResult> {
    const payload = { name: "math_indefinite_integral", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Calculate a univariate one-sided or two-sided limit
   * Category: symbolic.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async math_limit(args: MathLimitArgs): Promise<UtilityResult> {
    const payload = { name: "math_limit", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Estimate derivative using centered finite differences
   * Category: symbolic.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async math_numeric_derivative(args: MathNumericDerivativeArgs): Promise<UtilityResult> {
    const payload = { name: "math_numeric_derivative", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute a multivariable partial derivative
   * Category: symbolic.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async math_partial_derivative(args: MathPartialDerivativeArgs): Promise<UtilityResult> {
    const payload = { name: "math_partial_derivative", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Extract polynomial coefficients from highest to lowest degree
   * Category: symbolic.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async math_polynomial_coefficients(args: MathPolynomialCoefficientsArgs): Promise<UtilityResult> {
    const payload = { name: "math_polynomial_coefficients", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Simplify an algebraic expression using optional SymPy
   * Category: symbolic.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async math_simplify(args: MathSimplifyArgs): Promise<UtilityResult> {
    const payload = { name: "math_simplify", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Solve a univariate polynomial equation expression = 0
   * Category: symbolic.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async math_solve_polynomial(args: MathSolvePolynomialArgs): Promise<UtilityResult> {
    const payload = { name: "math_solve_polynomial", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Replace one symbol with a number
   * Category: symbolic.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async math_substitute(args: MathSubstituteArgs): Promise<UtilityResult> {
    const payload = { name: "math_substitute", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute a truncated Taylor series at zero or another point
   * Category: symbolic.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async math_taylor_series(args: MathTaylorSeriesArgs): Promise<UtilityResult> {
    const payload = { name: "math_taylor_series", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute average absolute deviation around the mean
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async mean_absolute_deviation(args: MeanAbsoluteDeviationArgs): Promise<UtilityResult> {
    const payload = { name: "mean_absolute_deviation", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Calculate mean median and modes
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async mean_median_mode(args: MeanMedianModeArgs): Promise<UtilityResult> {
    const payload = { name: "mean_median_mode", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute median absolute deviation from sample median
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async median_absolute_deviation(args: MedianAbsoluteDeviationArgs): Promise<UtilityResult> {
    const payload = { name: "median_absolute_deviation", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Display total minutes as days, hours and minutes
   * Category: dates.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async minutes_to_duration(args: MinutesToDurationArgs): Promise<UtilityResult> {
    const payload = { name: "minutes_to_duration", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute sliding simple moving averages
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async moving_average(args: MovingAverageArgs): Promise<UtilityResult> {
    const payload = { name: "moving_average", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Cumulative normal probability for a z-score
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async normal_cdf(args: NormalCdfArgs): Promise<UtilityResult> {
    const payload = { name: "normal_cdf", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Probability between two z-scores
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async normal_interval(args: NormalIntervalArgs): Promise<UtilityResult> {
    const payload = { name: "normal_interval", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Convert a measurement to standard deviation units
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async normal_zscore(args: NormalZscoreArgs): Promise<UtilityResult> {
    const payload = { name: "normal_zscore", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Map a numeric series to a selected range
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async normalize_minmax(args: NormalizeMinmaxArgs): Promise<UtilityResult> {
    const payload = { name: "normalize_minmax", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Standardize Unicode whitespace and optionally case
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async normalize_text(args: NormalizeTextArgs): Promise<UtilityResult> {
    const payload = { name: "normalize_text", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Find the Nth specified weekday in a calendar month
   * Category: dates.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async nth_weekday(args: NthWeekdayArgs): Promise<UtilityResult> {
    const payload = { name: "nth_weekday", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Convert an integer to binary, octal or hexadecimal
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async number_to_base(args: NumberToBaseArgs): Promise<UtilityResult> {
    const payload = { name: "number_to_base", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Convert positive odds ratio to probability
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async odds_to_probability(args: OddsToProbabilityArgs): Promise<UtilityResult> {
    const payload = { name: "odds_to_probability", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Find intersection of two timezone-aware intervals
   * Category: dates.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async overlap_time_ranges(args: OverlapTimeRangesArgs): Promise<UtilityResult> {
    const payload = { name: "overlap_time_ranges", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Calculate minutes per km from minutes and distance
   * Category: measure.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async pace_from_time(args: PaceFromTimeArgs): Promise<UtilityResult> {
    const payload = { name: "pace_from_time", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Check if alphanumeric characters read identically backwards
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async palindrome_check(args: PalindromeCheckArgs): Promise<UtilityResult> {
    const payload = { name: "palindrome_check", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Split text on empty lines
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async paragraph_split(args: ParagraphSplitArgs): Promise<UtilityResult> {
    const payload = { name: "paragraph_split", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Parse simple comma-separated data into row objects
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async parse_csv(args: ParseCsvArgs): Promise<UtilityResult> {
    const payload = { name: "parse_csv", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Validate and decode a JSON text value
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async parse_json(args: ParseJsonArgs): Promise<UtilityResult> {
    const payload = { name: "parse_json", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Extract query-string parameters without issuing HTTP requests
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async parse_querystring(args: ParseQuerystringArgs): Promise<UtilityResult> {
    const payload = { name: "parse_querystring", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Parse 24-hour clock time to elapsed minutes
   * Category: dates.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async parse_time_hhmm(args: ParseTimeHhmmArgs): Promise<UtilityResult> {
    const payload = { name: "parse_time_hhmm", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute Pearson linear correlation for paired data
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async pearson_correlation(args: PearsonCorrelationArgs): Promise<UtilityResult> {
    const payload = { name: "pearson_correlation", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Calculate the relative percentage change
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async percent_change(args: PercentChangeArgs): Promise<UtilityResult> {
    const payload = { name: "percent_change", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Calculate a percentage of any positive or negative number
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async percent_of(args: PercentOfArgs): Promise<UtilityResult> {
    const payload = { name: "percent_of", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Calculate percent share for each nonnegative contribution
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async percent_of_total(args: PercentOfTotalArgs): Promise<UtilityResult> {
    const payload = { name: "percent_of_total", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compare two measurements symmetrically
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async percentage_difference(args: PercentageDifferenceArgs): Promise<UtilityResult> {
    const payload = { name: "percentage_difference", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Percent of observations less than or equal to a given value
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async percentile_rank(args: PercentileRankArgs): Promise<UtilityResult> {
    const payload = { name: "percentile_rank", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Ordered arrangements of k selected items
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async permutations(args: PermutationsArgs): Promise<UtilityResult> {
    const payload = { name: "permutations", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute approximate pixels per inch for a display
   * Category: measure.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async pixel_density(args: PixelDensityArgs): Promise<UtilityResult> {
    const payload = { name: "pixel_density", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Poisson probability of exactly k events
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async poisson_exact(args: PoissonExactArgs): Promise<UtilityResult> {
    const payload = { name: "poisson_exact", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Get count min max span and mean from numeric data
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async population_range(args: PopulationRangeArgs): Promise<UtilityResult> {
    const payload = { name: "population_range", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Calculate energy from constant power and elapsed time
   * Category: measure.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async power_energy(args: PowerEnergyArgs): Promise<UtilityResult> {
    const payload = { name: "power_energy", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Check whether an integer is prime using trial division
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async prime_check(args: PrimeCheckArgs): Promise<UtilityResult> {
    const payload = { name: "prime_check", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Find prime factors of a moderate integer
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async prime_factors(args: PrimeFactorsArgs): Promise<UtilityResult> {
    const payload = { name: "prime_factors", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute the complement of an event probability
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async probability_not(args: ProbabilityNotArgs): Promise<UtilityResult> {
    const payload = { name: "probability_not", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Convert event probability into odds for vs against
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async probability_to_odds(args: ProbabilityToOddsArgs): Promise<UtilityResult> {
    const payload = { name: "probability_to_odds", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Solve a proportion a/b=c/d for missing d
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async proportion(args: ProportionArgs): Promise<UtilityResult> {
    const payload = { name: "proportion", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Solve a right triangle hypotenuse from two sides
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async pythagorean(args: PythagoreanArgs): Promise<UtilityResult> {
    const payload = { name: "pythagorean", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * List variables assigned in Python source
   * Category: software.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async python_assignment_names(args: PythonAssignmentNamesArgs): Promise<UtilityResult> {
    const payload = { name: "python_assignment_names", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Count syntax node types in a Python file
   * Category: software.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async python_ast_counts(args: PythonAstCountsArgs): Promise<UtilityResult> {
    const payload = { name: "python_ast_counts", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Find bare excepts and broad exception handlers
   * Category: software.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async python_broad_exception_candidates(args: PythonBroadExceptionCandidatesArgs): Promise<UtilityResult> {
    const payload = { name: "python_broad_exception_candidates", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * List function call names statically from Python source
   * Category: software.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async python_call_names(args: PythonCallNamesArgs): Promise<UtilityResult> {
    const payload = { name: "python_call_names", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Extract classes, bases, methods, and source line numbers
   * Category: software.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async python_classes(args: PythonClassesArgs): Promise<UtilityResult> {
    const payload = { name: "python_classes", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Estimate branch-based cyclomatic complexity of Python functions
   * Category: software.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async python_complexity(args: PythonComplexityArgs): Promise<UtilityResult> {
    const payload = { name: "python_complexity", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * List simple module-level constant assignments
   * Category: software.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async python_constant_values(args: PythonConstantValuesArgs): Promise<UtilityResult> {
    const payload = { name: "python_constant_values", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Produce a class/function declaration outline
   * Category: software.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async python_definition_outline(args: PythonDefinitionOutlineArgs): Promise<UtilityResult> {
    const payload = { name: "python_definition_outline", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Collect module, class and function docstrings
   * Category: software.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async python_docstrings(args: PythonDocstringsArgs): Promise<UtilityResult> {
    const payload = { name: "python_docstrings", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Suggest grouping import modules by name
   * Category: software.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async python_format_import_suggestions(args: PythonFormatImportSuggestionsArgs): Promise<UtilityResult> {
    const payload = { name: "python_format_import_suggestions", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * List functions, arguments, line ranges and async markers
   * Category: software.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async python_functions(args: PythonFunctionsArgs): Promise<UtilityResult> {
    const payload = { name: "python_functions", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Extract literal import statements without importing packages
   * Category: software.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async python_imports(args: PythonImportsArgs): Promise<UtilityResult> {
    const payload = { name: "python_imports", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Check Python keyword and identifier rules
   * Category: software.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async python_keyword_check(args: PythonKeywordCheckArgs): Promise<UtilityResult> {
    const payload = { name: "python_keyword_check", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Find literal list/dict/set defaults in function definitions
   * Category: software.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async python_mutable_default_candidates(args: PythonMutableDefaultCandidatesArgs): Promise<UtilityResult> {
    const payload = { name: "python_mutable_default_candidates", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Parse Python source and report syntax errors without running code
   * Category: software.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async python_syntax_check(args: PythonSyntaxCheckArgs): Promise<UtilityResult> {
    const payload = { name: "python_syntax_check", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Locate TODO and FIXME comments
   * Category: software.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async python_todo_comments(args: PythonTodoCommentsArgs): Promise<UtilityResult> {
    const payload = { name: "python_todo_comments", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Find imports whose names are not referenced elsewhere in the AST
   * Category: software.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async python_unused_import_candidates(args: PythonUnusedImportCandidatesArgs): Promise<UtilityResult> {
    const payload = { name: "python_unused_import_candidates", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Solve a real quadratic equation ax²+bx+c=0
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async quadratic_roots(args: QuadraticRootsArgs): Promise<UtilityResult> {
    const payload = { name: "quadratic_roots", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Find a linearly interpolated quantile
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async quantile(args: QuantileArgs): Promise<UtilityResult> {
    const payload = { name: "quantile", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Reduce an integer ratio using the greatest common divisor
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async ratio_simplify(args: RatioSimplifyArgs): Promise<UtilityResult> {
    const payload = { name: "ratio_simplify", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Predict y using fitted line from paired training data
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async regression_predict(args: RegressionPredictArgs): Promise<UtilityResult> {
    const payload = { name: "regression_predict", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Filter blank lines from a passage
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async remove_empty_lines(args: RemoveEmptyLinesArgs): Promise<UtilityResult> {
    const payload = { name: "remove_empty_lines", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Replace literal text with another substring
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async replace_literal(args: ReplaceLiteralArgs): Promise<UtilityResult> {
    const payload = { name: "replace_literal", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Rescale an image to fit within given bounds, preserving aspect ratio
   * Category: measure.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async rescale_image(args: RescaleImageArgs): Promise<UtilityResult> {
    const payload = { name: "rescale_image", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Calculate root-mean-square of numeric values
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async root_mean_square(args: RootMeanSquareArgs): Promise<UtilityResult> {
    const payload = { name: "root_mean_square", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Round a finite number to N significant digits
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async round_significant(args: RoundSignificantArgs): Promise<UtilityResult> {
    const payload = { name: "round_significant", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Estimate standard error for a sample average
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async sample_mean_standard_error(args: SampleMeanStandardErrorArgs): Promise<UtilityResult> {
    const payload = { name: "sample_mean_standard_error", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Wilson interval for a sample percentage
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async sample_proportion_interval(args: SampleProportionIntervalArgs): Promise<UtilityResult> {
    const payload = { name: "sample_proportion_interval", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Split a passage into sentences with their order preserved
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async sentence_split(args: SentenceSplitArgs): Promise<UtilityResult> {
    const payload = { name: "sentence_split", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Flag values outside the interquartile fence
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_anomaly_iqr(args: SeriesAnomalyIqrArgs): Promise<UtilityResult> {
    const payload = { name: "series_anomaly_iqr", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Flag values exceeding a standard z-score threshold
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_anomaly_zscore(args: SeriesAnomalyZscoreArgs): Promise<UtilityResult> {
    const payload = { name: "series_anomaly_zscore", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Lagged autocorrelation of a time series
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_autocorrelation(args: SeriesAutocorrelationArgs): Promise<UtilityResult> {
    const payload = { name: "series_autocorrelation", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Centered mean smoothing for an odd-width window
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_centered_smoothing(args: SeriesCenteredSmoothingArgs): Promise<UtilityResult> {
    const payload = { name: "series_centered_smoothing", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Pearson correlation of two aligned series
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_cross_correlation(args: SeriesCrossCorrelationArgs): Promise<UtilityResult> {
    const payload = { name: "series_cross_correlation", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Running product across observations
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_cumulative_product(args: SeriesCumulativeProductArgs): Promise<UtilityResult> {
    const payload = { name: "series_cumulative_product", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Running total across observations
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_cumulative_sum(args: SeriesCumulativeSumArgs): Promise<UtilityResult> {
    const payload = { name: "series_cumulative_sum", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Subtract the least-squares linear trend from a series
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_detrend(args: SeriesDetrendArgs): Promise<UtilityResult> {
    const payload = { name: "series_detrend", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute successive first differences
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_differences(args: SeriesDifferencesArgs): Promise<UtilityResult> {
    const payload = { name: "series_differences", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute drop relative to running maximum, in percent
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_drawdown(args: SeriesDrawdownArgs): Promise<UtilityResult> {
    const payload = { name: "series_drawdown", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Exponentially weighted moving average (EMA)
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_exponential_average(args: SeriesExponentialAverageArgs): Promise<UtilityResult> {
    const payload = { name: "series_exponential_average", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Constant-mean baseline forecast
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_forecast_average(args: SeriesForecastAverageArgs): Promise<UtilityResult> {
    const payload = { name: "series_forecast_average", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Last-observation-carried-forward baseline forecast
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_forecast_last(args: SeriesForecastLastArgs): Promise<UtilityResult> {
    const payload = { name: "series_forecast_last", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Extrapolate a fitted linear trend with explicit caveat
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_forecast_linear(args: SeriesForecastLinearArgs): Promise<UtilityResult> {
    const payload = { name: "series_forecast_linear", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Autocorrelation values for a range of lags
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_lag_table(args: SeriesLagTableArgs): Promise<UtilityResult> {
    const payload = { name: "series_lag_table", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * List the largest absolute changes between neighboring values
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_largest_changes(args: SeriesLargestChangesArgs): Promise<UtilityResult> {
    const payload = { name: "series_largest_changes", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Fit a least-squares time trend across equal intervals
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_linear_trend(args: SeriesLinearTrendArgs): Promise<UtilityResult> {
    const payload = { name: "series_linear_trend", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Subtract observation from k steps earlier
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_momentum(args: SeriesMomentumArgs): Promise<UtilityResult> {
    const payload = { name: "series_momentum", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Trailing simple moving average over a fixed window
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_moving_average(args: SeriesMovingAverageArgs): Promise<UtilityResult> {
    const payload = { name: "series_moving_average", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Scale finite observations to a 0..1 range
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_normalize_minmax(args: SeriesNormalizeMinmaxArgs): Promise<UtilityResult> {
    const payload = { name: "series_normalize_minmax", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Return indices and values of min and max observations
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_peak_trough(args: SeriesPeakTroughArgs): Promise<UtilityResult> {
    const payload = { name: "series_peak_trough", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Percentage growth from each observation to the next
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_percent_change(args: SeriesPercentChangeArgs): Promise<UtilityResult> {
    const payload = { name: "series_percent_change", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Rebase a series to an index value of 100
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_rebase(args: SeriesRebaseArgs): Promise<UtilityResult> {
    const payload = { name: "series_rebase", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Aggregate adjacent values into non-overlapping chunks
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_resample_chunks(args: SeriesResampleChunksArgs): Promise<UtilityResult> {
    const payload = { name: "series_resample_chunks", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Maximum over each trailing observation window
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_rolling_maximum(args: SeriesRollingMaximumArgs): Promise<UtilityResult> {
    const payload = { name: "series_rolling_maximum", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Minimum over each trailing observation window
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_rolling_minimum(args: SeriesRollingMinimumArgs): Promise<UtilityResult> {
    const payload = { name: "series_rolling_minimum", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Sample standard deviation in each rolling window
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_rolling_stddev(args: SeriesRollingStddevArgs): Promise<UtilityResult> {
    const payload = { name: "series_rolling_stddev", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute consecutive runs of equal categorical values
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_run_lengths(args: SeriesRunLengthsArgs): Promise<UtilityResult> {
    const payload = { name: "series_run_lengths", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Transform observations into z-score units
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_standardize(args: SeriesStandardizeArgs): Promise<UtilityResult> {
    const payload = { name: "series_standardize", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Count crossings between negative and positive values
   * Category: time_series.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async series_zero_crossings(args: SeriesZeroCrossingsArgs): Promise<UtilityResult> {
    const payload = { name: "series_zero_crossings", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute Shannon information entropy in bits
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async shannon_entropy(args: ShannonEntropyArgs): Promise<UtilityResult> {
    const payload = { name: "shannon_entropy", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Calculate non-compound interest, not investment advice
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async simple_interest(args: SimpleInterestArgs): Promise<UtilityResult> {
    const payload = { name: "simple_interest", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Reproducible weighted random sampling for education
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async simulate_discrete(args: SimulateDiscreteArgs): Promise<UtilityResult> {
    const payload = { name: "simulate_discrete", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Create a URL-friendly ASCII slug from a title
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async slugify(args: SlugifyArgs): Promise<UtilityResult> {
    const payload = { name: "slugify", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Sort a list of lines alphabetically
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async sort_lines(args: SortLinesArgs): Promise<UtilityResult> {
    const payload = { name: "sort_lines", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Check raw bracket balances for plain text, not a parser
   * Category: software.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async source_bracket_balance(args: SourceBracketBalanceArgs): Promise<UtilityResult> {
    const payload = { name: "source_bracket_balance", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Generate a bounded unified diff for two text versions
   * Category: software.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async source_diff(args: SourceDiffArgs): Promise<UtilityResult> {
    const payload = { name: "source_diff", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Find links appearing in an arbitrary text input
   * Category: software.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async source_extract_urls(args: SourceExtractUrlsArgs): Promise<UtilityResult> {
    const payload = { name: "source_extract_urls", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Count repeated nonempty lines of pasted source
   * Category: software.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async source_find_repeated_lines(args: SourceFindRepeatedLinesArgs): Promise<UtilityResult> {
    const payload = { name: "source_find_repeated_lines", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Summarize indentation widths in source text
   * Category: software.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async source_indent_profile(args: SourceIndentProfileArgs): Promise<UtilityResult> {
    const payload = { name: "source_indent_profile", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Count blank and nonblank source lines
   * Category: software.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async source_lines(args: SourceLinesArgs): Promise<UtilityResult> {
    const payload = { name: "source_lines", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Report source lines with trailing whitespace
   * Category: software.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async source_trailing_space_lines(args: SourceTrailingSpaceLinesArgs): Promise<UtilityResult> {
    const payload = { name: "source_trailing_space_lines", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute Spearman rank correlation with tie averaging
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async spearman_correlation(args: SpearmanCorrelationArgs): Promise<UtilityResult> {
    const payload = { name: "spearman_correlation", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Calculate average speed from time and distance
   * Category: measure.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async speed_from_distance(args: SpeedFromDistanceArgs): Promise<UtilityResult> {
    const payload = { name: "speed_from_distance", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute sphere volume and surface area
   * Category: measure.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async sphere_volume(args: SphereVolumeArgs): Promise<UtilityResult> {
    const payload = { name: "sphere_volume", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute standard error of sample mean
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async standard_error(args: StandardErrorArgs): Promise<UtilityResult> {
    const payload = { name: "standard_error", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Get first and last day of a month
   * Category: dates.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async start_end_of_month(args: StartEndOfMonthArgs): Promise<UtilityResult> {
    const payload = { name: "start_end_of_month", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Add a fixed text field to every record
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async table_add_constant(args: TableAddConstantArgs): Promise<UtilityResult> {
    const payload = { name: "table_add_constant", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Average a numeric column, ignoring empty values
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async table_column_average(args: TableColumnAverageArgs): Promise<UtilityResult> {
    const payload = { name: "table_column_average", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Numeric count, sum, mean, median and range
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async table_column_statistics(args: TableColumnStatisticsArgs): Promise<UtilityResult> {
    const payload = { name: "table_column_statistics", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Add a numeric column, ignoring empty values
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async table_column_sum(args: TableColumnSumArgs): Promise<UtilityResult> {
    const payload = { name: "table_column_sum", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * List all columns present in a JSON table
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async table_columns(args: TableColumnsArgs): Promise<UtilityResult> {
    const payload = { name: "table_columns", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Produce frequency counts for combinations of columns
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async table_cross_tab(args: TableCrossTabArgs): Promise<UtilityResult> {
    const payload = { name: "table_cross_tab", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Group ISO date strings by month
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async table_date_bucket(args: TableDateBucketArgs): Promise<UtilityResult> {
    const payload = { name: "table_date_bucket", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Remove duplicate complete JSON rows
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async table_distinct(args: TableDistinctArgs): Promise<UtilityResult> {
    const payload = { name: "table_distinct", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Remove rows whose specified fields are all empty
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async table_drop_empty(args: TableDropEmptyArgs): Promise<UtilityResult> {
    const payload = { name: "table_drop_empty", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Replace absent or null fields with a chosen value
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async table_fill_missing(args: TableFillMissingArgs): Promise<UtilityResult> {
    const payload = { name: "table_fill_missing", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Filter rows by exact value for a named column
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async table_filter_equal(args: TableFilterEqualArgs): Promise<UtilityResult> {
    const payload = { name: "table_filter_equal", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Filter rows based on a number comparison
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async table_filter_numeric(args: TableFilterNumericArgs): Promise<UtilityResult> {
    const payload = { name: "table_filter_numeric", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Count records grouped by a categorical field
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async table_group_count(args: TableGroupCountArgs): Promise<UtilityResult> {
    const payload = { name: "table_group_count", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Sum a numeric column grouped by a category
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async table_group_sum(args: TableGroupSumArgs): Promise<UtilityResult> {
    const payload = { name: "table_group_sum", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Join two small tables on an exact string key
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async table_join(args: TableJoinArgs): Promise<UtilityResult> {
    const payload = { name: "table_join", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Count combinations of two categorical fields
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async table_pivot_counts(args: TablePivotCountsArgs): Promise<UtilityResult> {
    const payload = { name: "table_pivot_counts", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Rename one field in every row without changing values
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async table_rename_column(args: TableRenameColumnArgs): Promise<UtilityResult> {
    const payload = { name: "table_rename_column", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Select and reorder table columns
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async table_select(args: TableSelectArgs): Promise<UtilityResult> {
    const payload = { name: "table_select", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Sort a table on a column, sorting missing values last
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async table_sort(args: TableSortArgs): Promise<UtilityResult> {
    const payload = { name: "table_sort", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Take a bounded slice of rows
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async table_take(args: TableTakeArgs): Promise<UtilityResult> {
    const payload = { name: "table_take", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Transpose a small matrix of lists
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async table_transpose(args: TableTransposeArgs): Promise<UtilityResult> {
    const payload = { name: "table_transpose", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Find unique values in one table column
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async table_unique(args: TableUniqueArgs): Promise<UtilityResult> {
    const payload = { name: "table_unique", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Count occurrences of each value in a column
   * Category: data.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async table_value_counts(args: TableValueCountsArgs): Promise<UtilityResult> {
    const payload = { name: "table_value_counts", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Add a percentage-based tax as a mathematical operation
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async tax_addition(args: TaxAdditionArgs): Promise<UtilityResult> {
    const payload = { name: "tax_addition", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Create a unified line-by-line difference between text versions
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async text_diff(args: TextDiffArgs): Promise<UtilityResult> {
    const payload = { name: "text_diff", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compare two passages using lexical similarity and shared keywords
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async text_similarity(args: TextSimilarityArgs): Promise<UtilityResult> {
    const payload = { name: "text_similarity", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Profile word count sentences and document traits
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async text_stats(args: TextStatsArgs): Promise<UtilityResult> {
    const payload = { name: "text_stats", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Select source sentences as a short extractive summary
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async text_summary(args: TextSummaryArgs): Promise<UtilityResult> {
    const payload = { name: "text_summary", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Wrap plain text to a specified column width
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async text_wrap(args: TextWrapArgs): Promise<UtilityResult> {
    const payload = { name: "text_wrap", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Count complete focus blocks fitting into available minutes
   * Category: dates.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async time_block_count(args: TimeBlockCountArgs): Promise<UtilityResult> {
    const payload = { name: "time_block_count", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Make fixed-duration study or work slots
   * Category: dates.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async time_slot_schedule(args: TimeSlotScheduleArgs): Promise<UtilityResult> {
    const payload = { name: "time_slot_schedule", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Convert an explicit timestamp between IANA timezones
   * Category: dates.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async timezone_convert(args: TimezoneConvertArgs): Promise<UtilityResult> {
    const payload = { name: "timezone_convert", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Calculate a total with a user-chosen gratuity
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async tip_calculator(args: TipCalculatorArgs): Promise<UtilityResult> {
    const payload = { name: "tip_calculator", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * List common adjacent two-word phrases
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async top_bigrams(args: TopBigramsArgs): Promise<UtilityResult> {
    const payload = { name: "top_bigrams", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Extract common non-stopword terms from a passage
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async top_keywords(args: TopKeywordsArgs): Promise<UtilityResult> {
    const payload = { name: "top_keywords", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Triangle area using base and height
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async triangle_area(args: TriangleAreaArgs): Promise<UtilityResult> {
    const payload = { name: "triangle_area", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Probability of a subinterval in a uniform range
   * Category: probability.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async uniform_probability(args: UniformProbabilityArgs): Promise<UtilityResult> {
    const payload = { name: "uniform_probability", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Decode percent-encoded URL text
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async url_decode_component(args: UrlDecodeComponentArgs): Promise<UtilityResult> {
    const payload = { name: "url_decode_component", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Percent-encode one URL path component
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async url_encode_component(args: UrlEncodeComponentArgs): Promise<UtilityResult> {
    const payload = { name: "url_encode_component", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Compute growth rates between consecutive measurements
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async value_growth_rate(args: ValueGrowthRateArgs): Promise<UtilityResult> {
    const payload = { name: "value_growth_rate", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Sample or population variance and standard deviation
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async variance(args: VarianceArgs): Promise<UtilityResult> {
    const payload = { name: "variance", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Read weekday name and ISO weekday number for a date
   * Category: dates.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async weekday(args: WeekdayArgs): Promise<UtilityResult> {
    const payload = { name: "weekday", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Calculate weighted arithmetic mean
   * Category: numbers.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async weighted_average(args: WeightedAverageArgs): Promise<UtilityResult> {
    const payload = { name: "weighted_average", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Count words within a passage
   * Category: strings.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async word_frequency(args: WordFrequencyArgs): Promise<UtilityResult> {
    const payload = { name: "word_frequency", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

  /**
   * Standardize samples using population deviation
   * Category: statistics.
   * Calls /api/utilities/run; authentication is handled by the transport.
   * Returns a structured result or throws JarvisAPIError.
   */
  async z_scores(args: ZScoresArgs): Promise<UtilityResult> {
    const payload = { name: "z_scores", arguments: args };
    const result = await this.transport.request('POST', '/api/utilities/run', {body:payload});
    return result as UtilityResult;
  }

}

/** Schema metadata for in-app catalog search, help and form generation. */
export interface SkillInfo {
  name: string;
  category: string;
  description: string;
  parameters: Record<string, unknown>;
  examples: string[];
}

export const JARVIS_SKILL_CATALOG: readonly SkillInfo[] = [
  {
    name: "add_business_days",
    category: "dates",
    description: "Advance a specified number of weekdays",
    parameters: {
      "start": {"type": "string", "description": "YYYY-MM-DD", "minLength": 0, "maxLength": 5000},
      "days": {"type": "integer", "description": "Signed weekdays", "minimum": -10000, "maximum": 10000},
    },
    examples: [],
  },
  {
    name: "add_days",
    category: "dates",
    description: "Add or subtract calendar days",
    parameters: {
      "date": {"type": "string", "description": "YYYY-MM-DD", "minLength": 0, "maxLength": 5000},
      "days": {"type": "integer", "description": "Signed number of days", "minimum": -365000, "maximum": 365000},
    },
    examples: [],
  },
  {
    name: "add_months",
    category: "dates",
    description: "Add calendar months, clamping day to month length",
    parameters: {
      "date": {"type": "string", "description": "YYYY-MM-DD", "minLength": 0, "maxLength": 5000},
      "months": {"type": "integer", "description": "Signed number of months", "minimum": -12000, "maximum": 12000},
    },
    examples: [],
  },
  {
    name: "anagram_check",
    category: "strings",
    description: "Check whether two phrases use the same alphanumeric characters",
    parameters: {
      "first": {"type": "string", "description": "Phrase 1", "minLength": 0, "maxLength": 5000},
      "second": {"type": "string", "description": "Phrase 2", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "arithmetic_sequence",
    category: "numbers",
    description: "Produce a finite arithmetic progression",
    parameters: {
      "start": {"type": "number", "description": "First term"},
      "difference": {"type": "number", "description": "Common difference"},
      "count": {"type": "integer", "description": "Terms", "minimum": 1, "maximum": 1000},
    },
    examples: [],
  },
  {
    name: "aspect_ratio",
    category: "measure",
    description: "Simplify pixel aspect ratio",
    parameters: {
      "width": {"type": "integer", "description": "Width", "minimum": 1},
      "height": {"type": "integer", "description": "Height", "minimum": 1},
    },
    examples: [],
  },
  {
    name: "base_to_number",
    category: "numbers",
    description: "Parse a base-2 to base-36 integer",
    parameters: {
      "text": {"type": "string", "description": "Digit string", "minLength": 0, "maxLength": 100},
      "base": {"type": "integer", "description": "Base", "minimum": 2, "maximum": 36},
    },
    examples: [],
  },
  {
    name: "bayes_rule",
    category: "probability",
    description: "Update a prior probability using sensitivity and false-positive rate",
    parameters: {
      "prior": {"type": "number", "description": "Prior P(H)", "minimum": 0, "maximum": 1},
      "sensitivity": {"type": "number", "description": "P(E given H)", "minimum": 0, "maximum": 1},
      "false_positive": {"type": "number", "description": "P(E given not H)", "minimum": 0, "maximum": 1},
    },
    examples: [],
  },
  {
    name: "binomial_at_least",
    category: "probability",
    description: "Binomial probability of at least k successes",
    parameters: {
      "trials": {"type": "integer", "description": "Trials", "minimum": 0, "maximum": 1000},
      "successes": {"type": "integer", "description": "Minimum successes", "minimum": 0, "maximum": 1000},
      "p": {"type": "number", "description": "Success probability", "minimum": 0, "maximum": 1},
    },
    examples: [],
  },
  {
    name: "binomial_exact",
    category: "probability",
    description: "Binomial probability of exactly k successes",
    parameters: {
      "trials": {"type": "integer", "description": "Independent trials", "minimum": 0, "maximum": 1000},
      "successes": {"type": "integer", "description": "Success count", "minimum": 0, "maximum": 1000},
      "p": {"type": "number", "description": "Success chance", "minimum": 0, "maximum": 1},
    },
    examples: [],
  },
  {
    name: "binomial_mean_variance",
    category: "probability",
    description: "Expected value and variance of a binomial distribution",
    parameters: {
      "trials": {"type": "integer", "description": "Number of trials", "minimum": 0, "maximum": 1000000},
      "p": {"type": "number", "description": "Success probability", "minimum": 0, "maximum": 1},
    },
    examples: [],
  },
  {
    name: "birthday_collision",
    category: "probability",
    description: "Approximate chance two people share a birthday",
    parameters: {
      "people": {"type": "integer", "description": "Group size", "minimum": 0, "maximum": 365},
    },
    examples: [],
  },
  {
    name: "bits_to_bytes",
    category: "measure",
    description: "Convert bit count to full and remaining bytes",
    parameters: {
      "bits": {"type": "integer", "description": "Bit count", "minimum": 0},
    },
    examples: [],
  },
  {
    name: "bootstrap_mean",
    category: "probability",
    description: "Compute deterministic bootstrap means for a small sample",
    parameters: {
      "values": {"type": "array", "description": "Input observations"},
      "replicates": {"type": "integer", "description": "Replicates", "minimum": 10, "maximum": 500},
      "seed": {"type": "integer", "description": "Random seed", "minimum": -100000, "maximum": 100000},
    },
    examples: [],
  },
  {
    name: "build_querystring",
    category: "strings",
    description: "Build URL query string from key-value pairs",
    parameters: {
      "items": {"type": "array", "description": "Pairs as objects with key and value"},
    },
    examples: [],
  },
  {
    name: "business_days",
    category: "dates",
    description: "Count weekdays Monday–Friday in inclusive date range, not holidays",
    parameters: {
      "start": {"type": "string", "description": "YYYY-MM-DD", "minLength": 0, "maxLength": 5000},
      "end": {"type": "string", "description": "YYYY-MM-DD", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "bytes_to_bits",
    category: "measure",
    description: "Convert bytes to bits",
    parameters: {
      "bytes": {"type": "integer", "description": "Byte count", "minimum": 0},
    },
    examples: [],
  },
  {
    name: "calendar_month",
    category: "dates",
    description: "Create a month grid of dates and empty cells",
    parameters: {
      "year": {"type": "integer", "description": "Year", "minimum": 1, "maximum": 9999},
      "month": {"type": "integer", "description": "Month", "minimum": 1, "maximum": 12},
      "monday_first": {"type": "boolean", "description": "Start weeks on Monday"},
    },
    examples: [],
  },
  {
    name: "case_transform",
    category: "strings",
    description: "Transform labels into snake kebab camel pascal title or constant case",
    parameters: {
      "text": {"type": "string", "description": "Text", "minLength": 0, "maxLength": 5000},
      "style": {"type": "string", "description": "Style", "minLength": 0, "maxLength": 5000, "enum": ["snake", "kebab", "camel", "pascal", "title", "constant"]},
    },
    examples: [],
  },
  {
    name: "character_count",
    category: "strings",
    description: "Count Unicode codepoints by broad category",
    parameters: {
      "text": {"type": "string", "description": "Passage", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "circle_area",
    category: "numbers",
    description: "Circle area and circumference for a positive radius",
    parameters: {
      "radius": {"type": "number", "description": "Radius", "minimum": 0},
    },
    examples: [],
  },
  {
    name: "clamp_number",
    category: "numbers",
    description: "Constrain a value between two numbers",
    parameters: {
      "value": {"type": "number", "description": "Input"},
      "minimum": {"type": "number", "description": "Lower limit"},
      "maximum": {"type": "number", "description": "Upper limit"},
    },
    examples: [],
  },
  {
    name: "coefficient_of_variation",
    category: "statistics",
    description: "Compute standard deviation relative to mean",
    parameters: {
      "values": {"type": "array", "description": "Numeric samples"},
    },
    examples: [],
  },
  {
    name: "coin_toss_distribution",
    category: "probability",
    description: "Distribution of heads across a fixed number of fair flips",
    parameters: {
      "flips": {"type": "integer", "description": "Number of flips", "minimum": 0, "maximum": 100},
    },
    examples: [],
  },
  {
    name: "combinations",
    category: "probability",
    description: "Number of ways to select k items without order",
    parameters: {
      "n": {"type": "integer", "description": "Total items", "minimum": 0, "maximum": 1000},
      "k": {"type": "integer", "description": "Selected items", "minimum": 0, "maximum": 1000},
    },
    examples: [],
  },
  {
    name: "common_words",
    category: "strings",
    description: "Find words present in both texts",
    parameters: {
      "first": {"type": "string", "description": "First text", "minLength": 0, "maxLength": 5000},
      "second": {"type": "string", "description": "Second text", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "compound_growth",
    category: "numbers",
    description: "Compute compounded hypothetical growth",
    parameters: {
      "principal": {"type": "number", "description": "Initial value", "minimum": 0},
      "annual_percent": {"type": "number", "description": "Annual growth rate"},
      "years": {"type": "number", "description": "Years", "minimum": 0, "maximum": 100},
      "periods": {"type": "integer", "description": "Compounding periods per year", "minimum": 1, "maximum": 365},
    },
    examples: [],
  },
  {
    name: "conditional_probability",
    category: "probability",
    description: "Compute P(A given B) from joint and marginal probabilities",
    parameters: {
      "joint": {"type": "number", "description": "P(A and B)", "minimum": 0, "maximum": 1},
      "given": {"type": "number", "description": "P(B)", "minimum": 0, "maximum": 1},
    },
    examples: [],
  },
  {
    name: "cone_volume",
    category: "measure",
    description: "Compute cone volume",
    parameters: {
      "radius": {"type": "number", "description": "Base radius", "minimum": 0},
      "height": {"type": "number", "description": "Cone height", "minimum": 0},
    },
    examples: [],
  },
  {
    name: "convert_temperature",
    category: "measure",
    description: "Convert Celsius Fahrenheit and Kelvin",
    parameters: {
      "value": {"type": "number", "description": "Temperature"},
      "origin": {"type": "string", "description": "c, f or k", "minLength": 0, "maxLength": 5000},
      "destination": {"type": "string", "description": "c, f or k", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "convert_units",
    category: "measure",
    description: "Convert between defined units in a physical category",
    parameters: {
      "value": {"type": "number", "description": "Numeric amount"},
      "category": {"type": "string", "description": "One of the unit categories", "minLength": 0, "maxLength": 5000},
      "origin": {"type": "string", "description": "Source symbol", "minLength": 0, "maxLength": 5000},
      "destination": {"type": "string", "description": "Target symbol", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "correlation_matrix",
    category: "statistics",
    description: "Compute correlations among several same-length series",
    parameters: {
      "series": {"type": "array", "description": "List of numeric series"},
    },
    examples: [],
  },
  {
    name: "covariance",
    category: "statistics",
    description: "Compute sample or population covariance",
    parameters: {
      "first": {"type": "array", "description": "Numeric series"},
      "second": {"type": "array", "description": "Paired numeric series"},
      "sample": {"type": "boolean", "description": "Sample covariance"},
    },
    examples: [],
  },
  {
    name: "cuboid_volume",
    category: "measure",
    description: "Compute cuboid volume and surface area",
    parameters: {
      "length": {"type": "number", "description": "Length", "minimum": 0},
      "width": {"type": "number", "description": "Width", "minimum": 0},
      "height": {"type": "number", "description": "Height", "minimum": 0},
    },
    examples: [],
  },
  {
    name: "cumulative_product",
    category: "statistics",
    description: "Calculate bounded running products",
    parameters: {
      "values": {"type": "array", "description": "Numeric values"},
    },
    examples: [],
  },
  {
    name: "cumulative_sum",
    category: "statistics",
    description: "Calculate running totals for a numeric list",
    parameters: {
      "values": {"type": "array", "description": "Numeric values"},
    },
    examples: [],
  },
  {
    name: "cylinder_volume",
    category: "measure",
    description: "Compute cylinder volume in input cubic units",
    parameters: {
      "radius": {"type": "number", "description": "Base radius", "minimum": 0},
      "height": {"type": "number", "description": "Height", "minimum": 0},
    },
    examples: [],
  },
  {
    name: "date_range",
    category: "dates",
    description: "Generate an inclusive list of dates in a short interval",
    parameters: {
      "start": {"type": "string", "description": "YYYY-MM-DD", "minLength": 0, "maxLength": 5000},
      "end": {"type": "string", "description": "YYYY-MM-DD", "minLength": 0, "maxLength": 5000},
      "every_days": {"type": "integer", "description": "Interval in days", "minimum": 1, "maximum": 365},
    },
    examples: [],
  },
  {
    name: "datetime_difference",
    category: "dates",
    description: "Calculate a signed difference between instants",
    parameters: {
      "start": {"type": "string", "description": "ISO datetime with offset", "minLength": 0, "maxLength": 5000},
      "end": {"type": "string", "description": "ISO datetime with offset", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "days_between",
    category: "dates",
    description: "Calculate signed calendar days between two ISO dates",
    parameters: {
      "start": {"type": "string", "description": "YYYY-MM-DD", "minLength": 0, "maxLength": 5000},
      "end": {"type": "string", "description": "YYYY-MM-DD", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "deadline_progress",
    category: "dates",
    description: "Measure date-based progress through a known project timeline",
    parameters: {
      "started": {"type": "string", "description": "YYYY-MM-DD", "minLength": 0, "maxLength": 5000},
      "deadline": {"type": "string", "description": "YYYY-MM-DD", "minLength": 0, "maxLength": 5000},
      "current": {"type": "string", "description": "YYYY-MM-DD", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "deduplicate_lines",
    category: "strings",
    description: "Remove repeated lines while preserving first occurrence",
    parameters: {
      "text": {"type": "string", "description": "Multiline text", "minLength": 0, "maxLength": 5000},
      "ignore_case": {"type": "boolean", "description": "Compare case insensitively"},
    },
    examples: [],
  },
  {
    name: "detect_repetitions",
    category: "strings",
    description: "Show repeated full sentences",
    parameters: {
      "text": {"type": "string", "description": "Document", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "dice_sum_distribution",
    category: "probability",
    description: "Exact discrete distribution for small fair dice sums",
    parameters: {
      "dice": {"type": "integer", "description": "Number of dice", "minimum": 1, "maximum": 5},
      "sides": {"type": "integer", "description": "Faces per die", "minimum": 2, "maximum": 20},
    },
    examples: [],
  },
  {
    name: "discount_price",
    category: "numbers",
    description: "Apply a discount percentage",
    parameters: {
      "original": {"type": "number", "description": "Original price", "minimum": 0},
      "discount_percent": {"type": "number", "description": "Discount", "minimum": 0, "maximum": 100},
    },
    examples: [],
  },
  {
    name: "distance_2d",
    category: "numbers",
    description: "Calculate Euclidean distance between two 2D points",
    parameters: {
      "x1": {"type": "number", "description": "X 1"},
      "y1": {"type": "number", "description": "Y 1"},
      "x2": {"type": "number", "description": "X 2"},
      "y2": {"type": "number", "description": "Y 2"},
    },
    examples: [],
  },
  {
    name: "distance_from_speed",
    category: "measure",
    description: "Calculate distance traveled at constant speed",
    parameters: {
      "kilometers_per_hour": {"type": "number", "description": "Average speed", "minimum": 0},
      "hours": {"type": "number", "description": "Elapsed hours", "minimum": 0},
    },
    examples: [],
  },
  {
    name: "download_time_estimate",
    category: "measure",
    description: "Estimate download time without network measurement",
    parameters: {
      "size_megabytes": {"type": "number", "description": "File size MB decimal", "minimum": 0},
      "bandwidth_megabits_per_second": {"type": "number", "description": "Mbps", "minimum": 0.001},
    },
    examples: [],
  },
  {
    name: "electric_ohms_law",
    category: "measure",
    description: "Solve voltage current or resistance from the other two",
    parameters: {
      "volts": {"type": "number", "description": "Voltage, 0 if unknown"},
      "amps": {"type": "number", "description": "Current, 0 if unknown"},
      "ohms": {"type": "number", "description": "Resistance, 0 if unknown"},
      "solve_for": {"type": "string", "description": "One of volts amps ohms", "minLength": 0, "maxLength": 5000, "enum": ["volts", "amps", "ohms"]},
    },
    examples: [],
  },
  {
    name: "equal_split",
    category: "numbers",
    description: "Divide a bill or quantity equally",
    parameters: {
      "total": {"type": "number", "description": "Total amount"},
      "people": {"type": "integer", "description": "Number of people", "minimum": 1, "maximum": 10000},
    },
    examples: [],
  },
  {
    name: "expected_value",
    category: "probability",
    description: "Compute expectation of a discrete probability distribution",
    parameters: {
      "values": {"type": "array", "description": "Possible outcomes"},
      "probabilities": {"type": "array", "description": "Corresponding probabilities"},
    },
    examples: [],
  },
  {
    name: "exponential_moving_average",
    category: "statistics",
    description: "Compute exponential weighted moving average",
    parameters: {
      "values": {"type": "array", "description": "Numeric time series"},
      "alpha": {"type": "number", "description": "Smoothing constant", "minimum": 1e-05, "maximum": 1},
    },
    examples: [],
  },
  {
    name: "extract_headings",
    category: "strings",
    description: "Extract Markdown headings from an outline",
    parameters: {
      "text": {"type": "string", "description": "Markdown text", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "extract_patterns",
    category: "strings",
    description: "Extract explicit date email URL hashtag and time patterns",
    parameters: {
      "text": {"type": "string", "description": "Passage", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "extract_urls",
    category: "strings",
    description: "List HTTP(S) URLs visibly present in plain text",
    parameters: {
      "text": {"type": "string", "description": "Passage", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "factorial",
    category: "numbers",
    description: "Calculate factorial n! for a bounded nonnegative integer",
    parameters: {
      "n": {"type": "integer", "description": "Integer", "minimum": 0, "maximum": 1000},
    },
    examples: [],
  },
  {
    name: "factorial_probability",
    category: "probability",
    description: "Factorial of a bounded nonnegative integer",
    parameters: {
      "n": {"type": "integer", "description": "Value", "minimum": 0, "maximum": 100},
    },
    examples: [],
  },
  {
    name: "fibonacci",
    category: "numbers",
    description: "Generate the first N Fibonacci numbers",
    parameters: {
      "count": {"type": "integer", "description": "Number of terms", "minimum": 1, "maximum": 200},
    },
    examples: [],
  },
  {
    name: "file_size_format",
    category: "measure",
    description: "Format a byte count in binary or decimal units",
    parameters: {
      "bytes": {"type": "integer", "description": "Byte count", "minimum": 0},
      "binary": {"type": "boolean", "description": "Use KiB MiB GiB instead of kB MB GB"},
    },
    examples: [],
  },
  {
    name: "five_number_summary",
    category: "statistics",
    description: "Find minimum quartiles median and maximum",
    parameters: {
      "values": {"type": "array", "description": "Numeric samples"},
    },
    examples: [],
  },
  {
    name: "format_json",
    category: "data",
    description: "Pretty-print a bounded JSON value",
    parameters: {
      "value": {"type": "object", "description": "Object to format"},
      "indent": {"type": "integer", "description": "Indent spaces", "minimum": 0, "maximum": 6},
    },
    examples: [],
  },
  {
    name: "format_time_hhmm",
    category: "dates",
    description: "Convert minutes since midnight to HH:MM, wrapping each day",
    parameters: {
      "minutes": {"type": "integer", "description": "Minutes", "minimum": -100000, "maximum": 100000},
    },
    examples: [],
  },
  {
    name: "fraction_operations",
    category: "numbers",
    description: "Add, subtract, multiply or divide two rational numbers",
    parameters: {
      "left": {"type": "string", "description": "First fraction, e.g. 3/4", "minLength": 0, "maxLength": 5000},
      "right": {"type": "string", "description": "Second fraction, e.g. 1/2", "minLength": 0, "maxLength": 5000},
      "operation": {"type": "string", "description": "Operation", "minLength": 0, "maxLength": 5000, "enum": ["add", "subtract", "multiply", "divide"]},
    },
    examples: [],
  },
  {
    name: "frequency_table",
    category: "statistics",
    description: "Count occurrences of categorical labels",
    parameters: {
      "values": {"type": "array", "description": "Categories or labels"},
    },
    examples: [],
  },
  {
    name: "fuzzy_titles",
    category: "strings",
    description: "Find close candidate titles for a supplied name",
    parameters: {
      "query": {"type": "string", "description": "Title", "minLength": 0, "maxLength": 5000},
      "candidates": {"type": "array", "description": "List of titles"},
      "limit": {"type": "integer", "description": "Result count", "minimum": 1, "maximum": 20},
    },
    examples: [],
  },
  {
    name: "gcd_lcm",
    category: "numbers",
    description: "Compute the greatest common divisor and least common multiple",
    parameters: {
      "values": {"type": "array", "description": "Integer values"},
    },
    examples: [],
  },
  {
    name: "geometric_exact",
    category: "probability",
    description: "Probability first success occurs on a chosen trial",
    parameters: {
      "p": {"type": "number", "description": "Success chance", "minimum": 0, "maximum": 1},
      "trial": {"type": "integer", "description": "Trial number", "minimum": 1, "maximum": 1000000},
    },
    examples: [],
  },
  {
    name: "geometric_mean",
    category: "statistics",
    description: "Calculate geometric mean for positive values",
    parameters: {
      "values": {"type": "array", "description": "Positive numbers"},
    },
    examples: [],
  },
  {
    name: "geometric_sequence",
    category: "numbers",
    description: "Produce a bounded geometric progression",
    parameters: {
      "start": {"type": "number", "description": "First term"},
      "ratio": {"type": "number", "description": "Common ratio", "minimum": -100, "maximum": 100},
      "count": {"type": "integer", "description": "Terms", "minimum": 1, "maximum": 100},
    },
    examples: [],
  },
  {
    name: "graph_adjacency_list",
    category: "graphs",
    description: "Represent an edge list as a node-neighbor dictionary",
    parameters: {
      "nodes": {"type": "array", "description": "Nodes"},
      "edges": {"type": "array", "description": "Edges"},
      "directed": {"type": "boolean", "description": "Directed graph"},
    },
    examples: [],
  },
  {
    name: "graph_adjacency_matrix",
    category: "graphs",
    description: "Create a small binary adjacency matrix",
    parameters: {
      "nodes": {"type": "array", "description": "Nodes"},
      "edges": {"type": "array", "description": "Edges"},
      "directed": {"type": "boolean", "description": "Directed graph"},
    },
    examples: [],
  },
  {
    name: "graph_bipartite",
    category: "graphs",
    description: "Check whether an undirected graph can be two-colored",
    parameters: {
      "nodes": {"type": "array", "description": "Nodes"},
      "edges": {"type": "array", "description": "Edges"},
    },
    examples: [],
  },
  {
    name: "graph_closeness",
    category: "graphs",
    description: "Estimate closeness centrality using shortest hop counts",
    parameters: {
      "nodes": {"type": "array", "description": "Nodes"},
      "edges": {"type": "array", "description": "Edges"},
    },
    examples: [],
  },
  {
    name: "graph_components",
    category: "graphs",
    description: "Connected components in an undirected graph",
    parameters: {
      "nodes": {"type": "array", "description": "Nodes"},
      "edges": {"type": "array", "description": "Edges"},
    },
    examples: [],
  },
  {
    name: "graph_critical_path",
    category: "graphs",
    description: "Calculate a dependency path for tasks with durations",
    parameters: {
      "tasks": {"type": "array", "description": "Objects with id, duration, dependencies"},
    },
    examples: [],
  },
  {
    name: "graph_degree",
    category: "graphs",
    description: "Compute degree statistics of graph nodes",
    parameters: {
      "nodes": {"type": "array", "description": "Nodes"},
      "edges": {"type": "array", "description": "Edges"},
      "directed": {"type": "boolean", "description": "Directed graph"},
    },
    examples: [],
  },
  {
    name: "graph_density",
    category: "graphs",
    description: "Calculate the density of a graph",
    parameters: {
      "nodes": {"type": "array", "description": "Nodes"},
      "edges": {"type": "array", "description": "Edges"},
      "directed": {"type": "boolean", "description": "Directed"},
    },
    examples: [],
  },
  {
    name: "graph_dependency_levels",
    category: "graphs",
    description: "Group dependent tasks into parallelizable levels",
    parameters: {
      "nodes": {"type": "array", "description": "Task names"},
      "edges": {"type": "array", "description": "Prerequisite pairs"},
    },
    examples: [],
  },
  {
    name: "graph_edges_from_matrix",
    category: "graphs",
    description: "Convert an adjacency matrix into an edge list",
    parameters: {
      "nodes": {"type": "array", "description": "Nodes"},
      "matrix": {"type": "array", "description": "Binary matrix"},
    },
    examples: [],
  },
  {
    name: "graph_has_cycle",
    category: "graphs",
    description: "Test directed graph for a dependency cycle",
    parameters: {
      "nodes": {"type": "array", "description": "Nodes"},
      "edges": {"type": "array", "description": "Edges"},
    },
    examples: [],
  },
  {
    name: "graph_reachable",
    category: "graphs",
    description: "List nodes reachable from a given node",
    parameters: {
      "nodes": {"type": "array", "description": "Node labels"},
      "edges": {"type": "array", "description": "Edges"},
      "source": {"type": "string", "description": "Start", "minLength": 0, "maxLength": 5000},
      "directed": {"type": "boolean", "description": "Directed graph"},
    },
    examples: [],
  },
  {
    name: "graph_shortest_path",
    category: "graphs",
    description: "Shortest unweighted path between two nodes",
    parameters: {
      "nodes": {"type": "array", "description": "Node labels"},
      "edges": {"type": "array", "description": "Node pairs"},
      "source": {"type": "string", "description": "Start node", "minLength": 0, "maxLength": 5000},
      "target": {"type": "string", "description": "End node", "minLength": 0, "maxLength": 5000},
      "directed": {"type": "boolean", "description": "Use directed edges"},
    },
    examples: [],
  },
  {
    name: "graph_topological_order",
    category: "graphs",
    description: "Order prerequisites in a directed acyclic graph",
    parameters: {
      "nodes": {"type": "array", "description": "Nodes"},
      "edges": {"type": "array", "description": "Pairs [prerequisite,dependent]"},
    },
    examples: [],
  },
  {
    name: "graph_weighted_shortest_path",
    category: "graphs",
    description: "Dijkstra shortest path with positive weights",
    parameters: {
      "nodes": {"type": "array", "description": "Node labels"},
      "edges": {"type": "array", "description": "Triples [from,to,cost]"},
      "source": {"type": "string", "description": "Start", "minLength": 0, "maxLength": 5000},
      "target": {"type": "string", "description": "End", "minLength": 0, "maxLength": 5000},
      "directed": {"type": "boolean", "description": "Direction matters"},
    },
    examples: [],
  },
  {
    name: "harmonic_mean",
    category: "statistics",
    description: "Calculate harmonic mean for positive values",
    parameters: {
      "values": {"type": "array", "description": "Positive numbers"},
    },
    examples: [],
  },
  {
    name: "hash_sha256",
    category: "strings",
    description: "Compute SHA-256 digest for plain text, not passwords",
    parameters: {
      "text": {"type": "string", "description": "Input text", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "histogram",
    category: "statistics",
    description: "Build a fixed-width histogram for numeric data",
    parameters: {
      "values": {"type": "array", "description": "Numeric samples"},
      "bins": {"type": "integer", "description": "Bin count", "minimum": 1, "maximum": 100},
    },
    examples: [],
  },
  {
    name: "html_escape",
    category: "strings",
    description: "Escape HTML special characters for safe display",
    parameters: {
      "text": {"type": "string", "description": "Text", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "hypergeometric_exact",
    category: "probability",
    description: "Probability of k successes sampled without replacement",
    parameters: {
      "population": {"type": "integer", "description": "Total population", "minimum": 1, "maximum": 10000},
      "positive": {"type": "integer", "description": "Positive items in population", "minimum": 0, "maximum": 10000},
      "draws": {"type": "integer", "description": "Number of draws", "minimum": 0, "maximum": 10000},
      "successes": {"type": "integer", "description": "Observed positive draws", "minimum": 0, "maximum": 10000},
    },
    examples: [],
  },
  {
    name: "hyperspace_data_size",
    category: "measure",
    description: "Estimate storage for uncompressed images in bytes",
    parameters: {
      "width": {"type": "integer", "description": "Width pixels", "minimum": 1, "maximum": 16384},
      "height": {"type": "integer", "description": "Height pixels", "minimum": 1, "maximum": 16384},
      "channels": {"type": "integer", "description": "Color channels", "minimum": 1, "maximum": 4},
      "bits_per_channel": {"type": "integer", "description": "Channel bit depth", "minimum": 1, "maximum": 32},
    },
    examples: [],
  },
  {
    name: "independent_and",
    category: "probability",
    description: "Probability of independent events both occurring",
    parameters: {
      "p": {"type": "number", "description": "First probability", "minimum": 0, "maximum": 1},
      "q": {"type": "number", "description": "Second probability", "minimum": 0, "maximum": 1},
    },
    examples: [],
  },
  {
    name: "independent_or",
    category: "probability",
    description: "Probability that either independent event occurs",
    parameters: {
      "p": {"type": "number", "description": "First probability", "minimum": 0, "maximum": 1},
      "q": {"type": "number", "description": "Second probability", "minimum": 0, "maximum": 1},
    },
    examples: [],
  },
  {
    name: "initials",
    category: "strings",
    description: "Make initials from a short phrase",
    parameters: {
      "text": {"type": "string", "description": "Name or phrase", "minLength": 0, "maxLength": 5000},
      "limit": {"type": "integer", "description": "Maximum initials", "minimum": 1, "maximum": 20},
    },
    examples: [],
  },
  {
    name: "integer_bit_count",
    category: "numbers",
    description: "Count 1 bits in a nonnegative integer",
    parameters: {
      "value": {"type": "integer", "description": "Integer", "minimum": 0},
    },
    examples: [],
  },
  {
    name: "interquartile_range",
    category: "statistics",
    description: "Calculate IQR and Tukey outlier fences",
    parameters: {
      "values": {"type": "array", "description": "Numeric samples"},
    },
    examples: [],
  },
  {
    name: "iso_week",
    category: "dates",
    description: "Read ISO week, weekday and week-numbering year",
    parameters: {
      "date": {"type": "string", "description": "YYYY-MM-DD", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "json_extract_path",
    category: "data",
    description: "Read a nested JSON object by a simple dotted path",
    parameters: {
      "value": {"type": "object", "description": "Source document"},
      "path": {"type": "string", "description": "Dot-separated keys", "minLength": 0, "maxLength": 300},
    },
    examples: [],
  },
  {
    name: "json_object_diff",
    category: "data",
    description: "Show changed, added and removed top-level keys",
    parameters: {
      "before": {"type": "object", "description": "Earlier object"},
      "after": {"type": "object", "description": "Later object"},
    },
    examples: [],
  },
  {
    name: "language_script_hint",
    category: "strings",
    description: "Detect which common writing script is most visible",
    parameters: {
      "text": {"type": "string", "description": "Passage", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "leap_year",
    category: "dates",
    description: "Check Gregorian leap-year status",
    parameters: {
      "year": {"type": "integer", "description": "Year", "minimum": 1, "maximum": 9999},
    },
    examples: [],
  },
  {
    name: "line_numbers",
    category: "strings",
    description: "Prefix each line with its line number",
    parameters: {
      "text": {"type": "string", "description": "Multiline text", "minLength": 0, "maxLength": 5000},
      "start": {"type": "integer", "description": "Starting number", "minimum": 0, "maximum": 100000},
    },
    examples: [],
  },
  {
    name: "linear_interpolation",
    category: "numbers",
    description: "Find a point on a line between two measurements",
    parameters: {
      "x0": {"type": "number", "description": "Start X"},
      "y0": {"type": "number", "description": "Start Y"},
      "x1": {"type": "number", "description": "End X"},
      "y1": {"type": "number", "description": "End Y"},
      "x": {"type": "number", "description": "Query X"},
    },
    examples: [],
  },
  {
    name: "linear_regression",
    category: "statistics",
    description: "Fit least-squares slope and intercept for simple regression",
    parameters: {
      "x": {"type": "array", "description": "Numeric x series"},
      "y": {"type": "array", "description": "Numeric y series"},
    },
    examples: [],
  },
  {
    name: "list_units",
    category: "measure",
    description: "List accepted symbols for each conversion category",
    parameters: {
      "category": {"type": "string", "description": "Category, or blank for all", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "literal_find",
    category: "strings",
    description: "Find exact substring positions without regular expressions",
    parameters: {
      "text": {"type": "string", "description": "Text", "minLength": 0, "maxLength": 5000},
      "needle": {"type": "string", "description": "Search term", "minLength": 1, "maxLength": 100},
      "ignore_case": {"type": "boolean", "description": "Case insensitive"},
    },
    examples: [],
  },
  {
    name: "make_csv",
    category: "data",
    description: "Convert a JSON table into escaped CSV text",
    parameters: {
      "rows": {"type": "array", "description": "Rows to encode"},
      "delimiter": {"type": "string", "description": "Delimiter", "minLength": 1, "maxLength": 1},
    },
    examples: [],
  },
  {
    name: "markdown_toc",
    category: "strings",
    description: "Create a simple Markdown table of contents",
    parameters: {
      "text": {"type": "string", "description": "Markdown document", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "mask_identifier",
    category: "strings",
    description: "Mask characters of a user-supplied non-secret identifier",
    parameters: {
      "text": {"type": "string", "description": "Identifier", "minLength": 0, "maxLength": 5000},
      "keep_last": {"type": "integer", "description": "Trailing visible characters", "minimum": 0, "maximum": 20},
    },
    examples: [],
  },
  {
    name: "math_definite_integral",
    category: "symbolic",
    description: "Compute a definite integral over a bounded numeric interval",
    parameters: {
      "expression": {"type": "string", "description": "Integrand", "minLength": 0, "maxLength": 300},
      "lower": {"type": "number", "description": "Lower limit", "minimum": -1000, "maximum": 1000},
      "upper": {"type": "number", "description": "Upper limit", "minimum": -1000, "maximum": 1000},
    },
    examples: [],
  },
  {
    name: "math_derivative",
    category: "symbolic",
    description: "Compute a first or higher-order derivative",
    parameters: {
      "expression": {"type": "string", "description": "Function, e.g. (x**2+3)**2", "minLength": 0, "maxLength": 500},
      "variable": {"type": "string", "description": "Differentiate with respect to", "minLength": 0, "maxLength": 5000, "enum": ["x", "y", "z", "t"]},
      "order": {"type": "integer", "description": "Derivative order", "minimum": 1, "maximum": 5},
    },
    examples: [],
  },
  {
    name: "math_evaluate",
    category: "symbolic",
    description: "Substitute one numeric variable and evaluate expression",
    parameters: {
      "expression": {"type": "string", "description": "Expression", "minLength": 0, "maxLength": 500},
      "variable": {"type": "string", "description": "Variable", "minLength": 0, "maxLength": 5000, "enum": ["x", "y", "z", "t"]},
      "value": {"type": "number", "description": "Substitution value", "minimum": -10000, "maximum": 10000},
    },
    examples: [],
  },
  {
    name: "math_expand",
    category: "symbolic",
    description: "Expand products and integer powers",
    parameters: {
      "expression": {"type": "string", "description": "Algebraic expression", "minLength": 0, "maxLength": 500},
    },
    examples: [],
  },
  {
    name: "math_factor",
    category: "symbolic",
    description: "Factor a bounded polynomial expression",
    parameters: {
      "expression": {"type": "string", "description": "Polynomial to factor", "minLength": 0, "maxLength": 500},
    },
    examples: [],
  },
  {
    name: "math_gradient",
    category: "symbolic",
    description: "Calculate gradient of a scalar function in up to three variables",
    parameters: {
      "expression": {"type": "string", "description": "Expression in x, y, z", "minLength": 0, "maxLength": 300},
      "variables": {"type": "array", "description": "Variable names in order"},
    },
    examples: [],
  },
  {
    name: "math_hessian",
    category: "symbolic",
    description: "Compute the Hessian matrix of a scalar function",
    parameters: {
      "expression": {"type": "string", "description": "Expression", "minLength": 0, "maxLength": 300},
      "variables": {"type": "array", "description": "Variables"},
    },
    examples: [],
  },
  {
    name: "math_indefinite_integral",
    category: "symbolic",
    description: "Compute a simple symbolic indefinite integral",
    parameters: {
      "expression": {"type": "string", "description": "Integrand", "minLength": 0, "maxLength": 300},
      "variable": {"type": "string", "description": "Integrating variable", "minLength": 0, "maxLength": 5000, "enum": ["x", "y", "z", "t"]},
    },
    examples: [],
  },
  {
    name: "math_limit",
    category: "symbolic",
    description: "Calculate a univariate one-sided or two-sided limit",
    parameters: {
      "expression": {"type": "string", "description": "Expression", "minLength": 0, "maxLength": 250},
      "point": {"type": "number", "description": "Value x approaches", "minimum": -1000, "maximum": 1000},
      "direction": {"type": "string", "description": "Approach direction", "minLength": 0, "maxLength": 5000, "enum": ["left", "right", "both"]},
    },
    examples: [],
  },
  {
    name: "math_numeric_derivative",
    category: "symbolic",
    description: "Estimate derivative using centered finite differences",
    parameters: {
      "expression": {"type": "string", "description": "Function of x", "minLength": 0, "maxLength": 300},
      "at": {"type": "number", "description": "Point", "minimum": -10000, "maximum": 10000},
      "step": {"type": "number", "description": "Finite difference step", "minimum": 1e-07, "maximum": 0.1},
    },
    examples: [],
  },
  {
    name: "math_partial_derivative",
    category: "symbolic",
    description: "Compute a multivariable partial derivative",
    parameters: {
      "expression": {"type": "string", "description": "Expression in x, y or z", "minLength": 0, "maxLength": 300},
      "variable": {"type": "string", "description": "Partial derivative variable", "minLength": 0, "maxLength": 5000, "enum": ["x", "y", "z"]},
    },
    examples: [],
  },
  {
    name: "math_polynomial_coefficients",
    category: "symbolic",
    description: "Extract polynomial coefficients from highest to lowest degree",
    parameters: {
      "expression": {"type": "string", "description": "Polynomial", "minLength": 0, "maxLength": 300},
      "variable": {"type": "string", "description": "Variable", "minLength": 0, "maxLength": 5000, "enum": ["x", "y", "z", "t"]},
    },
    examples: [],
  },
  {
    name: "math_simplify",
    category: "symbolic",
    description: "Simplify an algebraic expression using optional SymPy",
    parameters: {
      "expression": {"type": "string", "description": "Expression using x, sin(x), x**2, etc.", "minLength": 0, "maxLength": 500},
    },
    examples: [],
  },
  {
    name: "math_solve_polynomial",
    category: "symbolic",
    description: "Solve a univariate polynomial equation expression = 0",
    parameters: {
      "expression": {"type": "string", "description": "Polynomial expression", "minLength": 0, "maxLength": 300},
      "variable": {"type": "string", "description": "Unknown variable", "minLength": 0, "maxLength": 5000, "enum": ["x", "y", "z", "t"]},
    },
    examples: [],
  },
  {
    name: "math_substitute",
    category: "symbolic",
    description: "Replace one symbol with a number",
    parameters: {
      "expression": {"type": "string", "description": "Expression", "minLength": 0, "maxLength": 300},
      "variable": {"type": "string", "description": "Symbol", "minLength": 0, "maxLength": 5000, "enum": ["x", "y", "z", "t", "a", "b", "c"]},
      "value": {"type": "number", "description": "Numeric replacement", "minimum": -10000, "maximum": 10000},
    },
    examples: [],
  },
  {
    name: "math_taylor_series",
    category: "symbolic",
    description: "Compute a truncated Taylor series at zero or another point",
    parameters: {
      "expression": {"type": "string", "description": "Expression", "minLength": 0, "maxLength": 250},
      "point": {"type": "number", "description": "Expansion point", "minimum": -20, "maximum": 20},
      "order": {"type": "integer", "description": "Terms through order n-1", "minimum": 1, "maximum": 10},
    },
    examples: [],
  },
  {
    name: "mean_absolute_deviation",
    category: "statistics",
    description: "Compute average absolute deviation around the mean",
    parameters: {
      "values": {"type": "array", "description": "Numeric samples"},
    },
    examples: [],
  },
  {
    name: "mean_median_mode",
    category: "statistics",
    description: "Calculate mean median and modes",
    parameters: {
      "values": {"type": "array", "description": "Numeric samples"},
    },
    examples: [],
  },
  {
    name: "median_absolute_deviation",
    category: "statistics",
    description: "Compute median absolute deviation from sample median",
    parameters: {
      "values": {"type": "array", "description": "Numeric samples"},
    },
    examples: [],
  },
  {
    name: "minutes_to_duration",
    category: "dates",
    description: "Display total minutes as days, hours and minutes",
    parameters: {
      "minutes": {"type": "integer", "description": "Total signed minutes", "minimum": -10000000, "maximum": 10000000},
    },
    examples: [],
  },
  {
    name: "moving_average",
    category: "statistics",
    description: "Compute sliding simple moving averages",
    parameters: {
      "values": {"type": "array", "description": "Numeric time series"},
      "window": {"type": "integer", "description": "Number of samples per window", "minimum": 1, "maximum": 1000},
    },
    examples: [],
  },
  {
    name: "normal_cdf",
    category: "probability",
    description: "Cumulative normal probability for a z-score",
    parameters: {
      "z": {"type": "number", "description": "Z score", "minimum": -50, "maximum": 50},
    },
    examples: [],
  },
  {
    name: "normal_interval",
    category: "probability",
    description: "Probability between two z-scores",
    parameters: {
      "low": {"type": "number", "description": "Lower z score", "minimum": -50, "maximum": 50},
      "high": {"type": "number", "description": "Upper z score", "minimum": -50, "maximum": 50},
    },
    examples: [],
  },
  {
    name: "normal_zscore",
    category: "probability",
    description: "Convert a measurement to standard deviation units",
    parameters: {
      "value": {"type": "number", "description": "Observation"},
      "mean": {"type": "number", "description": "Population mean"},
      "stddev": {"type": "number", "description": "Population standard deviation", "minimum": 0},
    },
    examples: [],
  },
  {
    name: "normalize_minmax",
    category: "statistics",
    description: "Map a numeric series to a selected range",
    parameters: {
      "values": {"type": "array", "description": "Numeric samples"},
      "lower": {"type": "number", "description": "Target lower bound"},
      "upper": {"type": "number", "description": "Target upper bound"},
    },
    examples: [],
  },
  {
    name: "normalize_text",
    category: "strings",
    description: "Standardize Unicode whitespace and optionally case",
    parameters: {
      "text": {"type": "string", "description": "Text", "minLength": 0, "maxLength": 5000},
      "casefold": {"type": "boolean", "description": "Convert to casefolded lowercase"},
    },
    examples: [],
  },
  {
    name: "nth_weekday",
    category: "dates",
    description: "Find the Nth specified weekday in a calendar month",
    parameters: {
      "year": {"type": "integer", "description": "Year", "minimum": 1, "maximum": 9999},
      "month": {"type": "integer", "description": "Month", "minimum": 1, "maximum": 12},
      "weekday": {"type": "integer", "description": "Monday=0 through Sunday=6", "minimum": 0, "maximum": 6},
      "occurrence": {"type": "integer", "description": "Nth occurrence, 1–5", "minimum": 1, "maximum": 5},
    },
    examples: [],
  },
  {
    name: "number_to_base",
    category: "numbers",
    description: "Convert an integer to binary, octal or hexadecimal",
    parameters: {
      "value": {"type": "integer", "description": "Integer"},
      "base": {"type": "integer", "description": "Base", "minimum": 2, "maximum": 36},
    },
    examples: [],
  },
  {
    name: "odds_to_probability",
    category: "probability",
    description: "Convert positive odds ratio to probability",
    parameters: {
      "odds": {"type": "number", "description": "Odds for vs against", "minimum": 0, "maximum": 1000000000000.0},
    },
    examples: [],
  },
  {
    name: "overlap_time_ranges",
    category: "dates",
    description: "Find intersection of two timezone-aware intervals",
    parameters: {
      "first_start": {"type": "string", "description": "Timestamp", "minLength": 0, "maxLength": 5000},
      "first_end": {"type": "string", "description": "Timestamp", "minLength": 0, "maxLength": 5000},
      "second_start": {"type": "string", "description": "Timestamp", "minLength": 0, "maxLength": 5000},
      "second_end": {"type": "string", "description": "Timestamp", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "pace_from_time",
    category: "measure",
    description: "Calculate minutes per km from minutes and distance",
    parameters: {
      "minutes": {"type": "number", "description": "Elapsed minutes", "minimum": 0},
      "kilometers": {"type": "number", "description": "Distance in km", "minimum": 1e-07},
    },
    examples: [],
  },
  {
    name: "palindrome_check",
    category: "strings",
    description: "Check if alphanumeric characters read identically backwards",
    parameters: {
      "text": {"type": "string", "description": "Phrase", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "paragraph_split",
    category: "strings",
    description: "Split text on empty lines",
    parameters: {
      "text": {"type": "string", "description": "Multiline text", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "parse_csv",
    category: "data",
    description: "Parse simple comma-separated data into row objects",
    parameters: {
      "text": {"type": "string", "description": "CSV content", "minLength": 0, "maxLength": 15000},
      "delimiter": {"type": "string", "description": "Field delimiter", "minLength": 1, "maxLength": 1},
    },
    examples: [],
  },
  {
    name: "parse_json",
    category: "data",
    description: "Validate and decode a JSON text value",
    parameters: {
      "text": {"type": "string", "description": "JSON document", "minLength": 0, "maxLength": 15000},
    },
    examples: [],
  },
  {
    name: "parse_querystring",
    category: "strings",
    description: "Extract query-string parameters without issuing HTTP requests",
    parameters: {
      "text": {"type": "string", "description": "URL query string", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "parse_time_hhmm",
    category: "dates",
    description: "Parse 24-hour clock time to elapsed minutes",
    parameters: {
      "time": {"type": "string", "description": "HH:MM", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "pearson_correlation",
    category: "statistics",
    description: "Compute Pearson linear correlation for paired data",
    parameters: {
      "first": {"type": "array", "description": "First numeric series"},
      "second": {"type": "array", "description": "Second numeric series"},
    },
    examples: [],
  },
  {
    name: "percent_change",
    category: "numbers",
    description: "Calculate the relative percentage change",
    parameters: {
      "before": {"type": "number", "description": "Original value"},
      "after": {"type": "number", "description": "Updated value"},
    },
    examples: [],
  },
  {
    name: "percent_of",
    category: "numbers",
    description: "Calculate a percentage of any positive or negative number",
    parameters: {
      "part": {"type": "number", "description": "The percentage"},
      "whole": {"type": "number", "description": "The amount"},
    },
    examples: ["20 percent of 450"],
  },
  {
    name: "percent_of_total",
    category: "statistics",
    description: "Calculate percent share for each nonnegative contribution",
    parameters: {
      "values": {"type": "array", "description": "Nonnegative numeric values"},
    },
    examples: [],
  },
  {
    name: "percentage_difference",
    category: "numbers",
    description: "Compare two measurements symmetrically",
    parameters: {
      "first": {"type": "number", "description": "First amount"},
      "second": {"type": "number", "description": "Second amount"},
    },
    examples: [],
  },
  {
    name: "percentile_rank",
    category: "statistics",
    description: "Percent of observations less than or equal to a given value",
    parameters: {
      "values": {"type": "array", "description": "Numeric samples"},
      "value": {"type": "number", "description": "Value to compare"},
    },
    examples: [],
  },
  {
    name: "permutations",
    category: "probability",
    description: "Ordered arrangements of k selected items",
    parameters: {
      "n": {"type": "integer", "description": "Total items", "minimum": 0, "maximum": 1000},
      "k": {"type": "integer", "description": "Selected items", "minimum": 0, "maximum": 1000},
    },
    examples: [],
  },
  {
    name: "pixel_density",
    category: "measure",
    description: "Compute approximate pixels per inch for a display",
    parameters: {
      "width_px": {"type": "integer", "description": "Horizontal pixels", "minimum": 1},
      "height_px": {"type": "integer", "description": "Vertical pixels", "minimum": 1},
      "diagonal_inches": {"type": "number", "description": "Diagonal screen size", "minimum": 0.01},
    },
    examples: [],
  },
  {
    name: "poisson_exact",
    category: "probability",
    description: "Poisson probability of exactly k events",
    parameters: {
      "rate": {"type": "number", "description": "Expected number of events", "minimum": 0, "maximum": 100},
      "count": {"type": "integer", "description": "Number of observed events", "minimum": 0, "maximum": 300},
    },
    examples: [],
  },
  {
    name: "population_range",
    category: "statistics",
    description: "Get count min max span and mean from numeric data",
    parameters: {
      "values": {"type": "array", "description": "Numeric samples"},
    },
    examples: [],
  },
  {
    name: "power_energy",
    category: "measure",
    description: "Calculate energy from constant power and elapsed time",
    parameters: {
      "watts": {"type": "number", "description": "Power in W", "minimum": 0},
      "hours": {"type": "number", "description": "Duration in hours", "minimum": 0},
    },
    examples: [],
  },
  {
    name: "prime_check",
    category: "numbers",
    description: "Check whether an integer is prime using trial division",
    parameters: {
      "value": {"type": "integer", "description": "Integer to check", "minimum": 0, "maximum": 1000000000000},
    },
    examples: [],
  },
  {
    name: "prime_factors",
    category: "numbers",
    description: "Find prime factors of a moderate integer",
    parameters: {
      "value": {"type": "integer", "description": "Positive integer", "minimum": 2, "maximum": 10000000000},
    },
    examples: [],
  },
  {
    name: "probability_not",
    category: "probability",
    description: "Compute the complement of an event probability",
    parameters: {
      "p": {"type": "number", "description": "Event probability", "minimum": 0, "maximum": 1},
    },
    examples: [],
  },
  {
    name: "probability_to_odds",
    category: "probability",
    description: "Convert event probability into odds for vs against",
    parameters: {
      "probability": {"type": "number", "description": "Probability", "minimum": 0, "maximum": 1},
    },
    examples: [],
  },
  {
    name: "proportion",
    category: "numbers",
    description: "Solve a proportion a/b=c/d for missing d",
    parameters: {
      "a": {"type": "number", "description": "Known numerator"},
      "b": {"type": "number", "description": "Known denominator"},
      "c": {"type": "number", "description": "Known second numerator"},
    },
    examples: [],
  },
  {
    name: "pythagorean",
    category: "numbers",
    description: "Solve a right triangle hypotenuse from two sides",
    parameters: {
      "a": {"type": "number", "description": "First leg", "minimum": 0},
      "b": {"type": "number", "description": "Second leg", "minimum": 0},
    },
    examples: [],
  },
  {
    name: "python_assignment_names",
    category: "software",
    description: "List variables assigned in Python source",
    parameters: {
      "source": {"type": "string", "description": "Source", "minLength": 0, "maxLength": 12000},
    },
    examples: [],
  },
  {
    name: "python_ast_counts",
    category: "software",
    description: "Count syntax node types in a Python file",
    parameters: {
      "source": {"type": "string", "description": "Source", "minLength": 0, "maxLength": 12000},
    },
    examples: [],
  },
  {
    name: "python_broad_exception_candidates",
    category: "software",
    description: "Find bare excepts and broad exception handlers",
    parameters: {
      "source": {"type": "string", "description": "Source", "minLength": 0, "maxLength": 12000},
    },
    examples: [],
  },
  {
    name: "python_call_names",
    category: "software",
    description: "List function call names statically from Python source",
    parameters: {
      "source": {"type": "string", "description": "Source", "minLength": 0, "maxLength": 12000},
    },
    examples: [],
  },
  {
    name: "python_classes",
    category: "software",
    description: "Extract classes, bases, methods, and source line numbers",
    parameters: {
      "source": {"type": "string", "description": "Source text", "minLength": 0, "maxLength": 12000},
    },
    examples: [],
  },
  {
    name: "python_complexity",
    category: "software",
    description: "Estimate branch-based cyclomatic complexity of Python functions",
    parameters: {
      "source": {"type": "string", "description": "Source", "minLength": 0, "maxLength": 12000},
    },
    examples: [],
  },
  {
    name: "python_constant_values",
    category: "software",
    description: "List simple module-level constant assignments",
    parameters: {
      "source": {"type": "string", "description": "Source", "minLength": 0, "maxLength": 12000},
    },
    examples: [],
  },
  {
    name: "python_definition_outline",
    category: "software",
    description: "Produce a class/function declaration outline",
    parameters: {
      "source": {"type": "string", "description": "Source", "minLength": 0, "maxLength": 12000},
    },
    examples: [],
  },
  {
    name: "python_docstrings",
    category: "software",
    description: "Collect module, class and function docstrings",
    parameters: {
      "source": {"type": "string", "description": "Source", "minLength": 0, "maxLength": 12000},
    },
    examples: [],
  },
  {
    name: "python_format_import_suggestions",
    category: "software",
    description: "Suggest grouping import modules by name",
    parameters: {
      "source": {"type": "string", "description": "Source", "minLength": 0, "maxLength": 12000},
    },
    examples: [],
  },
  {
    name: "python_functions",
    category: "software",
    description: "List functions, arguments, line ranges and async markers",
    parameters: {
      "source": {"type": "string", "description": "Source text", "minLength": 0, "maxLength": 12000},
    },
    examples: [],
  },
  {
    name: "python_imports",
    category: "software",
    description: "Extract literal import statements without importing packages",
    parameters: {
      "source": {"type": "string", "description": "Source", "minLength": 0, "maxLength": 12000},
    },
    examples: [],
  },
  {
    name: "python_keyword_check",
    category: "software",
    description: "Check Python keyword and identifier rules",
    parameters: {
      "name": {"type": "string", "description": "Candidate variable or function name", "minLength": 0, "maxLength": 100},
    },
    examples: [],
  },
  {
    name: "python_mutable_default_candidates",
    category: "software",
    description: "Find literal list/dict/set defaults in function definitions",
    parameters: {
      "source": {"type": "string", "description": "Source", "minLength": 0, "maxLength": 12000},
    },
    examples: [],
  },
  {
    name: "python_syntax_check",
    category: "software",
    description: "Parse Python source and report syntax errors without running code",
    parameters: {
      "source": {"type": "string", "description": "Source text", "minLength": 0, "maxLength": 12000},
    },
    examples: [],
  },
  {
    name: "python_todo_comments",
    category: "software",
    description: "Locate TODO and FIXME comments",
    parameters: {
      "source": {"type": "string", "description": "Source text", "minLength": 0, "maxLength": 12000},
    },
    examples: [],
  },
  {
    name: "python_unused_import_candidates",
    category: "software",
    description: "Find imports whose names are not referenced elsewhere in the AST",
    parameters: {
      "source": {"type": "string", "description": "Source", "minLength": 0, "maxLength": 12000},
    },
    examples: [],
  },
  {
    name: "quadratic_roots",
    category: "numbers",
    description: "Solve a real quadratic equation ax²+bx+c=0",
    parameters: {
      "a": {"type": "number", "description": "Coefficient a"},
      "b": {"type": "number", "description": "Coefficient b"},
      "c": {"type": "number", "description": "Coefficient c"},
    },
    examples: [],
  },
  {
    name: "quantile",
    category: "statistics",
    description: "Find a linearly interpolated quantile",
    parameters: {
      "values": {"type": "array", "description": "Numeric samples"},
      "quantile": {"type": "number", "description": "Fraction between 0 and 1", "minimum": 0, "maximum": 1},
    },
    examples: [],
  },
  {
    name: "ratio_simplify",
    category: "numbers",
    description: "Reduce an integer ratio using the greatest common divisor",
    parameters: {
      "a": {"type": "integer", "description": "First integer"},
      "b": {"type": "integer", "description": "Second integer"},
    },
    examples: [],
  },
  {
    name: "regression_predict",
    category: "statistics",
    description: "Predict y using fitted line from paired training data",
    parameters: {
      "x": {"type": "array", "description": "Training x series"},
      "y": {"type": "array", "description": "Training y series"},
      "predict_x": {"type": "number", "description": "New x"},
    },
    examples: [],
  },
  {
    name: "remove_empty_lines",
    category: "strings",
    description: "Filter blank lines from a passage",
    parameters: {
      "text": {"type": "string", "description": "Multiline text", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "replace_literal",
    category: "strings",
    description: "Replace literal text with another substring",
    parameters: {
      "text": {"type": "string", "description": "Input", "minLength": 0, "maxLength": 5000},
      "old": {"type": "string", "description": "Exact old text", "minLength": 1, "maxLength": 200},
      "new": {"type": "string", "description": "Replacement", "minLength": 0, "maxLength": 5000},
      "limit": {"type": "integer", "description": "Maximum replacements", "minimum": 0, "maximum": 1000},
    },
    examples: [],
  },
  {
    name: "rescale_image",
    category: "measure",
    description: "Rescale an image to fit within given bounds, preserving aspect ratio",
    parameters: {
      "width": {"type": "integer", "description": "Original width", "minimum": 1, "maximum": 100000},
      "height": {"type": "integer", "description": "Original height", "minimum": 1, "maximum": 100000},
      "max_width": {"type": "integer", "description": "Target width", "minimum": 1, "maximum": 100000},
      "max_height": {"type": "integer", "description": "Target height", "minimum": 1, "maximum": 100000},
      "upscale": {"type": "boolean", "description": "Allow enlarging the original"},
    },
    examples: [],
  },
  {
    name: "root_mean_square",
    category: "statistics",
    description: "Calculate root-mean-square of numeric values",
    parameters: {
      "values": {"type": "array", "description": "Numbers"},
    },
    examples: [],
  },
  {
    name: "round_significant",
    category: "numbers",
    description: "Round a finite number to N significant digits",
    parameters: {
      "value": {"type": "number", "description": "Number"},
      "digits": {"type": "integer", "description": "Significant digits", "minimum": 1, "maximum": 12},
    },
    examples: [],
  },
  {
    name: "sample_mean_standard_error",
    category: "probability",
    description: "Estimate standard error for a sample average",
    parameters: {
      "stddev": {"type": "number", "description": "Sample standard deviation", "minimum": 0},
      "sample_size": {"type": "integer", "description": "Number of observations", "minimum": 1, "maximum": 10000000},
    },
    examples: [],
  },
  {
    name: "sample_proportion_interval",
    category: "probability",
    description: "Wilson interval for a sample percentage",
    parameters: {
      "successes": {"type": "integer", "description": "Number of successes", "minimum": 0, "maximum": 1000000},
      "trials": {"type": "integer", "description": "Total trials", "minimum": 1, "maximum": 1000000},
      "z": {"type": "number", "description": "Critical z value", "minimum": 0.1, "maximum": 6},
    },
    examples: [],
  },
  {
    name: "sentence_split",
    category: "strings",
    description: "Split a passage into sentences with their order preserved",
    parameters: {
      "text": {"type": "string", "description": "Passage", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "series_anomaly_iqr",
    category: "time_series",
    description: "Flag values outside the interquartile fence",
    parameters: {
      "values": {"type": "array", "description": "Observed values"},
      "multiplier": {"type": "number", "description": "IQR multiplier", "minimum": 0.5, "maximum": 10},
    },
    examples: [],
  },
  {
    name: "series_anomaly_zscore",
    category: "time_series",
    description: "Flag values exceeding a standard z-score threshold",
    parameters: {
      "values": {"type": "array", "description": "Observed values"},
      "threshold": {"type": "number", "description": "Absolute z threshold", "minimum": 0.5, "maximum": 10},
    },
    examples: [],
  },
  {
    name: "series_autocorrelation",
    category: "time_series",
    description: "Lagged autocorrelation of a time series",
    parameters: {
      "values": {"type": "array", "description": "Observations"},
      "lag": {"type": "integer", "description": "Positive lag", "minimum": 1, "maximum": 499},
    },
    examples: [],
  },
  {
    name: "series_centered_smoothing",
    category: "time_series",
    description: "Centered mean smoothing for an odd-width window",
    parameters: {
      "values": {"type": "array", "description": "Values"},
      "window": {"type": "integer", "description": "Odd window", "minimum": 3, "maximum": 99},
    },
    examples: [],
  },
  {
    name: "series_cross_correlation",
    category: "time_series",
    description: "Pearson correlation of two aligned series",
    parameters: {
      "first": {"type": "array", "description": "First series"},
      "second": {"type": "array", "description": "Second series"},
    },
    examples: [],
  },
  {
    name: "series_cumulative_product",
    category: "time_series",
    description: "Running product across observations",
    parameters: {
      "values": {"type": "array", "description": "Numbers"},
    },
    examples: [],
  },
  {
    name: "series_cumulative_sum",
    category: "time_series",
    description: "Running total across observations",
    parameters: {
      "values": {"type": "array", "description": "Numbers"},
    },
    examples: [],
  },
  {
    name: "series_detrend",
    category: "time_series",
    description: "Subtract the least-squares linear trend from a series",
    parameters: {
      "values": {"type": "array", "description": "Observed series"},
    },
    examples: [],
  },
  {
    name: "series_differences",
    category: "time_series",
    description: "Compute successive first differences",
    parameters: {
      "values": {"type": "array", "description": "Time-ordered numbers"},
    },
    examples: [],
  },
  {
    name: "series_drawdown",
    category: "time_series",
    description: "Compute drop relative to running maximum, in percent",
    parameters: {
      "values": {"type": "array", "description": "Positive observed values"},
    },
    examples: [],
  },
  {
    name: "series_exponential_average",
    category: "time_series",
    description: "Exponentially weighted moving average (EMA)",
    parameters: {
      "values": {"type": "array", "description": "Observations"},
      "span": {"type": "integer", "description": "Smoothing span", "minimum": 1, "maximum": 500},
    },
    examples: [],
  },
  {
    name: "series_forecast_average",
    category: "time_series",
    description: "Constant-mean baseline forecast",
    parameters: {
      "values": {"type": "array", "description": "Historical data"},
      "steps": {"type": "integer", "description": "Steps ahead", "minimum": 1, "maximum": 30},
    },
    examples: [],
  },
  {
    name: "series_forecast_last",
    category: "time_series",
    description: "Last-observation-carried-forward baseline forecast",
    parameters: {
      "values": {"type": "array", "description": "Historical data"},
      "steps": {"type": "integer", "description": "Future steps", "minimum": 1, "maximum": 30},
    },
    examples: [],
  },
  {
    name: "series_forecast_linear",
    category: "time_series",
    description: "Extrapolate a fitted linear trend with explicit caveat",
    parameters: {
      "values": {"type": "array", "description": "Historical values"},
      "steps": {"type": "integer", "description": "Number of forecast steps", "minimum": 1, "maximum": 30},
    },
    examples: [],
  },
  {
    name: "series_lag_table",
    category: "time_series",
    description: "Autocorrelation values for a range of lags",
    parameters: {
      "values": {"type": "array", "description": "Observations"},
      "max_lag": {"type": "integer", "description": "Maximum lag", "minimum": 1, "maximum": 100},
    },
    examples: [],
  },
  {
    name: "series_largest_changes",
    category: "time_series",
    description: "List the largest absolute changes between neighboring values",
    parameters: {
      "values": {"type": "array", "description": "Values"},
      "limit": {"type": "integer", "description": "Maximum changes", "minimum": 1, "maximum": 30},
    },
    examples: [],
  },
  {
    name: "series_linear_trend",
    category: "time_series",
    description: "Fit a least-squares time trend across equal intervals",
    parameters: {
      "values": {"type": "array", "description": "Observed series"},
    },
    examples: [],
  },
  {
    name: "series_momentum",
    category: "time_series",
    description: "Subtract observation from k steps earlier",
    parameters: {
      "values": {"type": "array", "description": "Series"},
      "period": {"type": "integer", "description": "Number of periods back", "minimum": 1, "maximum": 499},
    },
    examples: [],
  },
  {
    name: "series_moving_average",
    category: "time_series",
    description: "Trailing simple moving average over a fixed window",
    parameters: {
      "values": {"type": "array", "description": "Observations"},
      "window": {"type": "integer", "description": "Window length", "minimum": 1, "maximum": 500},
    },
    examples: [],
  },
  {
    name: "series_normalize_minmax",
    category: "time_series",
    description: "Scale finite observations to a 0..1 range",
    parameters: {
      "values": {"type": "array", "description": "Observations"},
    },
    examples: [],
  },
  {
    name: "series_peak_trough",
    category: "time_series",
    description: "Return indices and values of min and max observations",
    parameters: {
      "values": {"type": "array", "description": "Observations"},
    },
    examples: [],
  },
  {
    name: "series_percent_change",
    category: "time_series",
    description: "Percentage growth from each observation to the next",
    parameters: {
      "values": {"type": "array", "description": "Time-ordered numbers"},
    },
    examples: [],
  },
  {
    name: "series_rebase",
    category: "time_series",
    description: "Rebase a series to an index value of 100",
    parameters: {
      "values": {"type": "array", "description": "Observations"},
    },
    examples: [],
  },
  {
    name: "series_resample_chunks",
    category: "time_series",
    description: "Aggregate adjacent values into non-overlapping chunks",
    parameters: {
      "values": {"type": "array", "description": "Series"},
      "size": {"type": "integer", "description": "Observations per chunk", "minimum": 1, "maximum": 500},
      "method": {"type": "boolean", "description": "Use sum instead of mean"},
    },
    examples: [],
  },
  {
    name: "series_rolling_maximum",
    category: "time_series",
    description: "Maximum over each trailing observation window",
    parameters: {
      "values": {"type": "array", "description": "Observations"},
      "window": {"type": "integer", "description": "Window size", "minimum": 1, "maximum": 500},
    },
    examples: [],
  },
  {
    name: "series_rolling_minimum",
    category: "time_series",
    description: "Minimum over each trailing observation window",
    parameters: {
      "values": {"type": "array", "description": "Observations"},
      "window": {"type": "integer", "description": "Window size", "minimum": 1, "maximum": 500},
    },
    examples: [],
  },
  {
    name: "series_rolling_stddev",
    category: "time_series",
    description: "Sample standard deviation in each rolling window",
    parameters: {
      "values": {"type": "array", "description": "Observations"},
      "window": {"type": "integer", "description": "Window size", "minimum": 2, "maximum": 500},
    },
    examples: [],
  },
  {
    name: "series_run_lengths",
    category: "time_series",
    description: "Compute consecutive runs of equal categorical values",
    parameters: {
      "values": {"type": "array", "description": "Categorical sequence"},
    },
    examples: [],
  },
  {
    name: "series_standardize",
    category: "time_series",
    description: "Transform observations into z-score units",
    parameters: {
      "values": {"type": "array", "description": "Observations"},
    },
    examples: [],
  },
  {
    name: "series_zero_crossings",
    category: "time_series",
    description: "Count crossings between negative and positive values",
    parameters: {
      "values": {"type": "array", "description": "Values"},
    },
    examples: [],
  },
  {
    name: "shannon_entropy",
    category: "probability",
    description: "Compute Shannon information entropy in bits",
    parameters: {
      "probabilities": {"type": "array", "description": "Probabilities"},
    },
    examples: [],
  },
  {
    name: "simple_interest",
    category: "numbers",
    description: "Calculate non-compound interest, not investment advice",
    parameters: {
      "principal": {"type": "number", "description": "Initial principal", "minimum": 0},
      "annual_percent": {"type": "number", "description": "Annual interest percentage"},
      "years": {"type": "number", "description": "Number of years", "minimum": 0},
    },
    examples: [],
  },
  {
    name: "simulate_discrete",
    category: "probability",
    description: "Reproducible weighted random sampling for education",
    parameters: {
      "values": {"type": "array", "description": "Possible outcomes"},
      "weights": {"type": "array", "description": "Nonnegative weights"},
      "count": {"type": "integer", "description": "Number of draws", "minimum": 1, "maximum": 1000},
      "seed": {"type": "integer", "description": "Random seed", "minimum": -100000, "maximum": 100000},
    },
    examples: [],
  },
  {
    name: "slugify",
    category: "strings",
    description: "Create a URL-friendly ASCII slug from a title",
    parameters: {
      "text": {"type": "string", "description": "Title or phrase", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "sort_lines",
    category: "strings",
    description: "Sort a list of lines alphabetically",
    parameters: {
      "text": {"type": "string", "description": "Multiline text", "minLength": 0, "maxLength": 5000},
      "reverse": {"type": "boolean", "description": "Descending order"},
      "casefold": {"type": "boolean", "description": "Case insensitive"},
    },
    examples: [],
  },
  {
    name: "source_bracket_balance",
    category: "software",
    description: "Check raw bracket balances for plain text, not a parser",
    parameters: {
      "source": {"type": "string", "description": "Text", "minLength": 0, "maxLength": 12000},
    },
    examples: [],
  },
  {
    name: "source_diff",
    category: "software",
    description: "Generate a bounded unified diff for two text versions",
    parameters: {
      "before": {"type": "string", "description": "Earlier text", "minLength": 0, "maxLength": 10000},
      "after": {"type": "string", "description": "New text", "minLength": 0, "maxLength": 10000},
      "context": {"type": "integer", "description": "Context lines", "minimum": 0, "maximum": 10},
    },
    examples: [],
  },
  {
    name: "source_extract_urls",
    category: "software",
    description: "Find links appearing in an arbitrary text input",
    parameters: {
      "source": {"type": "string", "description": "Text to inspect", "minLength": 0, "maxLength": 12000},
    },
    examples: [],
  },
  {
    name: "source_find_repeated_lines",
    category: "software",
    description: "Count repeated nonempty lines of pasted source",
    parameters: {
      "source": {"type": "string", "description": "Source", "minLength": 0, "maxLength": 12000},
      "minimum": {"type": "integer", "description": "Minimum repetitions", "minimum": 2, "maximum": 20},
    },
    examples: [],
  },
  {
    name: "source_indent_profile",
    category: "software",
    description: "Summarize indentation widths in source text",
    parameters: {
      "source": {"type": "string", "description": "Source text", "minLength": 0, "maxLength": 12000},
    },
    examples: [],
  },
  {
    name: "source_lines",
    category: "software",
    description: "Count blank and nonblank source lines",
    parameters: {
      "source": {"type": "string", "description": "Source", "minLength": 0, "maxLength": 12000},
    },
    examples: [],
  },
  {
    name: "source_trailing_space_lines",
    category: "software",
    description: "Report source lines with trailing whitespace",
    parameters: {
      "source": {"type": "string", "description": "Source text", "minLength": 0, "maxLength": 12000},
    },
    examples: [],
  },
  {
    name: "spearman_correlation",
    category: "statistics",
    description: "Compute Spearman rank correlation with tie averaging",
    parameters: {
      "first": {"type": "array", "description": "First numeric series"},
      "second": {"type": "array", "description": "Second numeric series"},
    },
    examples: [],
  },
  {
    name: "speed_from_distance",
    category: "measure",
    description: "Calculate average speed from time and distance",
    parameters: {
      "kilometers": {"type": "number", "description": "Distance in km", "minimum": 0},
      "hours": {"type": "number", "description": "Elapsed hours", "minimum": 1e-06},
    },
    examples: [],
  },
  {
    name: "sphere_volume",
    category: "measure",
    description: "Compute sphere volume and surface area",
    parameters: {
      "radius": {"type": "number", "description": "Sphere radius", "minimum": 0},
    },
    examples: [],
  },
  {
    name: "standard_error",
    category: "statistics",
    description: "Compute standard error of sample mean",
    parameters: {
      "values": {"type": "array", "description": "Numeric samples"},
    },
    examples: [],
  },
  {
    name: "start_end_of_month",
    category: "dates",
    description: "Get first and last day of a month",
    parameters: {
      "date": {"type": "string", "description": "A date within the month", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "table_add_constant",
    category: "data",
    description: "Add a fixed text field to every record",
    parameters: {
      "rows": {"type": "array", "description": "Rows"},
      "column": {"type": "string", "description": "New field name", "minLength": 0, "maxLength": 5000},
      "value": {"type": "string", "description": "Assigned value", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "table_column_average",
    category: "data",
    description: "Average a numeric column, ignoring empty values",
    parameters: {
      "rows": {"type": "array", "description": "Rows"},
      "column": {"type": "string", "description": "Field", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "table_column_statistics",
    category: "data",
    description: "Numeric count, sum, mean, median and range",
    parameters: {
      "rows": {"type": "array", "description": "Rows"},
      "column": {"type": "string", "description": "Field", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "table_column_sum",
    category: "data",
    description: "Add a numeric column, ignoring empty values",
    parameters: {
      "rows": {"type": "array", "description": "Rows"},
      "column": {"type": "string", "description": "Field", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "table_columns",
    category: "data",
    description: "List all columns present in a JSON table",
    parameters: {
      "rows": {"type": "array", "description": "Table of row objects"},
    },
    examples: [],
  },
  {
    name: "table_cross_tab",
    category: "data",
    description: "Produce frequency counts for combinations of columns",
    parameters: {
      "rows": {"type": "array", "description": "Rows"},
      "columns": {"type": "array", "description": "Fields to group"},
    },
    examples: [],
  },
  {
    name: "table_date_bucket",
    category: "data",
    description: "Group ISO date strings by month",
    parameters: {
      "rows": {"type": "array", "description": "Rows"},
      "date_column": {"type": "string", "description": "ISO date field", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "table_distinct",
    category: "data",
    description: "Remove duplicate complete JSON rows",
    parameters: {
      "rows": {"type": "array", "description": "Rows"},
    },
    examples: [],
  },
  {
    name: "table_drop_empty",
    category: "data",
    description: "Remove rows whose specified fields are all empty",
    parameters: {
      "rows": {"type": "array", "description": "Rows"},
      "columns": {"type": "array", "description": "Field names"},
    },
    examples: [],
  },
  {
    name: "table_fill_missing",
    category: "data",
    description: "Replace absent or null fields with a chosen value",
    parameters: {
      "rows": {"type": "array", "description": "Rows"},
      "column": {"type": "string", "description": "Field", "minLength": 0, "maxLength": 5000},
      "value": {"type": "string", "description": "Replacement text", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "table_filter_equal",
    category: "data",
    description: "Filter rows by exact value for a named column",
    parameters: {
      "rows": {"type": "array", "description": "Rows"},
      "column": {"type": "string", "description": "Field name", "minLength": 0, "maxLength": 5000},
      "value": {"type": "string", "description": "Desired text value", "minLength": 0, "maxLength": 5000},
      "case_sensitive": {"type": "boolean", "description": "Exact case match"},
    },
    examples: [],
  },
  {
    name: "table_filter_numeric",
    category: "data",
    description: "Filter rows based on a number comparison",
    parameters: {
      "rows": {"type": "array", "description": "Rows"},
      "column": {"type": "string", "description": "Field name", "minLength": 0, "maxLength": 5000},
      "comparison": {"type": "string", "description": "Comparison", "minLength": 0, "maxLength": 5000, "enum": ["gt", "gte", "lt", "lte", "eq", "neq"]},
      "value": {"type": "number", "description": "Numeric threshold"},
    },
    examples: [],
  },
  {
    name: "table_group_count",
    category: "data",
    description: "Count records grouped by a categorical field",
    parameters: {
      "rows": {"type": "array", "description": "Rows"},
      "column": {"type": "string", "description": "Category field", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "table_group_sum",
    category: "data",
    description: "Sum a numeric column grouped by a category",
    parameters: {
      "rows": {"type": "array", "description": "Rows"},
      "group_by": {"type": "string", "description": "Category field", "minLength": 0, "maxLength": 5000},
      "value_column": {"type": "string", "description": "Numeric field", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "table_join",
    category: "data",
    description: "Join two small tables on an exact string key",
    parameters: {
      "left": {"type": "array", "description": "Left table"},
      "right": {"type": "array", "description": "Right table"},
      "key": {"type": "string", "description": "Common join field", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "table_pivot_counts",
    category: "data",
    description: "Count combinations of two categorical fields",
    parameters: {
      "rows": {"type": "array", "description": "Rows"},
      "row_field": {"type": "string", "description": "Rows", "minLength": 0, "maxLength": 5000},
      "column_field": {"type": "string", "description": "Columns", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "table_rename_column",
    category: "data",
    description: "Rename one field in every row without changing values",
    parameters: {
      "rows": {"type": "array", "description": "Rows"},
      "before": {"type": "string", "description": "Old name", "minLength": 0, "maxLength": 5000},
      "after": {"type": "string", "description": "New name", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "table_select",
    category: "data",
    description: "Select and reorder table columns",
    parameters: {
      "rows": {"type": "array", "description": "Rows"},
      "columns": {"type": "array", "description": "Desired field names"},
    },
    examples: [],
  },
  {
    name: "table_sort",
    category: "data",
    description: "Sort a table on a column, sorting missing values last",
    parameters: {
      "rows": {"type": "array", "description": "Rows"},
      "column": {"type": "string", "description": "Sort column", "minLength": 0, "maxLength": 5000},
      "descending": {"type": "boolean", "description": "Reverse sort order"},
    },
    examples: [],
  },
  {
    name: "table_take",
    category: "data",
    description: "Take a bounded slice of rows",
    parameters: {
      "rows": {"type": "array", "description": "Rows"},
      "start": {"type": "integer", "description": "Start index", "minimum": 0, "maximum": 500},
      "count": {"type": "integer", "description": "Maximum returned rows", "minimum": 0, "maximum": 200},
    },
    examples: [],
  },
  {
    name: "table_transpose",
    category: "data",
    description: "Transpose a small matrix of lists",
    parameters: {
      "matrix": {"type": "array", "description": "Rectangular matrix"},
    },
    examples: [],
  },
  {
    name: "table_unique",
    category: "data",
    description: "Find unique values in one table column",
    parameters: {
      "rows": {"type": "array", "description": "Rows"},
      "column": {"type": "string", "description": "Field", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "table_value_counts",
    category: "data",
    description: "Count occurrences of each value in a column",
    parameters: {
      "rows": {"type": "array", "description": "Rows"},
      "column": {"type": "string", "description": "Field", "minLength": 0, "maxLength": 5000},
      "limit": {"type": "integer", "description": "Results limit", "minimum": 1, "maximum": 100},
    },
    examples: [],
  },
  {
    name: "tax_addition",
    category: "numbers",
    description: "Add a percentage-based tax as a mathematical operation",
    parameters: {
      "subtotal": {"type": "number", "description": "Subtotal", "minimum": 0},
      "tax_percent": {"type": "number", "description": "Tax rate", "minimum": 0, "maximum": 100},
    },
    examples: [],
  },
  {
    name: "text_diff",
    category: "strings",
    description: "Create a unified line-by-line difference between text versions",
    parameters: {
      "before": {"type": "string", "description": "Original", "minLength": 0, "maxLength": 5000},
      "after": {"type": "string", "description": "Updated", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "text_similarity",
    category: "strings",
    description: "Compare two passages using lexical similarity and shared keywords",
    parameters: {
      "first": {"type": "string", "description": "First passage", "minLength": 0, "maxLength": 5000},
      "second": {"type": "string", "description": "Second passage", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "text_stats",
    category: "strings",
    description: "Profile word count sentences and document traits",
    parameters: {
      "text": {"type": "string", "description": "Text to analyze", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "text_summary",
    category: "strings",
    description: "Select source sentences as a short extractive summary",
    parameters: {
      "text": {"type": "string", "description": "Passage", "minLength": 0, "maxLength": 5000},
      "sentences_count": {"type": "integer", "description": "Number of sentences", "minimum": 1, "maximum": 20},
    },
    examples: [],
  },
  {
    name: "text_wrap",
    category: "strings",
    description: "Wrap plain text to a specified column width",
    parameters: {
      "text": {"type": "string", "description": "Plain text", "minLength": 0, "maxLength": 5000},
      "width": {"type": "integer", "description": "Columns", "minimum": 20, "maximum": 200},
      "preserve_whitespace": {"type": "boolean", "description": "Preserve whitespace"},
    },
    examples: [],
  },
  {
    name: "time_block_count",
    category: "dates",
    description: "Count complete focus blocks fitting into available minutes",
    parameters: {
      "available_minutes": {"type": "integer", "description": "Available time", "minimum": 0, "maximum": 10080},
      "work_minutes": {"type": "integer", "description": "Work block length", "minimum": 1, "maximum": 240},
      "break_minutes": {"type": "integer", "description": "Rest block length", "minimum": 0, "maximum": 120},
    },
    examples: [],
  },
  {
    name: "time_slot_schedule",
    category: "dates",
    description: "Make fixed-duration study or work slots",
    parameters: {
      "start": {"type": "string", "description": "ISO timestamp with timezone", "minLength": 0, "maxLength": 5000},
      "number": {"type": "integer", "description": "Slots", "minimum": 1, "maximum": 24},
      "slot_minutes": {"type": "integer", "description": "Time per slot", "minimum": 5, "maximum": 240},
      "break_minutes": {"type": "integer", "description": "Break after each slot", "minimum": 0, "maximum": 120},
    },
    examples: [],
  },
  {
    name: "timezone_convert",
    category: "dates",
    description: "Convert an explicit timestamp between IANA timezones",
    parameters: {
      "timestamp": {"type": "string", "description": "ISO datetime with UTC offset", "minLength": 0, "maxLength": 5000},
      "destination": {"type": "string", "description": "IANA zone name, e.g. Asia/Kolkata", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "tip_calculator",
    category: "numbers",
    description: "Calculate a total with a user-chosen gratuity",
    parameters: {
      "bill": {"type": "number", "description": "Bill amount", "minimum": 0},
      "tip_percent": {"type": "number", "description": "Tip percentage", "minimum": 0, "maximum": 100},
      "people": {"type": "integer", "description": "People sharing the bill", "minimum": 1, "maximum": 10000},
    },
    examples: [],
  },
  {
    name: "top_bigrams",
    category: "strings",
    description: "List common adjacent two-word phrases",
    parameters: {
      "text": {"type": "string", "description": "Passage", "minLength": 0, "maxLength": 5000},
      "limit": {"type": "integer", "description": "Phrase count", "minimum": 1, "maximum": 30},
    },
    examples: [],
  },
  {
    name: "top_keywords",
    category: "strings",
    description: "Extract common non-stopword terms from a passage",
    parameters: {
      "text": {"type": "string", "description": "Passage", "minLength": 0, "maxLength": 5000},
      "limit": {"type": "integer", "description": "Keyword count", "minimum": 1, "maximum": 50},
    },
    examples: [],
  },
  {
    name: "triangle_area",
    category: "numbers",
    description: "Triangle area using base and height",
    parameters: {
      "base": {"type": "number", "description": "Base", "minimum": 0},
      "height": {"type": "number", "description": "Height", "minimum": 0},
    },
    examples: [],
  },
  {
    name: "uniform_probability",
    category: "probability",
    description: "Probability of a subinterval in a uniform range",
    parameters: {
      "minimum": {"type": "number", "description": "Minimum"},
      "maximum": {"type": "number", "description": "Maximum"},
      "event_low": {"type": "number", "description": "Event lower limit"},
      "event_high": {"type": "number", "description": "Event upper limit"},
    },
    examples: [],
  },
  {
    name: "url_decode_component",
    category: "strings",
    description: "Decode percent-encoded URL text",
    parameters: {
      "text": {"type": "string", "description": "Encoded text", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "url_encode_component",
    category: "strings",
    description: "Percent-encode one URL path component",
    parameters: {
      "text": {"type": "string", "description": "Text", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "value_growth_rate",
    category: "statistics",
    description: "Compute growth rates between consecutive measurements",
    parameters: {
      "values": {"type": "array", "description": "Numeric series"},
    },
    examples: [],
  },
  {
    name: "variance",
    category: "statistics",
    description: "Sample or population variance and standard deviation",
    parameters: {
      "values": {"type": "array", "description": "Numeric samples"},
      "sample": {"type": "boolean", "description": "Use sample n-1 denominator"},
    },
    examples: [],
  },
  {
    name: "weekday",
    category: "dates",
    description: "Read weekday name and ISO weekday number for a date",
    parameters: {
      "date": {"type": "string", "description": "YYYY-MM-DD", "minLength": 0, "maxLength": 5000},
    },
    examples: [],
  },
  {
    name: "weighted_average",
    category: "numbers",
    description: "Calculate weighted arithmetic mean",
    parameters: {
      "values": {"type": "array", "description": "Numeric values"},
      "weights": {"type": "array", "description": "Nonnegative weights"},
    },
    examples: [],
  },
  {
    name: "word_frequency",
    category: "strings",
    description: "Count words within a passage",
    parameters: {
      "text": {"type": "string", "description": "Passage", "minLength": 0, "maxLength": 5000},
      "limit": {"type": "integer", "description": "Maximum frequency rows", "minimum": 1, "maximum": 300},
    },
    examples: [],
  },
  {
    name: "z_scores",
    category: "statistics",
    description: "Standardize samples using population deviation",
    parameters: {
      "values": {"type": "array", "description": "Numeric samples"},
    },
    examples: [],
  },
] as const;

