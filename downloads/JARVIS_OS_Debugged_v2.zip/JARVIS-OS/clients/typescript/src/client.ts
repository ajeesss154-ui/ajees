/** Minimal dependency-free browser and Node.js transport for JARVIS OS. */
import { JarvisUtilityClient } from './generated_skills.js';
import { JarvisApiRoutes } from './generated_routes.js';

export type Method = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
export interface RequestOptions {
  body?: Record<string, unknown> | unknown[] | null;
  query?: Record<string, string | number | boolean | null | undefined>;
}
export class JarvisAPIError extends Error {
  constructor(public status: number, message: string) {
    super(`JARVIS API returned HTTP ${status}: ${message}`);
    this.name='JarvisAPIError';
  }
}
export class JarvisTransport {
  readonly utilities: JarvisUtilityClient;
  readonly routes: JarvisApiRoutes;
  private readonly base: string;
  private readonly token: string;

  constructor(token: string, baseUrl = 'http://127.0.0.1:8765') {
    if (!token || !token.trim()) throw new Error('JARVIS private access token required');
    const parsed = new URL(baseUrl);
    if (!['http:', 'https:'].includes(parsed.protocol)) {
      throw new Error('Use HTTP(S) to connect to JARVIS');
    }
    if (parsed.username || parsed.password) {
      throw new Error('Do not embed credentials in the server URL');
    }
    if (parsed.search || parsed.hash) {
      throw new Error('Provide a server URL without a query or fragment');
    }
    if (parsed.protocol==='http:' && !['localhost','127.0.0.1','[::1]'].includes(parsed.hostname)) {
      throw new Error('Use HTTPS for remote hosts');
    }
    this.base=baseUrl.replace(/\/+$/,'');
    this.token=token.trim();
    this.utilities=new JarvisUtilityClient(this);
    this.routes=new JarvisApiRoutes(this);
  }

  async request(method: Method, path: string, options: RequestOptions={}): Promise<unknown> {
    if (!['GET', 'POST', 'PUT', 'PATCH', 'DELETE'].includes(method)) {
      throw new Error('Unsupported HTTP method');
    }
    const rawPath = path.split(/[?#]/, 1)[0];
    let decoded: string;
    try { decoded = decodeURIComponent(rawPath); } catch { throw new Error('Invalid API path encoding'); }
    if (!path.startsWith('/api/') || path.includes('://') || path.includes('\\') || path.includes('#') || decoded.split('/').some(part => part === '.' || part === '..')) {
      throw new Error('Only JARVIS API paths without traversal are supported');
    }
    const url = new URL(this.base + path);
    for (const [key,value] of Object.entries(options.query || {})) {
      if (value !== undefined && value !== null) url.searchParams.set(key,String(value));
    }
    const response=await fetch(url,{
      method,
      redirect:'error',
      headers:{'Authorization':`Bearer ${this.token}`,
               'Accept':'application/json',
               ...(options.body!==undefined ? {'Content-Type':'application/json'} : {})},
      body:options.body===undefined ? undefined : JSON.stringify(options.body),
    });
    const result:unknown=await response.json().catch(()=>({detail:'Invalid server response'}));
    if (!response.ok) {
      const detail=typeof result==='object' && result!==null && 'detail' in result
        ? String((result as {detail:unknown}).detail) : 'Request failed';
      throw new JarvisAPIError(response.status,detail.slice(0,250));
    }
    return result;
  }
}
