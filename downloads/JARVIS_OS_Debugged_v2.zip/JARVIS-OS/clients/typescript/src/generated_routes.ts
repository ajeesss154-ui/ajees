/** AUTO-GENERATED JARVIS REST methods from the actual OpenAPI schema. */
import type { JarvisTransport } from './client.js';

export class JarvisApiRoutes {
  constructor(private readonly transport: JarvisTransport) {}

  /**
   * Approvals
   * GET /api/approvals
   * Result is decoded JSON; the transport enforces authentication.
   */
  async approvals_api_approvals_get(): Promise<unknown> {
    let path = "/api/approvals";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Approve
   * POST /api/approvals/{ident}/approve
   * Result is decoded JSON; the transport enforces authentication.
   */
  async approve_api_approvals__ident__approve_post(args: {ident: string}): Promise<unknown> {
    let path = "/api/approvals/{ident}/approve";
    path = path.replace("{ident}", encodeURIComponent(String(args.ident)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:undefined});
  }

  /**
   * Deny
   * POST /api/approvals/{ident}/deny
   * Result is decoded JSON; the transport enforces authentication.
   */
  async deny_api_approvals__ident__deny_post(args: {ident: string}): Promise<unknown> {
    let path = "/api/approvals/{ident}/deny";
    path = path.replace("{ident}", encodeURIComponent(String(args.ident)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:undefined});
  }

  /**
   * Audit
   * GET /api/audit
   * Result is decoded JSON; the transport enforces authentication.
   */
  async audit_api_audit_get(): Promise<unknown> {
    let path = "/api/audit";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Chat
   * POST /api/chat
   * Result is decoded JSON; the transport enforces authentication.
   */
  async chat_api_chat_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/chat";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Facts
   * GET /api/facts
   * Result is decoded JSON; the transport enforces authentication.
   */
  async facts_api_facts_get(): Promise<unknown> {
    let path = "/api/facts";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Health
   * GET /api/health
   * Result is decoded JSON; the transport enforces authentication.
   */
  async health_api_health_get(): Promise<unknown> {
    let path = "/api/health";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Clear History
   * DELETE /api/history/{session_id}
   * Result is decoded JSON; the transport enforces authentication.
   */
  async clear_history_api_history__session_id__delete(args: {session_id: string}): Promise<unknown> {
    let path = "/api/history/{session_id}";
    path = path.replace("{session_id}", encodeURIComponent(String(args.session_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("DELETE", path, {query, body:undefined});
  }

  /**
   * History
   * GET /api/history/{session_id}
   * Result is decoded JSON; the transport enforces authentication.
   */
  async history_api_history__session_id__get(args: {session_id: string}): Promise<unknown> {
    let path = "/api/history/{session_id}";
    path = path.replace("{session_id}", encodeURIComponent(String(args.session_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Get Chunk
   * GET /api/knowledge/chunks/{chunk_id}
   * Result is decoded JSON; the transport enforces authentication.
   */
  async get_chunk_api_knowledge_chunks__chunk_id__get(args: {chunk_id: string}): Promise<unknown> {
    let path = "/api/knowledge/chunks/{chunk_id}";
    path = path.replace("{chunk_id}", encodeURIComponent(String(args.chunk_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Context
   * POST /api/knowledge/context
   * Result is decoded JSON; the transport enforces authentication.
   */
  async context_api_knowledge_context_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/knowledge/context";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Refresh
   * POST /api/knowledge/refresh
   * Result is decoded JSON; the transport enforces authentication.
   */
  async refresh_api_knowledge_refresh_post(): Promise<unknown> {
    let path = "/api/knowledge/refresh";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:undefined});
  }

  /**
   * Search
   * POST /api/knowledge/search
   * Result is decoded JSON; the transport enforces authentication.
   */
  async search_api_knowledge_search_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/knowledge/search";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Sources
   * GET /api/knowledge/sources
   * Result is decoded JSON; the transport enforces authentication.
   */
  async sources_api_knowledge_sources_get(): Promise<unknown> {
    let path = "/api/knowledge/sources";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Stats
   * GET /api/knowledge/stats
   * Result is decoded JSON; the transport enforces authentication.
   */
  async stats_api_knowledge_stats_get(): Promise<unknown> {
    let path = "/api/knowledge/stats";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Compare
   * POST /api/knowledge/text/compare
   * Result is decoded JSON; the transport enforces authentication.
   */
  async compare_api_knowledge_text_compare_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/knowledge/text/compare";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Entities
   * POST /api/knowledge/text/entities
   * Result is decoded JSON; the transport enforces authentication.
   */
  async entities_api_knowledge_text_entities_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/knowledge/text/entities";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Profile
   * POST /api/knowledge/text/profile
   * Result is decoded JSON; the transport enforces authentication.
   */
  async profile_api_knowledge_text_profile_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/knowledge/text/profile";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Study Prompts
   * POST /api/knowledge/text/study-prompts
   * Result is decoded JSON; the transport enforces authentication.
   */
  async study_prompts_api_knowledge_text_study_prompts_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/knowledge/text/study-prompts";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Summary
   * POST /api/knowledge/text/summary
   * Result is decoded JSON; the transport enforces authentication.
   */
  async summary_api_knowledge_text_summary_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/knowledge/text/summary";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Decisions
   * GET /api/lab/decisions
   * Result is decoded JSON; the transport enforces authentication.
   */
  async decisions_api_lab_decisions_get(args: {limit?: number}): Promise<unknown> {
    let path = "/api/lab/decisions";
    const query: Record<string, string | number | boolean> = {};
    if (args.limit !== undefined && args.limit !== null) {
      query["limit"] = String(args.limit);
    }
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Add Decision
   * POST /api/lab/decisions
   * Result is decoded JSON; the transport enforces authentication.
   */
  async add_decision_api_lab_decisions_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/lab/decisions";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Experiments
   * GET /api/lab/experiments
   * Result is decoded JSON; the transport enforces authentication.
   */
  async experiments_api_lab_experiments_get(args: {idea_id?: unknown; limit?: number}): Promise<unknown> {
    let path = "/api/lab/experiments";
    const query: Record<string, string | number | boolean> = {};
    if (args.idea_id !== undefined && args.idea_id !== null) {
      query["idea_id"] = String(args.idea_id);
    }
    if (args.limit !== undefined && args.limit !== null) {
      query["limit"] = String(args.limit);
    }
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Add Experiment
   * POST /api/lab/experiments
   * Result is decoded JSON; the transport enforces authentication.
   */
  async add_experiment_api_lab_experiments_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/lab/experiments";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Conclude
   * PATCH /api/lab/experiments/{ident}
   * Result is decoded JSON; the transport enforces authentication.
   */
  async conclude_api_lab_experiments__ident__patch(args: {ident: string; body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/lab/experiments/{ident}";
    path = path.replace("{ident}", encodeURIComponent(String(args.ident)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("PATCH", path, {query, body:args.body});
  }

  /**
   * Feedback
   * GET /api/lab/feedback
   * Result is decoded JSON; the transport enforces authentication.
   */
  async feedback_api_lab_feedback_get(args: {status?: unknown; limit?: number}): Promise<unknown> {
    let path = "/api/lab/feedback";
    const query: Record<string, string | number | boolean> = {};
    if (args.status !== undefined && args.status !== null) {
      query["status"] = String(args.status);
    }
    if (args.limit !== undefined && args.limit !== null) {
      query["limit"] = String(args.limit);
    }
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Add Feedback
   * POST /api/lab/feedback
   * Result is decoded JSON; the transport enforces authentication.
   */
  async add_feedback_api_lab_feedback_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/lab/feedback";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Patch Feedback
   * PATCH /api/lab/feedback/{ident}
   * Result is decoded JSON; the transport enforces authentication.
   */
  async patch_feedback_api_lab_feedback__ident__patch(args: {ident: string; body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/lab/feedback/{ident}";
    path = path.replace("{ident}", encodeURIComponent(String(args.ident)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("PATCH", path, {query, body:args.body});
  }

  /**
   * Ideas
   * GET /api/lab/ideas
   * Result is decoded JSON; the transport enforces authentication.
   */
  async ideas_api_lab_ideas_get(args: {query?: string; status?: unknown; limit?: number}): Promise<unknown> {
    let path = "/api/lab/ideas";
    const query: Record<string, string | number | boolean> = {};
    if (args.query !== undefined && args.query !== null) {
      query["query"] = String(args.query);
    }
    if (args.status !== undefined && args.status !== null) {
      query["status"] = String(args.status);
    }
    if (args.limit !== undefined && args.limit !== null) {
      query["limit"] = String(args.limit);
    }
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Create Idea
   * POST /api/lab/ideas
   * Result is decoded JSON; the transport enforces authentication.
   */
  async create_idea_api_lab_ideas_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/lab/ideas";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Delete Idea
   * DELETE /api/lab/ideas/{ident}
   * Result is decoded JSON; the transport enforces authentication.
   */
  async delete_idea_api_lab_ideas__ident__delete(args: {ident: string}): Promise<unknown> {
    let path = "/api/lab/ideas/{ident}";
    path = path.replace("{ident}", encodeURIComponent(String(args.ident)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("DELETE", path, {query, body:undefined});
  }

  /**
   * Get Idea
   * GET /api/lab/ideas/{ident}
   * Result is decoded JSON; the transport enforces authentication.
   */
  async get_idea_api_lab_ideas__ident__get(args: {ident: string}): Promise<unknown> {
    let path = "/api/lab/ideas/{ident}";
    path = path.replace("{ident}", encodeURIComponent(String(args.ident)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Patch Idea
   * PATCH /api/lab/ideas/{ident}
   * Result is decoded JSON; the transport enforces authentication.
   */
  async patch_idea_api_lab_ideas__ident__patch(args: {ident: string; body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/lab/ideas/{ident}";
    path = path.replace("{ident}", encodeURIComponent(String(args.ident)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("PATCH", path, {query, body:args.body});
  }

  /**
   * Overview
   * GET /api/lab/overview
   * Result is decoded JSON; the transport enforces authentication.
   */
  async overview_api_lab_overview_get(): Promise<unknown> {
    let path = "/api/lab/overview";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Me
   * GET /api/me
   * Result is decoded JSON; the transport enforces authentication.
   */
  async me_api_me_get(): Promise<unknown> {
    let path = "/api/me";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Notes
   * GET /api/notes
   * Result is decoded JSON; the transport enforces authentication.
   */
  async notes_api_notes_get(): Promise<unknown> {
    let path = "/api/notes";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Save Note
   * POST /api/notes
   * Result is decoded JSON; the transport enforces authentication.
   */
  async save_note_api_notes_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/notes";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Notifications
   * GET /api/notifications
   * Result is decoded JSON; the transport enforces authentication.
   */
  async notifications_api_notifications_get(): Promise<unknown> {
    let path = "/api/notifications";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Ack
   * POST /api/notifications/{ident}/ack
   * Result is decoded JSON; the transport enforces authentication.
   */
  async ack_api_notifications__ident__ack_post(args: {ident: string}): Promise<unknown> {
    let path = "/api/notifications/{ident}/ack";
    path = path.replace("{ident}", encodeURIComponent(String(args.ident)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:undefined});
  }

  /**
   * Transcribe Audio
   * POST /api/perception/audio
   * Result is decoded JSON; the transport enforces authentication.
   */
  async transcribe_audio_api_perception_audio_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/perception/audio";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Features
   * GET /api/perception/features
   * Result is decoded JSON; the transport enforces authentication.
   */
  async features_api_perception_features_get(): Promise<unknown> {
    let path = "/api/perception/features";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Describe Image
   * POST /api/perception/image
   * Result is decoded JSON; the transport enforces authentication.
   */
  async describe_image_api_perception_image_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/perception/image";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Reminders
   * GET /api/reminders
   * Result is decoded JSON; the transport enforces authentication.
   */
  async reminders_api_reminders_get(): Promise<unknown> {
    let path = "/api/reminders";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Add Reminder
   * POST /api/reminders
   * Result is decoded JSON; the transport enforces authentication.
   */
  async add_reminder_api_reminders_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/reminders";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Status Info
   * GET /api/status
   * Result is decoded JSON; the transport enforces authentication.
   */
  async status_info_api_status_get(): Promise<unknown> {
    let path = "/api/status";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Delete Card
   * DELETE /api/study/cards/{card_id}
   * Result is decoded JSON; the transport enforces authentication.
   */
  async delete_card_api_study_cards__card_id__delete(args: {card_id: string}): Promise<unknown> {
    let path = "/api/study/cards/{card_id}";
    path = path.replace("{card_id}", encodeURIComponent(String(args.card_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("DELETE", path, {query, body:undefined});
  }

  /**
   * Card
   * GET /api/study/cards/{card_id}
   * Result is decoded JSON; the transport enforces authentication.
   */
  async card_api_study_cards__card_id__get(args: {card_id: string}): Promise<unknown> {
    let path = "/api/study/cards/{card_id}";
    path = path.replace("{card_id}", encodeURIComponent(String(args.card_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Update Card
   * PATCH /api/study/cards/{card_id}
   * Result is decoded JSON; the transport enforces authentication.
   */
  async update_card_api_study_cards__card_id__patch(args: {card_id: string; body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/study/cards/{card_id}";
    path = path.replace("{card_id}", encodeURIComponent(String(args.card_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("PATCH", path, {query, body:args.body});
  }

  /**
   * Review
   * POST /api/study/cards/{card_id}/review
   * Result is decoded JSON; the transport enforces authentication.
   */
  async review_api_study_cards__card_id__review_post(args: {card_id: string; body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/study/cards/{card_id}/review";
    path = path.replace("{card_id}", encodeURIComponent(String(args.card_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Decks
   * GET /api/study/decks
   * Result is decoded JSON; the transport enforces authentication.
   */
  async decks_api_study_decks_get(args: {archived?: boolean}): Promise<unknown> {
    let path = "/api/study/decks";
    const query: Record<string, string | number | boolean> = {};
    if (args.archived !== undefined && args.archived !== null) {
      query["archived"] = String(args.archived);
    }
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Create Deck
   * POST /api/study/decks
   * Result is decoded JSON; the transport enforces authentication.
   */
  async create_deck_api_study_decks_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/study/decks";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Deck
   * GET /api/study/decks/{deck_id}
   * Result is decoded JSON; the transport enforces authentication.
   */
  async deck_api_study_decks__deck_id__get(args: {deck_id: string}): Promise<unknown> {
    let path = "/api/study/decks/{deck_id}";
    path = path.replace("{deck_id}", encodeURIComponent(String(args.deck_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Update Deck
   * PATCH /api/study/decks/{deck_id}
   * Result is decoded JSON; the transport enforces authentication.
   */
  async update_deck_api_study_decks__deck_id__patch(args: {deck_id: string; body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/study/decks/{deck_id}";
    path = path.replace("{deck_id}", encodeURIComponent(String(args.deck_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("PATCH", path, {query, body:args.body});
  }

  /**
   * Cards
   * GET /api/study/decks/{deck_id}/cards
   * Result is decoded JSON; the transport enforces authentication.
   */
  async cards_api_study_decks__deck_id__cards_get(args: {deck_id: string; query?: string; limit?: number}): Promise<unknown> {
    let path = "/api/study/decks/{deck_id}/cards";
    path = path.replace("{deck_id}", encodeURIComponent(String(args.deck_id)));
    const query: Record<string, string | number | boolean> = {};
    if (args.query !== undefined && args.query !== null) {
      query["query"] = String(args.query);
    }
    if (args.limit !== undefined && args.limit !== null) {
      query["limit"] = String(args.limit);
    }
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Create Card
   * POST /api/study/decks/{deck_id}/cards
   * Result is decoded JSON; the transport enforces authentication.
   */
  async create_card_api_study_decks__deck_id__cards_post(args: {deck_id: string; body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/study/decks/{deck_id}/cards";
    path = path.replace("{deck_id}", encodeURIComponent(String(args.deck_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Export Deck
   * GET /api/study/decks/{deck_id}/export
   * Result is decoded JSON; the transport enforces authentication.
   */
  async export_deck_api_study_decks__deck_id__export_get(args: {deck_id: string}): Promise<unknown> {
    let path = "/api/study/decks/{deck_id}/export";
    path = path.replace("{deck_id}", encodeURIComponent(String(args.deck_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Import Cards
   * POST /api/study/decks/{deck_id}/import
   * Result is decoded JSON; the transport enforces authentication.
   */
  async import_cards_api_study_decks__deck_id__import_post(args: {deck_id: string; body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/study/decks/{deck_id}/import";
    path = path.replace("{deck_id}", encodeURIComponent(String(args.deck_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Due
   * GET /api/study/due
   * Result is decoded JSON; the transport enforces authentication.
   */
  async due_api_study_due_get(args: {deck_id?: unknown; day?: unknown; limit?: number}): Promise<unknown> {
    let path = "/api/study/due";
    const query: Record<string, string | number | boolean> = {};
    if (args.deck_id !== undefined && args.deck_id !== null) {
      query["deck_id"] = String(args.deck_id);
    }
    if (args.day !== undefined && args.day !== null) {
      query["day"] = String(args.day);
    }
    if (args.limit !== undefined && args.limit !== null) {
      query["limit"] = String(args.limit);
    }
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Reviews
   * GET /api/study/reviews
   * Result is decoded JSON; the transport enforces authentication.
   */
  async reviews_api_study_reviews_get(args: {card_id?: unknown; limit?: number}): Promise<unknown> {
    let path = "/api/study/reviews";
    const query: Record<string, string | number | boolean> = {};
    if (args.card_id !== undefined && args.card_id !== null) {
      query["card_id"] = String(args.card_id);
    }
    if (args.limit !== undefined && args.limit !== null) {
      query["limit"] = String(args.limit);
    }
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Statistics
   * GET /api/study/statistics
   * Result is decoded JSON; the transport enforces authentication.
   */
  async statistics_api_study_statistics_get(): Promise<unknown> {
    let path = "/api/study/statistics";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Tasks
   * GET /api/tasks
   * Result is decoded JSON; the transport enforces authentication.
   */
  async tasks_api_tasks_get(): Promise<unknown> {
    let path = "/api/tasks";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Create Task
   * POST /api/tasks
   * Result is decoded JSON; the transport enforces authentication.
   */
  async create_task_api_tasks_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/tasks";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Complete Task
   * POST /api/tasks/{task_id}/complete
   * Result is decoded JSON; the transport enforces authentication.
   */
  async complete_task_api_tasks__task_id__complete_post(args: {task_id: string}): Promise<unknown> {
    let path = "/api/tasks/{task_id}/complete";
    path = path.replace("{task_id}", encodeURIComponent(String(args.task_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:undefined});
  }

  /**
   * Tools
   * GET /api/tools
   * Result is decoded JSON; the transport enforces authentication.
   */
  async tools_api_tools_get(): Promise<unknown> {
    let path = "/api/tools";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Catalog
   * GET /api/utilities/catalog
   * Result is decoded JSON; the transport enforces authentication.
   */
  async catalog_api_utilities_catalog_get(args: {category?: unknown}): Promise<unknown> {
    let path = "/api/utilities/catalog";
    const query: Record<string, string | number | boolean> = {};
    if (args.category !== undefined && args.category !== null) {
      query["category"] = String(args.category);
    }
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Definition
   * GET /api/utilities/catalog/{name}
   * Result is decoded JSON; the transport enforces authentication.
   */
  async definition_api_utilities_catalog__name__get(args: {name: string}): Promise<unknown> {
    let path = "/api/utilities/catalog/{name}";
    path = path.replace("{name}", encodeURIComponent(String(args.name)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Categories
   * GET /api/utilities/categories
   * Result is decoded JSON; the transport enforces authentication.
   */
  async categories_api_utilities_categories_get(): Promise<unknown> {
    let path = "/api/utilities/categories";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Run
   * POST /api/utilities/run
   * Result is decoded JSON; the transport enforces authentication.
   */
  async run_api_utilities_run_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/utilities/run";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Stats
   * GET /api/utilities/stats
   * Result is decoded JSON; the transport enforces authentication.
   */
  async stats_api_utilities_stats_get(): Promise<unknown> {
    let path = "/api/utilities/stats";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Activity
   * GET /api/v2/activity
   * Result is decoded JSON; the transport enforces authentication.
   */
  async activity_api_v2_activity_get(args: {limit?: number}): Promise<unknown> {
    let path = "/api/v2/activity";
    const query: Record<string, string | number | boolean> = {};
    if (args.limit !== undefined && args.limit !== null) {
      query["limit"] = String(args.limit);
    }
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Backups
   * GET /api/v2/backups
   * Result is decoded JSON; the transport enforces authentication.
   */
  async backups_api_v2_backups_get(): Promise<unknown> {
    let path = "/api/v2/backups";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Create Backup
   * POST /api/v2/backups
   * Result is decoded JSON; the transport enforces authentication.
   */
  async create_backup_api_v2_backups_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/v2/backups";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Check Backup
   * GET /api/v2/backups/{filename}/validate
   * Result is decoded JSON; the transport enforces authentication.
   */
  async check_backup_api_v2_backups__filename__validate_get(args: {filename: string}): Promise<unknown> {
    let path = "/api/v2/backups/{filename}/validate";
    path = path.replace("{filename}", encodeURIComponent(String(args.filename)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Bookmarks
   * GET /api/v2/bookmarks
   * Result is decoded JSON; the transport enforces authentication.
   */
  async bookmarks_api_v2_bookmarks_get(args: {query?: string}): Promise<unknown> {
    let path = "/api/v2/bookmarks";
    const query: Record<string, string | number | boolean> = {};
    if (args.query !== undefined && args.query !== null) {
      query["query"] = String(args.query);
    }
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Bookmark
   * POST /api/v2/bookmarks
   * Result is decoded JSON; the transport enforces authentication.
   */
  async bookmark_api_v2_bookmarks_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/v2/bookmarks";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Delete Bookmark
   * DELETE /api/v2/bookmarks/{bookmark_id}
   * Result is decoded JSON; the transport enforces authentication.
   */
  async delete_bookmark_api_v2_bookmarks__bookmark_id__delete(args: {bookmark_id: string}): Promise<unknown> {
    let path = "/api/v2/bookmarks/{bookmark_id}";
    path = path.replace("{bookmark_id}", encodeURIComponent(String(args.bookmark_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("DELETE", path, {query, body:undefined});
  }

  /**
   * Dashboard
   * GET /api/v2/dashboard
   * Result is decoded JSON; the transport enforces authentication.
   */
  async dashboard_api_v2_dashboard_get(): Promise<unknown> {
    let path = "/api/v2/dashboard";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Events Recent
   * GET /api/v2/events
   * Result is decoded JSON; the transport enforces authentication.
   */
  async events_recent_api_v2_events_get(): Promise<unknown> {
    let path = "/api/v2/events";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Add Event
   * POST /api/v2/events
   * Result is decoded JSON; the transport enforces authentication.
   */
  async add_event_api_v2_events_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/v2/events";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Delete Event
   * DELETE /api/v2/events/{event_id}
   * Result is decoded JSON; the transport enforces authentication.
   */
  async delete_event_api_v2_events__event_id__delete(args: {event_id: string}): Promise<unknown> {
    let path = "/api/v2/events/{event_id}";
    path = path.replace("{event_id}", encodeURIComponent(String(args.event_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("DELETE", path, {query, body:undefined});
  }

  /**
   * Focus
   * GET /api/v2/focus
   * Result is decoded JSON; the transport enforces authentication.
   */
  async focus_api_v2_focus_get(): Promise<unknown> {
    let path = "/api/v2/focus";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Focus Start
   * POST /api/v2/focus
   * Result is decoded JSON; the transport enforces authentication.
   */
  async focus_start_api_v2_focus_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/v2/focus";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Focus Finish
   * POST /api/v2/focus/{focus_id}/finish
   * Result is decoded JSON; the transport enforces authentication.
   */
  async focus_finish_api_v2_focus__focus_id__finish_post(args: {focus_id: string; body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/v2/focus/{focus_id}/finish";
    path = path.replace("{focus_id}", encodeURIComponent(String(args.focus_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Goals
   * GET /api/v2/goals
   * Result is decoded JSON; the transport enforces authentication.
   */
  async goals_api_v2_goals_get(): Promise<unknown> {
    let path = "/api/v2/goals";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Add Goal
   * POST /api/v2/goals
   * Result is decoded JSON; the transport enforces authentication.
   */
  async add_goal_api_v2_goals_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/v2/goals";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Goal Progress
   * PATCH /api/v2/goals/{goal_id}
   * Result is decoded JSON; the transport enforces authentication.
   */
  async goal_progress_api_v2_goals__goal_id__patch(args: {goal_id: string; body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/v2/goals/{goal_id}";
    path = path.replace("{goal_id}", encodeURIComponent(String(args.goal_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("PATCH", path, {query, body:args.body});
  }

  /**
   * Habits
   * GET /api/v2/habits
   * Result is decoded JSON; the transport enforces authentication.
   */
  async habits_api_v2_habits_get(args: {weeks?: number}): Promise<unknown> {
    let path = "/api/v2/habits";
    const query: Record<string, string | number | boolean> = {};
    if (args.weeks !== undefined && args.weeks !== null) {
      query["weeks"] = String(args.weeks);
    }
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Add Habit
   * POST /api/v2/habits
   * Result is decoded JSON; the transport enforces authentication.
   */
  async add_habit_api_v2_habits_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/v2/habits";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Check Habit
   * POST /api/v2/habits/{habit_id}/check
   * Result is decoded JSON; the transport enforces authentication.
   */
  async check_habit_api_v2_habits__habit_id__check_post(args: {habit_id: string; body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/v2/habits/{habit_id}/check";
    path = path.replace("{habit_id}", encodeURIComponent(String(args.habit_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Metrics
   * GET /api/v2/metrics
   * Result is decoded JSON; the transport enforces authentication.
   */
  async metrics_api_v2_metrics_get(): Promise<unknown> {
    let path = "/api/v2/metrics";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Metrics Series
   * GET /api/v2/metrics/timeseries
   * Result is decoded JSON; the transport enforces authentication.
   */
  async metrics_series_api_v2_metrics_timeseries_get(args: {limit?: number}): Promise<unknown> {
    let path = "/api/v2/metrics/timeseries";
    const query: Record<string, string | number | boolean> = {};
    if (args.limit !== undefined && args.limit !== null) {
      query["limit"] = String(args.limit);
    }
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Update Project Item
   * PATCH /api/v2/project-items/{item_id}
   * Result is decoded JSON; the transport enforces authentication.
   */
  async update_project_item_api_v2_project_items__item_id__patch(args: {item_id: string; body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/v2/project-items/{item_id}";
    path = path.replace("{item_id}", encodeURIComponent(String(args.item_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("PATCH", path, {query, body:args.body});
  }

  /**
   * Projects
   * GET /api/v2/projects
   * Result is decoded JSON; the transport enforces authentication.
   */
  async projects_api_v2_projects_get(args: {include_archived?: boolean}): Promise<unknown> {
    let path = "/api/v2/projects";
    const query: Record<string, string | number | boolean> = {};
    if (args.include_archived !== undefined && args.include_archived !== null) {
      query["include_archived"] = String(args.include_archived);
    }
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Add Project
   * POST /api/v2/projects
   * Result is decoded JSON; the transport enforces authentication.
   */
  async add_project_api_v2_projects_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/v2/projects";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Change Project
   * PATCH /api/v2/projects/{project_id}
   * Result is decoded JSON; the transport enforces authentication.
   */
  async change_project_api_v2_projects__project_id__patch(args: {project_id: string; body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/v2/projects/{project_id}";
    path = path.replace("{project_id}", encodeURIComponent(String(args.project_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("PATCH", path, {query, body:args.body});
  }

  /**
   * Project Items
   * GET /api/v2/projects/{project_id}/items
   * Result is decoded JSON; the transport enforces authentication.
   */
  async project_items_api_v2_projects__project_id__items_get(args: {project_id: string}): Promise<unknown> {
    let path = "/api/v2/projects/{project_id}/items";
    path = path.replace("{project_id}", encodeURIComponent(String(args.project_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Add Project Item
   * POST /api/v2/projects/{project_id}/items
   * Result is decoded JSON; the transport enforces authentication.
   */
  async add_project_item_api_v2_projects__project_id__items_post(args: {project_id: string; body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/v2/projects/{project_id}/items";
    path = path.replace("{project_id}", encodeURIComponent(String(args.project_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Schedules
   * GET /api/v2/schedules
   * Result is decoded JSON; the transport enforces authentication.
   */
  async schedules_api_v2_schedules_get(): Promise<unknown> {
    let path = "/api/v2/schedules";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Create Schedule
   * POST /api/v2/schedules
   * Result is decoded JSON; the transport enforces authentication.
   */
  async create_schedule_api_v2_schedules_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/v2/schedules";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Schedule Toggle
   * PATCH /api/v2/schedules/{schedule_id}
   * Result is decoded JSON; the transport enforces authentication.
   */
  async schedule_toggle_api_v2_schedules__schedule_id__patch(args: {schedule_id: string; body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/v2/schedules/{schedule_id}";
    path = path.replace("{schedule_id}", encodeURIComponent(String(args.schedule_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("PATCH", path, {query, body:args.body});
  }

  /**
   * Preferences
   * GET /api/v2/settings
   * Result is decoded JSON; the transport enforces authentication.
   */
  async preferences_api_v2_settings_get(): Promise<unknown> {
    let path = "/api/v2/settings";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Update Preference
   * PATCH /api/v2/settings
   * Result is decoded JSON; the transport enforces authentication.
   */
  async update_preference_api_v2_settings_patch(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/v2/settings";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("PATCH", path, {query, body:args.body});
  }

  /**
   * Snippets
   * GET /api/v2/snippets
   * Result is decoded JSON; the transport enforces authentication.
   */
  async snippets_api_v2_snippets_get(args: {query?: string}): Promise<unknown> {
    let path = "/api/v2/snippets";
    const query: Record<string, string | number | boolean> = {};
    if (args.query !== undefined && args.query !== null) {
      query["query"] = String(args.query);
    }
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Snippet
   * POST /api/v2/snippets
   * Result is decoded JSON; the transport enforces authentication.
   */
  async snippet_api_v2_snippets_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/v2/snippets";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Delete Snippet
   * DELETE /api/v2/snippets/{snippet_id}
   * Result is decoded JSON; the transport enforces authentication.
   */
  async delete_snippet_api_v2_snippets__snippet_id__delete(args: {snippet_id: string}): Promise<unknown> {
    let path = "/api/v2/snippets/{snippet_id}";
    path = path.replace("{snippet_id}", encodeURIComponent(String(args.snippet_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("DELETE", path, {query, body:undefined});
  }

  /**
   * Workflow Templates
   * GET /api/v2/workflow-templates
   * Result is decoded JSON; the transport enforces authentication.
   */
  async workflow_templates_api_v2_workflow_templates_get(): Promise<unknown> {
    let path = "/api/v2/workflow-templates";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Workflows
   * GET /api/v2/workflows
   * Result is decoded JSON; the transport enforces authentication.
   */
  async workflows_api_v2_workflows_get(): Promise<unknown> {
    let path = "/api/v2/workflows";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

  /**
   * Create Workflow
   * POST /api/v2/workflows
   * Result is decoded JSON; the transport enforces authentication.
   */
  async create_workflow_api_v2_workflows_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/v2/workflows";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Validate Workflow
   * POST /api/v2/workflows/validate
   * Result is decoded JSON; the transport enforces authentication.
   */
  async validate_workflow_api_v2_workflows_validate_post(args: {body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/v2/workflows/validate";
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:args.body});
  }

  /**
   * Toggle Workflow
   * PATCH /api/v2/workflows/{workflow_id}
   * Result is decoded JSON; the transport enforces authentication.
   */
  async toggle_workflow_api_v2_workflows__workflow_id__patch(args: {workflow_id: string; body: Record<string, unknown> | unknown[]}): Promise<unknown> {
    let path = "/api/v2/workflows/{workflow_id}";
    path = path.replace("{workflow_id}", encodeURIComponent(String(args.workflow_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("PATCH", path, {query, body:args.body});
  }

  /**
   * Run Workflow
   * POST /api/v2/workflows/{workflow_id}/run
   * Result is decoded JSON; the transport enforces authentication.
   */
  async run_workflow_api_v2_workflows__workflow_id__run_post(args: {workflow_id: string}): Promise<unknown> {
    let path = "/api/v2/workflows/{workflow_id}/run";
    path = path.replace("{workflow_id}", encodeURIComponent(String(args.workflow_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("POST", path, {query, body:undefined});
  }

  /**
   * Workflow Runs
   * GET /api/v2/workflows/{workflow_id}/runs
   * Result is decoded JSON; the transport enforces authentication.
   */
  async workflow_runs_api_v2_workflows__workflow_id__runs_get(args: {workflow_id: string}): Promise<unknown> {
    let path = "/api/v2/workflows/{workflow_id}/runs";
    path = path.replace("{workflow_id}", encodeURIComponent(String(args.workflow_id)));
    const query: Record<string, string | number | boolean> = {};
    return this.transport.request("GET", path, {query, body:undefined});
  }

}

