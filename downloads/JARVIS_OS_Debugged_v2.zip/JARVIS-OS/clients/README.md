# JARVIS Developer Client SDKs

The Python and TypeScript clients provide *actual executable wrappers* for all
JARVIS endpoints and deterministic offline skills. Each method has exact
parameter names and a description sourced from the server's schema.

- `clients/python`: install with `pip install -e clients/python` (includes `httpx`).
- `clients/typescript`: run `npm ci`, `npm run check`, and `npm run build` in that folder. Import from `src/client.ts` in a TypeScript bundler, or from `dist/client.js` in Node.js 18+ / browser ESM.
- Both require a user-supplied bearer token from the JARVIS server.
- Clients refuse HTTP connections to non-loopback hosts. Use HTTPS for phone or
  remote app integrations; the built-in browser interface supports trusted LAN
  access in plain HTTP, with a clearly stated privacy warning.
- These are generated method wrappers, not a separate autonomous AI model.
- Regenerate the clients after adding endpoints or utility skills with
  `python tools/generate_clients.py` from the project root.

## Python example

```python
from jarvis_sdk import JarvisClient

with JarvisClient(token="COPY YOUR LOCAL TOKEN") as jarvis:
    print(jarvis.utilities.percent_of(part=20,whole=250))
    print(jarvis.utilities.math_derivative(expression="(x**2+4)**3"))
    print(jarvis.routes.health_api_health_get())
```

## TypeScript example

```typescript
import { JarvisTransport } from './src/client';

const jarvis = new JarvisTransport('COPY YOUR LOCAL TOKEN');
const percent = await jarvis.utilities.percent_of({part:20,whole:250});
console.log(percent);
```

### Security and availability

- Generated client functions cannot bypass approval-gated device tools.
- Some skills use optional local dependencies such as SymPy. They will report an
  understandable error when the dependency is not installed.
- `Math` and `ML` results are computational assistance, not guaranteed answers
  for consequential decisions.
- Never embed production access tokens into public web applications or source
  repositories. This SDK is intended for software you control.

## SDK verification

The Python SDK is covered by the root project's `python -m pytest tests/test_sdk.py`.
For the optional TypeScript SDK, run `npm ci && npm run check && npm test` from
`clients/typescript`. These tests use a local test transport only; production
SDK methods still call the actual authenticated server.
