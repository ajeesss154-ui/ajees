"""Small synchronous JARVIS client with explicit bearer-token authentication.

Never logs the secret access token. The target URL is chosen by the caller.
This SDK is intended for your own local or trusted HTTPS JARVIS server.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from urllib.parse import unquote, urlsplit

import httpx


class JarvisAPIError(RuntimeError):
    def __init__(self, status: int, message: str):
        self.status = status
        self.message = message
        super().__init__(f'JARVIS API returned HTTP {status}: {message}')


class JarvisClient:
    """Access an authenticated JARVIS server using a private bearer token.

    Usage::
        with JarvisClient(token='PRIVATE TOKEN') as jarvis:
            print(jarvis.utilities.percent_of(part=20, whole=450))
            print(jarvis.routes.health_api_health_get())
    """
    def __init__(self, token: str,
                 base_url: str = 'http://127.0.0.1:8765',
                 timeout: float = 30):
        if not isinstance(token, str) or not token.strip():
            raise ValueError('A private JARVIS access token is required')
        url = urlsplit(base_url)
        if url.scheme not in ('http', 'https') or not url.hostname or url.username or url.password:
            raise ValueError('Provide an HTTP(S) server URL without credentials')
        if url.query or url.fragment:
            raise ValueError('Provide a server URL without a query or fragment')
        if url.scheme == 'http' and url.hostname not in ('localhost','127.0.0.1','::1'):
            # HTTP on private LAN is intentionally opt-in: expose nothing silently.
            raise ValueError('Use HTTPS for remote hosts. Run locally or use an HTTPS reverse proxy')
        if not 1 <= timeout <= 180:
            raise ValueError('Timeout must be between 1 and 180 seconds')
        self._http = httpx.Client(base_url=base_url.rstrip('/'), timeout=timeout,
                                  follow_redirects=False,
                                  headers={'Authorization':'Bearer '+token.strip(),
                                           'Accept':'application/json'})
        from .generated_skills import UtilityMethods
        from .generated_routes import ApiRoutes
        self.utilities = UtilityMethods(self)
        self.routes = ApiRoutes(self)

    def _request(self, method: str, path: str,
                 json: dict | None = None,
                 params: dict | None = None) -> Any:
        if method not in ('GET','POST','PATCH','PUT','DELETE'):
            raise ValueError('Unsupported HTTP method')
        parsed = urlsplit(path)
        if (not path.startswith('/api/') or '://' in path or '\\' in path
                or parsed.fragment or any(part in ('.', '..') for part in unquote(parsed.path).split('/'))):
            raise ValueError('Only JARVIS API paths without traversal are supported')
        response = self._http.request(method, path, json=json, params=params)
        try:
            result = response.json()
        except ValueError:
            result = {'detail':response.text[:200]}
        if response.is_error or response.is_redirect:
            detail=result.get('detail') if isinstance(result,dict) else 'Request failed'
            if isinstance(detail,dict):
                detail='Request validation failed'
            raise JarvisAPIError(response.status_code,str(detail)[:250])
        return result

    def close(self):
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self,*args):
        self.close()
        return False
