"""AUTO-GENERATED REST endpoint methods from FastAPI OpenAPI routes.

All methods call a real running JARVIS server. The raw JSON request
body follows the matching Pydantic schema documented in /openapi.json.
Regenerate with python tools/generate_clients.py.
"""
from __future__ import annotations

from typing import Any
from urllib.parse import quote
from .client import JarvisClient


class ApiRoutes:
    """Methods for every published token-protected JARVIS REST route."""

    def __init__(self, client: JarvisClient):
        self._client=client

    def approvals_api_approvals_get(
        self,
    ) -> Any:
        """Approvals

        Endpoint: GET /api/approvals.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/approvals'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def approve_api_approvals__ident__approve_post(
        self,
        ident: str,
    ) -> Any:
        """Approve

        Endpoint: POST /api/approvals/{ident}/approve.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/approvals/{ident}/approve'
        path = path.replace('{ident}', quote(str(ident), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=None,
        )

    def deny_api_approvals__ident__deny_post(
        self,
        ident: str,
    ) -> Any:
        """Deny

        Endpoint: POST /api/approvals/{ident}/deny.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/approvals/{ident}/deny'
        path = path.replace('{ident}', quote(str(ident), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=None,
        )

    def audit_api_audit_get(
        self,
    ) -> Any:
        """Audit

        Endpoint: GET /api/audit.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/audit'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def chat_api_chat_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Chat

        Endpoint: POST /api/chat.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/chat'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def facts_api_facts_get(
        self,
    ) -> Any:
        """Facts

        Endpoint: GET /api/facts.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/facts'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def health_api_health_get(
        self,
    ) -> Any:
        """Health

        Endpoint: GET /api/health.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/health'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def clear_history_api_history__session_id__delete(
        self,
        session_id: str,
    ) -> Any:
        """Clear History

        Endpoint: DELETE /api/history/{session_id}.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/history/{session_id}'
        path = path.replace('{session_id}', quote(str(session_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'DELETE', path,
            params=query or None,
            json=None,
        )

    def history_api_history__session_id__get(
        self,
        session_id: str,
    ) -> Any:
        """History

        Endpoint: GET /api/history/{session_id}.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/history/{session_id}'
        path = path.replace('{session_id}', quote(str(session_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def get_chunk_api_knowledge_chunks__chunk_id__get(
        self,
        chunk_id: str,
    ) -> Any:
        """Get Chunk

        Endpoint: GET /api/knowledge/chunks/{chunk_id}.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/knowledge/chunks/{chunk_id}'
        path = path.replace('{chunk_id}', quote(str(chunk_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def context_api_knowledge_context_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Context

        Endpoint: POST /api/knowledge/context.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/knowledge/context'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def refresh_api_knowledge_refresh_post(
        self,
    ) -> Any:
        """Refresh

        Endpoint: POST /api/knowledge/refresh.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/knowledge/refresh'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=None,
        )

    def search_api_knowledge_search_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Search

        Endpoint: POST /api/knowledge/search.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/knowledge/search'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def sources_api_knowledge_sources_get(
        self,
    ) -> Any:
        """Sources

        Endpoint: GET /api/knowledge/sources.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/knowledge/sources'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def stats_api_knowledge_stats_get(
        self,
    ) -> Any:
        """Stats

        Endpoint: GET /api/knowledge/stats.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/knowledge/stats'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def compare_api_knowledge_text_compare_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Compare

        Endpoint: POST /api/knowledge/text/compare.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/knowledge/text/compare'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def entities_api_knowledge_text_entities_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Entities

        Endpoint: POST /api/knowledge/text/entities.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/knowledge/text/entities'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def profile_api_knowledge_text_profile_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Profile

        Endpoint: POST /api/knowledge/text/profile.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/knowledge/text/profile'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def study_prompts_api_knowledge_text_study_prompts_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Study Prompts

        Endpoint: POST /api/knowledge/text/study-prompts.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/knowledge/text/study-prompts'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def summary_api_knowledge_text_summary_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Summary

        Endpoint: POST /api/knowledge/text/summary.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/knowledge/text/summary'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def decisions_api_lab_decisions_get(
        self,
        *,
        limit: int | None = None,
    ) -> Any:
        """Decisions

        Endpoint: GET /api/lab/decisions.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/lab/decisions'
        query: dict[str, Any] = {}
        if limit is not None:
            query['limit'] = limit
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def add_decision_api_lab_decisions_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Add Decision

        Endpoint: POST /api/lab/decisions.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/lab/decisions'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def experiments_api_lab_experiments_get(
        self,
        *,
        idea_id: Any | None = None,
        limit: int | None = None,
    ) -> Any:
        """Experiments

        Endpoint: GET /api/lab/experiments.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/lab/experiments'
        query: dict[str, Any] = {}
        if idea_id is not None:
            query['idea_id'] = idea_id
        if limit is not None:
            query['limit'] = limit
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def add_experiment_api_lab_experiments_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Add Experiment

        Endpoint: POST /api/lab/experiments.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/lab/experiments'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def conclude_api_lab_experiments__ident__patch(
        self,
        ident: str,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Conclude

        Endpoint: PATCH /api/lab/experiments/{ident}.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/lab/experiments/{ident}'
        path = path.replace('{ident}', quote(str(ident), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'PATCH', path,
            params=query or None,
            json=body,
        )

    def feedback_api_lab_feedback_get(
        self,
        *,
        status: Any | None = None,
        limit: int | None = None,
    ) -> Any:
        """Feedback

        Endpoint: GET /api/lab/feedback.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/lab/feedback'
        query: dict[str, Any] = {}
        if status is not None:
            query['status'] = status
        if limit is not None:
            query['limit'] = limit
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def add_feedback_api_lab_feedback_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Add Feedback

        Endpoint: POST /api/lab/feedback.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/lab/feedback'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def patch_feedback_api_lab_feedback__ident__patch(
        self,
        ident: str,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Patch Feedback

        Endpoint: PATCH /api/lab/feedback/{ident}.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/lab/feedback/{ident}'
        path = path.replace('{ident}', quote(str(ident), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'PATCH', path,
            params=query or None,
            json=body,
        )

    def ideas_api_lab_ideas_get(
        self,
        *,
        query: str | None = None,
        status: Any | None = None,
        limit: int | None = None,
    ) -> Any:
        """Ideas

        Endpoint: GET /api/lab/ideas.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/lab/ideas'
        query: dict[str, Any] = {}
        if query is not None:
            query['query'] = query
        if status is not None:
            query['status'] = status
        if limit is not None:
            query['limit'] = limit
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def create_idea_api_lab_ideas_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Create Idea

        Endpoint: POST /api/lab/ideas.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/lab/ideas'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def delete_idea_api_lab_ideas__ident__delete(
        self,
        ident: str,
    ) -> Any:
        """Delete Idea

        Endpoint: DELETE /api/lab/ideas/{ident}.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/lab/ideas/{ident}'
        path = path.replace('{ident}', quote(str(ident), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'DELETE', path,
            params=query or None,
            json=None,
        )

    def get_idea_api_lab_ideas__ident__get(
        self,
        ident: str,
    ) -> Any:
        """Get Idea

        Endpoint: GET /api/lab/ideas/{ident}.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/lab/ideas/{ident}'
        path = path.replace('{ident}', quote(str(ident), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def patch_idea_api_lab_ideas__ident__patch(
        self,
        ident: str,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Patch Idea

        Endpoint: PATCH /api/lab/ideas/{ident}.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/lab/ideas/{ident}'
        path = path.replace('{ident}', quote(str(ident), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'PATCH', path,
            params=query or None,
            json=body,
        )

    def overview_api_lab_overview_get(
        self,
    ) -> Any:
        """Overview

        Endpoint: GET /api/lab/overview.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/lab/overview'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def me_api_me_get(
        self,
    ) -> Any:
        """Me

        Endpoint: GET /api/me.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/me'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def notes_api_notes_get(
        self,
    ) -> Any:
        """Notes

        Endpoint: GET /api/notes.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/notes'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def save_note_api_notes_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Save Note

        Endpoint: POST /api/notes.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/notes'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def notifications_api_notifications_get(
        self,
    ) -> Any:
        """Notifications

        Endpoint: GET /api/notifications.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/notifications'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def ack_api_notifications__ident__ack_post(
        self,
        ident: str,
    ) -> Any:
        """Ack

        Endpoint: POST /api/notifications/{ident}/ack.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/notifications/{ident}/ack'
        path = path.replace('{ident}', quote(str(ident), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=None,
        )

    def transcribe_audio_api_perception_audio_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Transcribe Audio

        Endpoint: POST /api/perception/audio.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/perception/audio'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def features_api_perception_features_get(
        self,
    ) -> Any:
        """Features

        Endpoint: GET /api/perception/features.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/perception/features'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def describe_image_api_perception_image_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Describe Image

        Endpoint: POST /api/perception/image.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/perception/image'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def reminders_api_reminders_get(
        self,
    ) -> Any:
        """Reminders

        Endpoint: GET /api/reminders.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/reminders'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def add_reminder_api_reminders_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Add Reminder

        Endpoint: POST /api/reminders.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/reminders'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def status_info_api_status_get(
        self,
    ) -> Any:
        """Status Info

        Endpoint: GET /api/status.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/status'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def delete_card_api_study_cards__card_id__delete(
        self,
        card_id: str,
    ) -> Any:
        """Delete Card

        Endpoint: DELETE /api/study/cards/{card_id}.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/study/cards/{card_id}'
        path = path.replace('{card_id}', quote(str(card_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'DELETE', path,
            params=query or None,
            json=None,
        )

    def card_api_study_cards__card_id__get(
        self,
        card_id: str,
    ) -> Any:
        """Card

        Endpoint: GET /api/study/cards/{card_id}.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/study/cards/{card_id}'
        path = path.replace('{card_id}', quote(str(card_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def update_card_api_study_cards__card_id__patch(
        self,
        card_id: str,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Update Card

        Endpoint: PATCH /api/study/cards/{card_id}.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/study/cards/{card_id}'
        path = path.replace('{card_id}', quote(str(card_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'PATCH', path,
            params=query or None,
            json=body,
        )

    def review_api_study_cards__card_id__review_post(
        self,
        card_id: str,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Review

        Endpoint: POST /api/study/cards/{card_id}/review.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/study/cards/{card_id}/review'
        path = path.replace('{card_id}', quote(str(card_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def decks_api_study_decks_get(
        self,
        *,
        archived: bool | None = None,
    ) -> Any:
        """Decks

        Endpoint: GET /api/study/decks.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/study/decks'
        query: dict[str, Any] = {}
        if archived is not None:
            query['archived'] = archived
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def create_deck_api_study_decks_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Create Deck

        Endpoint: POST /api/study/decks.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/study/decks'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def deck_api_study_decks__deck_id__get(
        self,
        deck_id: str,
    ) -> Any:
        """Deck

        Endpoint: GET /api/study/decks/{deck_id}.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/study/decks/{deck_id}'
        path = path.replace('{deck_id}', quote(str(deck_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def update_deck_api_study_decks__deck_id__patch(
        self,
        deck_id: str,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Update Deck

        Endpoint: PATCH /api/study/decks/{deck_id}.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/study/decks/{deck_id}'
        path = path.replace('{deck_id}', quote(str(deck_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'PATCH', path,
            params=query or None,
            json=body,
        )

    def cards_api_study_decks__deck_id__cards_get(
        self,
        deck_id: str,
        *,
        query: str | None = None,
        limit: int | None = None,
    ) -> Any:
        """Cards

        Endpoint: GET /api/study/decks/{deck_id}/cards.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/study/decks/{deck_id}/cards'
        path = path.replace('{deck_id}', quote(str(deck_id), safe=''))
        query: dict[str, Any] = {}
        if query is not None:
            query['query'] = query
        if limit is not None:
            query['limit'] = limit
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def create_card_api_study_decks__deck_id__cards_post(
        self,
        deck_id: str,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Create Card

        Endpoint: POST /api/study/decks/{deck_id}/cards.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/study/decks/{deck_id}/cards'
        path = path.replace('{deck_id}', quote(str(deck_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def export_deck_api_study_decks__deck_id__export_get(
        self,
        deck_id: str,
    ) -> Any:
        """Export Deck

        Endpoint: GET /api/study/decks/{deck_id}/export.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/study/decks/{deck_id}/export'
        path = path.replace('{deck_id}', quote(str(deck_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def import_cards_api_study_decks__deck_id__import_post(
        self,
        deck_id: str,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Import Cards

        Endpoint: POST /api/study/decks/{deck_id}/import.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/study/decks/{deck_id}/import'
        path = path.replace('{deck_id}', quote(str(deck_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def due_api_study_due_get(
        self,
        *,
        deck_id: Any | None = None,
        day: Any | None = None,
        limit: int | None = None,
    ) -> Any:
        """Due

        Endpoint: GET /api/study/due.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/study/due'
        query: dict[str, Any] = {}
        if deck_id is not None:
            query['deck_id'] = deck_id
        if day is not None:
            query['day'] = day
        if limit is not None:
            query['limit'] = limit
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def reviews_api_study_reviews_get(
        self,
        *,
        card_id: Any | None = None,
        limit: int | None = None,
    ) -> Any:
        """Reviews

        Endpoint: GET /api/study/reviews.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/study/reviews'
        query: dict[str, Any] = {}
        if card_id is not None:
            query['card_id'] = card_id
        if limit is not None:
            query['limit'] = limit
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def statistics_api_study_statistics_get(
        self,
    ) -> Any:
        """Statistics

        Endpoint: GET /api/study/statistics.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/study/statistics'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def tasks_api_tasks_get(
        self,
    ) -> Any:
        """Tasks

        Endpoint: GET /api/tasks.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/tasks'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def create_task_api_tasks_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Create Task

        Endpoint: POST /api/tasks.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/tasks'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def complete_task_api_tasks__task_id__complete_post(
        self,
        task_id: str,
    ) -> Any:
        """Complete Task

        Endpoint: POST /api/tasks/{task_id}/complete.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/tasks/{task_id}/complete'
        path = path.replace('{task_id}', quote(str(task_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=None,
        )

    def tools_api_tools_get(
        self,
    ) -> Any:
        """Tools

        Endpoint: GET /api/tools.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/tools'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def catalog_api_utilities_catalog_get(
        self,
        *,
        category: Any | None = None,
    ) -> Any:
        """Catalog

        Endpoint: GET /api/utilities/catalog.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/utilities/catalog'
        query: dict[str, Any] = {}
        if category is not None:
            query['category'] = category
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def definition_api_utilities_catalog__name__get(
        self,
        name: str,
    ) -> Any:
        """Definition

        Endpoint: GET /api/utilities/catalog/{name}.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/utilities/catalog/{name}'
        path = path.replace('{name}', quote(str(name), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def categories_api_utilities_categories_get(
        self,
    ) -> Any:
        """Categories

        Endpoint: GET /api/utilities/categories.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/utilities/categories'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def run_api_utilities_run_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Run

        Endpoint: POST /api/utilities/run.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/utilities/run'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def stats_api_utilities_stats_get(
        self,
    ) -> Any:
        """Stats

        Endpoint: GET /api/utilities/stats.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/utilities/stats'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def activity_api_v2_activity_get(
        self,
        *,
        limit: int | None = None,
    ) -> Any:
        """Activity

        Endpoint: GET /api/v2/activity.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/activity'
        query: dict[str, Any] = {}
        if limit is not None:
            query['limit'] = limit
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def backups_api_v2_backups_get(
        self,
    ) -> Any:
        """Backups

        Endpoint: GET /api/v2/backups.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/backups'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def create_backup_api_v2_backups_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Create Backup

        Endpoint: POST /api/v2/backups.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/backups'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def check_backup_api_v2_backups__filename__validate_get(
        self,
        filename: str,
    ) -> Any:
        """Check Backup

        Endpoint: GET /api/v2/backups/{filename}/validate.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/backups/{filename}/validate'
        path = path.replace('{filename}', quote(str(filename), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def bookmarks_api_v2_bookmarks_get(
        self,
        *,
        query: str | None = None,
    ) -> Any:
        """Bookmarks

        Endpoint: GET /api/v2/bookmarks.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/bookmarks'
        query: dict[str, Any] = {}
        if query is not None:
            query['query'] = query
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def bookmark_api_v2_bookmarks_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Bookmark

        Endpoint: POST /api/v2/bookmarks.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/bookmarks'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def delete_bookmark_api_v2_bookmarks__bookmark_id__delete(
        self,
        bookmark_id: str,
    ) -> Any:
        """Delete Bookmark

        Endpoint: DELETE /api/v2/bookmarks/{bookmark_id}.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/bookmarks/{bookmark_id}'
        path = path.replace('{bookmark_id}', quote(str(bookmark_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'DELETE', path,
            params=query or None,
            json=None,
        )

    def dashboard_api_v2_dashboard_get(
        self,
    ) -> Any:
        """Dashboard

        Endpoint: GET /api/v2/dashboard.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/dashboard'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def events_recent_api_v2_events_get(
        self,
    ) -> Any:
        """Events Recent

        Endpoint: GET /api/v2/events.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/events'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def add_event_api_v2_events_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Add Event

        Endpoint: POST /api/v2/events.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/events'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def delete_event_api_v2_events__event_id__delete(
        self,
        event_id: str,
    ) -> Any:
        """Delete Event

        Endpoint: DELETE /api/v2/events/{event_id}.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/events/{event_id}'
        path = path.replace('{event_id}', quote(str(event_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'DELETE', path,
            params=query or None,
            json=None,
        )

    def focus_api_v2_focus_get(
        self,
    ) -> Any:
        """Focus

        Endpoint: GET /api/v2/focus.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/focus'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def focus_start_api_v2_focus_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Focus Start

        Endpoint: POST /api/v2/focus.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/focus'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def focus_finish_api_v2_focus__focus_id__finish_post(
        self,
        focus_id: str,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Focus Finish

        Endpoint: POST /api/v2/focus/{focus_id}/finish.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/focus/{focus_id}/finish'
        path = path.replace('{focus_id}', quote(str(focus_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def goals_api_v2_goals_get(
        self,
    ) -> Any:
        """Goals

        Endpoint: GET /api/v2/goals.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/goals'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def add_goal_api_v2_goals_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Add Goal

        Endpoint: POST /api/v2/goals.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/goals'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def goal_progress_api_v2_goals__goal_id__patch(
        self,
        goal_id: str,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Goal Progress

        Endpoint: PATCH /api/v2/goals/{goal_id}.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/goals/{goal_id}'
        path = path.replace('{goal_id}', quote(str(goal_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'PATCH', path,
            params=query or None,
            json=body,
        )

    def habits_api_v2_habits_get(
        self,
        *,
        weeks: int | None = None,
    ) -> Any:
        """Habits

        Endpoint: GET /api/v2/habits.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/habits'
        query: dict[str, Any] = {}
        if weeks is not None:
            query['weeks'] = weeks
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def add_habit_api_v2_habits_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Add Habit

        Endpoint: POST /api/v2/habits.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/habits'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def check_habit_api_v2_habits__habit_id__check_post(
        self,
        habit_id: str,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Check Habit

        Endpoint: POST /api/v2/habits/{habit_id}/check.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/habits/{habit_id}/check'
        path = path.replace('{habit_id}', quote(str(habit_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def metrics_api_v2_metrics_get(
        self,
    ) -> Any:
        """Metrics

        Endpoint: GET /api/v2/metrics.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/metrics'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def metrics_series_api_v2_metrics_timeseries_get(
        self,
        *,
        limit: int | None = None,
    ) -> Any:
        """Metrics Series

        Endpoint: GET /api/v2/metrics/timeseries.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/metrics/timeseries'
        query: dict[str, Any] = {}
        if limit is not None:
            query['limit'] = limit
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def update_project_item_api_v2_project_items__item_id__patch(
        self,
        item_id: str,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Update Project Item

        Endpoint: PATCH /api/v2/project-items/{item_id}.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/project-items/{item_id}'
        path = path.replace('{item_id}', quote(str(item_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'PATCH', path,
            params=query or None,
            json=body,
        )

    def projects_api_v2_projects_get(
        self,
        *,
        include_archived: bool | None = None,
    ) -> Any:
        """Projects

        Endpoint: GET /api/v2/projects.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/projects'
        query: dict[str, Any] = {}
        if include_archived is not None:
            query['include_archived'] = include_archived
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def add_project_api_v2_projects_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Add Project

        Endpoint: POST /api/v2/projects.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/projects'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def change_project_api_v2_projects__project_id__patch(
        self,
        project_id: str,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Change Project

        Endpoint: PATCH /api/v2/projects/{project_id}.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/projects/{project_id}'
        path = path.replace('{project_id}', quote(str(project_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'PATCH', path,
            params=query or None,
            json=body,
        )

    def project_items_api_v2_projects__project_id__items_get(
        self,
        project_id: str,
    ) -> Any:
        """Project Items

        Endpoint: GET /api/v2/projects/{project_id}/items.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/projects/{project_id}/items'
        path = path.replace('{project_id}', quote(str(project_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def add_project_item_api_v2_projects__project_id__items_post(
        self,
        project_id: str,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Add Project Item

        Endpoint: POST /api/v2/projects/{project_id}/items.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/projects/{project_id}/items'
        path = path.replace('{project_id}', quote(str(project_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def schedules_api_v2_schedules_get(
        self,
    ) -> Any:
        """Schedules

        Endpoint: GET /api/v2/schedules.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/schedules'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def create_schedule_api_v2_schedules_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Create Schedule

        Endpoint: POST /api/v2/schedules.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/schedules'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def schedule_toggle_api_v2_schedules__schedule_id__patch(
        self,
        schedule_id: str,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Schedule Toggle

        Endpoint: PATCH /api/v2/schedules/{schedule_id}.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/schedules/{schedule_id}'
        path = path.replace('{schedule_id}', quote(str(schedule_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'PATCH', path,
            params=query or None,
            json=body,
        )

    def preferences_api_v2_settings_get(
        self,
    ) -> Any:
        """Preferences

        Endpoint: GET /api/v2/settings.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/settings'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def update_preference_api_v2_settings_patch(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Update Preference

        Endpoint: PATCH /api/v2/settings.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/settings'
        query: dict[str, Any] = {}
        return self._client._request(
            'PATCH', path,
            params=query or None,
            json=body,
        )

    def snippets_api_v2_snippets_get(
        self,
        *,
        query: str | None = None,
    ) -> Any:
        """Snippets

        Endpoint: GET /api/v2/snippets.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/snippets'
        query: dict[str, Any] = {}
        if query is not None:
            query['query'] = query
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def snippet_api_v2_snippets_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Snippet

        Endpoint: POST /api/v2/snippets.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/snippets'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def delete_snippet_api_v2_snippets__snippet_id__delete(
        self,
        snippet_id: str,
    ) -> Any:
        """Delete Snippet

        Endpoint: DELETE /api/v2/snippets/{snippet_id}.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/snippets/{snippet_id}'
        path = path.replace('{snippet_id}', quote(str(snippet_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'DELETE', path,
            params=query or None,
            json=None,
        )

    def workflow_templates_api_v2_workflow_templates_get(
        self,
    ) -> Any:
        """Workflow Templates

        Endpoint: GET /api/v2/workflow-templates.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/workflow-templates'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def workflows_api_v2_workflows_get(
        self,
    ) -> Any:
        """Workflows

        Endpoint: GET /api/v2/workflows.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/workflows'
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

    def create_workflow_api_v2_workflows_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Create Workflow

        Endpoint: POST /api/v2/workflows.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/workflows'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def validate_workflow_api_v2_workflows_validate_post(
        self,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Validate Workflow

        Endpoint: POST /api/v2/workflows/validate.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/workflows/validate'
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=body,
        )

    def toggle_workflow_api_v2_workflows__workflow_id__patch(
        self,
        workflow_id: str,
        *,
        body: dict[str, Any] | list[Any],
    ) -> Any:
        """Toggle Workflow

        Endpoint: PATCH /api/v2/workflows/{workflow_id}.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/workflows/{workflow_id}'
        path = path.replace('{workflow_id}', quote(str(workflow_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'PATCH', path,
            params=query or None,
            json=body,
        )

    def run_workflow_api_v2_workflows__workflow_id__run_post(
        self,
        workflow_id: str,
    ) -> Any:
        """Run Workflow

        Endpoint: POST /api/v2/workflows/{workflow_id}/run.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/workflows/{workflow_id}/run'
        path = path.replace('{workflow_id}', quote(str(workflow_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'POST', path,
            params=query or None,
            json=None,
        )

    def workflow_runs_api_v2_workflows__workflow_id__runs_get(
        self,
        workflow_id: str,
    ) -> Any:
        """Workflow Runs

        Endpoint: GET /api/v2/workflows/{workflow_id}/runs.
        Requires a valid JARVIS access token.
        Device-control actions still require independent user approval.
        Returns decoded JSON or raises JarvisAPIError.
        """
        path = '/api/v2/workflows/{workflow_id}/runs'
        path = path.replace('{workflow_id}', quote(str(workflow_id), safe=''))
        query: dict[str, Any] = {}
        return self._client._request(
            'GET', path,
            params=query or None,
            json=None,
        )

