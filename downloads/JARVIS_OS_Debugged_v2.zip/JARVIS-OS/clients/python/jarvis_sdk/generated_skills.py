"""AUTO-GENERATED typed JARVIS utility methods. Do not edit by hand.

All wrappers call a real token-protected API endpoint. There is no
code execution, model training, network discovery, or hidden OS access.
Regenerate with: python tools/generate_clients.py
"""
from __future__ import annotations

from typing import Any, Required, NotRequired, TypedDict
from .client import JarvisClient


class AddBusinessDaysArgs(TypedDict):
    """Typed request fields for add_business_days.

    Advance a specified number of weekdays
    """
    start: Required[str]
    """YYYY-MM-DD"""
    days: Required[int]
    """Signed weekdays"""


class AddDaysArgs(TypedDict):
    """Typed request fields for add_days.

    Add or subtract calendar days
    """
    date: Required[str]
    """YYYY-MM-DD"""
    days: Required[int]
    """Signed number of days"""


class AddMonthsArgs(TypedDict):
    """Typed request fields for add_months.

    Add calendar months, clamping day to month length
    """
    date: Required[str]
    """YYYY-MM-DD"""
    months: Required[int]
    """Signed number of months"""


class AnagramCheckArgs(TypedDict):
    """Typed request fields for anagram_check.

    Check whether two phrases use the same alphanumeric characters
    """
    first: Required[str]
    """Phrase 1"""
    second: Required[str]
    """Phrase 2"""


class ArithmeticSequenceArgs(TypedDict):
    """Typed request fields for arithmetic_sequence.

    Produce a finite arithmetic progression
    """
    start: Required[float]
    """First term"""
    difference: Required[float]
    """Common difference"""
    count: Required[int]
    """Terms"""


class AspectRatioArgs(TypedDict):
    """Typed request fields for aspect_ratio.

    Simplify pixel aspect ratio
    """
    width: Required[int]
    """Width"""
    height: Required[int]
    """Height"""


class BaseToNumberArgs(TypedDict):
    """Typed request fields for base_to_number.

    Parse a base-2 to base-36 integer
    """
    text: Required[str]
    """Digit string"""
    base: Required[int]
    """Base"""


class BayesRuleArgs(TypedDict):
    """Typed request fields for bayes_rule.

    Update a prior probability using sensitivity and false-positive rate
    """
    prior: Required[float]
    """Prior P(H)"""
    sensitivity: Required[float]
    """P(E given H)"""
    false_positive: Required[float]
    """P(E given not H)"""


class BinomialAtLeastArgs(TypedDict):
    """Typed request fields for binomial_at_least.

    Binomial probability of at least k successes
    """
    trials: Required[int]
    """Trials"""
    successes: Required[int]
    """Minimum successes"""
    p: Required[float]
    """Success probability"""


class BinomialExactArgs(TypedDict):
    """Typed request fields for binomial_exact.

    Binomial probability of exactly k successes
    """
    trials: Required[int]
    """Independent trials"""
    successes: Required[int]
    """Success count"""
    p: Required[float]
    """Success chance"""


class BinomialMeanVarianceArgs(TypedDict):
    """Typed request fields for binomial_mean_variance.

    Expected value and variance of a binomial distribution
    """
    trials: Required[int]
    """Number of trials"""
    p: Required[float]
    """Success probability"""


class BirthdayCollisionArgs(TypedDict):
    """Typed request fields for birthday_collision.

    Approximate chance two people share a birthday
    """
    people: Required[int]
    """Group size"""


class BitsToBytesArgs(TypedDict):
    """Typed request fields for bits_to_bytes.

    Convert bit count to full and remaining bytes
    """
    bits: Required[int]
    """Bit count"""


class BootstrapMeanArgs(TypedDict):
    """Typed request fields for bootstrap_mean.

    Compute deterministic bootstrap means for a small sample
    """
    values: Required[list[Any]]
    """Input observations"""
    replicates: NotRequired[int]
    """Replicates"""
    seed: NotRequired[int]
    """Random seed"""


class BuildQuerystringArgs(TypedDict):
    """Typed request fields for build_querystring.

    Build URL query string from key-value pairs
    """
    items: Required[list[Any]]
    """Pairs as objects with key and value"""


class BusinessDaysArgs(TypedDict):
    """Typed request fields for business_days.

    Count weekdays Monday–Friday in inclusive date range, not holidays
    """
    start: Required[str]
    """YYYY-MM-DD"""
    end: Required[str]
    """YYYY-MM-DD"""


class BytesToBitsArgs(TypedDict):
    """Typed request fields for bytes_to_bits.

    Convert bytes to bits
    """
    bytes: Required[int]
    """Byte count"""


class CalendarMonthArgs(TypedDict):
    """Typed request fields for calendar_month.

    Create a month grid of dates and empty cells
    """
    year: Required[int]
    """Year"""
    month: Required[int]
    """Month"""
    monday_first: NotRequired[bool]
    """Start weeks on Monday"""


class CaseTransformArgs(TypedDict):
    """Typed request fields for case_transform.

    Transform labels into snake kebab camel pascal title or constant case
    """
    text: Required[str]
    """Text"""
    style: Required[str]
    """Style"""


class CharacterCountArgs(TypedDict):
    """Typed request fields for character_count.

    Count Unicode codepoints by broad category
    """
    text: Required[str]
    """Passage"""


class CircleAreaArgs(TypedDict):
    """Typed request fields for circle_area.

    Circle area and circumference for a positive radius
    """
    radius: Required[float]
    """Radius"""


class ClampNumberArgs(TypedDict):
    """Typed request fields for clamp_number.

    Constrain a value between two numbers
    """
    value: Required[float]
    """Input"""
    minimum: Required[float]
    """Lower limit"""
    maximum: Required[float]
    """Upper limit"""


class CoefficientOfVariationArgs(TypedDict):
    """Typed request fields for coefficient_of_variation.

    Compute standard deviation relative to mean
    """
    values: Required[list[Any]]
    """Numeric samples"""


class CoinTossDistributionArgs(TypedDict):
    """Typed request fields for coin_toss_distribution.

    Distribution of heads across a fixed number of fair flips
    """
    flips: Required[int]
    """Number of flips"""


class CombinationsArgs(TypedDict):
    """Typed request fields for combinations.

    Number of ways to select k items without order
    """
    n: Required[int]
    """Total items"""
    k: Required[int]
    """Selected items"""


class CommonWordsArgs(TypedDict):
    """Typed request fields for common_words.

    Find words present in both texts
    """
    first: Required[str]
    """First text"""
    second: Required[str]
    """Second text"""


class CompoundGrowthArgs(TypedDict):
    """Typed request fields for compound_growth.

    Compute compounded hypothetical growth
    """
    principal: Required[float]
    """Initial value"""
    annual_percent: Required[float]
    """Annual growth rate"""
    years: Required[float]
    """Years"""
    periods: NotRequired[int]
    """Compounding periods per year"""


class ConditionalProbabilityArgs(TypedDict):
    """Typed request fields for conditional_probability.

    Compute P(A given B) from joint and marginal probabilities
    """
    joint: Required[float]
    """P(A and B)"""
    given: Required[float]
    """P(B)"""


class ConeVolumeArgs(TypedDict):
    """Typed request fields for cone_volume.

    Compute cone volume
    """
    radius: Required[float]
    """Base radius"""
    height: Required[float]
    """Cone height"""


class ConvertTemperatureArgs(TypedDict):
    """Typed request fields for convert_temperature.

    Convert Celsius Fahrenheit and Kelvin
    """
    value: Required[float]
    """Temperature"""
    origin: Required[str]
    """c, f or k"""
    destination: Required[str]
    """c, f or k"""


class ConvertUnitsArgs(TypedDict):
    """Typed request fields for convert_units.

    Convert between defined units in a physical category
    """
    value: Required[float]
    """Numeric amount"""
    category: Required[str]
    """One of the unit categories"""
    origin: Required[str]
    """Source symbol"""
    destination: Required[str]
    """Target symbol"""


class CorrelationMatrixArgs(TypedDict):
    """Typed request fields for correlation_matrix.

    Compute correlations among several same-length series
    """
    series: Required[list[Any]]
    """List of numeric series"""


class CovarianceArgs(TypedDict):
    """Typed request fields for covariance.

    Compute sample or population covariance
    """
    first: Required[list[Any]]
    """Numeric series"""
    second: Required[list[Any]]
    """Paired numeric series"""
    sample: NotRequired[bool]
    """Sample covariance"""


class CuboidVolumeArgs(TypedDict):
    """Typed request fields for cuboid_volume.

    Compute cuboid volume and surface area
    """
    length: Required[float]
    """Length"""
    width: Required[float]
    """Width"""
    height: Required[float]
    """Height"""


class CumulativeProductArgs(TypedDict):
    """Typed request fields for cumulative_product.

    Calculate bounded running products
    """
    values: Required[list[Any]]
    """Numeric values"""


class CumulativeSumArgs(TypedDict):
    """Typed request fields for cumulative_sum.

    Calculate running totals for a numeric list
    """
    values: Required[list[Any]]
    """Numeric values"""


class CylinderVolumeArgs(TypedDict):
    """Typed request fields for cylinder_volume.

    Compute cylinder volume in input cubic units
    """
    radius: Required[float]
    """Base radius"""
    height: Required[float]
    """Height"""


class DateRangeArgs(TypedDict):
    """Typed request fields for date_range.

    Generate an inclusive list of dates in a short interval
    """
    start: Required[str]
    """YYYY-MM-DD"""
    end: Required[str]
    """YYYY-MM-DD"""
    every_days: NotRequired[int]
    """Interval in days"""


class DatetimeDifferenceArgs(TypedDict):
    """Typed request fields for datetime_difference.

    Calculate a signed difference between instants
    """
    start: Required[str]
    """ISO datetime with offset"""
    end: Required[str]
    """ISO datetime with offset"""


class DaysBetweenArgs(TypedDict):
    """Typed request fields for days_between.

    Calculate signed calendar days between two ISO dates
    """
    start: Required[str]
    """YYYY-MM-DD"""
    end: Required[str]
    """YYYY-MM-DD"""


class DeadlineProgressArgs(TypedDict):
    """Typed request fields for deadline_progress.

    Measure date-based progress through a known project timeline
    """
    started: Required[str]
    """YYYY-MM-DD"""
    deadline: Required[str]
    """YYYY-MM-DD"""
    current: Required[str]
    """YYYY-MM-DD"""


class DeduplicateLinesArgs(TypedDict):
    """Typed request fields for deduplicate_lines.

    Remove repeated lines while preserving first occurrence
    """
    text: Required[str]
    """Multiline text"""
    ignore_case: NotRequired[bool]
    """Compare case insensitively"""


class DetectRepetitionsArgs(TypedDict):
    """Typed request fields for detect_repetitions.

    Show repeated full sentences
    """
    text: Required[str]
    """Document"""


class DiceSumDistributionArgs(TypedDict):
    """Typed request fields for dice_sum_distribution.

    Exact discrete distribution for small fair dice sums
    """
    dice: Required[int]
    """Number of dice"""
    sides: NotRequired[int]
    """Faces per die"""


class DiscountPriceArgs(TypedDict):
    """Typed request fields for discount_price.

    Apply a discount percentage
    """
    original: Required[float]
    """Original price"""
    discount_percent: Required[float]
    """Discount"""


class Distance2dArgs(TypedDict):
    """Typed request fields for distance_2d.

    Calculate Euclidean distance between two 2D points
    """
    x1: Required[float]
    """X 1"""
    y1: Required[float]
    """Y 1"""
    x2: Required[float]
    """X 2"""
    y2: Required[float]
    """Y 2"""


class DistanceFromSpeedArgs(TypedDict):
    """Typed request fields for distance_from_speed.

    Calculate distance traveled at constant speed
    """
    kilometers_per_hour: Required[float]
    """Average speed"""
    hours: Required[float]
    """Elapsed hours"""


class DownloadTimeEstimateArgs(TypedDict):
    """Typed request fields for download_time_estimate.

    Estimate download time without network measurement
    """
    size_megabytes: Required[float]
    """File size MB decimal"""
    bandwidth_megabits_per_second: Required[float]
    """Mbps"""


class ElectricOhmsLawArgs(TypedDict):
    """Typed request fields for electric_ohms_law.

    Solve voltage current or resistance from the other two
    """
    volts: NotRequired[float]
    """Voltage, 0 if unknown"""
    amps: NotRequired[float]
    """Current, 0 if unknown"""
    ohms: NotRequired[float]
    """Resistance, 0 if unknown"""
    solve_for: Required[str]
    """One of volts amps ohms"""


class EqualSplitArgs(TypedDict):
    """Typed request fields for equal_split.

    Divide a bill or quantity equally
    """
    total: Required[float]
    """Total amount"""
    people: Required[int]
    """Number of people"""


class ExpectedValueArgs(TypedDict):
    """Typed request fields for expected_value.

    Compute expectation of a discrete probability distribution
    """
    values: Required[list[Any]]
    """Possible outcomes"""
    probabilities: Required[list[Any]]
    """Corresponding probabilities"""


class ExponentialMovingAverageArgs(TypedDict):
    """Typed request fields for exponential_moving_average.

    Compute exponential weighted moving average
    """
    values: Required[list[Any]]
    """Numeric time series"""
    alpha: Required[float]
    """Smoothing constant"""


class ExtractHeadingsArgs(TypedDict):
    """Typed request fields for extract_headings.

    Extract Markdown headings from an outline
    """
    text: Required[str]
    """Markdown text"""


class ExtractPatternsArgs(TypedDict):
    """Typed request fields for extract_patterns.

    Extract explicit date email URL hashtag and time patterns
    """
    text: Required[str]
    """Passage"""


class ExtractUrlsArgs(TypedDict):
    """Typed request fields for extract_urls.

    List HTTP(S) URLs visibly present in plain text
    """
    text: Required[str]
    """Passage"""


class FactorialArgs(TypedDict):
    """Typed request fields for factorial.

    Calculate factorial n! for a bounded nonnegative integer
    """
    n: Required[int]
    """Integer"""


class FactorialProbabilityArgs(TypedDict):
    """Typed request fields for factorial_probability.

    Factorial of a bounded nonnegative integer
    """
    n: Required[int]
    """Value"""


class FibonacciArgs(TypedDict):
    """Typed request fields for fibonacci.

    Generate the first N Fibonacci numbers
    """
    count: Required[int]
    """Number of terms"""


class FileSizeFormatArgs(TypedDict):
    """Typed request fields for file_size_format.

    Format a byte count in binary or decimal units
    """
    bytes: Required[int]
    """Byte count"""
    binary: NotRequired[bool]
    """Use KiB MiB GiB instead of kB MB GB"""


class FiveNumberSummaryArgs(TypedDict):
    """Typed request fields for five_number_summary.

    Find minimum quartiles median and maximum
    """
    values: Required[list[Any]]
    """Numeric samples"""


class FormatJsonArgs(TypedDict):
    """Typed request fields for format_json.

    Pretty-print a bounded JSON value
    """
    value: Required[dict[str, Any]]
    """Object to format"""
    indent: NotRequired[int]
    """Indent spaces"""


class FormatTimeHhmmArgs(TypedDict):
    """Typed request fields for format_time_hhmm.

    Convert minutes since midnight to HH:MM, wrapping each day
    """
    minutes: Required[int]
    """Minutes"""


class FractionOperationsArgs(TypedDict):
    """Typed request fields for fraction_operations.

    Add, subtract, multiply or divide two rational numbers
    """
    left: Required[str]
    """First fraction, e.g. 3/4"""
    right: Required[str]
    """Second fraction, e.g. 1/2"""
    operation: Required[str]
    """Operation"""


class FrequencyTableArgs(TypedDict):
    """Typed request fields for frequency_table.

    Count occurrences of categorical labels
    """
    values: Required[list[Any]]
    """Categories or labels"""


class FuzzyTitlesArgs(TypedDict):
    """Typed request fields for fuzzy_titles.

    Find close candidate titles for a supplied name
    """
    query: Required[str]
    """Title"""
    candidates: Required[list[Any]]
    """List of titles"""
    limit: NotRequired[int]
    """Result count"""


class GcdLcmArgs(TypedDict):
    """Typed request fields for gcd_lcm.

    Compute the greatest common divisor and least common multiple
    """
    values: Required[list[Any]]
    """Integer values"""


class GeometricExactArgs(TypedDict):
    """Typed request fields for geometric_exact.

    Probability first success occurs on a chosen trial
    """
    p: Required[float]
    """Success chance"""
    trial: Required[int]
    """Trial number"""


class GeometricMeanArgs(TypedDict):
    """Typed request fields for geometric_mean.

    Calculate geometric mean for positive values
    """
    values: Required[list[Any]]
    """Positive numbers"""


class GeometricSequenceArgs(TypedDict):
    """Typed request fields for geometric_sequence.

    Produce a bounded geometric progression
    """
    start: Required[float]
    """First term"""
    ratio: Required[float]
    """Common ratio"""
    count: Required[int]
    """Terms"""


class GraphAdjacencyListArgs(TypedDict):
    """Typed request fields for graph_adjacency_list.

    Represent an edge list as a node-neighbor dictionary
    """
    nodes: Required[list[Any]]
    """Nodes"""
    edges: Required[list[Any]]
    """Edges"""
    directed: NotRequired[bool]
    """Directed graph"""


class GraphAdjacencyMatrixArgs(TypedDict):
    """Typed request fields for graph_adjacency_matrix.

    Create a small binary adjacency matrix
    """
    nodes: Required[list[Any]]
    """Nodes"""
    edges: Required[list[Any]]
    """Edges"""
    directed: NotRequired[bool]
    """Directed graph"""


class GraphBipartiteArgs(TypedDict):
    """Typed request fields for graph_bipartite.

    Check whether an undirected graph can be two-colored
    """
    nodes: Required[list[Any]]
    """Nodes"""
    edges: Required[list[Any]]
    """Edges"""


class GraphClosenessArgs(TypedDict):
    """Typed request fields for graph_closeness.

    Estimate closeness centrality using shortest hop counts
    """
    nodes: Required[list[Any]]
    """Nodes"""
    edges: Required[list[Any]]
    """Edges"""


class GraphComponentsArgs(TypedDict):
    """Typed request fields for graph_components.

    Connected components in an undirected graph
    """
    nodes: Required[list[Any]]
    """Nodes"""
    edges: Required[list[Any]]
    """Edges"""


class GraphCriticalPathArgs(TypedDict):
    """Typed request fields for graph_critical_path.

    Calculate a dependency path for tasks with durations
    """
    tasks: Required[list[Any]]
    """Objects with id, duration, dependencies"""


class GraphDegreeArgs(TypedDict):
    """Typed request fields for graph_degree.

    Compute degree statistics of graph nodes
    """
    nodes: Required[list[Any]]
    """Nodes"""
    edges: Required[list[Any]]
    """Edges"""
    directed: NotRequired[bool]
    """Directed graph"""


class GraphDensityArgs(TypedDict):
    """Typed request fields for graph_density.

    Calculate the density of a graph
    """
    nodes: Required[list[Any]]
    """Nodes"""
    edges: Required[list[Any]]
    """Edges"""
    directed: NotRequired[bool]
    """Directed"""


class GraphDependencyLevelsArgs(TypedDict):
    """Typed request fields for graph_dependency_levels.

    Group dependent tasks into parallelizable levels
    """
    nodes: Required[list[Any]]
    """Task names"""
    edges: Required[list[Any]]
    """Prerequisite pairs"""


class GraphEdgesFromMatrixArgs(TypedDict):
    """Typed request fields for graph_edges_from_matrix.

    Convert an adjacency matrix into an edge list
    """
    nodes: Required[list[Any]]
    """Nodes"""
    matrix: Required[list[Any]]
    """Binary matrix"""


class GraphHasCycleArgs(TypedDict):
    """Typed request fields for graph_has_cycle.

    Test directed graph for a dependency cycle
    """
    nodes: Required[list[Any]]
    """Nodes"""
    edges: Required[list[Any]]
    """Edges"""


class GraphReachableArgs(TypedDict):
    """Typed request fields for graph_reachable.

    List nodes reachable from a given node
    """
    nodes: Required[list[Any]]
    """Node labels"""
    edges: Required[list[Any]]
    """Edges"""
    source: Required[str]
    """Start"""
    directed: NotRequired[bool]
    """Directed graph"""


class GraphShortestPathArgs(TypedDict):
    """Typed request fields for graph_shortest_path.

    Shortest unweighted path between two nodes
    """
    nodes: Required[list[Any]]
    """Node labels"""
    edges: Required[list[Any]]
    """Node pairs"""
    source: Required[str]
    """Start node"""
    target: Required[str]
    """End node"""
    directed: NotRequired[bool]
    """Use directed edges"""


class GraphTopologicalOrderArgs(TypedDict):
    """Typed request fields for graph_topological_order.

    Order prerequisites in a directed acyclic graph
    """
    nodes: Required[list[Any]]
    """Nodes"""
    edges: Required[list[Any]]
    """Pairs [prerequisite,dependent]"""


class GraphWeightedShortestPathArgs(TypedDict):
    """Typed request fields for graph_weighted_shortest_path.

    Dijkstra shortest path with positive weights
    """
    nodes: Required[list[Any]]
    """Node labels"""
    edges: Required[list[Any]]
    """Triples [from,to,cost]"""
    source: Required[str]
    """Start"""
    target: Required[str]
    """End"""
    directed: NotRequired[bool]
    """Direction matters"""


class HarmonicMeanArgs(TypedDict):
    """Typed request fields for harmonic_mean.

    Calculate harmonic mean for positive values
    """
    values: Required[list[Any]]
    """Positive numbers"""


class HashSha256Args(TypedDict):
    """Typed request fields for hash_sha256.

    Compute SHA-256 digest for plain text, not passwords
    """
    text: Required[str]
    """Input text"""


class HistogramArgs(TypedDict):
    """Typed request fields for histogram.

    Build a fixed-width histogram for numeric data
    """
    values: Required[list[Any]]
    """Numeric samples"""
    bins: NotRequired[int]
    """Bin count"""


class HtmlEscapeArgs(TypedDict):
    """Typed request fields for html_escape.

    Escape HTML special characters for safe display
    """
    text: Required[str]
    """Text"""


class HypergeometricExactArgs(TypedDict):
    """Typed request fields for hypergeometric_exact.

    Probability of k successes sampled without replacement
    """
    population: Required[int]
    """Total population"""
    positive: Required[int]
    """Positive items in population"""
    draws: Required[int]
    """Number of draws"""
    successes: Required[int]
    """Observed positive draws"""


class HyperspaceDataSizeArgs(TypedDict):
    """Typed request fields for hyperspace_data_size.

    Estimate storage for uncompressed images in bytes
    """
    width: Required[int]
    """Width pixels"""
    height: Required[int]
    """Height pixels"""
    channels: NotRequired[int]
    """Color channels"""
    bits_per_channel: NotRequired[int]
    """Channel bit depth"""


class IndependentAndArgs(TypedDict):
    """Typed request fields for independent_and.

    Probability of independent events both occurring
    """
    p: Required[float]
    """First probability"""
    q: Required[float]
    """Second probability"""


class IndependentOrArgs(TypedDict):
    """Typed request fields for independent_or.

    Probability that either independent event occurs
    """
    p: Required[float]
    """First probability"""
    q: Required[float]
    """Second probability"""


class InitialsArgs(TypedDict):
    """Typed request fields for initials.

    Make initials from a short phrase
    """
    text: Required[str]
    """Name or phrase"""
    limit: NotRequired[int]
    """Maximum initials"""


class IntegerBitCountArgs(TypedDict):
    """Typed request fields for integer_bit_count.

    Count 1 bits in a nonnegative integer
    """
    value: Required[int]
    """Integer"""


class InterquartileRangeArgs(TypedDict):
    """Typed request fields for interquartile_range.

    Calculate IQR and Tukey outlier fences
    """
    values: Required[list[Any]]
    """Numeric samples"""


class IsoWeekArgs(TypedDict):
    """Typed request fields for iso_week.

    Read ISO week, weekday and week-numbering year
    """
    date: Required[str]
    """YYYY-MM-DD"""


class JsonExtractPathArgs(TypedDict):
    """Typed request fields for json_extract_path.

    Read a nested JSON object by a simple dotted path
    """
    value: Required[dict[str, Any]]
    """Source document"""
    path: Required[str]
    """Dot-separated keys"""


class JsonObjectDiffArgs(TypedDict):
    """Typed request fields for json_object_diff.

    Show changed, added and removed top-level keys
    """
    before: Required[dict[str, Any]]
    """Earlier object"""
    after: Required[dict[str, Any]]
    """Later object"""


class LanguageScriptHintArgs(TypedDict):
    """Typed request fields for language_script_hint.

    Detect which common writing script is most visible
    """
    text: Required[str]
    """Passage"""


class LeapYearArgs(TypedDict):
    """Typed request fields for leap_year.

    Check Gregorian leap-year status
    """
    year: Required[int]
    """Year"""


class LineNumbersArgs(TypedDict):
    """Typed request fields for line_numbers.

    Prefix each line with its line number
    """
    text: Required[str]
    """Multiline text"""
    start: NotRequired[int]
    """Starting number"""


class LinearInterpolationArgs(TypedDict):
    """Typed request fields for linear_interpolation.

    Find a point on a line between two measurements
    """
    x0: Required[float]
    """Start X"""
    y0: Required[float]
    """Start Y"""
    x1: Required[float]
    """End X"""
    y1: Required[float]
    """End Y"""
    x: Required[float]
    """Query X"""


class LinearRegressionArgs(TypedDict):
    """Typed request fields for linear_regression.

    Fit least-squares slope and intercept for simple regression
    """
    x: Required[list[Any]]
    """Numeric x series"""
    y: Required[list[Any]]
    """Numeric y series"""


class ListUnitsArgs(TypedDict):
    """Typed request fields for list_units.

    List accepted symbols for each conversion category
    """
    category: NotRequired[str]
    """Category, or blank for all"""


class LiteralFindArgs(TypedDict):
    """Typed request fields for literal_find.

    Find exact substring positions without regular expressions
    """
    text: Required[str]
    """Text"""
    needle: Required[str]
    """Search term"""
    ignore_case: NotRequired[bool]
    """Case insensitive"""


class MakeCsvArgs(TypedDict):
    """Typed request fields for make_csv.

    Convert a JSON table into escaped CSV text
    """
    rows: Required[list[Any]]
    """Rows to encode"""
    delimiter: NotRequired[str]
    """Delimiter"""


class MarkdownTocArgs(TypedDict):
    """Typed request fields for markdown_toc.

    Create a simple Markdown table of contents
    """
    text: Required[str]
    """Markdown document"""


class MaskIdentifierArgs(TypedDict):
    """Typed request fields for mask_identifier.

    Mask characters of a user-supplied non-secret identifier
    """
    text: Required[str]
    """Identifier"""
    keep_last: NotRequired[int]
    """Trailing visible characters"""


class MathDefiniteIntegralArgs(TypedDict):
    """Typed request fields for math_definite_integral.

    Compute a definite integral over a bounded numeric interval
    """
    expression: Required[str]
    """Integrand"""
    lower: Required[float]
    """Lower limit"""
    upper: Required[float]
    """Upper limit"""


class MathDerivativeArgs(TypedDict):
    """Typed request fields for math_derivative.

    Compute a first or higher-order derivative
    """
    expression: Required[str]
    """Function, e.g. (x**2+3)**2"""
    variable: NotRequired[str]
    """Differentiate with respect to"""
    order: NotRequired[int]
    """Derivative order"""


class MathEvaluateArgs(TypedDict):
    """Typed request fields for math_evaluate.

    Substitute one numeric variable and evaluate expression
    """
    expression: Required[str]
    """Expression"""
    variable: NotRequired[str]
    """Variable"""
    value: Required[float]
    """Substitution value"""


class MathExpandArgs(TypedDict):
    """Typed request fields for math_expand.

    Expand products and integer powers
    """
    expression: Required[str]
    """Algebraic expression"""


class MathFactorArgs(TypedDict):
    """Typed request fields for math_factor.

    Factor a bounded polynomial expression
    """
    expression: Required[str]
    """Polynomial to factor"""


class MathGradientArgs(TypedDict):
    """Typed request fields for math_gradient.

    Calculate gradient of a scalar function in up to three variables
    """
    expression: Required[str]
    """Expression in x, y, z"""
    variables: NotRequired[list[Any]]
    """Variable names in order"""


class MathHessianArgs(TypedDict):
    """Typed request fields for math_hessian.

    Compute the Hessian matrix of a scalar function
    """
    expression: Required[str]
    """Expression"""
    variables: NotRequired[list[Any]]
    """Variables"""


class MathIndefiniteIntegralArgs(TypedDict):
    """Typed request fields for math_indefinite_integral.

    Compute a simple symbolic indefinite integral
    """
    expression: Required[str]
    """Integrand"""
    variable: NotRequired[str]
    """Integrating variable"""


class MathLimitArgs(TypedDict):
    """Typed request fields for math_limit.

    Calculate a univariate one-sided or two-sided limit
    """
    expression: Required[str]
    """Expression"""
    point: Required[float]
    """Value x approaches"""
    direction: NotRequired[str]
    """Approach direction"""


class MathNumericDerivativeArgs(TypedDict):
    """Typed request fields for math_numeric_derivative.

    Estimate derivative using centered finite differences
    """
    expression: Required[str]
    """Function of x"""
    at: Required[float]
    """Point"""
    step: NotRequired[float]
    """Finite difference step"""


class MathPartialDerivativeArgs(TypedDict):
    """Typed request fields for math_partial_derivative.

    Compute a multivariable partial derivative
    """
    expression: Required[str]
    """Expression in x, y or z"""
    variable: Required[str]
    """Partial derivative variable"""


class MathPolynomialCoefficientsArgs(TypedDict):
    """Typed request fields for math_polynomial_coefficients.

    Extract polynomial coefficients from highest to lowest degree
    """
    expression: Required[str]
    """Polynomial"""
    variable: NotRequired[str]
    """Variable"""


class MathSimplifyArgs(TypedDict):
    """Typed request fields for math_simplify.

    Simplify an algebraic expression using optional SymPy
    """
    expression: Required[str]
    """Expression using x, sin(x), x**2, etc."""


class MathSolvePolynomialArgs(TypedDict):
    """Typed request fields for math_solve_polynomial.

    Solve a univariate polynomial equation expression = 0
    """
    expression: Required[str]
    """Polynomial expression"""
    variable: NotRequired[str]
    """Unknown variable"""


class MathSubstituteArgs(TypedDict):
    """Typed request fields for math_substitute.

    Replace one symbol with a number
    """
    expression: Required[str]
    """Expression"""
    variable: Required[str]
    """Symbol"""
    value: Required[float]
    """Numeric replacement"""


class MathTaylorSeriesArgs(TypedDict):
    """Typed request fields for math_taylor_series.

    Compute a truncated Taylor series at zero or another point
    """
    expression: Required[str]
    """Expression"""
    point: NotRequired[float]
    """Expansion point"""
    order: NotRequired[int]
    """Terms through order n-1"""


class MeanAbsoluteDeviationArgs(TypedDict):
    """Typed request fields for mean_absolute_deviation.

    Compute average absolute deviation around the mean
    """
    values: Required[list[Any]]
    """Numeric samples"""


class MeanMedianModeArgs(TypedDict):
    """Typed request fields for mean_median_mode.

    Calculate mean median and modes
    """
    values: Required[list[Any]]
    """Numeric samples"""


class MedianAbsoluteDeviationArgs(TypedDict):
    """Typed request fields for median_absolute_deviation.

    Compute median absolute deviation from sample median
    """
    values: Required[list[Any]]
    """Numeric samples"""


class MinutesToDurationArgs(TypedDict):
    """Typed request fields for minutes_to_duration.

    Display total minutes as days, hours and minutes
    """
    minutes: Required[int]
    """Total signed minutes"""


class MovingAverageArgs(TypedDict):
    """Typed request fields for moving_average.

    Compute sliding simple moving averages
    """
    values: Required[list[Any]]
    """Numeric time series"""
    window: Required[int]
    """Number of samples per window"""


class NormalCdfArgs(TypedDict):
    """Typed request fields for normal_cdf.

    Cumulative normal probability for a z-score
    """
    z: Required[float]
    """Z score"""


class NormalIntervalArgs(TypedDict):
    """Typed request fields for normal_interval.

    Probability between two z-scores
    """
    low: Required[float]
    """Lower z score"""
    high: Required[float]
    """Upper z score"""


class NormalZscoreArgs(TypedDict):
    """Typed request fields for normal_zscore.

    Convert a measurement to standard deviation units
    """
    value: Required[float]
    """Observation"""
    mean: Required[float]
    """Population mean"""
    stddev: Required[float]
    """Population standard deviation"""


class NormalizeMinmaxArgs(TypedDict):
    """Typed request fields for normalize_minmax.

    Map a numeric series to a selected range
    """
    values: Required[list[Any]]
    """Numeric samples"""
    lower: NotRequired[float]
    """Target lower bound"""
    upper: NotRequired[float]
    """Target upper bound"""


class NormalizeTextArgs(TypedDict):
    """Typed request fields for normalize_text.

    Standardize Unicode whitespace and optionally case
    """
    text: Required[str]
    """Text"""
    casefold: NotRequired[bool]
    """Convert to casefolded lowercase"""


class NthWeekdayArgs(TypedDict):
    """Typed request fields for nth_weekday.

    Find the Nth specified weekday in a calendar month
    """
    year: Required[int]
    """Year"""
    month: Required[int]
    """Month"""
    weekday: Required[int]
    """Monday=0 through Sunday=6"""
    occurrence: Required[int]
    """Nth occurrence, 1–5"""


class NumberToBaseArgs(TypedDict):
    """Typed request fields for number_to_base.

    Convert an integer to binary, octal or hexadecimal
    """
    value: Required[int]
    """Integer"""
    base: Required[int]
    """Base"""


class OddsToProbabilityArgs(TypedDict):
    """Typed request fields for odds_to_probability.

    Convert positive odds ratio to probability
    """
    odds: Required[float]
    """Odds for vs against"""


class OverlapTimeRangesArgs(TypedDict):
    """Typed request fields for overlap_time_ranges.

    Find intersection of two timezone-aware intervals
    """
    first_start: Required[str]
    """Timestamp"""
    first_end: Required[str]
    """Timestamp"""
    second_start: Required[str]
    """Timestamp"""
    second_end: Required[str]
    """Timestamp"""


class PaceFromTimeArgs(TypedDict):
    """Typed request fields for pace_from_time.

    Calculate minutes per km from minutes and distance
    """
    minutes: Required[float]
    """Elapsed minutes"""
    kilometers: Required[float]
    """Distance in km"""


class PalindromeCheckArgs(TypedDict):
    """Typed request fields for palindrome_check.

    Check if alphanumeric characters read identically backwards
    """
    text: Required[str]
    """Phrase"""


class ParagraphSplitArgs(TypedDict):
    """Typed request fields for paragraph_split.

    Split text on empty lines
    """
    text: Required[str]
    """Multiline text"""


class ParseCsvArgs(TypedDict):
    """Typed request fields for parse_csv.

    Parse simple comma-separated data into row objects
    """
    text: Required[str]
    """CSV content"""
    delimiter: NotRequired[str]
    """Field delimiter"""


class ParseJsonArgs(TypedDict):
    """Typed request fields for parse_json.

    Validate and decode a JSON text value
    """
    text: Required[str]
    """JSON document"""


class ParseQuerystringArgs(TypedDict):
    """Typed request fields for parse_querystring.

    Extract query-string parameters without issuing HTTP requests
    """
    text: Required[str]
    """URL query string"""


class ParseTimeHhmmArgs(TypedDict):
    """Typed request fields for parse_time_hhmm.

    Parse 24-hour clock time to elapsed minutes
    """
    time: Required[str]
    """HH:MM"""


class PearsonCorrelationArgs(TypedDict):
    """Typed request fields for pearson_correlation.

    Compute Pearson linear correlation for paired data
    """
    first: Required[list[Any]]
    """First numeric series"""
    second: Required[list[Any]]
    """Second numeric series"""


class PercentChangeArgs(TypedDict):
    """Typed request fields for percent_change.

    Calculate the relative percentage change
    """
    before: Required[float]
    """Original value"""
    after: Required[float]
    """Updated value"""


class PercentOfArgs(TypedDict):
    """Typed request fields for percent_of.

    Calculate a percentage of any positive or negative number
    """
    part: Required[float]
    """The percentage"""
    whole: Required[float]
    """The amount"""


class PercentOfTotalArgs(TypedDict):
    """Typed request fields for percent_of_total.

    Calculate percent share for each nonnegative contribution
    """
    values: Required[list[Any]]
    """Nonnegative numeric values"""


class PercentageDifferenceArgs(TypedDict):
    """Typed request fields for percentage_difference.

    Compare two measurements symmetrically
    """
    first: Required[float]
    """First amount"""
    second: Required[float]
    """Second amount"""


class PercentileRankArgs(TypedDict):
    """Typed request fields for percentile_rank.

    Percent of observations less than or equal to a given value
    """
    values: Required[list[Any]]
    """Numeric samples"""
    value: Required[float]
    """Value to compare"""


class PermutationsArgs(TypedDict):
    """Typed request fields for permutations.

    Ordered arrangements of k selected items
    """
    n: Required[int]
    """Total items"""
    k: Required[int]
    """Selected items"""


class PixelDensityArgs(TypedDict):
    """Typed request fields for pixel_density.

    Compute approximate pixels per inch for a display
    """
    width_px: Required[int]
    """Horizontal pixels"""
    height_px: Required[int]
    """Vertical pixels"""
    diagonal_inches: Required[float]
    """Diagonal screen size"""


class PoissonExactArgs(TypedDict):
    """Typed request fields for poisson_exact.

    Poisson probability of exactly k events
    """
    rate: Required[float]
    """Expected number of events"""
    count: Required[int]
    """Number of observed events"""


class PopulationRangeArgs(TypedDict):
    """Typed request fields for population_range.

    Get count min max span and mean from numeric data
    """
    values: Required[list[Any]]
    """Numeric samples"""


class PowerEnergyArgs(TypedDict):
    """Typed request fields for power_energy.

    Calculate energy from constant power and elapsed time
    """
    watts: Required[float]
    """Power in W"""
    hours: Required[float]
    """Duration in hours"""


class PrimeCheckArgs(TypedDict):
    """Typed request fields for prime_check.

    Check whether an integer is prime using trial division
    """
    value: Required[int]
    """Integer to check"""


class PrimeFactorsArgs(TypedDict):
    """Typed request fields for prime_factors.

    Find prime factors of a moderate integer
    """
    value: Required[int]
    """Positive integer"""


class ProbabilityNotArgs(TypedDict):
    """Typed request fields for probability_not.

    Compute the complement of an event probability
    """
    p: Required[float]
    """Event probability"""


class ProbabilityToOddsArgs(TypedDict):
    """Typed request fields for probability_to_odds.

    Convert event probability into odds for vs against
    """
    probability: Required[float]
    """Probability"""


class ProportionArgs(TypedDict):
    """Typed request fields for proportion.

    Solve a proportion a/b=c/d for missing d
    """
    a: Required[float]
    """Known numerator"""
    b: Required[float]
    """Known denominator"""
    c: Required[float]
    """Known second numerator"""


class PythagoreanArgs(TypedDict):
    """Typed request fields for pythagorean.

    Solve a right triangle hypotenuse from two sides
    """
    a: Required[float]
    """First leg"""
    b: Required[float]
    """Second leg"""


class PythonAssignmentNamesArgs(TypedDict):
    """Typed request fields for python_assignment_names.

    List variables assigned in Python source
    """
    source: Required[str]
    """Source"""


class PythonAstCountsArgs(TypedDict):
    """Typed request fields for python_ast_counts.

    Count syntax node types in a Python file
    """
    source: Required[str]
    """Source"""


class PythonBroadExceptionCandidatesArgs(TypedDict):
    """Typed request fields for python_broad_exception_candidates.

    Find bare excepts and broad exception handlers
    """
    source: Required[str]
    """Source"""


class PythonCallNamesArgs(TypedDict):
    """Typed request fields for python_call_names.

    List function call names statically from Python source
    """
    source: Required[str]
    """Source"""


class PythonClassesArgs(TypedDict):
    """Typed request fields for python_classes.

    Extract classes, bases, methods, and source line numbers
    """
    source: Required[str]
    """Source text"""


class PythonComplexityArgs(TypedDict):
    """Typed request fields for python_complexity.

    Estimate branch-based cyclomatic complexity of Python functions
    """
    source: Required[str]
    """Source"""


class PythonConstantValuesArgs(TypedDict):
    """Typed request fields for python_constant_values.

    List simple module-level constant assignments
    """
    source: Required[str]
    """Source"""


class PythonDefinitionOutlineArgs(TypedDict):
    """Typed request fields for python_definition_outline.

    Produce a class/function declaration outline
    """
    source: Required[str]
    """Source"""


class PythonDocstringsArgs(TypedDict):
    """Typed request fields for python_docstrings.

    Collect module, class and function docstrings
    """
    source: Required[str]
    """Source"""


class PythonFormatImportSuggestionsArgs(TypedDict):
    """Typed request fields for python_format_import_suggestions.

    Suggest grouping import modules by name
    """
    source: Required[str]
    """Source"""


class PythonFunctionsArgs(TypedDict):
    """Typed request fields for python_functions.

    List functions, arguments, line ranges and async markers
    """
    source: Required[str]
    """Source text"""


class PythonImportsArgs(TypedDict):
    """Typed request fields for python_imports.

    Extract literal import statements without importing packages
    """
    source: Required[str]
    """Source"""


class PythonKeywordCheckArgs(TypedDict):
    """Typed request fields for python_keyword_check.

    Check Python keyword and identifier rules
    """
    name: Required[str]
    """Candidate variable or function name"""


class PythonMutableDefaultCandidatesArgs(TypedDict):
    """Typed request fields for python_mutable_default_candidates.

    Find literal list/dict/set defaults in function definitions
    """
    source: Required[str]
    """Source"""


class PythonSyntaxCheckArgs(TypedDict):
    """Typed request fields for python_syntax_check.

    Parse Python source and report syntax errors without running code
    """
    source: Required[str]
    """Source text"""


class PythonTodoCommentsArgs(TypedDict):
    """Typed request fields for python_todo_comments.

    Locate TODO and FIXME comments
    """
    source: Required[str]
    """Source text"""


class PythonUnusedImportCandidatesArgs(TypedDict):
    """Typed request fields for python_unused_import_candidates.

    Find imports whose names are not referenced elsewhere in the AST
    """
    source: Required[str]
    """Source"""


class QuadraticRootsArgs(TypedDict):
    """Typed request fields for quadratic_roots.

    Solve a real quadratic equation ax²+bx+c=0
    """
    a: Required[float]
    """Coefficient a"""
    b: Required[float]
    """Coefficient b"""
    c: Required[float]
    """Coefficient c"""


class QuantileArgs(TypedDict):
    """Typed request fields for quantile.

    Find a linearly interpolated quantile
    """
    values: Required[list[Any]]
    """Numeric samples"""
    quantile: Required[float]
    """Fraction between 0 and 1"""


class RatioSimplifyArgs(TypedDict):
    """Typed request fields for ratio_simplify.

    Reduce an integer ratio using the greatest common divisor
    """
    a: Required[int]
    """First integer"""
    b: Required[int]
    """Second integer"""


class RegressionPredictArgs(TypedDict):
    """Typed request fields for regression_predict.

    Predict y using fitted line from paired training data
    """
    x: Required[list[Any]]
    """Training x series"""
    y: Required[list[Any]]
    """Training y series"""
    predict_x: Required[float]
    """New x"""


class RemoveEmptyLinesArgs(TypedDict):
    """Typed request fields for remove_empty_lines.

    Filter blank lines from a passage
    """
    text: Required[str]
    """Multiline text"""


class ReplaceLiteralArgs(TypedDict):
    """Typed request fields for replace_literal.

    Replace literal text with another substring
    """
    text: Required[str]
    """Input"""
    old: Required[str]
    """Exact old text"""
    new: Required[str]
    """Replacement"""
    limit: NotRequired[int]
    """Maximum replacements"""


class RescaleImageArgs(TypedDict):
    """Typed request fields for rescale_image.

    Rescale an image to fit within given bounds, preserving aspect ratio
    """
    width: Required[int]
    """Original width"""
    height: Required[int]
    """Original height"""
    max_width: Required[int]
    """Target width"""
    max_height: Required[int]
    """Target height"""
    upscale: NotRequired[bool]
    """Allow enlarging the original"""


class RootMeanSquareArgs(TypedDict):
    """Typed request fields for root_mean_square.

    Calculate root-mean-square of numeric values
    """
    values: Required[list[Any]]
    """Numbers"""


class RoundSignificantArgs(TypedDict):
    """Typed request fields for round_significant.

    Round a finite number to N significant digits
    """
    value: Required[float]
    """Number"""
    digits: Required[int]
    """Significant digits"""


class SampleMeanStandardErrorArgs(TypedDict):
    """Typed request fields for sample_mean_standard_error.

    Estimate standard error for a sample average
    """
    stddev: Required[float]
    """Sample standard deviation"""
    sample_size: Required[int]
    """Number of observations"""


class SampleProportionIntervalArgs(TypedDict):
    """Typed request fields for sample_proportion_interval.

    Wilson interval for a sample percentage
    """
    successes: Required[int]
    """Number of successes"""
    trials: Required[int]
    """Total trials"""
    z: NotRequired[float]
    """Critical z value"""


class SentenceSplitArgs(TypedDict):
    """Typed request fields for sentence_split.

    Split a passage into sentences with their order preserved
    """
    text: Required[str]
    """Passage"""


class SeriesAnomalyIqrArgs(TypedDict):
    """Typed request fields for series_anomaly_iqr.

    Flag values outside the interquartile fence
    """
    values: Required[list[Any]]
    """Observed values"""
    multiplier: NotRequired[float]
    """IQR multiplier"""


class SeriesAnomalyZscoreArgs(TypedDict):
    """Typed request fields for series_anomaly_zscore.

    Flag values exceeding a standard z-score threshold
    """
    values: Required[list[Any]]
    """Observed values"""
    threshold: NotRequired[float]
    """Absolute z threshold"""


class SeriesAutocorrelationArgs(TypedDict):
    """Typed request fields for series_autocorrelation.

    Lagged autocorrelation of a time series
    """
    values: Required[list[Any]]
    """Observations"""
    lag: Required[int]
    """Positive lag"""


class SeriesCenteredSmoothingArgs(TypedDict):
    """Typed request fields for series_centered_smoothing.

    Centered mean smoothing for an odd-width window
    """
    values: Required[list[Any]]
    """Values"""
    window: NotRequired[int]
    """Odd window"""


class SeriesCrossCorrelationArgs(TypedDict):
    """Typed request fields for series_cross_correlation.

    Pearson correlation of two aligned series
    """
    first: Required[list[Any]]
    """First series"""
    second: Required[list[Any]]
    """Second series"""


class SeriesCumulativeProductArgs(TypedDict):
    """Typed request fields for series_cumulative_product.

    Running product across observations
    """
    values: Required[list[Any]]
    """Numbers"""


class SeriesCumulativeSumArgs(TypedDict):
    """Typed request fields for series_cumulative_sum.

    Running total across observations
    """
    values: Required[list[Any]]
    """Numbers"""


class SeriesDetrendArgs(TypedDict):
    """Typed request fields for series_detrend.

    Subtract the least-squares linear trend from a series
    """
    values: Required[list[Any]]
    """Observed series"""


class SeriesDifferencesArgs(TypedDict):
    """Typed request fields for series_differences.

    Compute successive first differences
    """
    values: Required[list[Any]]
    """Time-ordered numbers"""


class SeriesDrawdownArgs(TypedDict):
    """Typed request fields for series_drawdown.

    Compute drop relative to running maximum, in percent
    """
    values: Required[list[Any]]
    """Positive observed values"""


class SeriesExponentialAverageArgs(TypedDict):
    """Typed request fields for series_exponential_average.

    Exponentially weighted moving average (EMA)
    """
    values: Required[list[Any]]
    """Observations"""
    span: Required[int]
    """Smoothing span"""


class SeriesForecastAverageArgs(TypedDict):
    """Typed request fields for series_forecast_average.

    Constant-mean baseline forecast
    """
    values: Required[list[Any]]
    """Historical data"""
    steps: NotRequired[int]
    """Steps ahead"""


class SeriesForecastLastArgs(TypedDict):
    """Typed request fields for series_forecast_last.

    Last-observation-carried-forward baseline forecast
    """
    values: Required[list[Any]]
    """Historical data"""
    steps: NotRequired[int]
    """Future steps"""


class SeriesForecastLinearArgs(TypedDict):
    """Typed request fields for series_forecast_linear.

    Extrapolate a fitted linear trend with explicit caveat
    """
    values: Required[list[Any]]
    """Historical values"""
    steps: NotRequired[int]
    """Number of forecast steps"""


class SeriesLagTableArgs(TypedDict):
    """Typed request fields for series_lag_table.

    Autocorrelation values for a range of lags
    """
    values: Required[list[Any]]
    """Observations"""
    max_lag: NotRequired[int]
    """Maximum lag"""


class SeriesLargestChangesArgs(TypedDict):
    """Typed request fields for series_largest_changes.

    List the largest absolute changes between neighboring values
    """
    values: Required[list[Any]]
    """Values"""
    limit: NotRequired[int]
    """Maximum changes"""


class SeriesLinearTrendArgs(TypedDict):
    """Typed request fields for series_linear_trend.

    Fit a least-squares time trend across equal intervals
    """
    values: Required[list[Any]]
    """Observed series"""


class SeriesMomentumArgs(TypedDict):
    """Typed request fields for series_momentum.

    Subtract observation from k steps earlier
    """
    values: Required[list[Any]]
    """Series"""
    period: Required[int]
    """Number of periods back"""


class SeriesMovingAverageArgs(TypedDict):
    """Typed request fields for series_moving_average.

    Trailing simple moving average over a fixed window
    """
    values: Required[list[Any]]
    """Observations"""
    window: Required[int]
    """Window length"""


class SeriesNormalizeMinmaxArgs(TypedDict):
    """Typed request fields for series_normalize_minmax.

    Scale finite observations to a 0..1 range
    """
    values: Required[list[Any]]
    """Observations"""


class SeriesPeakTroughArgs(TypedDict):
    """Typed request fields for series_peak_trough.

    Return indices and values of min and max observations
    """
    values: Required[list[Any]]
    """Observations"""


class SeriesPercentChangeArgs(TypedDict):
    """Typed request fields for series_percent_change.

    Percentage growth from each observation to the next
    """
    values: Required[list[Any]]
    """Time-ordered numbers"""


class SeriesRebaseArgs(TypedDict):
    """Typed request fields for series_rebase.

    Rebase a series to an index value of 100
    """
    values: Required[list[Any]]
    """Observations"""


class SeriesResampleChunksArgs(TypedDict):
    """Typed request fields for series_resample_chunks.

    Aggregate adjacent values into non-overlapping chunks
    """
    values: Required[list[Any]]
    """Series"""
    size: Required[int]
    """Observations per chunk"""
    method: NotRequired[bool]
    """Use sum instead of mean"""


class SeriesRollingMaximumArgs(TypedDict):
    """Typed request fields for series_rolling_maximum.

    Maximum over each trailing observation window
    """
    values: Required[list[Any]]
    """Observations"""
    window: Required[int]
    """Window size"""


class SeriesRollingMinimumArgs(TypedDict):
    """Typed request fields for series_rolling_minimum.

    Minimum over each trailing observation window
    """
    values: Required[list[Any]]
    """Observations"""
    window: Required[int]
    """Window size"""


class SeriesRollingStddevArgs(TypedDict):
    """Typed request fields for series_rolling_stddev.

    Sample standard deviation in each rolling window
    """
    values: Required[list[Any]]
    """Observations"""
    window: Required[int]
    """Window size"""


class SeriesRunLengthsArgs(TypedDict):
    """Typed request fields for series_run_lengths.

    Compute consecutive runs of equal categorical values
    """
    values: Required[list[Any]]
    """Categorical sequence"""


class SeriesStandardizeArgs(TypedDict):
    """Typed request fields for series_standardize.

    Transform observations into z-score units
    """
    values: Required[list[Any]]
    """Observations"""


class SeriesZeroCrossingsArgs(TypedDict):
    """Typed request fields for series_zero_crossings.

    Count crossings between negative and positive values
    """
    values: Required[list[Any]]
    """Values"""


class ShannonEntropyArgs(TypedDict):
    """Typed request fields for shannon_entropy.

    Compute Shannon information entropy in bits
    """
    probabilities: Required[list[Any]]
    """Probabilities"""


class SimpleInterestArgs(TypedDict):
    """Typed request fields for simple_interest.

    Calculate non-compound interest, not investment advice
    """
    principal: Required[float]
    """Initial principal"""
    annual_percent: Required[float]
    """Annual interest percentage"""
    years: Required[float]
    """Number of years"""


class SimulateDiscreteArgs(TypedDict):
    """Typed request fields for simulate_discrete.

    Reproducible weighted random sampling for education
    """
    values: Required[list[Any]]
    """Possible outcomes"""
    weights: Required[list[Any]]
    """Nonnegative weights"""
    count: NotRequired[int]
    """Number of draws"""
    seed: NotRequired[int]
    """Random seed"""


class SlugifyArgs(TypedDict):
    """Typed request fields for slugify.

    Create a URL-friendly ASCII slug from a title
    """
    text: Required[str]
    """Title or phrase"""


class SortLinesArgs(TypedDict):
    """Typed request fields for sort_lines.

    Sort a list of lines alphabetically
    """
    text: Required[str]
    """Multiline text"""
    reverse: NotRequired[bool]
    """Descending order"""
    casefold: NotRequired[bool]
    """Case insensitive"""


class SourceBracketBalanceArgs(TypedDict):
    """Typed request fields for source_bracket_balance.

    Check raw bracket balances for plain text, not a parser
    """
    source: Required[str]
    """Text"""


class SourceDiffArgs(TypedDict):
    """Typed request fields for source_diff.

    Generate a bounded unified diff for two text versions
    """
    before: Required[str]
    """Earlier text"""
    after: Required[str]
    """New text"""
    context: NotRequired[int]
    """Context lines"""


class SourceExtractUrlsArgs(TypedDict):
    """Typed request fields for source_extract_urls.

    Find links appearing in an arbitrary text input
    """
    source: Required[str]
    """Text to inspect"""


class SourceFindRepeatedLinesArgs(TypedDict):
    """Typed request fields for source_find_repeated_lines.

    Count repeated nonempty lines of pasted source
    """
    source: Required[str]
    """Source"""
    minimum: NotRequired[int]
    """Minimum repetitions"""


class SourceIndentProfileArgs(TypedDict):
    """Typed request fields for source_indent_profile.

    Summarize indentation widths in source text
    """
    source: Required[str]
    """Source text"""


class SourceLinesArgs(TypedDict):
    """Typed request fields for source_lines.

    Count blank and nonblank source lines
    """
    source: Required[str]
    """Source"""


class SourceTrailingSpaceLinesArgs(TypedDict):
    """Typed request fields for source_trailing_space_lines.

    Report source lines with trailing whitespace
    """
    source: Required[str]
    """Source text"""


class SpearmanCorrelationArgs(TypedDict):
    """Typed request fields for spearman_correlation.

    Compute Spearman rank correlation with tie averaging
    """
    first: Required[list[Any]]
    """First numeric series"""
    second: Required[list[Any]]
    """Second numeric series"""


class SpeedFromDistanceArgs(TypedDict):
    """Typed request fields for speed_from_distance.

    Calculate average speed from time and distance
    """
    kilometers: Required[float]
    """Distance in km"""
    hours: Required[float]
    """Elapsed hours"""


class SphereVolumeArgs(TypedDict):
    """Typed request fields for sphere_volume.

    Compute sphere volume and surface area
    """
    radius: Required[float]
    """Sphere radius"""


class StandardErrorArgs(TypedDict):
    """Typed request fields for standard_error.

    Compute standard error of sample mean
    """
    values: Required[list[Any]]
    """Numeric samples"""


class StartEndOfMonthArgs(TypedDict):
    """Typed request fields for start_end_of_month.

    Get first and last day of a month
    """
    date: Required[str]
    """A date within the month"""


class TableAddConstantArgs(TypedDict):
    """Typed request fields for table_add_constant.

    Add a fixed text field to every record
    """
    rows: Required[list[Any]]
    """Rows"""
    column: Required[str]
    """New field name"""
    value: Required[str]
    """Assigned value"""


class TableColumnAverageArgs(TypedDict):
    """Typed request fields for table_column_average.

    Average a numeric column, ignoring empty values
    """
    rows: Required[list[Any]]
    """Rows"""
    column: Required[str]
    """Field"""


class TableColumnStatisticsArgs(TypedDict):
    """Typed request fields for table_column_statistics.

    Numeric count, sum, mean, median and range
    """
    rows: Required[list[Any]]
    """Rows"""
    column: Required[str]
    """Field"""


class TableColumnSumArgs(TypedDict):
    """Typed request fields for table_column_sum.

    Add a numeric column, ignoring empty values
    """
    rows: Required[list[Any]]
    """Rows"""
    column: Required[str]
    """Field"""


class TableColumnsArgs(TypedDict):
    """Typed request fields for table_columns.

    List all columns present in a JSON table
    """
    rows: Required[list[Any]]
    """Table of row objects"""


class TableCrossTabArgs(TypedDict):
    """Typed request fields for table_cross_tab.

    Produce frequency counts for combinations of columns
    """
    rows: Required[list[Any]]
    """Rows"""
    columns: Required[list[Any]]
    """Fields to group"""


class TableDateBucketArgs(TypedDict):
    """Typed request fields for table_date_bucket.

    Group ISO date strings by month
    """
    rows: Required[list[Any]]
    """Rows"""
    date_column: Required[str]
    """ISO date field"""


class TableDistinctArgs(TypedDict):
    """Typed request fields for table_distinct.

    Remove duplicate complete JSON rows
    """
    rows: Required[list[Any]]
    """Rows"""


class TableDropEmptyArgs(TypedDict):
    """Typed request fields for table_drop_empty.

    Remove rows whose specified fields are all empty
    """
    rows: Required[list[Any]]
    """Rows"""
    columns: Required[list[Any]]
    """Field names"""


class TableFillMissingArgs(TypedDict):
    """Typed request fields for table_fill_missing.

    Replace absent or null fields with a chosen value
    """
    rows: Required[list[Any]]
    """Rows"""
    column: Required[str]
    """Field"""
    value: Required[str]
    """Replacement text"""


class TableFilterEqualArgs(TypedDict):
    """Typed request fields for table_filter_equal.

    Filter rows by exact value for a named column
    """
    rows: Required[list[Any]]
    """Rows"""
    column: Required[str]
    """Field name"""
    value: Required[str]
    """Desired text value"""
    case_sensitive: NotRequired[bool]
    """Exact case match"""


class TableFilterNumericArgs(TypedDict):
    """Typed request fields for table_filter_numeric.

    Filter rows based on a number comparison
    """
    rows: Required[list[Any]]
    """Rows"""
    column: Required[str]
    """Field name"""
    comparison: Required[str]
    """Comparison"""
    value: Required[float]
    """Numeric threshold"""


class TableGroupCountArgs(TypedDict):
    """Typed request fields for table_group_count.

    Count records grouped by a categorical field
    """
    rows: Required[list[Any]]
    """Rows"""
    column: Required[str]
    """Category field"""


class TableGroupSumArgs(TypedDict):
    """Typed request fields for table_group_sum.

    Sum a numeric column grouped by a category
    """
    rows: Required[list[Any]]
    """Rows"""
    group_by: Required[str]
    """Category field"""
    value_column: Required[str]
    """Numeric field"""


class TableJoinArgs(TypedDict):
    """Typed request fields for table_join.

    Join two small tables on an exact string key
    """
    left: Required[list[Any]]
    """Left table"""
    right: Required[list[Any]]
    """Right table"""
    key: Required[str]
    """Common join field"""


class TablePivotCountsArgs(TypedDict):
    """Typed request fields for table_pivot_counts.

    Count combinations of two categorical fields
    """
    rows: Required[list[Any]]
    """Rows"""
    row_field: Required[str]
    """Rows"""
    column_field: Required[str]
    """Columns"""


class TableRenameColumnArgs(TypedDict):
    """Typed request fields for table_rename_column.

    Rename one field in every row without changing values
    """
    rows: Required[list[Any]]
    """Rows"""
    before: Required[str]
    """Old name"""
    after: Required[str]
    """New name"""


class TableSelectArgs(TypedDict):
    """Typed request fields for table_select.

    Select and reorder table columns
    """
    rows: Required[list[Any]]
    """Rows"""
    columns: Required[list[Any]]
    """Desired field names"""


class TableSortArgs(TypedDict):
    """Typed request fields for table_sort.

    Sort a table on a column, sorting missing values last
    """
    rows: Required[list[Any]]
    """Rows"""
    column: Required[str]
    """Sort column"""
    descending: NotRequired[bool]
    """Reverse sort order"""


class TableTakeArgs(TypedDict):
    """Typed request fields for table_take.

    Take a bounded slice of rows
    """
    rows: Required[list[Any]]
    """Rows"""
    start: NotRequired[int]
    """Start index"""
    count: NotRequired[int]
    """Maximum returned rows"""


class TableTransposeArgs(TypedDict):
    """Typed request fields for table_transpose.

    Transpose a small matrix of lists
    """
    matrix: Required[list[Any]]
    """Rectangular matrix"""


class TableUniqueArgs(TypedDict):
    """Typed request fields for table_unique.

    Find unique values in one table column
    """
    rows: Required[list[Any]]
    """Rows"""
    column: Required[str]
    """Field"""


class TableValueCountsArgs(TypedDict):
    """Typed request fields for table_value_counts.

    Count occurrences of each value in a column
    """
    rows: Required[list[Any]]
    """Rows"""
    column: Required[str]
    """Field"""
    limit: NotRequired[int]
    """Results limit"""


class TaxAdditionArgs(TypedDict):
    """Typed request fields for tax_addition.

    Add a percentage-based tax as a mathematical operation
    """
    subtotal: Required[float]
    """Subtotal"""
    tax_percent: Required[float]
    """Tax rate"""


class TextDiffArgs(TypedDict):
    """Typed request fields for text_diff.

    Create a unified line-by-line difference between text versions
    """
    before: Required[str]
    """Original"""
    after: Required[str]
    """Updated"""


class TextSimilarityArgs(TypedDict):
    """Typed request fields for text_similarity.

    Compare two passages using lexical similarity and shared keywords
    """
    first: Required[str]
    """First passage"""
    second: Required[str]
    """Second passage"""


class TextStatsArgs(TypedDict):
    """Typed request fields for text_stats.

    Profile word count sentences and document traits
    """
    text: Required[str]
    """Text to analyze"""


class TextSummaryArgs(TypedDict):
    """Typed request fields for text_summary.

    Select source sentences as a short extractive summary
    """
    text: Required[str]
    """Passage"""
    sentences_count: NotRequired[int]
    """Number of sentences"""


class TextWrapArgs(TypedDict):
    """Typed request fields for text_wrap.

    Wrap plain text to a specified column width
    """
    text: Required[str]
    """Plain text"""
    width: NotRequired[int]
    """Columns"""
    preserve_whitespace: NotRequired[bool]
    """Preserve whitespace"""


class TimeBlockCountArgs(TypedDict):
    """Typed request fields for time_block_count.

    Count complete focus blocks fitting into available minutes
    """
    available_minutes: Required[int]
    """Available time"""
    work_minutes: Required[int]
    """Work block length"""
    break_minutes: NotRequired[int]
    """Rest block length"""


class TimeSlotScheduleArgs(TypedDict):
    """Typed request fields for time_slot_schedule.

    Make fixed-duration study or work slots
    """
    start: Required[str]
    """ISO timestamp with timezone"""
    number: Required[int]
    """Slots"""
    slot_minutes: Required[int]
    """Time per slot"""
    break_minutes: NotRequired[int]
    """Break after each slot"""


class TimezoneConvertArgs(TypedDict):
    """Typed request fields for timezone_convert.

    Convert an explicit timestamp between IANA timezones
    """
    timestamp: Required[str]
    """ISO datetime with UTC offset"""
    destination: Required[str]
    """IANA zone name, e.g. Asia/Kolkata"""


class TipCalculatorArgs(TypedDict):
    """Typed request fields for tip_calculator.

    Calculate a total with a user-chosen gratuity
    """
    bill: Required[float]
    """Bill amount"""
    tip_percent: Required[float]
    """Tip percentage"""
    people: NotRequired[int]
    """People sharing the bill"""


class TopBigramsArgs(TypedDict):
    """Typed request fields for top_bigrams.

    List common adjacent two-word phrases
    """
    text: Required[str]
    """Passage"""
    limit: NotRequired[int]
    """Phrase count"""


class TopKeywordsArgs(TypedDict):
    """Typed request fields for top_keywords.

    Extract common non-stopword terms from a passage
    """
    text: Required[str]
    """Passage"""
    limit: NotRequired[int]
    """Keyword count"""


class TriangleAreaArgs(TypedDict):
    """Typed request fields for triangle_area.

    Triangle area using base and height
    """
    base: Required[float]
    """Base"""
    height: Required[float]
    """Height"""


class UniformProbabilityArgs(TypedDict):
    """Typed request fields for uniform_probability.

    Probability of a subinterval in a uniform range
    """
    minimum: Required[float]
    """Minimum"""
    maximum: Required[float]
    """Maximum"""
    event_low: Required[float]
    """Event lower limit"""
    event_high: Required[float]
    """Event upper limit"""


class UrlDecodeComponentArgs(TypedDict):
    """Typed request fields for url_decode_component.

    Decode percent-encoded URL text
    """
    text: Required[str]
    """Encoded text"""


class UrlEncodeComponentArgs(TypedDict):
    """Typed request fields for url_encode_component.

    Percent-encode one URL path component
    """
    text: Required[str]
    """Text"""


class ValueGrowthRateArgs(TypedDict):
    """Typed request fields for value_growth_rate.

    Compute growth rates between consecutive measurements
    """
    values: Required[list[Any]]
    """Numeric series"""


class VarianceArgs(TypedDict):
    """Typed request fields for variance.

    Sample or population variance and standard deviation
    """
    values: Required[list[Any]]
    """Numeric samples"""
    sample: NotRequired[bool]
    """Use sample n-1 denominator"""


class WeekdayArgs(TypedDict):
    """Typed request fields for weekday.

    Read weekday name and ISO weekday number for a date
    """
    date: Required[str]
    """YYYY-MM-DD"""


class WeightedAverageArgs(TypedDict):
    """Typed request fields for weighted_average.

    Calculate weighted arithmetic mean
    """
    values: Required[list[Any]]
    """Numeric values"""
    weights: Required[list[Any]]
    """Nonnegative weights"""


class WordFrequencyArgs(TypedDict):
    """Typed request fields for word_frequency.

    Count words within a passage
    """
    text: Required[str]
    """Passage"""
    limit: NotRequired[int]
    """Maximum frequency rows"""


class ZScoresArgs(TypedDict):
    """Typed request fields for z_scores.

    Standardize samples using population deviation
    """
    values: Required[list[Any]]
    """Numeric samples"""


class UtilityMethods:
    """Typed helpers for every installed deterministic JARVIS skill."""

    def __init__(self, client: JarvisClient) -> None:
        self._client = client

    def add_business_days(
        self,
        *,
        start: str,
        days: int,
    ) -> dict[str, Any]:
        """Advance a specified number of weekdays

        Skill: ``add_business_days``; category: ``dates``.

        Arguments:
            start (required, str): YYYY-MM-DD max_length=5000
            days (required, int): Signed weekdays max=10000 min=-10000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: AddBusinessDaysArgs = {}  # type: ignore[typeddict-item]
        arguments['start'] = start
        arguments['days'] = days
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'add_business_days', 'arguments': arguments},
        )

    def add_days(
        self,
        *,
        date: str,
        days: int,
    ) -> dict[str, Any]:
        """Add or subtract calendar days

        Skill: ``add_days``; category: ``dates``.

        Arguments:
            date (required, str): YYYY-MM-DD max_length=5000
            days (required, int): Signed number of days max=365000 min=-365000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: AddDaysArgs = {}  # type: ignore[typeddict-item]
        arguments['date'] = date
        arguments['days'] = days
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'add_days', 'arguments': arguments},
        )

    def add_months(
        self,
        *,
        date: str,
        months: int,
    ) -> dict[str, Any]:
        """Add calendar months, clamping day to month length

        Skill: ``add_months``; category: ``dates``.

        Arguments:
            date (required, str): YYYY-MM-DD max_length=5000
            months (required, int): Signed number of months max=12000 min=-12000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: AddMonthsArgs = {}  # type: ignore[typeddict-item]
        arguments['date'] = date
        arguments['months'] = months
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'add_months', 'arguments': arguments},
        )

    def anagram_check(
        self,
        *,
        first: str,
        second: str,
    ) -> dict[str, Any]:
        """Check whether two phrases use the same alphanumeric characters

        Skill: ``anagram_check``; category: ``strings``.

        Arguments:
            first (required, str): Phrase 1 max_length=5000
            second (required, str): Phrase 2 max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: AnagramCheckArgs = {}  # type: ignore[typeddict-item]
        arguments['first'] = first
        arguments['second'] = second
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'anagram_check', 'arguments': arguments},
        )

    def arithmetic_sequence(
        self,
        *,
        start: float,
        difference: float,
        count: int,
    ) -> dict[str, Any]:
        """Produce a finite arithmetic progression

        Skill: ``arithmetic_sequence``; category: ``numbers``.

        Arguments:
            start (required, float): First term
            difference (required, float): Common difference
            count (required, int): Terms max=1000 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: ArithmeticSequenceArgs = {}  # type: ignore[typeddict-item]
        arguments['start'] = start
        arguments['difference'] = difference
        arguments['count'] = count
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'arithmetic_sequence', 'arguments': arguments},
        )

    def aspect_ratio(
        self,
        *,
        width: int,
        height: int,
    ) -> dict[str, Any]:
        """Simplify pixel aspect ratio

        Skill: ``aspect_ratio``; category: ``measure``.

        Arguments:
            width (required, int): Width min=1
            height (required, int): Height min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: AspectRatioArgs = {}  # type: ignore[typeddict-item]
        arguments['width'] = width
        arguments['height'] = height
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'aspect_ratio', 'arguments': arguments},
        )

    def base_to_number(
        self,
        *,
        text: str,
        base: int,
    ) -> dict[str, Any]:
        """Parse a base-2 to base-36 integer

        Skill: ``base_to_number``; category: ``numbers``.

        Arguments:
            text (required, str): Digit string max_length=100
            base (required, int): Base max=36 min=2

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: BaseToNumberArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        arguments['base'] = base
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'base_to_number', 'arguments': arguments},
        )

    def bayes_rule(
        self,
        *,
        prior: float,
        sensitivity: float,
        false_positive: float,
    ) -> dict[str, Any]:
        """Update a prior probability using sensitivity and false-positive rate

        Skill: ``bayes_rule``; category: ``probability``.

        Arguments:
            prior (required, float): Prior P(H) max=1 min=0
            sensitivity (required, float): P(E given H) max=1 min=0
            false_positive (required, float): P(E given not H) max=1 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: BayesRuleArgs = {}  # type: ignore[typeddict-item]
        arguments['prior'] = prior
        arguments['sensitivity'] = sensitivity
        arguments['false_positive'] = false_positive
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'bayes_rule', 'arguments': arguments},
        )

    def binomial_at_least(
        self,
        *,
        trials: int,
        successes: int,
        p: float,
    ) -> dict[str, Any]:
        """Binomial probability of at least k successes

        Skill: ``binomial_at_least``; category: ``probability``.

        Arguments:
            trials (required, int): Trials max=1000 min=0
            successes (required, int): Minimum successes max=1000 min=0
            p (required, float): Success probability max=1 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: BinomialAtLeastArgs = {}  # type: ignore[typeddict-item]
        arguments['trials'] = trials
        arguments['successes'] = successes
        arguments['p'] = p
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'binomial_at_least', 'arguments': arguments},
        )

    def binomial_exact(
        self,
        *,
        trials: int,
        successes: int,
        p: float,
    ) -> dict[str, Any]:
        """Binomial probability of exactly k successes

        Skill: ``binomial_exact``; category: ``probability``.

        Arguments:
            trials (required, int): Independent trials max=1000 min=0
            successes (required, int): Success count max=1000 min=0
            p (required, float): Success chance max=1 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: BinomialExactArgs = {}  # type: ignore[typeddict-item]
        arguments['trials'] = trials
        arguments['successes'] = successes
        arguments['p'] = p
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'binomial_exact', 'arguments': arguments},
        )

    def binomial_mean_variance(
        self,
        *,
        trials: int,
        p: float,
    ) -> dict[str, Any]:
        """Expected value and variance of a binomial distribution

        Skill: ``binomial_mean_variance``; category: ``probability``.

        Arguments:
            trials (required, int): Number of trials max=1000000 min=0
            p (required, float): Success probability max=1 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: BinomialMeanVarianceArgs = {}  # type: ignore[typeddict-item]
        arguments['trials'] = trials
        arguments['p'] = p
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'binomial_mean_variance', 'arguments': arguments},
        )

    def birthday_collision(
        self,
        *,
        people: int,
    ) -> dict[str, Any]:
        """Approximate chance two people share a birthday

        Skill: ``birthday_collision``; category: ``probability``.

        Arguments:
            people (required, int): Group size max=365 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: BirthdayCollisionArgs = {}  # type: ignore[typeddict-item]
        arguments['people'] = people
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'birthday_collision', 'arguments': arguments},
        )

    def bits_to_bytes(
        self,
        *,
        bits: int,
    ) -> dict[str, Any]:
        """Convert bit count to full and remaining bytes

        Skill: ``bits_to_bytes``; category: ``measure``.

        Arguments:
            bits (required, int): Bit count min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: BitsToBytesArgs = {}  # type: ignore[typeddict-item]
        arguments['bits'] = bits
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'bits_to_bytes', 'arguments': arguments},
        )

    def bootstrap_mean(
        self,
        *,
        values: list[Any],
        replicates: int | None = None,
        seed: int | None = None,
    ) -> dict[str, Any]:
        """Compute deterministic bootstrap means for a small sample

        Skill: ``bootstrap_mean``; category: ``probability``.

        Arguments:
            values (required, list[Any]): Input observations
            replicates (optional, int): Replicates max=500 min=10
            seed (optional, int): Random seed max=100000 min=-100000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: BootstrapMeanArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        if replicates is not None:
            arguments['replicates'] = replicates
        if seed is not None:
            arguments['seed'] = seed
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'bootstrap_mean', 'arguments': arguments},
        )

    def build_querystring(
        self,
        *,
        items: list[Any],
    ) -> dict[str, Any]:
        """Build URL query string from key-value pairs

        Skill: ``build_querystring``; category: ``strings``.

        Arguments:
            items (required, list[Any]): Pairs as objects with key and value

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: BuildQuerystringArgs = {}  # type: ignore[typeddict-item]
        arguments['items'] = items
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'build_querystring', 'arguments': arguments},
        )

    def business_days(
        self,
        *,
        start: str,
        end: str,
    ) -> dict[str, Any]:
        """Count weekdays Monday–Friday in inclusive date range, not holidays

        Skill: ``business_days``; category: ``dates``.

        Arguments:
            start (required, str): YYYY-MM-DD max_length=5000
            end (required, str): YYYY-MM-DD max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: BusinessDaysArgs = {}  # type: ignore[typeddict-item]
        arguments['start'] = start
        arguments['end'] = end
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'business_days', 'arguments': arguments},
        )

    def bytes_to_bits(
        self,
        *,
        bytes: int,
    ) -> dict[str, Any]:
        """Convert bytes to bits

        Skill: ``bytes_to_bits``; category: ``measure``.

        Arguments:
            bytes (required, int): Byte count min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: BytesToBitsArgs = {}  # type: ignore[typeddict-item]
        arguments['bytes'] = bytes
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'bytes_to_bits', 'arguments': arguments},
        )

    def calendar_month(
        self,
        *,
        year: int,
        month: int,
        monday_first: bool | None = None,
    ) -> dict[str, Any]:
        """Create a month grid of dates and empty cells

        Skill: ``calendar_month``; category: ``dates``.

        Arguments:
            year (required, int): Year max=9999 min=1
            month (required, int): Month max=12 min=1
            monday_first (optional, bool): Start weeks on Monday

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: CalendarMonthArgs = {}  # type: ignore[typeddict-item]
        arguments['year'] = year
        arguments['month'] = month
        if monday_first is not None:
            arguments['monday_first'] = monday_first
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'calendar_month', 'arguments': arguments},
        )

    def case_transform(
        self,
        *,
        text: str,
        style: str,
    ) -> dict[str, Any]:
        """Transform labels into snake kebab camel pascal title or constant case

        Skill: ``case_transform``; category: ``strings``.

        Arguments:
            text (required, str): Text max_length=5000
            style (required, str): Style max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: CaseTransformArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        arguments['style'] = style
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'case_transform', 'arguments': arguments},
        )

    def character_count(
        self,
        *,
        text: str,
    ) -> dict[str, Any]:
        """Count Unicode codepoints by broad category

        Skill: ``character_count``; category: ``strings``.

        Arguments:
            text (required, str): Passage max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: CharacterCountArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'character_count', 'arguments': arguments},
        )

    def circle_area(
        self,
        *,
        radius: float,
    ) -> dict[str, Any]:
        """Circle area and circumference for a positive radius

        Skill: ``circle_area``; category: ``numbers``.

        Arguments:
            radius (required, float): Radius min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: CircleAreaArgs = {}  # type: ignore[typeddict-item]
        arguments['radius'] = radius
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'circle_area', 'arguments': arguments},
        )

    def clamp_number(
        self,
        *,
        value: float,
        minimum: float,
        maximum: float,
    ) -> dict[str, Any]:
        """Constrain a value between two numbers

        Skill: ``clamp_number``; category: ``numbers``.

        Arguments:
            value (required, float): Input
            minimum (required, float): Lower limit
            maximum (required, float): Upper limit

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: ClampNumberArgs = {}  # type: ignore[typeddict-item]
        arguments['value'] = value
        arguments['minimum'] = minimum
        arguments['maximum'] = maximum
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'clamp_number', 'arguments': arguments},
        )

    def coefficient_of_variation(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Compute standard deviation relative to mean

        Skill: ``coefficient_of_variation``; category: ``statistics``.

        Arguments:
            values (required, list[Any]): Numeric samples

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: CoefficientOfVariationArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'coefficient_of_variation', 'arguments': arguments},
        )

    def coin_toss_distribution(
        self,
        *,
        flips: int,
    ) -> dict[str, Any]:
        """Distribution of heads across a fixed number of fair flips

        Skill: ``coin_toss_distribution``; category: ``probability``.

        Arguments:
            flips (required, int): Number of flips max=100 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: CoinTossDistributionArgs = {}  # type: ignore[typeddict-item]
        arguments['flips'] = flips
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'coin_toss_distribution', 'arguments': arguments},
        )

    def combinations(
        self,
        *,
        n: int,
        k: int,
    ) -> dict[str, Any]:
        """Number of ways to select k items without order

        Skill: ``combinations``; category: ``probability``.

        Arguments:
            n (required, int): Total items max=1000 min=0
            k (required, int): Selected items max=1000 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: CombinationsArgs = {}  # type: ignore[typeddict-item]
        arguments['n'] = n
        arguments['k'] = k
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'combinations', 'arguments': arguments},
        )

    def common_words(
        self,
        *,
        first: str,
        second: str,
    ) -> dict[str, Any]:
        """Find words present in both texts

        Skill: ``common_words``; category: ``strings``.

        Arguments:
            first (required, str): First text max_length=5000
            second (required, str): Second text max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: CommonWordsArgs = {}  # type: ignore[typeddict-item]
        arguments['first'] = first
        arguments['second'] = second
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'common_words', 'arguments': arguments},
        )

    def compound_growth(
        self,
        *,
        principal: float,
        annual_percent: float,
        years: float,
        periods: int | None = None,
    ) -> dict[str, Any]:
        """Compute compounded hypothetical growth

        Skill: ``compound_growth``; category: ``numbers``.

        Arguments:
            principal (required, float): Initial value min=0
            annual_percent (required, float): Annual growth rate
            years (required, float): Years max=100 min=0
            periods (optional, int): Compounding periods per year max=365 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: CompoundGrowthArgs = {}  # type: ignore[typeddict-item]
        arguments['principal'] = principal
        arguments['annual_percent'] = annual_percent
        arguments['years'] = years
        if periods is not None:
            arguments['periods'] = periods
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'compound_growth', 'arguments': arguments},
        )

    def conditional_probability(
        self,
        *,
        joint: float,
        given: float,
    ) -> dict[str, Any]:
        """Compute P(A given B) from joint and marginal probabilities

        Skill: ``conditional_probability``; category: ``probability``.

        Arguments:
            joint (required, float): P(A and B) max=1 min=0
            given (required, float): P(B) max=1 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: ConditionalProbabilityArgs = {}  # type: ignore[typeddict-item]
        arguments['joint'] = joint
        arguments['given'] = given
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'conditional_probability', 'arguments': arguments},
        )

    def cone_volume(
        self,
        *,
        radius: float,
        height: float,
    ) -> dict[str, Any]:
        """Compute cone volume

        Skill: ``cone_volume``; category: ``measure``.

        Arguments:
            radius (required, float): Base radius min=0
            height (required, float): Cone height min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: ConeVolumeArgs = {}  # type: ignore[typeddict-item]
        arguments['radius'] = radius
        arguments['height'] = height
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'cone_volume', 'arguments': arguments},
        )

    def convert_temperature(
        self,
        *,
        value: float,
        origin: str,
        destination: str,
    ) -> dict[str, Any]:
        """Convert Celsius Fahrenheit and Kelvin

        Skill: ``convert_temperature``; category: ``measure``.

        Arguments:
            value (required, float): Temperature
            origin (required, str): c, f or k max_length=5000
            destination (required, str): c, f or k max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: ConvertTemperatureArgs = {}  # type: ignore[typeddict-item]
        arguments['value'] = value
        arguments['origin'] = origin
        arguments['destination'] = destination
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'convert_temperature', 'arguments': arguments},
        )

    def convert_units(
        self,
        *,
        value: float,
        category: str,
        origin: str,
        destination: str,
    ) -> dict[str, Any]:
        """Convert between defined units in a physical category

        Skill: ``convert_units``; category: ``measure``.

        Arguments:
            value (required, float): Numeric amount
            category (required, str): One of the unit categories max_length=5000
            origin (required, str): Source symbol max_length=5000
            destination (required, str): Target symbol max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: ConvertUnitsArgs = {}  # type: ignore[typeddict-item]
        arguments['value'] = value
        arguments['category'] = category
        arguments['origin'] = origin
        arguments['destination'] = destination
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'convert_units', 'arguments': arguments},
        )

    def correlation_matrix(
        self,
        *,
        series: list[Any],
    ) -> dict[str, Any]:
        """Compute correlations among several same-length series

        Skill: ``correlation_matrix``; category: ``statistics``.

        Arguments:
            series (required, list[Any]): List of numeric series

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: CorrelationMatrixArgs = {}  # type: ignore[typeddict-item]
        arguments['series'] = series
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'correlation_matrix', 'arguments': arguments},
        )

    def covariance(
        self,
        *,
        first: list[Any],
        second: list[Any],
        sample: bool | None = None,
    ) -> dict[str, Any]:
        """Compute sample or population covariance

        Skill: ``covariance``; category: ``statistics``.

        Arguments:
            first (required, list[Any]): Numeric series
            second (required, list[Any]): Paired numeric series
            sample (optional, bool): Sample covariance

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: CovarianceArgs = {}  # type: ignore[typeddict-item]
        arguments['first'] = first
        arguments['second'] = second
        if sample is not None:
            arguments['sample'] = sample
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'covariance', 'arguments': arguments},
        )

    def cuboid_volume(
        self,
        *,
        length: float,
        width: float,
        height: float,
    ) -> dict[str, Any]:
        """Compute cuboid volume and surface area

        Skill: ``cuboid_volume``; category: ``measure``.

        Arguments:
            length (required, float): Length min=0
            width (required, float): Width min=0
            height (required, float): Height min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: CuboidVolumeArgs = {}  # type: ignore[typeddict-item]
        arguments['length'] = length
        arguments['width'] = width
        arguments['height'] = height
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'cuboid_volume', 'arguments': arguments},
        )

    def cumulative_product(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Calculate bounded running products

        Skill: ``cumulative_product``; category: ``statistics``.

        Arguments:
            values (required, list[Any]): Numeric values

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: CumulativeProductArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'cumulative_product', 'arguments': arguments},
        )

    def cumulative_sum(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Calculate running totals for a numeric list

        Skill: ``cumulative_sum``; category: ``statistics``.

        Arguments:
            values (required, list[Any]): Numeric values

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: CumulativeSumArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'cumulative_sum', 'arguments': arguments},
        )

    def cylinder_volume(
        self,
        *,
        radius: float,
        height: float,
    ) -> dict[str, Any]:
        """Compute cylinder volume in input cubic units

        Skill: ``cylinder_volume``; category: ``measure``.

        Arguments:
            radius (required, float): Base radius min=0
            height (required, float): Height min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: CylinderVolumeArgs = {}  # type: ignore[typeddict-item]
        arguments['radius'] = radius
        arguments['height'] = height
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'cylinder_volume', 'arguments': arguments},
        )

    def date_range(
        self,
        *,
        start: str,
        end: str,
        every_days: int | None = None,
    ) -> dict[str, Any]:
        """Generate an inclusive list of dates in a short interval

        Skill: ``date_range``; category: ``dates``.

        Arguments:
            start (required, str): YYYY-MM-DD max_length=5000
            end (required, str): YYYY-MM-DD max_length=5000
            every_days (optional, int): Interval in days max=365 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: DateRangeArgs = {}  # type: ignore[typeddict-item]
        arguments['start'] = start
        arguments['end'] = end
        if every_days is not None:
            arguments['every_days'] = every_days
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'date_range', 'arguments': arguments},
        )

    def datetime_difference(
        self,
        *,
        start: str,
        end: str,
    ) -> dict[str, Any]:
        """Calculate a signed difference between instants

        Skill: ``datetime_difference``; category: ``dates``.

        Arguments:
            start (required, str): ISO datetime with offset max_length=5000
            end (required, str): ISO datetime with offset max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: DatetimeDifferenceArgs = {}  # type: ignore[typeddict-item]
        arguments['start'] = start
        arguments['end'] = end
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'datetime_difference', 'arguments': arguments},
        )

    def days_between(
        self,
        *,
        start: str,
        end: str,
    ) -> dict[str, Any]:
        """Calculate signed calendar days between two ISO dates

        Skill: ``days_between``; category: ``dates``.

        Arguments:
            start (required, str): YYYY-MM-DD max_length=5000
            end (required, str): YYYY-MM-DD max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: DaysBetweenArgs = {}  # type: ignore[typeddict-item]
        arguments['start'] = start
        arguments['end'] = end
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'days_between', 'arguments': arguments},
        )

    def deadline_progress(
        self,
        *,
        started: str,
        deadline: str,
        current: str,
    ) -> dict[str, Any]:
        """Measure date-based progress through a known project timeline

        Skill: ``deadline_progress``; category: ``dates``.

        Arguments:
            started (required, str): YYYY-MM-DD max_length=5000
            deadline (required, str): YYYY-MM-DD max_length=5000
            current (required, str): YYYY-MM-DD max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: DeadlineProgressArgs = {}  # type: ignore[typeddict-item]
        arguments['started'] = started
        arguments['deadline'] = deadline
        arguments['current'] = current
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'deadline_progress', 'arguments': arguments},
        )

    def deduplicate_lines(
        self,
        *,
        text: str,
        ignore_case: bool | None = None,
    ) -> dict[str, Any]:
        """Remove repeated lines while preserving first occurrence

        Skill: ``deduplicate_lines``; category: ``strings``.

        Arguments:
            text (required, str): Multiline text max_length=5000
            ignore_case (optional, bool): Compare case insensitively

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: DeduplicateLinesArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        if ignore_case is not None:
            arguments['ignore_case'] = ignore_case
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'deduplicate_lines', 'arguments': arguments},
        )

    def detect_repetitions(
        self,
        *,
        text: str,
    ) -> dict[str, Any]:
        """Show repeated full sentences

        Skill: ``detect_repetitions``; category: ``strings``.

        Arguments:
            text (required, str): Document max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: DetectRepetitionsArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'detect_repetitions', 'arguments': arguments},
        )

    def dice_sum_distribution(
        self,
        *,
        dice: int,
        sides: int | None = None,
    ) -> dict[str, Any]:
        """Exact discrete distribution for small fair dice sums

        Skill: ``dice_sum_distribution``; category: ``probability``.

        Arguments:
            dice (required, int): Number of dice max=5 min=1
            sides (optional, int): Faces per die max=20 min=2

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: DiceSumDistributionArgs = {}  # type: ignore[typeddict-item]
        arguments['dice'] = dice
        if sides is not None:
            arguments['sides'] = sides
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'dice_sum_distribution', 'arguments': arguments},
        )

    def discount_price(
        self,
        *,
        original: float,
        discount_percent: float,
    ) -> dict[str, Any]:
        """Apply a discount percentage

        Skill: ``discount_price``; category: ``numbers``.

        Arguments:
            original (required, float): Original price min=0
            discount_percent (required, float): Discount max=100 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: DiscountPriceArgs = {}  # type: ignore[typeddict-item]
        arguments['original'] = original
        arguments['discount_percent'] = discount_percent
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'discount_price', 'arguments': arguments},
        )

    def distance_2d(
        self,
        *,
        x1: float,
        y1: float,
        x2: float,
        y2: float,
    ) -> dict[str, Any]:
        """Calculate Euclidean distance between two 2D points

        Skill: ``distance_2d``; category: ``numbers``.

        Arguments:
            x1 (required, float): X 1
            y1 (required, float): Y 1
            x2 (required, float): X 2
            y2 (required, float): Y 2

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: Distance2dArgs = {}  # type: ignore[typeddict-item]
        arguments['x1'] = x1
        arguments['y1'] = y1
        arguments['x2'] = x2
        arguments['y2'] = y2
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'distance_2d', 'arguments': arguments},
        )

    def distance_from_speed(
        self,
        *,
        kilometers_per_hour: float,
        hours: float,
    ) -> dict[str, Any]:
        """Calculate distance traveled at constant speed

        Skill: ``distance_from_speed``; category: ``measure``.

        Arguments:
            kilometers_per_hour (required, float): Average speed min=0
            hours (required, float): Elapsed hours min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: DistanceFromSpeedArgs = {}  # type: ignore[typeddict-item]
        arguments['kilometers_per_hour'] = kilometers_per_hour
        arguments['hours'] = hours
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'distance_from_speed', 'arguments': arguments},
        )

    def download_time_estimate(
        self,
        *,
        size_megabytes: float,
        bandwidth_megabits_per_second: float,
    ) -> dict[str, Any]:
        """Estimate download time without network measurement

        Skill: ``download_time_estimate``; category: ``measure``.

        Arguments:
            size_megabytes (required, float): File size MB decimal min=0
            bandwidth_megabits_per_second (required, float): Mbps min=0.001

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: DownloadTimeEstimateArgs = {}  # type: ignore[typeddict-item]
        arguments['size_megabytes'] = size_megabytes
        arguments['bandwidth_megabits_per_second'] = bandwidth_megabits_per_second
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'download_time_estimate', 'arguments': arguments},
        )

    def electric_ohms_law(
        self,
        *,
        solve_for: str,
        volts: float | None = None,
        amps: float | None = None,
        ohms: float | None = None,
    ) -> dict[str, Any]:
        """Solve voltage current or resistance from the other two

        Skill: ``electric_ohms_law``; category: ``measure``.

        Arguments:
            solve_for (required, str): One of volts amps ohms max_length=5000
            volts (optional, float): Voltage, 0 if unknown
            amps (optional, float): Current, 0 if unknown
            ohms (optional, float): Resistance, 0 if unknown

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: ElectricOhmsLawArgs = {}  # type: ignore[typeddict-item]
        arguments['solve_for'] = solve_for
        if volts is not None:
            arguments['volts'] = volts
        if amps is not None:
            arguments['amps'] = amps
        if ohms is not None:
            arguments['ohms'] = ohms
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'electric_ohms_law', 'arguments': arguments},
        )

    def equal_split(
        self,
        *,
        total: float,
        people: int,
    ) -> dict[str, Any]:
        """Divide a bill or quantity equally

        Skill: ``equal_split``; category: ``numbers``.

        Arguments:
            total (required, float): Total amount
            people (required, int): Number of people max=10000 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: EqualSplitArgs = {}  # type: ignore[typeddict-item]
        arguments['total'] = total
        arguments['people'] = people
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'equal_split', 'arguments': arguments},
        )

    def expected_value(
        self,
        *,
        values: list[Any],
        probabilities: list[Any],
    ) -> dict[str, Any]:
        """Compute expectation of a discrete probability distribution

        Skill: ``expected_value``; category: ``probability``.

        Arguments:
            values (required, list[Any]): Possible outcomes
            probabilities (required, list[Any]): Corresponding probabilities

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: ExpectedValueArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        arguments['probabilities'] = probabilities
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'expected_value', 'arguments': arguments},
        )

    def exponential_moving_average(
        self,
        *,
        values: list[Any],
        alpha: float,
    ) -> dict[str, Any]:
        """Compute exponential weighted moving average

        Skill: ``exponential_moving_average``; category: ``statistics``.

        Arguments:
            values (required, list[Any]): Numeric time series
            alpha (required, float): Smoothing constant max=1 min=1e-05

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: ExponentialMovingAverageArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        arguments['alpha'] = alpha
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'exponential_moving_average', 'arguments': arguments},
        )

    def extract_headings(
        self,
        *,
        text: str,
    ) -> dict[str, Any]:
        """Extract Markdown headings from an outline

        Skill: ``extract_headings``; category: ``strings``.

        Arguments:
            text (required, str): Markdown text max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: ExtractHeadingsArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'extract_headings', 'arguments': arguments},
        )

    def extract_patterns(
        self,
        *,
        text: str,
    ) -> dict[str, Any]:
        """Extract explicit date email URL hashtag and time patterns

        Skill: ``extract_patterns``; category: ``strings``.

        Arguments:
            text (required, str): Passage max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: ExtractPatternsArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'extract_patterns', 'arguments': arguments},
        )

    def extract_urls(
        self,
        *,
        text: str,
    ) -> dict[str, Any]:
        """List HTTP(S) URLs visibly present in plain text

        Skill: ``extract_urls``; category: ``strings``.

        Arguments:
            text (required, str): Passage max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: ExtractUrlsArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'extract_urls', 'arguments': arguments},
        )

    def factorial(
        self,
        *,
        n: int,
    ) -> dict[str, Any]:
        """Calculate factorial n! for a bounded nonnegative integer

        Skill: ``factorial``; category: ``numbers``.

        Arguments:
            n (required, int): Integer max=1000 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: FactorialArgs = {}  # type: ignore[typeddict-item]
        arguments['n'] = n
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'factorial', 'arguments': arguments},
        )

    def factorial_probability(
        self,
        *,
        n: int,
    ) -> dict[str, Any]:
        """Factorial of a bounded nonnegative integer

        Skill: ``factorial_probability``; category: ``probability``.

        Arguments:
            n (required, int): Value max=100 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: FactorialProbabilityArgs = {}  # type: ignore[typeddict-item]
        arguments['n'] = n
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'factorial_probability', 'arguments': arguments},
        )

    def fibonacci(
        self,
        *,
        count: int,
    ) -> dict[str, Any]:
        """Generate the first N Fibonacci numbers

        Skill: ``fibonacci``; category: ``numbers``.

        Arguments:
            count (required, int): Number of terms max=200 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: FibonacciArgs = {}  # type: ignore[typeddict-item]
        arguments['count'] = count
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'fibonacci', 'arguments': arguments},
        )

    def file_size_format(
        self,
        *,
        bytes: int,
        binary: bool | None = None,
    ) -> dict[str, Any]:
        """Format a byte count in binary or decimal units

        Skill: ``file_size_format``; category: ``measure``.

        Arguments:
            bytes (required, int): Byte count min=0
            binary (optional, bool): Use KiB MiB GiB instead of kB MB GB

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: FileSizeFormatArgs = {}  # type: ignore[typeddict-item]
        arguments['bytes'] = bytes
        if binary is not None:
            arguments['binary'] = binary
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'file_size_format', 'arguments': arguments},
        )

    def five_number_summary(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Find minimum quartiles median and maximum

        Skill: ``five_number_summary``; category: ``statistics``.

        Arguments:
            values (required, list[Any]): Numeric samples

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: FiveNumberSummaryArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'five_number_summary', 'arguments': arguments},
        )

    def format_json(
        self,
        *,
        value: dict[str, Any],
        indent: int | None = None,
    ) -> dict[str, Any]:
        """Pretty-print a bounded JSON value

        Skill: ``format_json``; category: ``data``.

        Arguments:
            value (required, dict[str, Any]): Object to format
            indent (optional, int): Indent spaces max=6 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: FormatJsonArgs = {}  # type: ignore[typeddict-item]
        arguments['value'] = value
        if indent is not None:
            arguments['indent'] = indent
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'format_json', 'arguments': arguments},
        )

    def format_time_hhmm(
        self,
        *,
        minutes: int,
    ) -> dict[str, Any]:
        """Convert minutes since midnight to HH:MM, wrapping each day

        Skill: ``format_time_hhmm``; category: ``dates``.

        Arguments:
            minutes (required, int): Minutes max=100000 min=-100000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: FormatTimeHhmmArgs = {}  # type: ignore[typeddict-item]
        arguments['minutes'] = minutes
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'format_time_hhmm', 'arguments': arguments},
        )

    def fraction_operations(
        self,
        *,
        left: str,
        right: str,
        operation: str,
    ) -> dict[str, Any]:
        """Add, subtract, multiply or divide two rational numbers

        Skill: ``fraction_operations``; category: ``numbers``.

        Arguments:
            left (required, str): First fraction, e.g. 3/4 max_length=5000
            right (required, str): Second fraction, e.g. 1/2 max_length=5000
            operation (required, str): Operation max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: FractionOperationsArgs = {}  # type: ignore[typeddict-item]
        arguments['left'] = left
        arguments['right'] = right
        arguments['operation'] = operation
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'fraction_operations', 'arguments': arguments},
        )

    def frequency_table(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Count occurrences of categorical labels

        Skill: ``frequency_table``; category: ``statistics``.

        Arguments:
            values (required, list[Any]): Categories or labels

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: FrequencyTableArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'frequency_table', 'arguments': arguments},
        )

    def fuzzy_titles(
        self,
        *,
        query: str,
        candidates: list[Any],
        limit: int | None = None,
    ) -> dict[str, Any]:
        """Find close candidate titles for a supplied name

        Skill: ``fuzzy_titles``; category: ``strings``.

        Arguments:
            query (required, str): Title max_length=5000
            candidates (required, list[Any]): List of titles
            limit (optional, int): Result count max=20 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: FuzzyTitlesArgs = {}  # type: ignore[typeddict-item]
        arguments['query'] = query
        arguments['candidates'] = candidates
        if limit is not None:
            arguments['limit'] = limit
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'fuzzy_titles', 'arguments': arguments},
        )

    def gcd_lcm(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Compute the greatest common divisor and least common multiple

        Skill: ``gcd_lcm``; category: ``numbers``.

        Arguments:
            values (required, list[Any]): Integer values

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: GcdLcmArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'gcd_lcm', 'arguments': arguments},
        )

    def geometric_exact(
        self,
        *,
        p: float,
        trial: int,
    ) -> dict[str, Any]:
        """Probability first success occurs on a chosen trial

        Skill: ``geometric_exact``; category: ``probability``.

        Arguments:
            p (required, float): Success chance max=1 min=0
            trial (required, int): Trial number max=1000000 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: GeometricExactArgs = {}  # type: ignore[typeddict-item]
        arguments['p'] = p
        arguments['trial'] = trial
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'geometric_exact', 'arguments': arguments},
        )

    def geometric_mean(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Calculate geometric mean for positive values

        Skill: ``geometric_mean``; category: ``statistics``.

        Arguments:
            values (required, list[Any]): Positive numbers

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: GeometricMeanArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'geometric_mean', 'arguments': arguments},
        )

    def geometric_sequence(
        self,
        *,
        start: float,
        ratio: float,
        count: int,
    ) -> dict[str, Any]:
        """Produce a bounded geometric progression

        Skill: ``geometric_sequence``; category: ``numbers``.

        Arguments:
            start (required, float): First term
            ratio (required, float): Common ratio max=100 min=-100
            count (required, int): Terms max=100 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: GeometricSequenceArgs = {}  # type: ignore[typeddict-item]
        arguments['start'] = start
        arguments['ratio'] = ratio
        arguments['count'] = count
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'geometric_sequence', 'arguments': arguments},
        )

    def graph_adjacency_list(
        self,
        *,
        nodes: list[Any],
        edges: list[Any],
        directed: bool | None = None,
    ) -> dict[str, Any]:
        """Represent an edge list as a node-neighbor dictionary

        Skill: ``graph_adjacency_list``; category: ``graphs``.

        Arguments:
            nodes (required, list[Any]): Nodes
            edges (required, list[Any]): Edges
            directed (optional, bool): Directed graph

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: GraphAdjacencyListArgs = {}  # type: ignore[typeddict-item]
        arguments['nodes'] = nodes
        arguments['edges'] = edges
        if directed is not None:
            arguments['directed'] = directed
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'graph_adjacency_list', 'arguments': arguments},
        )

    def graph_adjacency_matrix(
        self,
        *,
        nodes: list[Any],
        edges: list[Any],
        directed: bool | None = None,
    ) -> dict[str, Any]:
        """Create a small binary adjacency matrix

        Skill: ``graph_adjacency_matrix``; category: ``graphs``.

        Arguments:
            nodes (required, list[Any]): Nodes
            edges (required, list[Any]): Edges
            directed (optional, bool): Directed graph

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: GraphAdjacencyMatrixArgs = {}  # type: ignore[typeddict-item]
        arguments['nodes'] = nodes
        arguments['edges'] = edges
        if directed is not None:
            arguments['directed'] = directed
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'graph_adjacency_matrix', 'arguments': arguments},
        )

    def graph_bipartite(
        self,
        *,
        nodes: list[Any],
        edges: list[Any],
    ) -> dict[str, Any]:
        """Check whether an undirected graph can be two-colored

        Skill: ``graph_bipartite``; category: ``graphs``.

        Arguments:
            nodes (required, list[Any]): Nodes
            edges (required, list[Any]): Edges

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: GraphBipartiteArgs = {}  # type: ignore[typeddict-item]
        arguments['nodes'] = nodes
        arguments['edges'] = edges
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'graph_bipartite', 'arguments': arguments},
        )

    def graph_closeness(
        self,
        *,
        nodes: list[Any],
        edges: list[Any],
    ) -> dict[str, Any]:
        """Estimate closeness centrality using shortest hop counts

        Skill: ``graph_closeness``; category: ``graphs``.

        Arguments:
            nodes (required, list[Any]): Nodes
            edges (required, list[Any]): Edges

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: GraphClosenessArgs = {}  # type: ignore[typeddict-item]
        arguments['nodes'] = nodes
        arguments['edges'] = edges
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'graph_closeness', 'arguments': arguments},
        )

    def graph_components(
        self,
        *,
        nodes: list[Any],
        edges: list[Any],
    ) -> dict[str, Any]:
        """Connected components in an undirected graph

        Skill: ``graph_components``; category: ``graphs``.

        Arguments:
            nodes (required, list[Any]): Nodes
            edges (required, list[Any]): Edges

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: GraphComponentsArgs = {}  # type: ignore[typeddict-item]
        arguments['nodes'] = nodes
        arguments['edges'] = edges
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'graph_components', 'arguments': arguments},
        )

    def graph_critical_path(
        self,
        *,
        tasks: list[Any],
    ) -> dict[str, Any]:
        """Calculate a dependency path for tasks with durations

        Skill: ``graph_critical_path``; category: ``graphs``.

        Arguments:
            tasks (required, list[Any]): Objects with id, duration, dependencies

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: GraphCriticalPathArgs = {}  # type: ignore[typeddict-item]
        arguments['tasks'] = tasks
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'graph_critical_path', 'arguments': arguments},
        )

    def graph_degree(
        self,
        *,
        nodes: list[Any],
        edges: list[Any],
        directed: bool | None = None,
    ) -> dict[str, Any]:
        """Compute degree statistics of graph nodes

        Skill: ``graph_degree``; category: ``graphs``.

        Arguments:
            nodes (required, list[Any]): Nodes
            edges (required, list[Any]): Edges
            directed (optional, bool): Directed graph

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: GraphDegreeArgs = {}  # type: ignore[typeddict-item]
        arguments['nodes'] = nodes
        arguments['edges'] = edges
        if directed is not None:
            arguments['directed'] = directed
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'graph_degree', 'arguments': arguments},
        )

    def graph_density(
        self,
        *,
        nodes: list[Any],
        edges: list[Any],
        directed: bool | None = None,
    ) -> dict[str, Any]:
        """Calculate the density of a graph

        Skill: ``graph_density``; category: ``graphs``.

        Arguments:
            nodes (required, list[Any]): Nodes
            edges (required, list[Any]): Edges
            directed (optional, bool): Directed

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: GraphDensityArgs = {}  # type: ignore[typeddict-item]
        arguments['nodes'] = nodes
        arguments['edges'] = edges
        if directed is not None:
            arguments['directed'] = directed
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'graph_density', 'arguments': arguments},
        )

    def graph_dependency_levels(
        self,
        *,
        nodes: list[Any],
        edges: list[Any],
    ) -> dict[str, Any]:
        """Group dependent tasks into parallelizable levels

        Skill: ``graph_dependency_levels``; category: ``graphs``.

        Arguments:
            nodes (required, list[Any]): Task names
            edges (required, list[Any]): Prerequisite pairs

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: GraphDependencyLevelsArgs = {}  # type: ignore[typeddict-item]
        arguments['nodes'] = nodes
        arguments['edges'] = edges
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'graph_dependency_levels', 'arguments': arguments},
        )

    def graph_edges_from_matrix(
        self,
        *,
        nodes: list[Any],
        matrix: list[Any],
    ) -> dict[str, Any]:
        """Convert an adjacency matrix into an edge list

        Skill: ``graph_edges_from_matrix``; category: ``graphs``.

        Arguments:
            nodes (required, list[Any]): Nodes
            matrix (required, list[Any]): Binary matrix

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: GraphEdgesFromMatrixArgs = {}  # type: ignore[typeddict-item]
        arguments['nodes'] = nodes
        arguments['matrix'] = matrix
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'graph_edges_from_matrix', 'arguments': arguments},
        )

    def graph_has_cycle(
        self,
        *,
        nodes: list[Any],
        edges: list[Any],
    ) -> dict[str, Any]:
        """Test directed graph for a dependency cycle

        Skill: ``graph_has_cycle``; category: ``graphs``.

        Arguments:
            nodes (required, list[Any]): Nodes
            edges (required, list[Any]): Edges

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: GraphHasCycleArgs = {}  # type: ignore[typeddict-item]
        arguments['nodes'] = nodes
        arguments['edges'] = edges
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'graph_has_cycle', 'arguments': arguments},
        )

    def graph_reachable(
        self,
        *,
        nodes: list[Any],
        edges: list[Any],
        source: str,
        directed: bool | None = None,
    ) -> dict[str, Any]:
        """List nodes reachable from a given node

        Skill: ``graph_reachable``; category: ``graphs``.

        Arguments:
            nodes (required, list[Any]): Node labels
            edges (required, list[Any]): Edges
            source (required, str): Start max_length=5000
            directed (optional, bool): Directed graph

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: GraphReachableArgs = {}  # type: ignore[typeddict-item]
        arguments['nodes'] = nodes
        arguments['edges'] = edges
        arguments['source'] = source
        if directed is not None:
            arguments['directed'] = directed
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'graph_reachable', 'arguments': arguments},
        )

    def graph_shortest_path(
        self,
        *,
        nodes: list[Any],
        edges: list[Any],
        source: str,
        target: str,
        directed: bool | None = None,
    ) -> dict[str, Any]:
        """Shortest unweighted path between two nodes

        Skill: ``graph_shortest_path``; category: ``graphs``.

        Arguments:
            nodes (required, list[Any]): Node labels
            edges (required, list[Any]): Node pairs
            source (required, str): Start node max_length=5000
            target (required, str): End node max_length=5000
            directed (optional, bool): Use directed edges

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: GraphShortestPathArgs = {}  # type: ignore[typeddict-item]
        arguments['nodes'] = nodes
        arguments['edges'] = edges
        arguments['source'] = source
        arguments['target'] = target
        if directed is not None:
            arguments['directed'] = directed
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'graph_shortest_path', 'arguments': arguments},
        )

    def graph_topological_order(
        self,
        *,
        nodes: list[Any],
        edges: list[Any],
    ) -> dict[str, Any]:
        """Order prerequisites in a directed acyclic graph

        Skill: ``graph_topological_order``; category: ``graphs``.

        Arguments:
            nodes (required, list[Any]): Nodes
            edges (required, list[Any]): Pairs [prerequisite,dependent]

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: GraphTopologicalOrderArgs = {}  # type: ignore[typeddict-item]
        arguments['nodes'] = nodes
        arguments['edges'] = edges
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'graph_topological_order', 'arguments': arguments},
        )

    def graph_weighted_shortest_path(
        self,
        *,
        nodes: list[Any],
        edges: list[Any],
        source: str,
        target: str,
        directed: bool | None = None,
    ) -> dict[str, Any]:
        """Dijkstra shortest path with positive weights

        Skill: ``graph_weighted_shortest_path``; category: ``graphs``.

        Arguments:
            nodes (required, list[Any]): Node labels
            edges (required, list[Any]): Triples [from,to,cost]
            source (required, str): Start max_length=5000
            target (required, str): End max_length=5000
            directed (optional, bool): Direction matters

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: GraphWeightedShortestPathArgs = {}  # type: ignore[typeddict-item]
        arguments['nodes'] = nodes
        arguments['edges'] = edges
        arguments['source'] = source
        arguments['target'] = target
        if directed is not None:
            arguments['directed'] = directed
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'graph_weighted_shortest_path', 'arguments': arguments},
        )

    def harmonic_mean(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Calculate harmonic mean for positive values

        Skill: ``harmonic_mean``; category: ``statistics``.

        Arguments:
            values (required, list[Any]): Positive numbers

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: HarmonicMeanArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'harmonic_mean', 'arguments': arguments},
        )

    def hash_sha256(
        self,
        *,
        text: str,
    ) -> dict[str, Any]:
        """Compute SHA-256 digest for plain text, not passwords

        Skill: ``hash_sha256``; category: ``strings``.

        Arguments:
            text (required, str): Input text max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: HashSha256Args = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'hash_sha256', 'arguments': arguments},
        )

    def histogram(
        self,
        *,
        values: list[Any],
        bins: int | None = None,
    ) -> dict[str, Any]:
        """Build a fixed-width histogram for numeric data

        Skill: ``histogram``; category: ``statistics``.

        Arguments:
            values (required, list[Any]): Numeric samples
            bins (optional, int): Bin count max=100 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: HistogramArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        if bins is not None:
            arguments['bins'] = bins
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'histogram', 'arguments': arguments},
        )

    def html_escape(
        self,
        *,
        text: str,
    ) -> dict[str, Any]:
        """Escape HTML special characters for safe display

        Skill: ``html_escape``; category: ``strings``.

        Arguments:
            text (required, str): Text max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: HtmlEscapeArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'html_escape', 'arguments': arguments},
        )

    def hypergeometric_exact(
        self,
        *,
        population: int,
        positive: int,
        draws: int,
        successes: int,
    ) -> dict[str, Any]:
        """Probability of k successes sampled without replacement

        Skill: ``hypergeometric_exact``; category: ``probability``.

        Arguments:
            population (required, int): Total population max=10000 min=1
            positive (required, int): Positive items in population max=10000 min=0
            draws (required, int): Number of draws max=10000 min=0
            successes (required, int): Observed positive draws max=10000 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: HypergeometricExactArgs = {}  # type: ignore[typeddict-item]
        arguments['population'] = population
        arguments['positive'] = positive
        arguments['draws'] = draws
        arguments['successes'] = successes
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'hypergeometric_exact', 'arguments': arguments},
        )

    def hyperspace_data_size(
        self,
        *,
        width: int,
        height: int,
        channels: int | None = None,
        bits_per_channel: int | None = None,
    ) -> dict[str, Any]:
        """Estimate storage for uncompressed images in bytes

        Skill: ``hyperspace_data_size``; category: ``measure``.

        Arguments:
            width (required, int): Width pixels max=16384 min=1
            height (required, int): Height pixels max=16384 min=1
            channels (optional, int): Color channels max=4 min=1
            bits_per_channel (optional, int): Channel bit depth max=32 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: HyperspaceDataSizeArgs = {}  # type: ignore[typeddict-item]
        arguments['width'] = width
        arguments['height'] = height
        if channels is not None:
            arguments['channels'] = channels
        if bits_per_channel is not None:
            arguments['bits_per_channel'] = bits_per_channel
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'hyperspace_data_size', 'arguments': arguments},
        )

    def independent_and(
        self,
        *,
        p: float,
        q: float,
    ) -> dict[str, Any]:
        """Probability of independent events both occurring

        Skill: ``independent_and``; category: ``probability``.

        Arguments:
            p (required, float): First probability max=1 min=0
            q (required, float): Second probability max=1 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: IndependentAndArgs = {}  # type: ignore[typeddict-item]
        arguments['p'] = p
        arguments['q'] = q
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'independent_and', 'arguments': arguments},
        )

    def independent_or(
        self,
        *,
        p: float,
        q: float,
    ) -> dict[str, Any]:
        """Probability that either independent event occurs

        Skill: ``independent_or``; category: ``probability``.

        Arguments:
            p (required, float): First probability max=1 min=0
            q (required, float): Second probability max=1 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: IndependentOrArgs = {}  # type: ignore[typeddict-item]
        arguments['p'] = p
        arguments['q'] = q
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'independent_or', 'arguments': arguments},
        )

    def initials(
        self,
        *,
        text: str,
        limit: int | None = None,
    ) -> dict[str, Any]:
        """Make initials from a short phrase

        Skill: ``initials``; category: ``strings``.

        Arguments:
            text (required, str): Name or phrase max_length=5000
            limit (optional, int): Maximum initials max=20 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: InitialsArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        if limit is not None:
            arguments['limit'] = limit
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'initials', 'arguments': arguments},
        )

    def integer_bit_count(
        self,
        *,
        value: int,
    ) -> dict[str, Any]:
        """Count 1 bits in a nonnegative integer

        Skill: ``integer_bit_count``; category: ``numbers``.

        Arguments:
            value (required, int): Integer min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: IntegerBitCountArgs = {}  # type: ignore[typeddict-item]
        arguments['value'] = value
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'integer_bit_count', 'arguments': arguments},
        )

    def interquartile_range(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Calculate IQR and Tukey outlier fences

        Skill: ``interquartile_range``; category: ``statistics``.

        Arguments:
            values (required, list[Any]): Numeric samples

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: InterquartileRangeArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'interquartile_range', 'arguments': arguments},
        )

    def iso_week(
        self,
        *,
        date: str,
    ) -> dict[str, Any]:
        """Read ISO week, weekday and week-numbering year

        Skill: ``iso_week``; category: ``dates``.

        Arguments:
            date (required, str): YYYY-MM-DD max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: IsoWeekArgs = {}  # type: ignore[typeddict-item]
        arguments['date'] = date
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'iso_week', 'arguments': arguments},
        )

    def json_extract_path(
        self,
        *,
        value: dict[str, Any],
        path: str,
    ) -> dict[str, Any]:
        """Read a nested JSON object by a simple dotted path

        Skill: ``json_extract_path``; category: ``data``.

        Arguments:
            value (required, dict[str, Any]): Source document
            path (required, str): Dot-separated keys max_length=300

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: JsonExtractPathArgs = {}  # type: ignore[typeddict-item]
        arguments['value'] = value
        arguments['path'] = path
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'json_extract_path', 'arguments': arguments},
        )

    def json_object_diff(
        self,
        *,
        before: dict[str, Any],
        after: dict[str, Any],
    ) -> dict[str, Any]:
        """Show changed, added and removed top-level keys

        Skill: ``json_object_diff``; category: ``data``.

        Arguments:
            before (required, dict[str, Any]): Earlier object
            after (required, dict[str, Any]): Later object

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: JsonObjectDiffArgs = {}  # type: ignore[typeddict-item]
        arguments['before'] = before
        arguments['after'] = after
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'json_object_diff', 'arguments': arguments},
        )

    def language_script_hint(
        self,
        *,
        text: str,
    ) -> dict[str, Any]:
        """Detect which common writing script is most visible

        Skill: ``language_script_hint``; category: ``strings``.

        Arguments:
            text (required, str): Passage max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: LanguageScriptHintArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'language_script_hint', 'arguments': arguments},
        )

    def leap_year(
        self,
        *,
        year: int,
    ) -> dict[str, Any]:
        """Check Gregorian leap-year status

        Skill: ``leap_year``; category: ``dates``.

        Arguments:
            year (required, int): Year max=9999 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: LeapYearArgs = {}  # type: ignore[typeddict-item]
        arguments['year'] = year
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'leap_year', 'arguments': arguments},
        )

    def line_numbers(
        self,
        *,
        text: str,
        start: int | None = None,
    ) -> dict[str, Any]:
        """Prefix each line with its line number

        Skill: ``line_numbers``; category: ``strings``.

        Arguments:
            text (required, str): Multiline text max_length=5000
            start (optional, int): Starting number max=100000 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: LineNumbersArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        if start is not None:
            arguments['start'] = start
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'line_numbers', 'arguments': arguments},
        )

    def linear_interpolation(
        self,
        *,
        x0: float,
        y0: float,
        x1: float,
        y1: float,
        x: float,
    ) -> dict[str, Any]:
        """Find a point on a line between two measurements

        Skill: ``linear_interpolation``; category: ``numbers``.

        Arguments:
            x0 (required, float): Start X
            y0 (required, float): Start Y
            x1 (required, float): End X
            y1 (required, float): End Y
            x (required, float): Query X

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: LinearInterpolationArgs = {}  # type: ignore[typeddict-item]
        arguments['x0'] = x0
        arguments['y0'] = y0
        arguments['x1'] = x1
        arguments['y1'] = y1
        arguments['x'] = x
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'linear_interpolation', 'arguments': arguments},
        )

    def linear_regression(
        self,
        *,
        x: list[Any],
        y: list[Any],
    ) -> dict[str, Any]:
        """Fit least-squares slope and intercept for simple regression

        Skill: ``linear_regression``; category: ``statistics``.

        Arguments:
            x (required, list[Any]): Numeric x series
            y (required, list[Any]): Numeric y series

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: LinearRegressionArgs = {}  # type: ignore[typeddict-item]
        arguments['x'] = x
        arguments['y'] = y
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'linear_regression', 'arguments': arguments},
        )

    def list_units(
        self,
        *,
        category: str | None = None,
    ) -> dict[str, Any]:
        """List accepted symbols for each conversion category

        Skill: ``list_units``; category: ``measure``.

        Arguments:
            category (optional, str): Category, or blank for all max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: ListUnitsArgs = {}  # type: ignore[typeddict-item]
        if category is not None:
            arguments['category'] = category
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'list_units', 'arguments': arguments},
        )

    def literal_find(
        self,
        *,
        text: str,
        needle: str,
        ignore_case: bool | None = None,
    ) -> dict[str, Any]:
        """Find exact substring positions without regular expressions

        Skill: ``literal_find``; category: ``strings``.

        Arguments:
            text (required, str): Text max_length=5000
            needle (required, str): Search term max_length=100
            ignore_case (optional, bool): Case insensitive

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: LiteralFindArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        arguments['needle'] = needle
        if ignore_case is not None:
            arguments['ignore_case'] = ignore_case
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'literal_find', 'arguments': arguments},
        )

    def make_csv(
        self,
        *,
        rows: list[Any],
        delimiter: str | None = None,
    ) -> dict[str, Any]:
        """Convert a JSON table into escaped CSV text

        Skill: ``make_csv``; category: ``data``.

        Arguments:
            rows (required, list[Any]): Rows to encode
            delimiter (optional, str): Delimiter max_length=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: MakeCsvArgs = {}  # type: ignore[typeddict-item]
        arguments['rows'] = rows
        if delimiter is not None:
            arguments['delimiter'] = delimiter
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'make_csv', 'arguments': arguments},
        )

    def markdown_toc(
        self,
        *,
        text: str,
    ) -> dict[str, Any]:
        """Create a simple Markdown table of contents

        Skill: ``markdown_toc``; category: ``strings``.

        Arguments:
            text (required, str): Markdown document max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: MarkdownTocArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'markdown_toc', 'arguments': arguments},
        )

    def mask_identifier(
        self,
        *,
        text: str,
        keep_last: int | None = None,
    ) -> dict[str, Any]:
        """Mask characters of a user-supplied non-secret identifier

        Skill: ``mask_identifier``; category: ``strings``.

        Arguments:
            text (required, str): Identifier max_length=5000
            keep_last (optional, int): Trailing visible characters max=20 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: MaskIdentifierArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        if keep_last is not None:
            arguments['keep_last'] = keep_last
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'mask_identifier', 'arguments': arguments},
        )

    def math_definite_integral(
        self,
        *,
        expression: str,
        lower: float,
        upper: float,
    ) -> dict[str, Any]:
        """Compute a definite integral over a bounded numeric interval

        Skill: ``math_definite_integral``; category: ``symbolic``.

        Arguments:
            expression (required, str): Integrand max_length=300
            lower (required, float): Lower limit max=1000 min=-1000
            upper (required, float): Upper limit max=1000 min=-1000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: MathDefiniteIntegralArgs = {}  # type: ignore[typeddict-item]
        arguments['expression'] = expression
        arguments['lower'] = lower
        arguments['upper'] = upper
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'math_definite_integral', 'arguments': arguments},
        )

    def math_derivative(
        self,
        *,
        expression: str,
        variable: str | None = None,
        order: int | None = None,
    ) -> dict[str, Any]:
        """Compute a first or higher-order derivative

        Skill: ``math_derivative``; category: ``symbolic``.

        Arguments:
            expression (required, str): Function, e.g. (x**2+3)**2 max_length=500
            variable (optional, str): Differentiate with respect to max_length=5000
            order (optional, int): Derivative order max=5 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: MathDerivativeArgs = {}  # type: ignore[typeddict-item]
        arguments['expression'] = expression
        if variable is not None:
            arguments['variable'] = variable
        if order is not None:
            arguments['order'] = order
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'math_derivative', 'arguments': arguments},
        )

    def math_evaluate(
        self,
        *,
        expression: str,
        value: float,
        variable: str | None = None,
    ) -> dict[str, Any]:
        """Substitute one numeric variable and evaluate expression

        Skill: ``math_evaluate``; category: ``symbolic``.

        Arguments:
            expression (required, str): Expression max_length=500
            value (required, float): Substitution value max=10000 min=-10000
            variable (optional, str): Variable max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: MathEvaluateArgs = {}  # type: ignore[typeddict-item]
        arguments['expression'] = expression
        arguments['value'] = value
        if variable is not None:
            arguments['variable'] = variable
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'math_evaluate', 'arguments': arguments},
        )

    def math_expand(
        self,
        *,
        expression: str,
    ) -> dict[str, Any]:
        """Expand products and integer powers

        Skill: ``math_expand``; category: ``symbolic``.

        Arguments:
            expression (required, str): Algebraic expression max_length=500

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: MathExpandArgs = {}  # type: ignore[typeddict-item]
        arguments['expression'] = expression
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'math_expand', 'arguments': arguments},
        )

    def math_factor(
        self,
        *,
        expression: str,
    ) -> dict[str, Any]:
        """Factor a bounded polynomial expression

        Skill: ``math_factor``; category: ``symbolic``.

        Arguments:
            expression (required, str): Polynomial to factor max_length=500

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: MathFactorArgs = {}  # type: ignore[typeddict-item]
        arguments['expression'] = expression
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'math_factor', 'arguments': arguments},
        )

    def math_gradient(
        self,
        *,
        expression: str,
        variables: list[Any] | None = None,
    ) -> dict[str, Any]:
        """Calculate gradient of a scalar function in up to three variables

        Skill: ``math_gradient``; category: ``symbolic``.

        Arguments:
            expression (required, str): Expression in x, y, z max_length=300
            variables (optional, list[Any]): Variable names in order

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: MathGradientArgs = {}  # type: ignore[typeddict-item]
        arguments['expression'] = expression
        if variables is not None:
            arguments['variables'] = variables
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'math_gradient', 'arguments': arguments},
        )

    def math_hessian(
        self,
        *,
        expression: str,
        variables: list[Any] | None = None,
    ) -> dict[str, Any]:
        """Compute the Hessian matrix of a scalar function

        Skill: ``math_hessian``; category: ``symbolic``.

        Arguments:
            expression (required, str): Expression max_length=300
            variables (optional, list[Any]): Variables

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: MathHessianArgs = {}  # type: ignore[typeddict-item]
        arguments['expression'] = expression
        if variables is not None:
            arguments['variables'] = variables
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'math_hessian', 'arguments': arguments},
        )

    def math_indefinite_integral(
        self,
        *,
        expression: str,
        variable: str | None = None,
    ) -> dict[str, Any]:
        """Compute a simple symbolic indefinite integral

        Skill: ``math_indefinite_integral``; category: ``symbolic``.

        Arguments:
            expression (required, str): Integrand max_length=300
            variable (optional, str): Integrating variable max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: MathIndefiniteIntegralArgs = {}  # type: ignore[typeddict-item]
        arguments['expression'] = expression
        if variable is not None:
            arguments['variable'] = variable
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'math_indefinite_integral', 'arguments': arguments},
        )

    def math_limit(
        self,
        *,
        expression: str,
        point: float,
        direction: str | None = None,
    ) -> dict[str, Any]:
        """Calculate a univariate one-sided or two-sided limit

        Skill: ``math_limit``; category: ``symbolic``.

        Arguments:
            expression (required, str): Expression max_length=250
            point (required, float): Value x approaches max=1000 min=-1000
            direction (optional, str): Approach direction max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: MathLimitArgs = {}  # type: ignore[typeddict-item]
        arguments['expression'] = expression
        arguments['point'] = point
        if direction is not None:
            arguments['direction'] = direction
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'math_limit', 'arguments': arguments},
        )

    def math_numeric_derivative(
        self,
        *,
        expression: str,
        at: float,
        step: float | None = None,
    ) -> dict[str, Any]:
        """Estimate derivative using centered finite differences

        Skill: ``math_numeric_derivative``; category: ``symbolic``.

        Arguments:
            expression (required, str): Function of x max_length=300
            at (required, float): Point max=10000 min=-10000
            step (optional, float): Finite difference step max=0.1 min=1e-07

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: MathNumericDerivativeArgs = {}  # type: ignore[typeddict-item]
        arguments['expression'] = expression
        arguments['at'] = at
        if step is not None:
            arguments['step'] = step
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'math_numeric_derivative', 'arguments': arguments},
        )

    def math_partial_derivative(
        self,
        *,
        expression: str,
        variable: str,
    ) -> dict[str, Any]:
        """Compute a multivariable partial derivative

        Skill: ``math_partial_derivative``; category: ``symbolic``.

        Arguments:
            expression (required, str): Expression in x, y or z max_length=300
            variable (required, str): Partial derivative variable max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: MathPartialDerivativeArgs = {}  # type: ignore[typeddict-item]
        arguments['expression'] = expression
        arguments['variable'] = variable
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'math_partial_derivative', 'arguments': arguments},
        )

    def math_polynomial_coefficients(
        self,
        *,
        expression: str,
        variable: str | None = None,
    ) -> dict[str, Any]:
        """Extract polynomial coefficients from highest to lowest degree

        Skill: ``math_polynomial_coefficients``; category: ``symbolic``.

        Arguments:
            expression (required, str): Polynomial max_length=300
            variable (optional, str): Variable max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: MathPolynomialCoefficientsArgs = {}  # type: ignore[typeddict-item]
        arguments['expression'] = expression
        if variable is not None:
            arguments['variable'] = variable
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'math_polynomial_coefficients', 'arguments': arguments},
        )

    def math_simplify(
        self,
        *,
        expression: str,
    ) -> dict[str, Any]:
        """Simplify an algebraic expression using optional SymPy

        Skill: ``math_simplify``; category: ``symbolic``.

        Arguments:
            expression (required, str): Expression using x, sin(x), x**2, etc. max_length=500

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: MathSimplifyArgs = {}  # type: ignore[typeddict-item]
        arguments['expression'] = expression
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'math_simplify', 'arguments': arguments},
        )

    def math_solve_polynomial(
        self,
        *,
        expression: str,
        variable: str | None = None,
    ) -> dict[str, Any]:
        """Solve a univariate polynomial equation expression = 0

        Skill: ``math_solve_polynomial``; category: ``symbolic``.

        Arguments:
            expression (required, str): Polynomial expression max_length=300
            variable (optional, str): Unknown variable max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: MathSolvePolynomialArgs = {}  # type: ignore[typeddict-item]
        arguments['expression'] = expression
        if variable is not None:
            arguments['variable'] = variable
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'math_solve_polynomial', 'arguments': arguments},
        )

    def math_substitute(
        self,
        *,
        expression: str,
        variable: str,
        value: float,
    ) -> dict[str, Any]:
        """Replace one symbol with a number

        Skill: ``math_substitute``; category: ``symbolic``.

        Arguments:
            expression (required, str): Expression max_length=300
            variable (required, str): Symbol max_length=5000
            value (required, float): Numeric replacement max=10000 min=-10000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: MathSubstituteArgs = {}  # type: ignore[typeddict-item]
        arguments['expression'] = expression
        arguments['variable'] = variable
        arguments['value'] = value
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'math_substitute', 'arguments': arguments},
        )

    def math_taylor_series(
        self,
        *,
        expression: str,
        point: float | None = None,
        order: int | None = None,
    ) -> dict[str, Any]:
        """Compute a truncated Taylor series at zero or another point

        Skill: ``math_taylor_series``; category: ``symbolic``.

        Arguments:
            expression (required, str): Expression max_length=250
            point (optional, float): Expansion point max=20 min=-20
            order (optional, int): Terms through order n-1 max=10 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: MathTaylorSeriesArgs = {}  # type: ignore[typeddict-item]
        arguments['expression'] = expression
        if point is not None:
            arguments['point'] = point
        if order is not None:
            arguments['order'] = order
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'math_taylor_series', 'arguments': arguments},
        )

    def mean_absolute_deviation(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Compute average absolute deviation around the mean

        Skill: ``mean_absolute_deviation``; category: ``statistics``.

        Arguments:
            values (required, list[Any]): Numeric samples

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: MeanAbsoluteDeviationArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'mean_absolute_deviation', 'arguments': arguments},
        )

    def mean_median_mode(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Calculate mean median and modes

        Skill: ``mean_median_mode``; category: ``statistics``.

        Arguments:
            values (required, list[Any]): Numeric samples

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: MeanMedianModeArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'mean_median_mode', 'arguments': arguments},
        )

    def median_absolute_deviation(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Compute median absolute deviation from sample median

        Skill: ``median_absolute_deviation``; category: ``statistics``.

        Arguments:
            values (required, list[Any]): Numeric samples

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: MedianAbsoluteDeviationArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'median_absolute_deviation', 'arguments': arguments},
        )

    def minutes_to_duration(
        self,
        *,
        minutes: int,
    ) -> dict[str, Any]:
        """Display total minutes as days, hours and minutes

        Skill: ``minutes_to_duration``; category: ``dates``.

        Arguments:
            minutes (required, int): Total signed minutes max=10000000 min=-10000000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: MinutesToDurationArgs = {}  # type: ignore[typeddict-item]
        arguments['minutes'] = minutes
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'minutes_to_duration', 'arguments': arguments},
        )

    def moving_average(
        self,
        *,
        values: list[Any],
        window: int,
    ) -> dict[str, Any]:
        """Compute sliding simple moving averages

        Skill: ``moving_average``; category: ``statistics``.

        Arguments:
            values (required, list[Any]): Numeric time series
            window (required, int): Number of samples per window max=1000 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: MovingAverageArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        arguments['window'] = window
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'moving_average', 'arguments': arguments},
        )

    def normal_cdf(
        self,
        *,
        z: float,
    ) -> dict[str, Any]:
        """Cumulative normal probability for a z-score

        Skill: ``normal_cdf``; category: ``probability``.

        Arguments:
            z (required, float): Z score max=50 min=-50

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: NormalCdfArgs = {}  # type: ignore[typeddict-item]
        arguments['z'] = z
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'normal_cdf', 'arguments': arguments},
        )

    def normal_interval(
        self,
        *,
        low: float,
        high: float,
    ) -> dict[str, Any]:
        """Probability between two z-scores

        Skill: ``normal_interval``; category: ``probability``.

        Arguments:
            low (required, float): Lower z score max=50 min=-50
            high (required, float): Upper z score max=50 min=-50

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: NormalIntervalArgs = {}  # type: ignore[typeddict-item]
        arguments['low'] = low
        arguments['high'] = high
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'normal_interval', 'arguments': arguments},
        )

    def normal_zscore(
        self,
        *,
        value: float,
        mean: float,
        stddev: float,
    ) -> dict[str, Any]:
        """Convert a measurement to standard deviation units

        Skill: ``normal_zscore``; category: ``probability``.

        Arguments:
            value (required, float): Observation
            mean (required, float): Population mean
            stddev (required, float): Population standard deviation min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: NormalZscoreArgs = {}  # type: ignore[typeddict-item]
        arguments['value'] = value
        arguments['mean'] = mean
        arguments['stddev'] = stddev
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'normal_zscore', 'arguments': arguments},
        )

    def normalize_minmax(
        self,
        *,
        values: list[Any],
        lower: float | None = None,
        upper: float | None = None,
    ) -> dict[str, Any]:
        """Map a numeric series to a selected range

        Skill: ``normalize_minmax``; category: ``statistics``.

        Arguments:
            values (required, list[Any]): Numeric samples
            lower (optional, float): Target lower bound
            upper (optional, float): Target upper bound

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: NormalizeMinmaxArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        if lower is not None:
            arguments['lower'] = lower
        if upper is not None:
            arguments['upper'] = upper
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'normalize_minmax', 'arguments': arguments},
        )

    def normalize_text(
        self,
        *,
        text: str,
        casefold: bool | None = None,
    ) -> dict[str, Any]:
        """Standardize Unicode whitespace and optionally case

        Skill: ``normalize_text``; category: ``strings``.

        Arguments:
            text (required, str): Text max_length=5000
            casefold (optional, bool): Convert to casefolded lowercase

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: NormalizeTextArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        if casefold is not None:
            arguments['casefold'] = casefold
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'normalize_text', 'arguments': arguments},
        )

    def nth_weekday(
        self,
        *,
        year: int,
        month: int,
        weekday: int,
        occurrence: int,
    ) -> dict[str, Any]:
        """Find the Nth specified weekday in a calendar month

        Skill: ``nth_weekday``; category: ``dates``.

        Arguments:
            year (required, int): Year max=9999 min=1
            month (required, int): Month max=12 min=1
            weekday (required, int): Monday=0 through Sunday=6 max=6 min=0
            occurrence (required, int): Nth occurrence, 1–5 max=5 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: NthWeekdayArgs = {}  # type: ignore[typeddict-item]
        arguments['year'] = year
        arguments['month'] = month
        arguments['weekday'] = weekday
        arguments['occurrence'] = occurrence
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'nth_weekday', 'arguments': arguments},
        )

    def number_to_base(
        self,
        *,
        value: int,
        base: int,
    ) -> dict[str, Any]:
        """Convert an integer to binary, octal or hexadecimal

        Skill: ``number_to_base``; category: ``numbers``.

        Arguments:
            value (required, int): Integer
            base (required, int): Base max=36 min=2

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: NumberToBaseArgs = {}  # type: ignore[typeddict-item]
        arguments['value'] = value
        arguments['base'] = base
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'number_to_base', 'arguments': arguments},
        )

    def odds_to_probability(
        self,
        *,
        odds: float,
    ) -> dict[str, Any]:
        """Convert positive odds ratio to probability

        Skill: ``odds_to_probability``; category: ``probability``.

        Arguments:
            odds (required, float): Odds for vs against max=1000000000000.0 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: OddsToProbabilityArgs = {}  # type: ignore[typeddict-item]
        arguments['odds'] = odds
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'odds_to_probability', 'arguments': arguments},
        )

    def overlap_time_ranges(
        self,
        *,
        first_start: str,
        first_end: str,
        second_start: str,
        second_end: str,
    ) -> dict[str, Any]:
        """Find intersection of two timezone-aware intervals

        Skill: ``overlap_time_ranges``; category: ``dates``.

        Arguments:
            first_start (required, str): Timestamp max_length=5000
            first_end (required, str): Timestamp max_length=5000
            second_start (required, str): Timestamp max_length=5000
            second_end (required, str): Timestamp max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: OverlapTimeRangesArgs = {}  # type: ignore[typeddict-item]
        arguments['first_start'] = first_start
        arguments['first_end'] = first_end
        arguments['second_start'] = second_start
        arguments['second_end'] = second_end
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'overlap_time_ranges', 'arguments': arguments},
        )

    def pace_from_time(
        self,
        *,
        minutes: float,
        kilometers: float,
    ) -> dict[str, Any]:
        """Calculate minutes per km from minutes and distance

        Skill: ``pace_from_time``; category: ``measure``.

        Arguments:
            minutes (required, float): Elapsed minutes min=0
            kilometers (required, float): Distance in km min=1e-07

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PaceFromTimeArgs = {}  # type: ignore[typeddict-item]
        arguments['minutes'] = minutes
        arguments['kilometers'] = kilometers
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'pace_from_time', 'arguments': arguments},
        )

    def palindrome_check(
        self,
        *,
        text: str,
    ) -> dict[str, Any]:
        """Check if alphanumeric characters read identically backwards

        Skill: ``palindrome_check``; category: ``strings``.

        Arguments:
            text (required, str): Phrase max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PalindromeCheckArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'palindrome_check', 'arguments': arguments},
        )

    def paragraph_split(
        self,
        *,
        text: str,
    ) -> dict[str, Any]:
        """Split text on empty lines

        Skill: ``paragraph_split``; category: ``strings``.

        Arguments:
            text (required, str): Multiline text max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: ParagraphSplitArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'paragraph_split', 'arguments': arguments},
        )

    def parse_csv(
        self,
        *,
        text: str,
        delimiter: str | None = None,
    ) -> dict[str, Any]:
        """Parse simple comma-separated data into row objects

        Skill: ``parse_csv``; category: ``data``.

        Arguments:
            text (required, str): CSV content max_length=15000
            delimiter (optional, str): Field delimiter max_length=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: ParseCsvArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        if delimiter is not None:
            arguments['delimiter'] = delimiter
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'parse_csv', 'arguments': arguments},
        )

    def parse_json(
        self,
        *,
        text: str,
    ) -> dict[str, Any]:
        """Validate and decode a JSON text value

        Skill: ``parse_json``; category: ``data``.

        Arguments:
            text (required, str): JSON document max_length=15000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: ParseJsonArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'parse_json', 'arguments': arguments},
        )

    def parse_querystring(
        self,
        *,
        text: str,
    ) -> dict[str, Any]:
        """Extract query-string parameters without issuing HTTP requests

        Skill: ``parse_querystring``; category: ``strings``.

        Arguments:
            text (required, str): URL query string max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: ParseQuerystringArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'parse_querystring', 'arguments': arguments},
        )

    def parse_time_hhmm(
        self,
        *,
        time: str,
    ) -> dict[str, Any]:
        """Parse 24-hour clock time to elapsed minutes

        Skill: ``parse_time_hhmm``; category: ``dates``.

        Arguments:
            time (required, str): HH:MM max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: ParseTimeHhmmArgs = {}  # type: ignore[typeddict-item]
        arguments['time'] = time
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'parse_time_hhmm', 'arguments': arguments},
        )

    def pearson_correlation(
        self,
        *,
        first: list[Any],
        second: list[Any],
    ) -> dict[str, Any]:
        """Compute Pearson linear correlation for paired data

        Skill: ``pearson_correlation``; category: ``statistics``.

        Arguments:
            first (required, list[Any]): First numeric series
            second (required, list[Any]): Second numeric series

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PearsonCorrelationArgs = {}  # type: ignore[typeddict-item]
        arguments['first'] = first
        arguments['second'] = second
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'pearson_correlation', 'arguments': arguments},
        )

    def percent_change(
        self,
        *,
        before: float,
        after: float,
    ) -> dict[str, Any]:
        """Calculate the relative percentage change

        Skill: ``percent_change``; category: ``numbers``.

        Arguments:
            before (required, float): Original value
            after (required, float): Updated value

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PercentChangeArgs = {}  # type: ignore[typeddict-item]
        arguments['before'] = before
        arguments['after'] = after
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'percent_change', 'arguments': arguments},
        )

    def percent_of(
        self,
        *,
        part: float,
        whole: float,
    ) -> dict[str, Any]:
        """Calculate a percentage of any positive or negative number

        Skill: ``percent_of``; category: ``numbers``.

        Arguments:
            part (required, float): The percentage
            whole (required, float): The amount

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PercentOfArgs = {}  # type: ignore[typeddict-item]
        arguments['part'] = part
        arguments['whole'] = whole
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'percent_of', 'arguments': arguments},
        )

    def percent_of_total(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Calculate percent share for each nonnegative contribution

        Skill: ``percent_of_total``; category: ``statistics``.

        Arguments:
            values (required, list[Any]): Nonnegative numeric values

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PercentOfTotalArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'percent_of_total', 'arguments': arguments},
        )

    def percentage_difference(
        self,
        *,
        first: float,
        second: float,
    ) -> dict[str, Any]:
        """Compare two measurements symmetrically

        Skill: ``percentage_difference``; category: ``numbers``.

        Arguments:
            first (required, float): First amount
            second (required, float): Second amount

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PercentageDifferenceArgs = {}  # type: ignore[typeddict-item]
        arguments['first'] = first
        arguments['second'] = second
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'percentage_difference', 'arguments': arguments},
        )

    def percentile_rank(
        self,
        *,
        values: list[Any],
        value: float,
    ) -> dict[str, Any]:
        """Percent of observations less than or equal to a given value

        Skill: ``percentile_rank``; category: ``statistics``.

        Arguments:
            values (required, list[Any]): Numeric samples
            value (required, float): Value to compare

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PercentileRankArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        arguments['value'] = value
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'percentile_rank', 'arguments': arguments},
        )

    def permutations(
        self,
        *,
        n: int,
        k: int,
    ) -> dict[str, Any]:
        """Ordered arrangements of k selected items

        Skill: ``permutations``; category: ``probability``.

        Arguments:
            n (required, int): Total items max=1000 min=0
            k (required, int): Selected items max=1000 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PermutationsArgs = {}  # type: ignore[typeddict-item]
        arguments['n'] = n
        arguments['k'] = k
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'permutations', 'arguments': arguments},
        )

    def pixel_density(
        self,
        *,
        width_px: int,
        height_px: int,
        diagonal_inches: float,
    ) -> dict[str, Any]:
        """Compute approximate pixels per inch for a display

        Skill: ``pixel_density``; category: ``measure``.

        Arguments:
            width_px (required, int): Horizontal pixels min=1
            height_px (required, int): Vertical pixels min=1
            diagonal_inches (required, float): Diagonal screen size min=0.01

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PixelDensityArgs = {}  # type: ignore[typeddict-item]
        arguments['width_px'] = width_px
        arguments['height_px'] = height_px
        arguments['diagonal_inches'] = diagonal_inches
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'pixel_density', 'arguments': arguments},
        )

    def poisson_exact(
        self,
        *,
        rate: float,
        count: int,
    ) -> dict[str, Any]:
        """Poisson probability of exactly k events

        Skill: ``poisson_exact``; category: ``probability``.

        Arguments:
            rate (required, float): Expected number of events max=100 min=0
            count (required, int): Number of observed events max=300 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PoissonExactArgs = {}  # type: ignore[typeddict-item]
        arguments['rate'] = rate
        arguments['count'] = count
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'poisson_exact', 'arguments': arguments},
        )

    def population_range(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Get count min max span and mean from numeric data

        Skill: ``population_range``; category: ``statistics``.

        Arguments:
            values (required, list[Any]): Numeric samples

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PopulationRangeArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'population_range', 'arguments': arguments},
        )

    def power_energy(
        self,
        *,
        watts: float,
        hours: float,
    ) -> dict[str, Any]:
        """Calculate energy from constant power and elapsed time

        Skill: ``power_energy``; category: ``measure``.

        Arguments:
            watts (required, float): Power in W min=0
            hours (required, float): Duration in hours min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PowerEnergyArgs = {}  # type: ignore[typeddict-item]
        arguments['watts'] = watts
        arguments['hours'] = hours
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'power_energy', 'arguments': arguments},
        )

    def prime_check(
        self,
        *,
        value: int,
    ) -> dict[str, Any]:
        """Check whether an integer is prime using trial division

        Skill: ``prime_check``; category: ``numbers``.

        Arguments:
            value (required, int): Integer to check max=1000000000000 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PrimeCheckArgs = {}  # type: ignore[typeddict-item]
        arguments['value'] = value
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'prime_check', 'arguments': arguments},
        )

    def prime_factors(
        self,
        *,
        value: int,
    ) -> dict[str, Any]:
        """Find prime factors of a moderate integer

        Skill: ``prime_factors``; category: ``numbers``.

        Arguments:
            value (required, int): Positive integer max=10000000000 min=2

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PrimeFactorsArgs = {}  # type: ignore[typeddict-item]
        arguments['value'] = value
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'prime_factors', 'arguments': arguments},
        )

    def probability_not(
        self,
        *,
        p: float,
    ) -> dict[str, Any]:
        """Compute the complement of an event probability

        Skill: ``probability_not``; category: ``probability``.

        Arguments:
            p (required, float): Event probability max=1 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: ProbabilityNotArgs = {}  # type: ignore[typeddict-item]
        arguments['p'] = p
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'probability_not', 'arguments': arguments},
        )

    def probability_to_odds(
        self,
        *,
        probability: float,
    ) -> dict[str, Any]:
        """Convert event probability into odds for vs against

        Skill: ``probability_to_odds``; category: ``probability``.

        Arguments:
            probability (required, float): Probability max=1 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: ProbabilityToOddsArgs = {}  # type: ignore[typeddict-item]
        arguments['probability'] = probability
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'probability_to_odds', 'arguments': arguments},
        )

    def proportion(
        self,
        *,
        a: float,
        b: float,
        c: float,
    ) -> dict[str, Any]:
        """Solve a proportion a/b=c/d for missing d

        Skill: ``proportion``; category: ``numbers``.

        Arguments:
            a (required, float): Known numerator
            b (required, float): Known denominator
            c (required, float): Known second numerator

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: ProportionArgs = {}  # type: ignore[typeddict-item]
        arguments['a'] = a
        arguments['b'] = b
        arguments['c'] = c
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'proportion', 'arguments': arguments},
        )

    def pythagorean(
        self,
        *,
        a: float,
        b: float,
    ) -> dict[str, Any]:
        """Solve a right triangle hypotenuse from two sides

        Skill: ``pythagorean``; category: ``numbers``.

        Arguments:
            a (required, float): First leg min=0
            b (required, float): Second leg min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PythagoreanArgs = {}  # type: ignore[typeddict-item]
        arguments['a'] = a
        arguments['b'] = b
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'pythagorean', 'arguments': arguments},
        )

    def python_assignment_names(
        self,
        *,
        source: str,
    ) -> dict[str, Any]:
        """List variables assigned in Python source

        Skill: ``python_assignment_names``; category: ``software``.

        Arguments:
            source (required, str): Source max_length=12000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PythonAssignmentNamesArgs = {}  # type: ignore[typeddict-item]
        arguments['source'] = source
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'python_assignment_names', 'arguments': arguments},
        )

    def python_ast_counts(
        self,
        *,
        source: str,
    ) -> dict[str, Any]:
        """Count syntax node types in a Python file

        Skill: ``python_ast_counts``; category: ``software``.

        Arguments:
            source (required, str): Source max_length=12000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PythonAstCountsArgs = {}  # type: ignore[typeddict-item]
        arguments['source'] = source
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'python_ast_counts', 'arguments': arguments},
        )

    def python_broad_exception_candidates(
        self,
        *,
        source: str,
    ) -> dict[str, Any]:
        """Find bare excepts and broad exception handlers

        Skill: ``python_broad_exception_candidates``; category: ``software``.

        Arguments:
            source (required, str): Source max_length=12000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PythonBroadExceptionCandidatesArgs = {}  # type: ignore[typeddict-item]
        arguments['source'] = source
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'python_broad_exception_candidates', 'arguments': arguments},
        )

    def python_call_names(
        self,
        *,
        source: str,
    ) -> dict[str, Any]:
        """List function call names statically from Python source

        Skill: ``python_call_names``; category: ``software``.

        Arguments:
            source (required, str): Source max_length=12000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PythonCallNamesArgs = {}  # type: ignore[typeddict-item]
        arguments['source'] = source
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'python_call_names', 'arguments': arguments},
        )

    def python_classes(
        self,
        *,
        source: str,
    ) -> dict[str, Any]:
        """Extract classes, bases, methods, and source line numbers

        Skill: ``python_classes``; category: ``software``.

        Arguments:
            source (required, str): Source text max_length=12000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PythonClassesArgs = {}  # type: ignore[typeddict-item]
        arguments['source'] = source
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'python_classes', 'arguments': arguments},
        )

    def python_complexity(
        self,
        *,
        source: str,
    ) -> dict[str, Any]:
        """Estimate branch-based cyclomatic complexity of Python functions

        Skill: ``python_complexity``; category: ``software``.

        Arguments:
            source (required, str): Source max_length=12000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PythonComplexityArgs = {}  # type: ignore[typeddict-item]
        arguments['source'] = source
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'python_complexity', 'arguments': arguments},
        )

    def python_constant_values(
        self,
        *,
        source: str,
    ) -> dict[str, Any]:
        """List simple module-level constant assignments

        Skill: ``python_constant_values``; category: ``software``.

        Arguments:
            source (required, str): Source max_length=12000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PythonConstantValuesArgs = {}  # type: ignore[typeddict-item]
        arguments['source'] = source
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'python_constant_values', 'arguments': arguments},
        )

    def python_definition_outline(
        self,
        *,
        source: str,
    ) -> dict[str, Any]:
        """Produce a class/function declaration outline

        Skill: ``python_definition_outline``; category: ``software``.

        Arguments:
            source (required, str): Source max_length=12000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PythonDefinitionOutlineArgs = {}  # type: ignore[typeddict-item]
        arguments['source'] = source
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'python_definition_outline', 'arguments': arguments},
        )

    def python_docstrings(
        self,
        *,
        source: str,
    ) -> dict[str, Any]:
        """Collect module, class and function docstrings

        Skill: ``python_docstrings``; category: ``software``.

        Arguments:
            source (required, str): Source max_length=12000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PythonDocstringsArgs = {}  # type: ignore[typeddict-item]
        arguments['source'] = source
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'python_docstrings', 'arguments': arguments},
        )

    def python_format_import_suggestions(
        self,
        *,
        source: str,
    ) -> dict[str, Any]:
        """Suggest grouping import modules by name

        Skill: ``python_format_import_suggestions``; category: ``software``.

        Arguments:
            source (required, str): Source max_length=12000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PythonFormatImportSuggestionsArgs = {}  # type: ignore[typeddict-item]
        arguments['source'] = source
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'python_format_import_suggestions', 'arguments': arguments},
        )

    def python_functions(
        self,
        *,
        source: str,
    ) -> dict[str, Any]:
        """List functions, arguments, line ranges and async markers

        Skill: ``python_functions``; category: ``software``.

        Arguments:
            source (required, str): Source text max_length=12000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PythonFunctionsArgs = {}  # type: ignore[typeddict-item]
        arguments['source'] = source
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'python_functions', 'arguments': arguments},
        )

    def python_imports(
        self,
        *,
        source: str,
    ) -> dict[str, Any]:
        """Extract literal import statements without importing packages

        Skill: ``python_imports``; category: ``software``.

        Arguments:
            source (required, str): Source max_length=12000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PythonImportsArgs = {}  # type: ignore[typeddict-item]
        arguments['source'] = source
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'python_imports', 'arguments': arguments},
        )

    def python_keyword_check(
        self,
        *,
        name: str,
    ) -> dict[str, Any]:
        """Check Python keyword and identifier rules

        Skill: ``python_keyword_check``; category: ``software``.

        Arguments:
            name (required, str): Candidate variable or function name max_length=100

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PythonKeywordCheckArgs = {}  # type: ignore[typeddict-item]
        arguments['name'] = name
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'python_keyword_check', 'arguments': arguments},
        )

    def python_mutable_default_candidates(
        self,
        *,
        source: str,
    ) -> dict[str, Any]:
        """Find literal list/dict/set defaults in function definitions

        Skill: ``python_mutable_default_candidates``; category: ``software``.

        Arguments:
            source (required, str): Source max_length=12000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PythonMutableDefaultCandidatesArgs = {}  # type: ignore[typeddict-item]
        arguments['source'] = source
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'python_mutable_default_candidates', 'arguments': arguments},
        )

    def python_syntax_check(
        self,
        *,
        source: str,
    ) -> dict[str, Any]:
        """Parse Python source and report syntax errors without running code

        Skill: ``python_syntax_check``; category: ``software``.

        Arguments:
            source (required, str): Source text max_length=12000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PythonSyntaxCheckArgs = {}  # type: ignore[typeddict-item]
        arguments['source'] = source
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'python_syntax_check', 'arguments': arguments},
        )

    def python_todo_comments(
        self,
        *,
        source: str,
    ) -> dict[str, Any]:
        """Locate TODO and FIXME comments

        Skill: ``python_todo_comments``; category: ``software``.

        Arguments:
            source (required, str): Source text max_length=12000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PythonTodoCommentsArgs = {}  # type: ignore[typeddict-item]
        arguments['source'] = source
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'python_todo_comments', 'arguments': arguments},
        )

    def python_unused_import_candidates(
        self,
        *,
        source: str,
    ) -> dict[str, Any]:
        """Find imports whose names are not referenced elsewhere in the AST

        Skill: ``python_unused_import_candidates``; category: ``software``.

        Arguments:
            source (required, str): Source max_length=12000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: PythonUnusedImportCandidatesArgs = {}  # type: ignore[typeddict-item]
        arguments['source'] = source
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'python_unused_import_candidates', 'arguments': arguments},
        )

    def quadratic_roots(
        self,
        *,
        a: float,
        b: float,
        c: float,
    ) -> dict[str, Any]:
        """Solve a real quadratic equation ax²+bx+c=0

        Skill: ``quadratic_roots``; category: ``numbers``.

        Arguments:
            a (required, float): Coefficient a
            b (required, float): Coefficient b
            c (required, float): Coefficient c

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: QuadraticRootsArgs = {}  # type: ignore[typeddict-item]
        arguments['a'] = a
        arguments['b'] = b
        arguments['c'] = c
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'quadratic_roots', 'arguments': arguments},
        )

    def quantile(
        self,
        *,
        values: list[Any],
        quantile: float,
    ) -> dict[str, Any]:
        """Find a linearly interpolated quantile

        Skill: ``quantile``; category: ``statistics``.

        Arguments:
            values (required, list[Any]): Numeric samples
            quantile (required, float): Fraction between 0 and 1 max=1 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: QuantileArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        arguments['quantile'] = quantile
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'quantile', 'arguments': arguments},
        )

    def ratio_simplify(
        self,
        *,
        a: int,
        b: int,
    ) -> dict[str, Any]:
        """Reduce an integer ratio using the greatest common divisor

        Skill: ``ratio_simplify``; category: ``numbers``.

        Arguments:
            a (required, int): First integer
            b (required, int): Second integer

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: RatioSimplifyArgs = {}  # type: ignore[typeddict-item]
        arguments['a'] = a
        arguments['b'] = b
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'ratio_simplify', 'arguments': arguments},
        )

    def regression_predict(
        self,
        *,
        x: list[Any],
        y: list[Any],
        predict_x: float,
    ) -> dict[str, Any]:
        """Predict y using fitted line from paired training data

        Skill: ``regression_predict``; category: ``statistics``.

        Arguments:
            x (required, list[Any]): Training x series
            y (required, list[Any]): Training y series
            predict_x (required, float): New x

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: RegressionPredictArgs = {}  # type: ignore[typeddict-item]
        arguments['x'] = x
        arguments['y'] = y
        arguments['predict_x'] = predict_x
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'regression_predict', 'arguments': arguments},
        )

    def remove_empty_lines(
        self,
        *,
        text: str,
    ) -> dict[str, Any]:
        """Filter blank lines from a passage

        Skill: ``remove_empty_lines``; category: ``strings``.

        Arguments:
            text (required, str): Multiline text max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: RemoveEmptyLinesArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'remove_empty_lines', 'arguments': arguments},
        )

    def replace_literal(
        self,
        *,
        text: str,
        old: str,
        new: str,
        limit: int | None = None,
    ) -> dict[str, Any]:
        """Replace literal text with another substring

        Skill: ``replace_literal``; category: ``strings``.

        Arguments:
            text (required, str): Input max_length=5000
            old (required, str): Exact old text max_length=200
            new (required, str): Replacement max_length=5000
            limit (optional, int): Maximum replacements max=1000 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: ReplaceLiteralArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        arguments['old'] = old
        arguments['new'] = new
        if limit is not None:
            arguments['limit'] = limit
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'replace_literal', 'arguments': arguments},
        )

    def rescale_image(
        self,
        *,
        width: int,
        height: int,
        max_width: int,
        max_height: int,
        upscale: bool | None = None,
    ) -> dict[str, Any]:
        """Rescale an image to fit within given bounds, preserving aspect ratio

        Skill: ``rescale_image``; category: ``measure``.

        Arguments:
            width (required, int): Original width max=100000 min=1
            height (required, int): Original height max=100000 min=1
            max_width (required, int): Target width max=100000 min=1
            max_height (required, int): Target height max=100000 min=1
            upscale (optional, bool): Allow enlarging the original

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: RescaleImageArgs = {}  # type: ignore[typeddict-item]
        arguments['width'] = width
        arguments['height'] = height
        arguments['max_width'] = max_width
        arguments['max_height'] = max_height
        if upscale is not None:
            arguments['upscale'] = upscale
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'rescale_image', 'arguments': arguments},
        )

    def root_mean_square(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Calculate root-mean-square of numeric values

        Skill: ``root_mean_square``; category: ``statistics``.

        Arguments:
            values (required, list[Any]): Numbers

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: RootMeanSquareArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'root_mean_square', 'arguments': arguments},
        )

    def round_significant(
        self,
        *,
        value: float,
        digits: int,
    ) -> dict[str, Any]:
        """Round a finite number to N significant digits

        Skill: ``round_significant``; category: ``numbers``.

        Arguments:
            value (required, float): Number
            digits (required, int): Significant digits max=12 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: RoundSignificantArgs = {}  # type: ignore[typeddict-item]
        arguments['value'] = value
        arguments['digits'] = digits
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'round_significant', 'arguments': arguments},
        )

    def sample_mean_standard_error(
        self,
        *,
        stddev: float,
        sample_size: int,
    ) -> dict[str, Any]:
        """Estimate standard error for a sample average

        Skill: ``sample_mean_standard_error``; category: ``probability``.

        Arguments:
            stddev (required, float): Sample standard deviation min=0
            sample_size (required, int): Number of observations max=10000000 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SampleMeanStandardErrorArgs = {}  # type: ignore[typeddict-item]
        arguments['stddev'] = stddev
        arguments['sample_size'] = sample_size
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'sample_mean_standard_error', 'arguments': arguments},
        )

    def sample_proportion_interval(
        self,
        *,
        successes: int,
        trials: int,
        z: float | None = None,
    ) -> dict[str, Any]:
        """Wilson interval for a sample percentage

        Skill: ``sample_proportion_interval``; category: ``probability``.

        Arguments:
            successes (required, int): Number of successes max=1000000 min=0
            trials (required, int): Total trials max=1000000 min=1
            z (optional, float): Critical z value max=6 min=0.1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SampleProportionIntervalArgs = {}  # type: ignore[typeddict-item]
        arguments['successes'] = successes
        arguments['trials'] = trials
        if z is not None:
            arguments['z'] = z
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'sample_proportion_interval', 'arguments': arguments},
        )

    def sentence_split(
        self,
        *,
        text: str,
    ) -> dict[str, Any]:
        """Split a passage into sentences with their order preserved

        Skill: ``sentence_split``; category: ``strings``.

        Arguments:
            text (required, str): Passage max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SentenceSplitArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'sentence_split', 'arguments': arguments},
        )

    def series_anomaly_iqr(
        self,
        *,
        values: list[Any],
        multiplier: float | None = None,
    ) -> dict[str, Any]:
        """Flag values outside the interquartile fence

        Skill: ``series_anomaly_iqr``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Observed values
            multiplier (optional, float): IQR multiplier max=10 min=0.5

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesAnomalyIqrArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        if multiplier is not None:
            arguments['multiplier'] = multiplier
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_anomaly_iqr', 'arguments': arguments},
        )

    def series_anomaly_zscore(
        self,
        *,
        values: list[Any],
        threshold: float | None = None,
    ) -> dict[str, Any]:
        """Flag values exceeding a standard z-score threshold

        Skill: ``series_anomaly_zscore``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Observed values
            threshold (optional, float): Absolute z threshold max=10 min=0.5

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesAnomalyZscoreArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        if threshold is not None:
            arguments['threshold'] = threshold
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_anomaly_zscore', 'arguments': arguments},
        )

    def series_autocorrelation(
        self,
        *,
        values: list[Any],
        lag: int,
    ) -> dict[str, Any]:
        """Lagged autocorrelation of a time series

        Skill: ``series_autocorrelation``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Observations
            lag (required, int): Positive lag max=499 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesAutocorrelationArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        arguments['lag'] = lag
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_autocorrelation', 'arguments': arguments},
        )

    def series_centered_smoothing(
        self,
        *,
        values: list[Any],
        window: int | None = None,
    ) -> dict[str, Any]:
        """Centered mean smoothing for an odd-width window

        Skill: ``series_centered_smoothing``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Values
            window (optional, int): Odd window max=99 min=3

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesCenteredSmoothingArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        if window is not None:
            arguments['window'] = window
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_centered_smoothing', 'arguments': arguments},
        )

    def series_cross_correlation(
        self,
        *,
        first: list[Any],
        second: list[Any],
    ) -> dict[str, Any]:
        """Pearson correlation of two aligned series

        Skill: ``series_cross_correlation``; category: ``time_series``.

        Arguments:
            first (required, list[Any]): First series
            second (required, list[Any]): Second series

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesCrossCorrelationArgs = {}  # type: ignore[typeddict-item]
        arguments['first'] = first
        arguments['second'] = second
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_cross_correlation', 'arguments': arguments},
        )

    def series_cumulative_product(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Running product across observations

        Skill: ``series_cumulative_product``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Numbers

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesCumulativeProductArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_cumulative_product', 'arguments': arguments},
        )

    def series_cumulative_sum(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Running total across observations

        Skill: ``series_cumulative_sum``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Numbers

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesCumulativeSumArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_cumulative_sum', 'arguments': arguments},
        )

    def series_detrend(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Subtract the least-squares linear trend from a series

        Skill: ``series_detrend``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Observed series

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesDetrendArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_detrend', 'arguments': arguments},
        )

    def series_differences(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Compute successive first differences

        Skill: ``series_differences``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Time-ordered numbers

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesDifferencesArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_differences', 'arguments': arguments},
        )

    def series_drawdown(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Compute drop relative to running maximum, in percent

        Skill: ``series_drawdown``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Positive observed values

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesDrawdownArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_drawdown', 'arguments': arguments},
        )

    def series_exponential_average(
        self,
        *,
        values: list[Any],
        span: int,
    ) -> dict[str, Any]:
        """Exponentially weighted moving average (EMA)

        Skill: ``series_exponential_average``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Observations
            span (required, int): Smoothing span max=500 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesExponentialAverageArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        arguments['span'] = span
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_exponential_average', 'arguments': arguments},
        )

    def series_forecast_average(
        self,
        *,
        values: list[Any],
        steps: int | None = None,
    ) -> dict[str, Any]:
        """Constant-mean baseline forecast

        Skill: ``series_forecast_average``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Historical data
            steps (optional, int): Steps ahead max=30 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesForecastAverageArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        if steps is not None:
            arguments['steps'] = steps
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_forecast_average', 'arguments': arguments},
        )

    def series_forecast_last(
        self,
        *,
        values: list[Any],
        steps: int | None = None,
    ) -> dict[str, Any]:
        """Last-observation-carried-forward baseline forecast

        Skill: ``series_forecast_last``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Historical data
            steps (optional, int): Future steps max=30 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesForecastLastArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        if steps is not None:
            arguments['steps'] = steps
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_forecast_last', 'arguments': arguments},
        )

    def series_forecast_linear(
        self,
        *,
        values: list[Any],
        steps: int | None = None,
    ) -> dict[str, Any]:
        """Extrapolate a fitted linear trend with explicit caveat

        Skill: ``series_forecast_linear``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Historical values
            steps (optional, int): Number of forecast steps max=30 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesForecastLinearArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        if steps is not None:
            arguments['steps'] = steps
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_forecast_linear', 'arguments': arguments},
        )

    def series_lag_table(
        self,
        *,
        values: list[Any],
        max_lag: int | None = None,
    ) -> dict[str, Any]:
        """Autocorrelation values for a range of lags

        Skill: ``series_lag_table``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Observations
            max_lag (optional, int): Maximum lag max=100 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesLagTableArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        if max_lag is not None:
            arguments['max_lag'] = max_lag
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_lag_table', 'arguments': arguments},
        )

    def series_largest_changes(
        self,
        *,
        values: list[Any],
        limit: int | None = None,
    ) -> dict[str, Any]:
        """List the largest absolute changes between neighboring values

        Skill: ``series_largest_changes``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Values
            limit (optional, int): Maximum changes max=30 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesLargestChangesArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        if limit is not None:
            arguments['limit'] = limit
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_largest_changes', 'arguments': arguments},
        )

    def series_linear_trend(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Fit a least-squares time trend across equal intervals

        Skill: ``series_linear_trend``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Observed series

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesLinearTrendArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_linear_trend', 'arguments': arguments},
        )

    def series_momentum(
        self,
        *,
        values: list[Any],
        period: int,
    ) -> dict[str, Any]:
        """Subtract observation from k steps earlier

        Skill: ``series_momentum``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Series
            period (required, int): Number of periods back max=499 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesMomentumArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        arguments['period'] = period
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_momentum', 'arguments': arguments},
        )

    def series_moving_average(
        self,
        *,
        values: list[Any],
        window: int,
    ) -> dict[str, Any]:
        """Trailing simple moving average over a fixed window

        Skill: ``series_moving_average``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Observations
            window (required, int): Window length max=500 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesMovingAverageArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        arguments['window'] = window
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_moving_average', 'arguments': arguments},
        )

    def series_normalize_minmax(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Scale finite observations to a 0..1 range

        Skill: ``series_normalize_minmax``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Observations

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesNormalizeMinmaxArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_normalize_minmax', 'arguments': arguments},
        )

    def series_peak_trough(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Return indices and values of min and max observations

        Skill: ``series_peak_trough``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Observations

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesPeakTroughArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_peak_trough', 'arguments': arguments},
        )

    def series_percent_change(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Percentage growth from each observation to the next

        Skill: ``series_percent_change``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Time-ordered numbers

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesPercentChangeArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_percent_change', 'arguments': arguments},
        )

    def series_rebase(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Rebase a series to an index value of 100

        Skill: ``series_rebase``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Observations

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesRebaseArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_rebase', 'arguments': arguments},
        )

    def series_resample_chunks(
        self,
        *,
        values: list[Any],
        size: int,
        method: bool | None = None,
    ) -> dict[str, Any]:
        """Aggregate adjacent values into non-overlapping chunks

        Skill: ``series_resample_chunks``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Series
            size (required, int): Observations per chunk max=500 min=1
            method (optional, bool): Use sum instead of mean

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesResampleChunksArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        arguments['size'] = size
        if method is not None:
            arguments['method'] = method
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_resample_chunks', 'arguments': arguments},
        )

    def series_rolling_maximum(
        self,
        *,
        values: list[Any],
        window: int,
    ) -> dict[str, Any]:
        """Maximum over each trailing observation window

        Skill: ``series_rolling_maximum``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Observations
            window (required, int): Window size max=500 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesRollingMaximumArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        arguments['window'] = window
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_rolling_maximum', 'arguments': arguments},
        )

    def series_rolling_minimum(
        self,
        *,
        values: list[Any],
        window: int,
    ) -> dict[str, Any]:
        """Minimum over each trailing observation window

        Skill: ``series_rolling_minimum``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Observations
            window (required, int): Window size max=500 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesRollingMinimumArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        arguments['window'] = window
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_rolling_minimum', 'arguments': arguments},
        )

    def series_rolling_stddev(
        self,
        *,
        values: list[Any],
        window: int,
    ) -> dict[str, Any]:
        """Sample standard deviation in each rolling window

        Skill: ``series_rolling_stddev``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Observations
            window (required, int): Window size max=500 min=2

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesRollingStddevArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        arguments['window'] = window
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_rolling_stddev', 'arguments': arguments},
        )

    def series_run_lengths(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Compute consecutive runs of equal categorical values

        Skill: ``series_run_lengths``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Categorical sequence

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesRunLengthsArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_run_lengths', 'arguments': arguments},
        )

    def series_standardize(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Transform observations into z-score units

        Skill: ``series_standardize``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Observations

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesStandardizeArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_standardize', 'arguments': arguments},
        )

    def series_zero_crossings(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Count crossings between negative and positive values

        Skill: ``series_zero_crossings``; category: ``time_series``.

        Arguments:
            values (required, list[Any]): Values

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SeriesZeroCrossingsArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'series_zero_crossings', 'arguments': arguments},
        )

    def shannon_entropy(
        self,
        *,
        probabilities: list[Any],
    ) -> dict[str, Any]:
        """Compute Shannon information entropy in bits

        Skill: ``shannon_entropy``; category: ``probability``.

        Arguments:
            probabilities (required, list[Any]): Probabilities

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: ShannonEntropyArgs = {}  # type: ignore[typeddict-item]
        arguments['probabilities'] = probabilities
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'shannon_entropy', 'arguments': arguments},
        )

    def simple_interest(
        self,
        *,
        principal: float,
        annual_percent: float,
        years: float,
    ) -> dict[str, Any]:
        """Calculate non-compound interest, not investment advice

        Skill: ``simple_interest``; category: ``numbers``.

        Arguments:
            principal (required, float): Initial principal min=0
            annual_percent (required, float): Annual interest percentage
            years (required, float): Number of years min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SimpleInterestArgs = {}  # type: ignore[typeddict-item]
        arguments['principal'] = principal
        arguments['annual_percent'] = annual_percent
        arguments['years'] = years
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'simple_interest', 'arguments': arguments},
        )

    def simulate_discrete(
        self,
        *,
        values: list[Any],
        weights: list[Any],
        count: int | None = None,
        seed: int | None = None,
    ) -> dict[str, Any]:
        """Reproducible weighted random sampling for education

        Skill: ``simulate_discrete``; category: ``probability``.

        Arguments:
            values (required, list[Any]): Possible outcomes
            weights (required, list[Any]): Nonnegative weights
            count (optional, int): Number of draws max=1000 min=1
            seed (optional, int): Random seed max=100000 min=-100000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SimulateDiscreteArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        arguments['weights'] = weights
        if count is not None:
            arguments['count'] = count
        if seed is not None:
            arguments['seed'] = seed
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'simulate_discrete', 'arguments': arguments},
        )

    def slugify(
        self,
        *,
        text: str,
    ) -> dict[str, Any]:
        """Create a URL-friendly ASCII slug from a title

        Skill: ``slugify``; category: ``strings``.

        Arguments:
            text (required, str): Title or phrase max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SlugifyArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'slugify', 'arguments': arguments},
        )

    def sort_lines(
        self,
        *,
        text: str,
        reverse: bool | None = None,
        casefold: bool | None = None,
    ) -> dict[str, Any]:
        """Sort a list of lines alphabetically

        Skill: ``sort_lines``; category: ``strings``.

        Arguments:
            text (required, str): Multiline text max_length=5000
            reverse (optional, bool): Descending order
            casefold (optional, bool): Case insensitive

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SortLinesArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        if reverse is not None:
            arguments['reverse'] = reverse
        if casefold is not None:
            arguments['casefold'] = casefold
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'sort_lines', 'arguments': arguments},
        )

    def source_bracket_balance(
        self,
        *,
        source: str,
    ) -> dict[str, Any]:
        """Check raw bracket balances for plain text, not a parser

        Skill: ``source_bracket_balance``; category: ``software``.

        Arguments:
            source (required, str): Text max_length=12000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SourceBracketBalanceArgs = {}  # type: ignore[typeddict-item]
        arguments['source'] = source
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'source_bracket_balance', 'arguments': arguments},
        )

    def source_diff(
        self,
        *,
        before: str,
        after: str,
        context: int | None = None,
    ) -> dict[str, Any]:
        """Generate a bounded unified diff for two text versions

        Skill: ``source_diff``; category: ``software``.

        Arguments:
            before (required, str): Earlier text max_length=10000
            after (required, str): New text max_length=10000
            context (optional, int): Context lines max=10 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SourceDiffArgs = {}  # type: ignore[typeddict-item]
        arguments['before'] = before
        arguments['after'] = after
        if context is not None:
            arguments['context'] = context
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'source_diff', 'arguments': arguments},
        )

    def source_extract_urls(
        self,
        *,
        source: str,
    ) -> dict[str, Any]:
        """Find links appearing in an arbitrary text input

        Skill: ``source_extract_urls``; category: ``software``.

        Arguments:
            source (required, str): Text to inspect max_length=12000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SourceExtractUrlsArgs = {}  # type: ignore[typeddict-item]
        arguments['source'] = source
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'source_extract_urls', 'arguments': arguments},
        )

    def source_find_repeated_lines(
        self,
        *,
        source: str,
        minimum: int | None = None,
    ) -> dict[str, Any]:
        """Count repeated nonempty lines of pasted source

        Skill: ``source_find_repeated_lines``; category: ``software``.

        Arguments:
            source (required, str): Source max_length=12000
            minimum (optional, int): Minimum repetitions max=20 min=2

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SourceFindRepeatedLinesArgs = {}  # type: ignore[typeddict-item]
        arguments['source'] = source
        if minimum is not None:
            arguments['minimum'] = minimum
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'source_find_repeated_lines', 'arguments': arguments},
        )

    def source_indent_profile(
        self,
        *,
        source: str,
    ) -> dict[str, Any]:
        """Summarize indentation widths in source text

        Skill: ``source_indent_profile``; category: ``software``.

        Arguments:
            source (required, str): Source text max_length=12000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SourceIndentProfileArgs = {}  # type: ignore[typeddict-item]
        arguments['source'] = source
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'source_indent_profile', 'arguments': arguments},
        )

    def source_lines(
        self,
        *,
        source: str,
    ) -> dict[str, Any]:
        """Count blank and nonblank source lines

        Skill: ``source_lines``; category: ``software``.

        Arguments:
            source (required, str): Source max_length=12000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SourceLinesArgs = {}  # type: ignore[typeddict-item]
        arguments['source'] = source
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'source_lines', 'arguments': arguments},
        )

    def source_trailing_space_lines(
        self,
        *,
        source: str,
    ) -> dict[str, Any]:
        """Report source lines with trailing whitespace

        Skill: ``source_trailing_space_lines``; category: ``software``.

        Arguments:
            source (required, str): Source text max_length=12000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SourceTrailingSpaceLinesArgs = {}  # type: ignore[typeddict-item]
        arguments['source'] = source
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'source_trailing_space_lines', 'arguments': arguments},
        )

    def spearman_correlation(
        self,
        *,
        first: list[Any],
        second: list[Any],
    ) -> dict[str, Any]:
        """Compute Spearman rank correlation with tie averaging

        Skill: ``spearman_correlation``; category: ``statistics``.

        Arguments:
            first (required, list[Any]): First numeric series
            second (required, list[Any]): Second numeric series

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SpearmanCorrelationArgs = {}  # type: ignore[typeddict-item]
        arguments['first'] = first
        arguments['second'] = second
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'spearman_correlation', 'arguments': arguments},
        )

    def speed_from_distance(
        self,
        *,
        kilometers: float,
        hours: float,
    ) -> dict[str, Any]:
        """Calculate average speed from time and distance

        Skill: ``speed_from_distance``; category: ``measure``.

        Arguments:
            kilometers (required, float): Distance in km min=0
            hours (required, float): Elapsed hours min=1e-06

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SpeedFromDistanceArgs = {}  # type: ignore[typeddict-item]
        arguments['kilometers'] = kilometers
        arguments['hours'] = hours
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'speed_from_distance', 'arguments': arguments},
        )

    def sphere_volume(
        self,
        *,
        radius: float,
    ) -> dict[str, Any]:
        """Compute sphere volume and surface area

        Skill: ``sphere_volume``; category: ``measure``.

        Arguments:
            radius (required, float): Sphere radius min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: SphereVolumeArgs = {}  # type: ignore[typeddict-item]
        arguments['radius'] = radius
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'sphere_volume', 'arguments': arguments},
        )

    def standard_error(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Compute standard error of sample mean

        Skill: ``standard_error``; category: ``statistics``.

        Arguments:
            values (required, list[Any]): Numeric samples

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: StandardErrorArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'standard_error', 'arguments': arguments},
        )

    def start_end_of_month(
        self,
        *,
        date: str,
    ) -> dict[str, Any]:
        """Get first and last day of a month

        Skill: ``start_end_of_month``; category: ``dates``.

        Arguments:
            date (required, str): A date within the month max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: StartEndOfMonthArgs = {}  # type: ignore[typeddict-item]
        arguments['date'] = date
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'start_end_of_month', 'arguments': arguments},
        )

    def table_add_constant(
        self,
        *,
        rows: list[Any],
        column: str,
        value: str,
    ) -> dict[str, Any]:
        """Add a fixed text field to every record

        Skill: ``table_add_constant``; category: ``data``.

        Arguments:
            rows (required, list[Any]): Rows
            column (required, str): New field name max_length=5000
            value (required, str): Assigned value max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TableAddConstantArgs = {}  # type: ignore[typeddict-item]
        arguments['rows'] = rows
        arguments['column'] = column
        arguments['value'] = value
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'table_add_constant', 'arguments': arguments},
        )

    def table_column_average(
        self,
        *,
        rows: list[Any],
        column: str,
    ) -> dict[str, Any]:
        """Average a numeric column, ignoring empty values

        Skill: ``table_column_average``; category: ``data``.

        Arguments:
            rows (required, list[Any]): Rows
            column (required, str): Field max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TableColumnAverageArgs = {}  # type: ignore[typeddict-item]
        arguments['rows'] = rows
        arguments['column'] = column
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'table_column_average', 'arguments': arguments},
        )

    def table_column_statistics(
        self,
        *,
        rows: list[Any],
        column: str,
    ) -> dict[str, Any]:
        """Numeric count, sum, mean, median and range

        Skill: ``table_column_statistics``; category: ``data``.

        Arguments:
            rows (required, list[Any]): Rows
            column (required, str): Field max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TableColumnStatisticsArgs = {}  # type: ignore[typeddict-item]
        arguments['rows'] = rows
        arguments['column'] = column
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'table_column_statistics', 'arguments': arguments},
        )

    def table_column_sum(
        self,
        *,
        rows: list[Any],
        column: str,
    ) -> dict[str, Any]:
        """Add a numeric column, ignoring empty values

        Skill: ``table_column_sum``; category: ``data``.

        Arguments:
            rows (required, list[Any]): Rows
            column (required, str): Field max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TableColumnSumArgs = {}  # type: ignore[typeddict-item]
        arguments['rows'] = rows
        arguments['column'] = column
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'table_column_sum', 'arguments': arguments},
        )

    def table_columns(
        self,
        *,
        rows: list[Any],
    ) -> dict[str, Any]:
        """List all columns present in a JSON table

        Skill: ``table_columns``; category: ``data``.

        Arguments:
            rows (required, list[Any]): Table of row objects

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TableColumnsArgs = {}  # type: ignore[typeddict-item]
        arguments['rows'] = rows
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'table_columns', 'arguments': arguments},
        )

    def table_cross_tab(
        self,
        *,
        rows: list[Any],
        columns: list[Any],
    ) -> dict[str, Any]:
        """Produce frequency counts for combinations of columns

        Skill: ``table_cross_tab``; category: ``data``.

        Arguments:
            rows (required, list[Any]): Rows
            columns (required, list[Any]): Fields to group

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TableCrossTabArgs = {}  # type: ignore[typeddict-item]
        arguments['rows'] = rows
        arguments['columns'] = columns
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'table_cross_tab', 'arguments': arguments},
        )

    def table_date_bucket(
        self,
        *,
        rows: list[Any],
        date_column: str,
    ) -> dict[str, Any]:
        """Group ISO date strings by month

        Skill: ``table_date_bucket``; category: ``data``.

        Arguments:
            rows (required, list[Any]): Rows
            date_column (required, str): ISO date field max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TableDateBucketArgs = {}  # type: ignore[typeddict-item]
        arguments['rows'] = rows
        arguments['date_column'] = date_column
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'table_date_bucket', 'arguments': arguments},
        )

    def table_distinct(
        self,
        *,
        rows: list[Any],
    ) -> dict[str, Any]:
        """Remove duplicate complete JSON rows

        Skill: ``table_distinct``; category: ``data``.

        Arguments:
            rows (required, list[Any]): Rows

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TableDistinctArgs = {}  # type: ignore[typeddict-item]
        arguments['rows'] = rows
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'table_distinct', 'arguments': arguments},
        )

    def table_drop_empty(
        self,
        *,
        rows: list[Any],
        columns: list[Any],
    ) -> dict[str, Any]:
        """Remove rows whose specified fields are all empty

        Skill: ``table_drop_empty``; category: ``data``.

        Arguments:
            rows (required, list[Any]): Rows
            columns (required, list[Any]): Field names

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TableDropEmptyArgs = {}  # type: ignore[typeddict-item]
        arguments['rows'] = rows
        arguments['columns'] = columns
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'table_drop_empty', 'arguments': arguments},
        )

    def table_fill_missing(
        self,
        *,
        rows: list[Any],
        column: str,
        value: str,
    ) -> dict[str, Any]:
        """Replace absent or null fields with a chosen value

        Skill: ``table_fill_missing``; category: ``data``.

        Arguments:
            rows (required, list[Any]): Rows
            column (required, str): Field max_length=5000
            value (required, str): Replacement text max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TableFillMissingArgs = {}  # type: ignore[typeddict-item]
        arguments['rows'] = rows
        arguments['column'] = column
        arguments['value'] = value
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'table_fill_missing', 'arguments': arguments},
        )

    def table_filter_equal(
        self,
        *,
        rows: list[Any],
        column: str,
        value: str,
        case_sensitive: bool | None = None,
    ) -> dict[str, Any]:
        """Filter rows by exact value for a named column

        Skill: ``table_filter_equal``; category: ``data``.

        Arguments:
            rows (required, list[Any]): Rows
            column (required, str): Field name max_length=5000
            value (required, str): Desired text value max_length=5000
            case_sensitive (optional, bool): Exact case match

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TableFilterEqualArgs = {}  # type: ignore[typeddict-item]
        arguments['rows'] = rows
        arguments['column'] = column
        arguments['value'] = value
        if case_sensitive is not None:
            arguments['case_sensitive'] = case_sensitive
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'table_filter_equal', 'arguments': arguments},
        )

    def table_filter_numeric(
        self,
        *,
        rows: list[Any],
        column: str,
        comparison: str,
        value: float,
    ) -> dict[str, Any]:
        """Filter rows based on a number comparison

        Skill: ``table_filter_numeric``; category: ``data``.

        Arguments:
            rows (required, list[Any]): Rows
            column (required, str): Field name max_length=5000
            comparison (required, str): Comparison max_length=5000
            value (required, float): Numeric threshold

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TableFilterNumericArgs = {}  # type: ignore[typeddict-item]
        arguments['rows'] = rows
        arguments['column'] = column
        arguments['comparison'] = comparison
        arguments['value'] = value
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'table_filter_numeric', 'arguments': arguments},
        )

    def table_group_count(
        self,
        *,
        rows: list[Any],
        column: str,
    ) -> dict[str, Any]:
        """Count records grouped by a categorical field

        Skill: ``table_group_count``; category: ``data``.

        Arguments:
            rows (required, list[Any]): Rows
            column (required, str): Category field max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TableGroupCountArgs = {}  # type: ignore[typeddict-item]
        arguments['rows'] = rows
        arguments['column'] = column
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'table_group_count', 'arguments': arguments},
        )

    def table_group_sum(
        self,
        *,
        rows: list[Any],
        group_by: str,
        value_column: str,
    ) -> dict[str, Any]:
        """Sum a numeric column grouped by a category

        Skill: ``table_group_sum``; category: ``data``.

        Arguments:
            rows (required, list[Any]): Rows
            group_by (required, str): Category field max_length=5000
            value_column (required, str): Numeric field max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TableGroupSumArgs = {}  # type: ignore[typeddict-item]
        arguments['rows'] = rows
        arguments['group_by'] = group_by
        arguments['value_column'] = value_column
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'table_group_sum', 'arguments': arguments},
        )

    def table_join(
        self,
        *,
        left: list[Any],
        right: list[Any],
        key: str,
    ) -> dict[str, Any]:
        """Join two small tables on an exact string key

        Skill: ``table_join``; category: ``data``.

        Arguments:
            left (required, list[Any]): Left table
            right (required, list[Any]): Right table
            key (required, str): Common join field max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TableJoinArgs = {}  # type: ignore[typeddict-item]
        arguments['left'] = left
        arguments['right'] = right
        arguments['key'] = key
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'table_join', 'arguments': arguments},
        )

    def table_pivot_counts(
        self,
        *,
        rows: list[Any],
        row_field: str,
        column_field: str,
    ) -> dict[str, Any]:
        """Count combinations of two categorical fields

        Skill: ``table_pivot_counts``; category: ``data``.

        Arguments:
            rows (required, list[Any]): Rows
            row_field (required, str): Rows max_length=5000
            column_field (required, str): Columns max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TablePivotCountsArgs = {}  # type: ignore[typeddict-item]
        arguments['rows'] = rows
        arguments['row_field'] = row_field
        arguments['column_field'] = column_field
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'table_pivot_counts', 'arguments': arguments},
        )

    def table_rename_column(
        self,
        *,
        rows: list[Any],
        before: str,
        after: str,
    ) -> dict[str, Any]:
        """Rename one field in every row without changing values

        Skill: ``table_rename_column``; category: ``data``.

        Arguments:
            rows (required, list[Any]): Rows
            before (required, str): Old name max_length=5000
            after (required, str): New name max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TableRenameColumnArgs = {}  # type: ignore[typeddict-item]
        arguments['rows'] = rows
        arguments['before'] = before
        arguments['after'] = after
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'table_rename_column', 'arguments': arguments},
        )

    def table_select(
        self,
        *,
        rows: list[Any],
        columns: list[Any],
    ) -> dict[str, Any]:
        """Select and reorder table columns

        Skill: ``table_select``; category: ``data``.

        Arguments:
            rows (required, list[Any]): Rows
            columns (required, list[Any]): Desired field names

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TableSelectArgs = {}  # type: ignore[typeddict-item]
        arguments['rows'] = rows
        arguments['columns'] = columns
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'table_select', 'arguments': arguments},
        )

    def table_sort(
        self,
        *,
        rows: list[Any],
        column: str,
        descending: bool | None = None,
    ) -> dict[str, Any]:
        """Sort a table on a column, sorting missing values last

        Skill: ``table_sort``; category: ``data``.

        Arguments:
            rows (required, list[Any]): Rows
            column (required, str): Sort column max_length=5000
            descending (optional, bool): Reverse sort order

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TableSortArgs = {}  # type: ignore[typeddict-item]
        arguments['rows'] = rows
        arguments['column'] = column
        if descending is not None:
            arguments['descending'] = descending
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'table_sort', 'arguments': arguments},
        )

    def table_take(
        self,
        *,
        rows: list[Any],
        start: int | None = None,
        count: int | None = None,
    ) -> dict[str, Any]:
        """Take a bounded slice of rows

        Skill: ``table_take``; category: ``data``.

        Arguments:
            rows (required, list[Any]): Rows
            start (optional, int): Start index max=500 min=0
            count (optional, int): Maximum returned rows max=200 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TableTakeArgs = {}  # type: ignore[typeddict-item]
        arguments['rows'] = rows
        if start is not None:
            arguments['start'] = start
        if count is not None:
            arguments['count'] = count
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'table_take', 'arguments': arguments},
        )

    def table_transpose(
        self,
        *,
        matrix: list[Any],
    ) -> dict[str, Any]:
        """Transpose a small matrix of lists

        Skill: ``table_transpose``; category: ``data``.

        Arguments:
            matrix (required, list[Any]): Rectangular matrix

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TableTransposeArgs = {}  # type: ignore[typeddict-item]
        arguments['matrix'] = matrix
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'table_transpose', 'arguments': arguments},
        )

    def table_unique(
        self,
        *,
        rows: list[Any],
        column: str,
    ) -> dict[str, Any]:
        """Find unique values in one table column

        Skill: ``table_unique``; category: ``data``.

        Arguments:
            rows (required, list[Any]): Rows
            column (required, str): Field max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TableUniqueArgs = {}  # type: ignore[typeddict-item]
        arguments['rows'] = rows
        arguments['column'] = column
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'table_unique', 'arguments': arguments},
        )

    def table_value_counts(
        self,
        *,
        rows: list[Any],
        column: str,
        limit: int | None = None,
    ) -> dict[str, Any]:
        """Count occurrences of each value in a column

        Skill: ``table_value_counts``; category: ``data``.

        Arguments:
            rows (required, list[Any]): Rows
            column (required, str): Field max_length=5000
            limit (optional, int): Results limit max=100 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TableValueCountsArgs = {}  # type: ignore[typeddict-item]
        arguments['rows'] = rows
        arguments['column'] = column
        if limit is not None:
            arguments['limit'] = limit
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'table_value_counts', 'arguments': arguments},
        )

    def tax_addition(
        self,
        *,
        subtotal: float,
        tax_percent: float,
    ) -> dict[str, Any]:
        """Add a percentage-based tax as a mathematical operation

        Skill: ``tax_addition``; category: ``numbers``.

        Arguments:
            subtotal (required, float): Subtotal min=0
            tax_percent (required, float): Tax rate max=100 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TaxAdditionArgs = {}  # type: ignore[typeddict-item]
        arguments['subtotal'] = subtotal
        arguments['tax_percent'] = tax_percent
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'tax_addition', 'arguments': arguments},
        )

    def text_diff(
        self,
        *,
        before: str,
        after: str,
    ) -> dict[str, Any]:
        """Create a unified line-by-line difference between text versions

        Skill: ``text_diff``; category: ``strings``.

        Arguments:
            before (required, str): Original max_length=5000
            after (required, str): Updated max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TextDiffArgs = {}  # type: ignore[typeddict-item]
        arguments['before'] = before
        arguments['after'] = after
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'text_diff', 'arguments': arguments},
        )

    def text_similarity(
        self,
        *,
        first: str,
        second: str,
    ) -> dict[str, Any]:
        """Compare two passages using lexical similarity and shared keywords

        Skill: ``text_similarity``; category: ``strings``.

        Arguments:
            first (required, str): First passage max_length=5000
            second (required, str): Second passage max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TextSimilarityArgs = {}  # type: ignore[typeddict-item]
        arguments['first'] = first
        arguments['second'] = second
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'text_similarity', 'arguments': arguments},
        )

    def text_stats(
        self,
        *,
        text: str,
    ) -> dict[str, Any]:
        """Profile word count sentences and document traits

        Skill: ``text_stats``; category: ``strings``.

        Arguments:
            text (required, str): Text to analyze max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TextStatsArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'text_stats', 'arguments': arguments},
        )

    def text_summary(
        self,
        *,
        text: str,
        sentences_count: int | None = None,
    ) -> dict[str, Any]:
        """Select source sentences as a short extractive summary

        Skill: ``text_summary``; category: ``strings``.

        Arguments:
            text (required, str): Passage max_length=5000
            sentences_count (optional, int): Number of sentences max=20 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TextSummaryArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        if sentences_count is not None:
            arguments['sentences_count'] = sentences_count
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'text_summary', 'arguments': arguments},
        )

    def text_wrap(
        self,
        *,
        text: str,
        width: int | None = None,
        preserve_whitespace: bool | None = None,
    ) -> dict[str, Any]:
        """Wrap plain text to a specified column width

        Skill: ``text_wrap``; category: ``strings``.

        Arguments:
            text (required, str): Plain text max_length=5000
            width (optional, int): Columns max=200 min=20
            preserve_whitespace (optional, bool): Preserve whitespace

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TextWrapArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        if width is not None:
            arguments['width'] = width
        if preserve_whitespace is not None:
            arguments['preserve_whitespace'] = preserve_whitespace
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'text_wrap', 'arguments': arguments},
        )

    def time_block_count(
        self,
        *,
        available_minutes: int,
        work_minutes: int,
        break_minutes: int | None = None,
    ) -> dict[str, Any]:
        """Count complete focus blocks fitting into available minutes

        Skill: ``time_block_count``; category: ``dates``.

        Arguments:
            available_minutes (required, int): Available time max=10080 min=0
            work_minutes (required, int): Work block length max=240 min=1
            break_minutes (optional, int): Rest block length max=120 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TimeBlockCountArgs = {}  # type: ignore[typeddict-item]
        arguments['available_minutes'] = available_minutes
        arguments['work_minutes'] = work_minutes
        if break_minutes is not None:
            arguments['break_minutes'] = break_minutes
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'time_block_count', 'arguments': arguments},
        )

    def time_slot_schedule(
        self,
        *,
        start: str,
        number: int,
        slot_minutes: int,
        break_minutes: int | None = None,
    ) -> dict[str, Any]:
        """Make fixed-duration study or work slots

        Skill: ``time_slot_schedule``; category: ``dates``.

        Arguments:
            start (required, str): ISO timestamp with timezone max_length=5000
            number (required, int): Slots max=24 min=1
            slot_minutes (required, int): Time per slot max=240 min=5
            break_minutes (optional, int): Break after each slot max=120 min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TimeSlotScheduleArgs = {}  # type: ignore[typeddict-item]
        arguments['start'] = start
        arguments['number'] = number
        arguments['slot_minutes'] = slot_minutes
        if break_minutes is not None:
            arguments['break_minutes'] = break_minutes
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'time_slot_schedule', 'arguments': arguments},
        )

    def timezone_convert(
        self,
        *,
        timestamp: str,
        destination: str,
    ) -> dict[str, Any]:
        """Convert an explicit timestamp between IANA timezones

        Skill: ``timezone_convert``; category: ``dates``.

        Arguments:
            timestamp (required, str): ISO datetime with UTC offset max_length=5000
            destination (required, str): IANA zone name, e.g. Asia/Kolkata max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TimezoneConvertArgs = {}  # type: ignore[typeddict-item]
        arguments['timestamp'] = timestamp
        arguments['destination'] = destination
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'timezone_convert', 'arguments': arguments},
        )

    def tip_calculator(
        self,
        *,
        bill: float,
        tip_percent: float,
        people: int | None = None,
    ) -> dict[str, Any]:
        """Calculate a total with a user-chosen gratuity

        Skill: ``tip_calculator``; category: ``numbers``.

        Arguments:
            bill (required, float): Bill amount min=0
            tip_percent (required, float): Tip percentage max=100 min=0
            people (optional, int): People sharing the bill max=10000 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TipCalculatorArgs = {}  # type: ignore[typeddict-item]
        arguments['bill'] = bill
        arguments['tip_percent'] = tip_percent
        if people is not None:
            arguments['people'] = people
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'tip_calculator', 'arguments': arguments},
        )

    def top_bigrams(
        self,
        *,
        text: str,
        limit: int | None = None,
    ) -> dict[str, Any]:
        """List common adjacent two-word phrases

        Skill: ``top_bigrams``; category: ``strings``.

        Arguments:
            text (required, str): Passage max_length=5000
            limit (optional, int): Phrase count max=30 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TopBigramsArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        if limit is not None:
            arguments['limit'] = limit
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'top_bigrams', 'arguments': arguments},
        )

    def top_keywords(
        self,
        *,
        text: str,
        limit: int | None = None,
    ) -> dict[str, Any]:
        """Extract common non-stopword terms from a passage

        Skill: ``top_keywords``; category: ``strings``.

        Arguments:
            text (required, str): Passage max_length=5000
            limit (optional, int): Keyword count max=50 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TopKeywordsArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        if limit is not None:
            arguments['limit'] = limit
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'top_keywords', 'arguments': arguments},
        )

    def triangle_area(
        self,
        *,
        base: float,
        height: float,
    ) -> dict[str, Any]:
        """Triangle area using base and height

        Skill: ``triangle_area``; category: ``numbers``.

        Arguments:
            base (required, float): Base min=0
            height (required, float): Height min=0

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: TriangleAreaArgs = {}  # type: ignore[typeddict-item]
        arguments['base'] = base
        arguments['height'] = height
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'triangle_area', 'arguments': arguments},
        )

    def uniform_probability(
        self,
        *,
        minimum: float,
        maximum: float,
        event_low: float,
        event_high: float,
    ) -> dict[str, Any]:
        """Probability of a subinterval in a uniform range

        Skill: ``uniform_probability``; category: ``probability``.

        Arguments:
            minimum (required, float): Minimum
            maximum (required, float): Maximum
            event_low (required, float): Event lower limit
            event_high (required, float): Event upper limit

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: UniformProbabilityArgs = {}  # type: ignore[typeddict-item]
        arguments['minimum'] = minimum
        arguments['maximum'] = maximum
        arguments['event_low'] = event_low
        arguments['event_high'] = event_high
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'uniform_probability', 'arguments': arguments},
        )

    def url_decode_component(
        self,
        *,
        text: str,
    ) -> dict[str, Any]:
        """Decode percent-encoded URL text

        Skill: ``url_decode_component``; category: ``strings``.

        Arguments:
            text (required, str): Encoded text max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: UrlDecodeComponentArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'url_decode_component', 'arguments': arguments},
        )

    def url_encode_component(
        self,
        *,
        text: str,
    ) -> dict[str, Any]:
        """Percent-encode one URL path component

        Skill: ``url_encode_component``; category: ``strings``.

        Arguments:
            text (required, str): Text max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: UrlEncodeComponentArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'url_encode_component', 'arguments': arguments},
        )

    def value_growth_rate(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Compute growth rates between consecutive measurements

        Skill: ``value_growth_rate``; category: ``statistics``.

        Arguments:
            values (required, list[Any]): Numeric series

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: ValueGrowthRateArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'value_growth_rate', 'arguments': arguments},
        )

    def variance(
        self,
        *,
        values: list[Any],
        sample: bool | None = None,
    ) -> dict[str, Any]:
        """Sample or population variance and standard deviation

        Skill: ``variance``; category: ``statistics``.

        Arguments:
            values (required, list[Any]): Numeric samples
            sample (optional, bool): Use sample n-1 denominator

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: VarianceArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        if sample is not None:
            arguments['sample'] = sample
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'variance', 'arguments': arguments},
        )

    def weekday(
        self,
        *,
        date: str,
    ) -> dict[str, Any]:
        """Read weekday name and ISO weekday number for a date

        Skill: ``weekday``; category: ``dates``.

        Arguments:
            date (required, str): YYYY-MM-DD max_length=5000

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: WeekdayArgs = {}  # type: ignore[typeddict-item]
        arguments['date'] = date
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'weekday', 'arguments': arguments},
        )

    def weighted_average(
        self,
        *,
        values: list[Any],
        weights: list[Any],
    ) -> dict[str, Any]:
        """Calculate weighted arithmetic mean

        Skill: ``weighted_average``; category: ``numbers``.

        Arguments:
            values (required, list[Any]): Numeric values
            weights (required, list[Any]): Nonnegative weights

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: WeightedAverageArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        arguments['weights'] = weights
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'weighted_average', 'arguments': arguments},
        )

    def word_frequency(
        self,
        *,
        text: str,
        limit: int | None = None,
    ) -> dict[str, Any]:
        """Count words within a passage

        Skill: ``word_frequency``; category: ``strings``.

        Arguments:
            text (required, str): Passage max_length=5000
            limit (optional, int): Maximum frequency rows max=300 min=1

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: WordFrequencyArgs = {}  # type: ignore[typeddict-item]
        arguments['text'] = text
        if limit is not None:
            arguments['limit'] = limit
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'word_frequency', 'arguments': arguments},
        )

    def z_scores(
        self,
        *,
        values: list[Any],
    ) -> dict[str, Any]:
        """Standardize samples using population deviation

        Skill: ``z_scores``; category: ``statistics``.

        Arguments:
            values (required, list[Any]): Numeric samples

        The server validates every argument against its tool schema.
        Results are wrapped in a JSON object with utility/category/result.
        """
        arguments: ZScoresArgs = {}  # type: ignore[typeddict-item]
        arguments['values'] = values
        return self._client._request(
            'POST',
            '/api/utilities/run',
            json={'name': 'z_scores', 'arguments': arguments},
        )

