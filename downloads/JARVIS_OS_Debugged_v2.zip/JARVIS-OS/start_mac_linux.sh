#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -c 'import sys; raise SystemExit("Python 3.11 or newer is required") if sys.version_info < (3, 11) else None'
if [ ! -x .venv/bin/python ]; then python3 -m venv .venv; fi
.venv/bin/python -c 'import sys; raise SystemExit("The existing .venv needs Python 3.11 or newer") if sys.version_info < (3, 11) else None'
.venv/bin/python -m pip install --disable-pip-version-check -e '.[ml]'
echo "Open http://127.0.0.1:8765 and use the private token printed below."
echo "For full local AI: start Ollama and run ollama pull qwen3:4b."
exec .venv/bin/python -m jarvis serve
