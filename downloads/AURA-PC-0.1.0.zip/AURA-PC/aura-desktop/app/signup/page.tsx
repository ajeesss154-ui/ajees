import { AuthForm } from "@/components/auth-form";
export default function Page() {
  return <AuthForm signup />;
}
